sap.ui.define([
	"WbsAdminReport/WBS_ADMINREPORTS/test/unit/controller/View1.controller"
], function () {
	"use strict";
});