sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("WbsAdminReport.WBS_ADMINREPORTS.controller.View1", {
		onInit: function () {

		},
		onOppDtlntfyReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "dealNfy"
					}
				});
		},
		onCycleTimeReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "cycleTime"
					}
				});
		},
		onAgingReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "wbsAging"
					}
				});
		},
		onEmpReport : function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "empReport"
					}
				});
		},
		onInactiveEmpReport : function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "inactEmpRep"
					}
				});
		}
	});
});