sap.ui.define([
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/BusyIndicator",
	"sap/m/Token",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/ODataModel",
	"AutoWBSClosure/model/formatter"
], function (MessageToast, MessageBox, Controller, Filter, FilterOperator, BusyIndicator, Token, JSONModel, ODataModel, formatter) {
	"use strict";

	return Controller.extend("AutoWBSClosure.controller.View1", {
		formatter: formatter,

		onInit: function () {
			// access OData model declared in manifest.json file
			//var oModel = this.getOwnerComponent().getModel("myModel");
			var oModel = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			//set the model on view to be used by the UI controls

			this.getView().setModel(oModel);

			// sap.ui.core.BusyIndicator.show(0);

			this.byId("idCheckDP").setMinDate(new Date(+new Date() + 86400000));
			// this.byId("idCheckDP").setMinDate(new Date());
			this.byId("C1Dateinp").setMinDate(new Date(+new Date() + 86400000));
			this.initiateCompass();
			//Start - Sam
			var CompassTableDataSet = new JSONModel({
				CompassTableDataSet: []
			});
			this.getOwnerComponent().setModel(CompassTableDataSet, "CompassTableModel");

			var C1TableDataSet = new JSONModel({
				C1TableDataSet: []
			});
			this.getOwnerComponent().setModel(C1TableDataSet, "C1TableModel");

			var C1TableDataSet = new JSONModel({
				C1TableDataSet: []
			});
			this.getOwnerComponent().setModel(C1TableDataSet, "C1TableModel");

			// End - Sam
			// debugger;
		},
		onValueHelpRequest: function (oEvent) {
			var proj = this.byId("inpProj").getValue();
			var sInputValue = oEvent.getSource().getValue(),
				// var sInputValue = proj,
				oView = this.getView();

			var oDialog = oView.byId("selectDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "AutoWBSClosure.fragments.WBSNumberCompass", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var term2 = this.jsonModel.getData().filter(function (a) {
				return a.Zpspid === proj;
			});
			// this.byId("selectDialog").setModel(this.jsonModel, "WBSModel");
			// oDialog.getBinding("items").filter([new Filter("Zposid", FilterOperator.Contains, sInputValue)]);
			var x = new JSONModel(term2);
			if (term2.length === 0) {

				this.byId("selectDialog").setModel(this.jsonModel, "WBSModel");
				oDialog.getBinding("items").filter([new Filter("Zposid", FilterOperator.Contains, sInputValue)]);
			} else {

				this.byId("selectDialog").setModel(x, "WBSModel");
				oDialog.getBinding("items").filter([new Filter("Zposid", FilterOperator.Contains, sInputValue)]);
			}
			// oDialog.getBinding("items").filter([
			// 					new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, sInputValue),
			// 					new sap.ui.model.Filter("pspid", sap.ui.model.FilterOperator.EQ, proj)
			// 				], true);

			// oDialog.getAggregation("items",{path:'ZCDS_AUTO_WBS_CLSSet',filters:oFilter});
			oDialog.open(proj);

		},
		onValueHelpSearchWBS: function (oEvent) {
			debugger;

			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Zposid", FilterOperator.Contains, sValue);
			// var oFilter = new Filter([
			// 					new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, sInputValue),
			// 					new sap.ui.model.Filter("pspid", sap.ui.model.FilterOperator.EQ, proj)
			// 				], true);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpRequestproj: function (oEvent) {

			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			var oDialog = oView.byId("selectDialogProj");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "AutoWBSClosure.fragments.Project", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			this.byId("selectDialogProj").setModel(this.projModel, "namedmodel");
			oDialog.getBinding("items").filter([new Filter("pspid", FilterOperator.Contains, sInputValue)]);

			// oDialog.getAggregation("items",{path:'ZCDS_AUTO_WBS_CLSSet',filters:oFilter});
			oDialog.open(sInputValue);

		},
		onValueHelpSearchproj: function (oEvent) {

			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("pspid", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpRequestCC: function (oEvent) {

			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			var oDialog = oView.byId("selectDialogCC");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "AutoWBSClosure.fragments.CompanyCode", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			this.byId("selectDialogCC").setModel(this.CCModel, "CCModel");
			oDialog.getBinding("items").filter([new Filter("Bukrs", FilterOperator.Contains, sInputValue)]);

			// oDialog.getAggregation("items",{path:'ZCDS_AUTO_WBS_CLSSet',filters:oFilter});
			oDialog.open(sInputValue);

		},
		onValueHelpSearchCC: function (oEvent) {

			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Bukrs", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpRequestFA: function (oEvent) {
			var proj = this.byId("inpProj").getValue();
			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			var oDialog = oView.byId("selectDialogFA");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "AutoWBSClosure.fragments.FinanceAnalyst", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();

			var term2 = this.jsonModel.getData().filter(function (a) {
				return a.Zpspid === proj;
			});
			var y = [],
				uniqueFA = [];
			if (term2.length !== 0) {
				for (var i = 0; i < term2.length; i++) {

					if (y.indexOf(term2[i].FinApp) === -1) {
						// that.CompassPspid.find(o => o.pspid === WBS)
						y.push(term2[i].FinApp);
						uniqueFA.push({
							"FinApp": term2[i].FinApp
						});
						// console.log(this.items);
					}
				}
			}
			var x = new JSONModel(uniqueFA);
			if (term2.length === 0) {

				this.byId("selectDialogFA").setModel(this.FAModel, "FAModel");
				oDialog.getBinding("items").filter([new Filter("FinApp", FilterOperator.Contains, sInputValue)]);

			} else {
				this.byId("selectDialogFA").setModel(x, "FAModel");
				oDialog.getBinding("items").filter([new Filter("FinApp", FilterOperator.Contains, sInputValue)]);
			}

			// oDialog.getAggregation("items",{path:'ZCDS_AUTO_WBS_CLSSet',filters:oFilter});
			oDialog.open(sInputValue);

		},
		onValueHelpSearchFA: function (oEvent) {

			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("FinApp", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpRequestPR: function (oEvent) {
			var proj = this.byId("inpProj").getValue();
			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			var oDialog = oView.byId("selectDialogPR");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "AutoWBSClosure.fragments.PersonResponsible", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var term2 = this.jsonModel.getData().filter(function (a) {
				return a.Zpspid === proj;
			});
			var y = [],
				uniquePR = [];
			if (term2.length !== 0) {
				for (var i = 0; i < term2.length; i++) {

					if (y.indexOf(term2[i].Wbsowner1) === -1) {
						// that.CompassPspid.find(o => o.pspid === WBS)
						y.push(term2[i].Wbsowner1);
						uniquePR.push({
							"Wbsowner1": term2[i].Wbsowner1
						});
						// console.log(this.items);
					}
				}
			}
			var x = new JSONModel(uniquePR);
			if (term2.length === 0) {

				this.byId("selectDialogPR").setModel(this.PRModel, "PRModel");
				oDialog.getBinding("items").filter([new Filter("Wbsowner1", FilterOperator.Contains, sInputValue)]);

			} else {
				this.byId("selectDialogPR").setModel(x, "PRModel");
				oDialog.getBinding("items").filter([new Filter("Wbsowner1", FilterOperator.Contains, sInputValue)]);
			}

			// oDialog.getAggregation("items",{path:'ZCDS_AUTO_WBS_CLSSet',filters:oFilter});
			oDialog.open(sInputValue);

		},
		onValueHelpSearchPR: function (oEvent) {

			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Wbsowner1", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		initiateCompassTable: function () {

			// this.finalFilters.push(new sap.ui.model.Filter("AutoClsd", sap.ui.model.FilterOperator.NE, "Y"));
			// var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			// var fC1WBS = this.getView().byId("inpCompWBS");
			// var bC1WBS = fC1WBS.getBinding("items");
			// bC1WBS.filter(this.finalFilters);

			// debugger;
			// var WBS = this.getView().byId("inpCompWBSTest");
			// var x = WBS.getSuggestionItems();
			// x.filter(this.finalFilters);

			// var Test = this.getView().byId("inpCompWBSTest");
			// var Test1 = Test.getBinding("suggestionItems");
			// Test1.filter(this.finalFilters);

			// var fCompProj = this.getView().byId("inpProj");
			// var bCompProj = fCompProj.getBinding("items");
			// bCompProj.filter(this.finalFilters);
			// debugger;
			// this.finalFilters.push(new sap.ui.model.Filter("FinCheck", sap.ui.model.FilterOperator.NE, "Y"));
			// this.finalFilters.push(new sap.ui.model.Filter("BalCheck", sap.ui.model.FilterOperator.NE, "Y"));
			// this.finalFilters.push(new sap.ui.model.Filter("PoCheck", sap.ui.model.FilterOperator.NE, "Y"));
			// this.finalFilters.push(new sap.ui.model.Filter("SoCheck", sap.ui.model.FilterOperator.NE, "Y"));
			// this.finalFilters.push(new sap.ui.model.Filter("FaCheck", sap.ui.model.FilterOperator.NE, "Y"));
			// this.finalFilters.push(new sap.ui.model.Filter("TimCheck", sap.ui.model.FilterOperator.NE, "Y"));

			// this.byId("vClosure").setProperty("selected", true);
			// BusyIndicator.show();
			// var that = this;

		},
		filter: function () {
			this.CompassPspid = [];
			this.CompassPspidunique = [];
			this.finalFilters.push(new sap.ui.model.Filter("AutoClsd", sap.ui.model.FilterOperator.NE, "Y"));
			// this.finalFilters.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS"));
			var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			var that = this;
			debugger;
			oDta.read("/ZCDS_AUTO_WBS_CLSSet", {
				filters: this.finalFilters,
				urlParameters: {
					"$top": 500
				},
				success: function (oData, oResponse) {

					that.jsonModel = new JSONModel(oData.results);
					// that.byId("inpCompWBS").setModel(that.jsonModel, "WBSModel");
					//that.byId("CompassTable").setVisibleRowCount(oData.results.length - oData.results.length);
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					// debugger;
					for (var i = 0; i < oData.results.length; i++) {

						if (that.CompassPspid.indexOf(oData.results[i].Zpspid) === -1) {
							// that.CompassPspid.find(o => o.pspid === WBS)
							that.CompassPspid.push(oData.results[i].Zpspid);
							that.CompassPspidunique.push({
								"pspid": oData.results[i].Zpspid
							});
							// console.log(this.items);
						}
					}
					that.projModel = new JSONModel(that.CompassPspidunique);
					// projModel.setData(projModel);
					that.byId("inpProj").setModel(that.projModel, "namedmodel");
					that.initiateCompassTable();
					BusyIndicator.hide();
					// that.tableModel = new JSONModel(oData.results);
					// that.getView().byId("CompassTable").setModel(that.tableModel);
					// that.getView().getModel("appView").setProperty("/oCount", oData.results.length);
				},
				error: function (err) {
					BusyIndicator.hide();
				}
			});
		},
		initiateCompass: function () {

			this.flagCompass = null;
			var that = this;
			this.finalFilters = [];
			this.finalFilters.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS"));
			var length = 0;
			//this.byId("CompassTable").setVisibleRowCount(length);
			var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			BusyIndicator.show();
			debugger;
			// oDta.read("/Fin_anaSet", {
			// 	filters: this.finalFilters,
			// 	success: function (oData, oResponse) {

			// 		// BusyIndicator.hide();
			// 		that.FAModel = new JSONModel(oData.results);
			// 		that.byId("inpCompFA").setModel(that.FAModel, "FAModel");
			// 		if (oData === null || oData === undefined) {
			// 			return;
			// 		}

			// 	},
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });
			// oDta.read("/Proj_idSet", {
			// 	filters: this.finalFilters,
			// 	success: function (oData, oResponse) {

			// 		// BusyIndicator.hide();
			// 		that.filterModel = new JSONModel(oData.results);
			// 		that.byId("inpProj").setModel(that.filterModel, "filterModel");
			// 		if (oData === null || oData === undefined) {
			// 			return;
			// 		}

			// 	},
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });
			oDta.read("/PER_RESSet", {
				filters: this.finalFilters,
				success: function (oData, oResponse) {
					// BusyIndicator.hide();
					// that.PRModel = new JSONModel(oData.results);
					// that.byId("inpCompPR").setModel(that.PRModel, "PRModel");
					if (oData.results.length === 1) {
						// 						normal user

						that.getView().byId("FBPRComp").setProperty("hiddenFilter", true);
						that.getView().byId("FBFAComp").setProperty("hiddenFilter", true);
						that.getView().byId("idProjComp").setProperty("hiddenFilter", true);
						that.getView().byId("idProjComp").setVisibleInFilterBar(false);
						that.getView().byId("FBPRComp").setVisibleInFilterBar(false);
						that.getView().byId("FBFAComp").setVisibleInFilterBar(false);
						that.flagCompass = oData.results[0].Wbsowner1;
						debugger;
						// that.getView().byId("inpProj").getProperty("required");

						// if (oData.results.length === 0) {
						// 	MessageBox.information("There is no WBS associated against your User ID.");
						// 	that.finalFilters.push(new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, "NoData"));
						// } else {

						// 	that.finalFilters.push(new sap.ui.model.Filter([
						// 		new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, that.flagCompass),
						// 		new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, that.flagCompass)
						// 	], false));

						// }
						// that.filter();
						// that.getView().byId("inpProj").setProperty("required", false);
						BusyIndicator.hide();
						// that.initiateCompassTable();
					} else {
						// 					admin user
						// that.filter();
						that.getView().byId("idProjCompNrml").setProperty("hiddenFilter", true);
						that.getView().byId("idProjCompNrml").setVisibleInFilterBar(false);
						// that.initiateCompassTable();
						BusyIndicator.hide();
					}
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}

				},
				error: function (err) {
					BusyIndicator.hide();

				}
			});

			// var fCompWBS = this.getView().byId("inpCompWBS");
			// var bCompWBS = fCompWBS.getBinding("items");
			// bCompWBS.filter([new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS")
			// ], false)]);
			// // debugger;	
			// var fCompPR = this.getView().byId("inpCompPR");
			// var bCompPR = fCompPR.getBinding("items");
			// bCompPR.filter([new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS")
			// ], false)]);

			// var fCompFA = this.getView().byId("inpCompFA");
			// var bCompFA = fCompFA.getBinding("items");
			// bCompFA.filter([new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS")
			// ], false)]);

			// sap.ui.core.BusyIndicator.hide();
		},
		initiateC1Table: function () {

			var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			// BusyIndicator.show();
			var that = this;

			oDta.read("/ZCDS_AUTO_WBS_CLSSet", {
				filters: this.finalFiltersC1,
				success: function (oData, oResponse) {

					BusyIndicator.hide();
					that.jsonModel = new JSONModel(oData.results);
					that.byId("inpC1WBS").setModel(that.jsonModel, "WBSModel");
					// that.byId("selectDialog").setModel(jsonModel, "WBSModel");
					//that.byId("C1Table").setVisibleRowCount(oData.results.length - oData.results.length);
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					// debugger;
					// for (var i = 0; i < oData.results.length; i++) {

					// 	if (that.CompassPspid.indexOf(oData.results[i].Zpspid) === -1) {
					// 		// that.CompassPspid.find(o => o.pspid === WBS)
					// 		that.CompassPspid.push(oData.results[i].Zpspid);
					// 		that.CompassPspidunique.push({
					// 			"pspid": oData.results[i].Zpspid
					// 		});
					// 		// console.log(this.items);
					// 	}
					// }
					// that.projModel = new JSONModel(that.CompassPspidunique);

					// that.byId("inpProj").setModel(that.projModel, "namedmodel");
					// that.initiateCompassTable();
				},
				error: function (err) {
					BusyIndicator.hide();
				}
			});

			// oDta.read("/Fin_anaSet", {
			// 	filters: this.finalFiltersC1,
			// 	success: function (oData, oResponse) {

			// 		BusyIndicator.hide();
			// 		that.FAModel = new JSONModel(oData.results);
			// 		that.byId("inpC1FA").setModel(that.FAModel, "FAModel");
			// 		if (oData === null || oData === undefined) {
			// 			return;
			// 		}

			// 	},
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });
			var length = 0;
			//this.byId("C1Table").setVisibleRowCount(length);
			// var fC1WBS = this.getView().byId("inpC1WBS");
			// var bC1WBS = fC1WBS.getBinding("items");
			// bC1WBS.filter(this.finalFiltersC1);

		},
		initiateC1: function () {
			// 	var oList = this.getView().byId("C1Table");
			// 	var oBinding = oList.getBinding("rows");
			// 	// oBinding.filter(filters);
			// 	// debugger;
			// 	 oBinding.filter( [ new sap.ui.model.Filter([
			//       new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "C1" )
			//   ],false)
			// ]);
			this.flag = null;
			this.finalFiltersC1 = [];
			this.finalFiltersC1.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1"));

			var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			BusyIndicator.show();
			var that = this;
			// oDta.read("/cocodeSet", {
			// 	filters: this.finalFiltersC1,
			// 	success: function (oData, oResponse) {

			// 		BusyIndicator.hide();
			// 		that.CCModel = new JSONModel(oData.results);
			// 		that.byId("inpC1CoCode").setModel(that.CCModel, "CCModel");
			// 		if (oData === null || oData === undefined) {
			// 			return;
			// 		}

			// 	},
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });
			// oDta.read("/Fin_anaSet", {
			// 	filters: this.finalFiltersC1,
			// 	success: function (oData, oResponse) {

			// 		BusyIndicator.hide();
			// 		that.FAModel = new JSONModel(oData.results);
			// 		that.byId("inpC1FA").setModel(that.FAModel, "FAModel");
			// 		if (oData === null || oData === undefined) {
			// 			return;
			// 		}

			// 	},
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });

			oDta.read("/PER_RESSet", {
				filters: this.finalFiltersC1,
				success: function (oData, oResponse) {
					BusyIndicator.hide();
					that.PRModel = new JSONModel(oData.results);
					that.byId("inpCompPR").setModel(that.PRModel, "PRModel");
					if (oData.results.length === 1) {
						// 						normal user
						// debugger;
						that.getView().byId("FBPRC1").setProperty("hiddenFilter", true);
						that.getView().byId("FBFAC1").setProperty("hiddenFilter", true);
						that.getView().byId("FBPRC1").setVisibleInFilterBar(false);
						that.getView().byId("FBFAC1").setVisibleInFilterBar(false);
						that.flag = oData.results[0].Wbsowner1;
						debugger;
						// if (oData.results.length === 0) {
						// 	MessageBox.information("There is no WBS associated against your User ID.");
						// 	that.finalFiltersC1.push(new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, "NoData"));
						// } else {

						// 	that.finalFiltersC1.push(new sap.ui.model.Filter([
						// 		new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, that.flag),
						// 		new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, that.flag)
						// 	], false));
						// }
						// that.initiateC1Table();
					} else {
						// 					admin user
						// that.initiateC1Table();
					}
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}

				},
				error: function (err) {
					BusyIndicator.hide();

				}
			});

			// var fC1PR = this.getView().byId("inpC1PR");
			// var bC1PR = fC1PR.getBinding("items");
			// bC1PR.filter([new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1")
			// ], false)]);

			// var fC1CoCode = this.getView().byId("inpC1CoCode");
			// var bC1CoCode = fC1CoCode.getBinding("items");
			// bC1CoCode.filter([new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1")
			// ], false)]);

			// // debugger
			// var fC1FA = this.getView().byId("inpC1FA");
			// var bC1FA = fC1FA.getBinding("items");
			// bC1FA.filter([new sap.ui.model.Filter([
			// 	new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1")
			// ], false)]);

			sap.ui.core.BusyIndicator.hide();
		},
		onChange: function (oEvent) {
			// debugger;
			sap.ui.core.BusyIndicator.show(0);
			var selectedItem1 = oEvent.getParameter("selectedItem").getText();

			if (selectedItem1 === "COMPASS") {

				this.byId("Compass").setVisible(true);
				this.byId("C1").setVisible(false);
				this.byId("inpCompWBS").setValue("");
				this.byId("inpProj").setValue("");
				this.byId("inpCompPR").setValue("");
				this.byId("inpCompFA").setValue("");

				this.initiateCompass();
				// debugger;
			}
			if (selectedItem1 === "C1") {
				this.byId("Compass").setVisible(false);
				this.byId("C1").setVisible(true);
				this.byId("inpC1WBS").setValue("");
				this.byId("inpC1CoCode").setValue("");
				this.byId("inpC1PR").setValue("");
				this.byId("inpC1FA").setValue("");
				this.byId("DRS3").setValue("");

				this.initiateC1();
				// debugger;

			}

		},
		update: function (index, obj) {
			debugger;
			// var WBS = tableData.getRows()[this.SelCompIndex].getCells()[0].getText();
			var tableData = this.getView().byId("CompassTable");
			//comment
			// var WBSID = tableData.getRows()[index].getCells()[0].getProperty("text");
			// var WBSStatus = tableData.getRows()[index].getCells()[1].getProperty("selected");
			// var DNC = tableData.getRows()[index].getCells()[2].getProperty("selected");
			// var CheckAgainOn = tableData.getRows()[index].getCells()[3].getValue();
			// var DoNotClose = tableData.getRows()[index].getCells()[4].getValue();

			var WBSID = obj.Zposid;
			var WBSStatus = obj.AutoClsd;
			var DNC = obj.IgFurun;
			var CheckAgainOn = obj.ChkAgain;
			var DoNotClose = obj.CldComnt;
			if (WBSStatus === "Y") {
				WBSStatus = true;
			} else {
				WBSStatus = false;
			}
			if (DNC === "Y") {
				DNC = true;
			} else {
				DNC = false;
			}
			if (CheckAgainOn === "0000-00-00") {
				CheckAgainOn = "";
			} else {
				CheckAgainOn = CheckAgainOn;
			}

			var x = this.getOwnerComponent().getModel().getData();

			// if (this.CompassWBS.indexOf(WBS) === -1) {
			// 	this.CompassWBS.push(WBS);
			// 	// console.log(this.items);
			// }
			if (WBSStatus === false) {
				// WBSStatus = "N";
				debugger;
				WBSStatus = "";
			} else {
				WBSStatus = "Y";
			}
			if (CheckAgainOn === "") {
				CheckAgainOn = null;
			}
			if (DNC === false) {
				// DNC = "N";
				DNC = "";
			} else {
				DNC = "Y";
			}

			if (x.CompassWBS.indexOf(WBSID) === -1) {

				if (WBSStatus === "Y" || DNC === "Y" || CheckAgainOn !== null) {
					x.CompassWBS.push(WBSID);
					x.toSaveCompass.push({
						"SysId": obj.SysId,
						"Zposid": WBSID,
						"Zpspid": obj.Zpspid,
						"Zbukrs": obj.Zbukrs,
						"AutoClsd": WBSStatus,
						"AuclDate": obj.AuclDate,
						"Systatusline": obj.Systatusline,
						"Ustatusline": obj.Ustatusline,
						"Stufe": obj.Stufe,
						"Wbsowner1": obj.Wbsowner1,
						"FinApp": obj.FinApp,
						"PrjAc": obj.PrjAc,
						"Zzpgid": obj.Zzpgid,
						"Zkunnr": obj.Zkunnr,
						"Plakz": obj.Plakz,
						"Belkz": obj.Belkz,
						"Fakkz": obj.Fakkz,
						"PoCheck": obj.PoCheck,
						"SoCheck": obj.SoCheck,
						"FinCheck": obj.FinCheck,
						"TimCheck": obj.TimCheck,
						"Open_iwo": obj.Open_iwo,
						"OpenChildwbs": obj.OpenChildwbs,
						"FaCheck": obj.FaCheck,
						"BalCheck": obj.BalCheck,
						"UrCheck": obj.UrCheck,
						"AlsCheck": obj.AlsCheck,
						"ActSord": obj.ActSord,
						"ChkAgain": CheckAgainOn,
						"IgFurun": DNC,
						"AskPm": obj.AskPm,
						"CldComnt": DoNotClose
					});
				}
			} else {
				var WBS = x.CompassWBS[x.CompassWBS.indexOf(WBSID)];
				var y = x.toSaveCompass.find(o => o.Zposid === WBS);
				if (y !== undefined) {
					y.AutoClsd = WBSStatus;
					y.IgFurun = DNC;
					y.ChkAgain = CheckAgainOn;
					y.CldComnt = DoNotClose;
				}
			}
			// if (this.CompassWBS.indexOf(WBS) === -1) {
			// 	this.CompassWBS.push(WBS);
			// 	// console.log(this.items);
			// }
		},
		onSelectCompass: function (oEvent) {

			var that = this;
			//var oTable = this.byId("CompassTable");
			//var currentRowContext = oEvent.getParameter("rowContext");
			var tableData = that.getView().byId("CompassTable");
			//debugger;
			// this.aIndices = this.byId("CompassTable").getSelectedIndices();	
			this.SelCompIndex = tableData.getSelectedIndex();
			// for (var i = 0; i < tableData.getRows().length; i++) {
			// 	tableData.getRows()[i].getCells()[1].setEditable(false);
			// 	tableData.getRows()[i].getCells()[2].setEditable(false);
			// 	tableData.getRows()[i].getCells()[3].setEditable(false);
			// 	tableData.getRows()[i].getCells()[4].setEditable(false);

			// }
			var RowObj = oEvent.getSource().getBinding().getContexts()[0].getModel().getData().CompassTableDataSet[this.SelCompIndex];

			if (this.SelCompIndex !== -1) {

				if (this.z !== undefined && this.SelCompIndex !== this.z) {
					var obj1 = oEvent.getSource().getBinding().getContexts()[0].getModel().getData().CompassTableDataSet[this.z];
					this.update(this.z, obj1);
					obj1.UserCheck1 = "";
					obj1.UserCheck2 = "";
					obj1.UserCheck3 = "";
					obj1.UserCheck4 = "";
					// tableData.getRows()[this.z].getCells()[1].setEditable(false);
					// tableData.getRows()[this.z].getCells()[2].setEditable(false);
					// tableData.getRows()[this.z].getCells()[3].setEditable(false);
					// tableData.getRows()[this.z].getCells()[4].setEditable(false);
				}
				this.z = this.SelCompIndex;

				var closeWBSStatus = RowObj.AutoClsd;
				var DNC = RowObj.IgFurun;
				var CheckAgainOn = RowObj.ChkAgain;
				if (closeWBSStatus === "Y") {
					closeWBSStatus = true;
				} else {
					closeWBSStatus = false;
				}
				if (DNC === "Y") {
					DNC = true;
				} else {
					DNC = false;
				}
				if (CheckAgainOn === "0000-00-00") {
					CheckAgainOn = "";
				} else {
					CheckAgainOn = CheckAgainOn;
				}

				//Sam change
				// var closeWBSStatus = tableData.getRows()[this.SelCompIndex].getCells()[1].getProperty("selected");
				// var CheckAgainOn = tableData.getRows()[this.SelCompIndex].getCells()[3].getValue();
				// var DNC = tableData.getRows()[this.SelCompIndex].getCells()[2].getProperty("selected");
				// var DoNotClose = tableData.getRows()[this.SelCompIndex].getCells()[4].getValue();
				// for ( i = 0 ; i< this.aIndices.length; i++){
				if (closeWBSStatus === true && CheckAgainOn === "" && DNC === false) {
					//tableData.getRows()[this.SelCompIndex].getCells()[1].setEditable(true);
					RowObj.UserCheck1 = "true";
				} else if (closeWBSStatus === false && (CheckAgainOn !== "" || DNC === true)) {
					//tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(true);
					//tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(true);
					RowObj.UserCheck2 = "true";
					RowObj.UserCheck3 = "true";
					if (DNC === true) {
						//tableData.getRows()[this.SelCompIndex].getCells()[4].setEditable(true);
						RowObj.UserCheck4 = "true";

					}
					// tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(true);
					// } else if (closeWBSStatus === false && CheckAgainOn === "" && DoNotClose !== "") {
					// 	// tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(true);
					// 	tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(true);
				} else {
					// tableData.getRows()[this.SelCompIndex].getCells()[1].setEditable(true);
					// tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(true);
					// tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(true);

					RowObj.UserCheck1 = "true";
					RowObj.UserCheck2 = "true";
					RowObj.UserCheck3 = "true";
				}
			} else {

				var obj = oEvent.getSource().getBinding().getContexts()[0].getModel().getData().CompassTableDataSet[this.z];
				this.update(this.z, obj);
				// tableData.getRows()[this.z].getCells()[1].setEditable(false);
				// tableData.getRows()[this.z].getCells()[2].setEditable(false);
				// tableData.getRows()[this.z].getCells()[3].setEditable(false);
				// tableData.getRows()[this.z].getCells()[4].setEditable(false);

				obj.UserCheck1 = "";
				obj.UserCheck2 = "";
				obj.UserCheck3 = "";
				obj.UserCheck4 = "";

			}

			this.getView().getModel("CompassTableModel").refresh(true);
			//tableData.getColumns().byId("idCloseCompass").getCells()[this.aIndices].setEditable(true);
			// debugger;

		},
		GetMessage: function () {
			var sCompass = this.getOwnerComponent().getModel().getData().toSaveCompass;
			var sCompassmsg = this.getOwnerComponent().getModel().getData();

			for (var i = 0; i < sCompass.length; i++) {
				debugger;
				var payload = sCompass[i];
				if (payload.AutoClsd === "Y" && payload.ChkAgain === null && payload.IgFurun === "") {
					if (payload.CldComnt !== "") {
						sCompassmsg.Messages.push({
							"WBSID": payload.Zposid,
							"type": "Error",
							"message": "Please clear 'Do Not close Comment' field for the WBS."
						});
						sCompass.splice(i, 1);
						i = i - 1;
						// MessageBox.error("Please clear 'Do Not close Comment' field for the WBS( " + payload.Zposid + " )");
						continue;
					}

				} else if (payload.AutoClsd === "" && payload.ChkAgain !== null && payload.IgFurun === "Y") {

					if (payload.CldComnt === "") {
						sCompassmsg.Messages.push({
							"WBSID": payload.Zposid,
							"type": "Error",
							"message": "Please input 'Do Not close Comment' field for the WBS."
						});
						sCompass.splice(i, 1);
						i = i - 1;
						// MessageBox.error("Please input 'Do Not close Comment' field for the WBS( " + payload.Zposid + " )");
						continue;
					}

				} else if (payload.AutoClsd === "" && payload.ChkAgain !== null && payload.IgFurun === "") {

					sCompassmsg.Messages.push({
						"WBSID": payload.Zposid,
						"type": "Error",
						"message": "Please check the Do not Close Checkbox for the WBS"
					});
					sCompass.splice(i, 1);
					i = i - 1;
					// MessageBox.error("Please input 'Do Not close Comment' field for the WBS( " + payload.Zposid + " )");
					continue;

				} else if (payload.AutoClsd === "" && payload.ChkAgain === null && payload.IgFurun === "Y") {

					if (payload.CldComnt === "") {
						sCompassmsg.Messages.push({
							"WBSID": payload.Zposid,
							"type": "Error",
							"message": "Please input 'Do Not close Comment' field for the WBS."
						});
						sCompass.splice(i, 1);
						i = i - 1;
						// MessageBox.error("Please input 'Do Not close Comment' field for the WBS");
						continue;
					}

					// this.closeWBSArray.push(obj);
				} else if (payload.AutoClsd === "" && payload.ChkAgain === null && payload.IgFurun === "") {
					sCompassmsg.Messages.push({
						"WBSID": payload.Zposid,
						"type": "Error",
						"message": "Please Select any input."
					});
					sCompass.splice(i, 1);
					i = i - 1;
					// MessageBox.error("Please Select any input");
					continue;
				} else {
					sCompassmsg.Messages.push({
						"WBSID": payload.Zposid,
						"type": "Error",
						"message": "You can only choose either Close WBS or Do not Close."
					});
					sCompass.splice(i, 1);
					i = i - 1;
					// MessageBox.error("You can only choose either Close WBS (" + WBSID + ") or Do not Close.");
					continue;
				}
			}
		},
		onSaveCompass: function (oEvent) {

			// this.closeWBSArray = [];
			var that = this;
			var tableData = that.getView().byId("CompassTable");
			var index = tableData.getSelectedIndex();
			if (index !== -1) {
				//add
				var obj = this.getView().byId("CompassTable").getModel("CompassTableModel").getData().CompassTableDataSet[index];

				//comment
				//var WBSID = tableData.getRows()[index].getCells()[0].getProperty("text");
				//var obj = tableData.getRows()[index].getModel().getData().find(o => o.Zposid === WBSID);
				this.update(index, obj);
			}
			this.GetMessage();

			// Update Code 
			var sCompass = this.getOwnerComponent().getModel().getData().toSaveCompass;
			var sCompassmsg = this.getOwnerComponent().getModel().getData();
			var CreateoModel = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			// var json = {};
			sCompassmsg.draftData.d.HeadToItemNavi.results = sCompass;
			var payload = sCompassmsg.draftData;
			CreateoModel.create("/projid_headSet", payload, {
				success: function (oResponse) {
					sap.ui.core.BusyIndicator.hide();
					if (sCompassmsg.Messages.length === 0) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.success("The Action is succesfully completed");

						var tableData = that.getView().byId("CompassTable");
						tableData.clearSelection();
						that.getOwnerComponent().getModel().getData().CompassWBS = [];
						that.getOwnerComponent().getModel().getData().toSaveCompass = [];
						// this.getOwnerComponent().getModel().getData().CompassWBS = [];
					} else {
						that.changesDialog();

						var tableData = that.getView().byId("CompassTable");
						tableData.clearSelection();
						that.getOwnerComponent().getModel().getData().CompassWBS = [];
						that.getOwnerComponent().getModel().getData().toSaveCompass = [];
						// that.getOwnerComponent().getModel().getData().Messages = [];
					}

				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					// var tableData = that.getView().byId("CompassTable");
					// 				tableData.clearSelection();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});

			// CreateoModel.setUseBatch(true);
			// CreateoModel.setDeferredGroups(["foo"]);
			// 			var mParameters = {
			// 		groupId: "foo",
			// 		success: function (oResponse) {

			// 			sap.ui.core.BusyIndicator.hide();

			// 		}
			// }

			// for (var i = 0; i < sCompass.length; i++) {

			// 	var payload = sCompass[i];
			// 	sap.ui.core.BusyIndicator.show();
			// 	var erp = "COMPASS";
			// 	var sPath = "/ZCDS_AUTO_WBS_CLSSet(SysId=" + "'" +erp+ "',Zposid=" + "'" +payload.Zposid+ "')" ; 
			// 	CreateoModel.update(sPath, payload, mParameters);
			// }

			// CreateoModel.submitChanges(mParameters);

		},
		onProjF4: function (oEvent) {
			debugger;
		},
		changesDialog: function () {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var oView = that.getView();
			var oDialog = oView.byId("errorLog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "AutoWBSClosure.fragments.SaveActionChanges", that);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var oData = this.getOwnerComponent().getModel().getData().Messages;
			var oModel = new sap.ui.model.json.JSONModel(oData);
			var oTable = this.byId("errorLog1");
			oTable.setModel(oModel);
			sap.ui.core.BusyIndicator.hide();
		},
		onCancelHelpWBS: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "COMPASS") {
				this.byId("inpCompWBS").setValue(oSelectedItem.getTitle());
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "C1") {
				this.byId("inpC1WBS").setValue(oSelectedItem.getTitle());
			}

		},
		onCancelHelpproj: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("inpProj").setValue(oSelectedItem.getTitle());
			// this.byId("inpCompWBS").setValue(oSelectedItem.getTitle());
		},
		onCancelHelpFA: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "COMPASS") {
				// this.byId("inpCompWBS").setValue(oSelectedItem.getTitle());
				this.byId("inpCompFA").setValue(oSelectedItem.getTitle());
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "C1") {
				this.byId("inpC1FA").setValue(oSelectedItem.getTitle());
			}
		},
		onCancelHelpCC: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "COMPASS") {
				// this.byId("inpCompWBS").setValue(oSelectedItem.getTitle());
				this.byId("inpC1CoCode").setValue(oSelectedItem.getTitle());
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "C1") {
				this.byId("inpC1CoCode").setValue(oSelectedItem.getTitle());
			}
		},
		onCancelHelpPR: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "COMPASS") {
				this.byId("inpCompPR").setValue(oSelectedItem.getTitle());
			}
			if (this.getView().byId("inpSelect").getSelectedItem().getText() === "C1") {
				this.byId("inpC1PR").setValue(oSelectedItem.getTitle());
			}
		},
		onCancel: function (oEvent) {
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			oDailog.destroy();
			this.getOwnerComponent().getModel().getData().Messages = [];
			this.getOwnerComponent().getModel().getData().toSaveCompass = [];
			this.getOwnerComponent().getModel().getData().CompassWBS = [];

		},
		SaveCompass: function (oEvent) {

			// this.closeWBSArray = [];
			var that = this;
			var tableData = that.getView().byId("CompassTable");
			var index = tableData.getSelectedIndex();
			// for ( var i = 0 ; i < this.aIndices.length ; i++ ){

			var closeWBSStatus = tableData.getRows()[index].getCells()[1].getProperty("selected");
			var CheckAgainOn = tableData.getRows()[index].getCells()[3].getValue();
			var DNC = tableData.getRows()[index].getCells()[2].getProperty("selected");
			var DoNotClose = tableData.getRows()[index].getCells()[4].getValue();
			var WBSID = tableData.getRows()[index].getCells()[0].getProperty("text");
			// debugger;
			// var obj1 = oEvent.getSource().getBinding().getContexts()[0].getModel().getData()[oEvent.getSource().getSelectedIndex()];
			var payload = {};
			if (closeWBSStatus === true && CheckAgainOn === "" && DNC === false) {
				if (DoNotClose !== "") {
					MessageBox.error("Please clear 'Do Not close Comment' field for the WBS");
					return;
				}
				payload = {
					// "SysId" : "COMPASS",
					// "Zposid" : WBSID,
					// "AutoClsd" : "Y"
					"SysId": this.obj1.SysId,
					"Zposid": this.obj1.Zposid,
					"Zpspid": this.obj1.Zpspid,
					"Zbukrs": this.obj1.Zbukrs,
					"AutoClsd": "Y",
					"AuclDate": this.obj1.AuclDate,
					"Systatusline": this.obj1.Systatusline,
					"Ustatusline": this.obj1.Ustatusline,
					"Stufe": this.obj1.Stufe,
					"Wbsowner1": this.obj1.Wbsowner1,
					"FinApp": this.obj1.FinApp,
					"PrjAc": this.obj1.PrjAc,
					"Zzpgid": this.obj1.Zzpgid,
					"Zkunnr": this.obj1.Zkunnr,
					"Plakz": this.obj1.Plakz,
					"Belkz": this.obj1.Belkz,
					"Fakkz": this.obj1.Fakkz,
					"PoCheck": this.obj1.PoCheck,
					"SoCheck": this.obj1.SoCheck,
					"FinCheck": this.obj1.FinCheck,
					"TimCheck": this.obj1.TimCheck,
					"Open_iwo": this.obj1.Open_iwo,
					"OpenChildwbs": this.obj1.OpenChildwbs,
					"FaCheck": this.obj1.FaCheck,
					"BalCheck": this.obj1.BalCheck,
					"UrCheck": this.obj1.UrCheck,
					"AlsCheck": this.obj1.AlsCheck,
					"ActSord": this.obj1.ActSord,
					"ChkAgain": null,
					"IgFurun": "N",
					"AskPm": this.obj1.AskPm,
					"CldComnt": DoNotClose

				};

			}
			// else if (closeWBSStatus === false && CheckAgainOn !== "" && DNC === false) {

			// 	if (DoNotClose !== "") {
			// 		MessageBox.error("Please clear 'Do Not close Comment' field for the WBS");
			// 		return;
			// 	}

			// 	payload = {
			// 		"SysId": this.obj1.SysId,
			// 		"Zposid": this.obj1.Zposid,
			// 		"Zpspid": this.obj1.Zpspid,
			// 		"Zbukrs": this.obj1.Zbukrs,
			// 		"AutoClsd": "N",
			// 		"AuclDate": this.obj1.AuclDate,
			// 		"Systatusline": this.obj1.Systatusline,
			// 		"Ustatusline": this.obj1.Ustatusline,
			// 		"Stufe": this.obj1.Stufe,
			// 		"Wbsowner1": this.obj1.Wbsowner1,
			// 		"FinApp": this.obj1.FinApp,
			// 		"PrjAc": this.obj1.PrjAc,
			// 		"Zzpgid": this.obj1.Zzpgid,
			// 		"Zkunnr": this.obj1.Zkunnr,
			// 		"Plakz": this.obj1.Plakz,
			// 		"Belkz": this.obj1.Belkz,
			// 		"Fakkz": this.obj1.Fakkz,
			// 		"PoCheck": this.obj1.PoCheck,
			// 		"SoCheck": this.obj1.SoCheck,
			// 		"FinCheck": this.obj1.FinCheck,
			// 		"TimCheck": this.obj1.TimCheck,
			// 		"FaCheck": this.obj1.FaCheck,
			// 		"BalCheck": this.obj1.BalCheck,
			// 		"UrCheck": this.obj1.UrCheck,
			// 		"AlsCheck": this.obj1.AlsCheck,
			// 		"ActSord": this.obj1.ActSord,
			// 		"ChkAgain": CheckAgainOn,
			// 		"IgFurun": "N",
			// 		"AskPm": this.obj1.AskPm,
			// 		"CldComnt": DoNotClose
			// 	};

			// 	// this.closeWBSArray.push(obj);
			// }
			else if (closeWBSStatus === false && CheckAgainOn !== "" && DNC === true) {

				if (DoNotClose === "") {
					MessageBox.error("Please input 'Do Not close Comment' field for the WBS");
					return;
				}

				payload = {
					"SysId": this.obj1.SysId,
					"Zposid": this.obj1.Zposid,
					"Zpspid": this.obj1.Zpspid,
					"Zbukrs": this.obj1.Zbukrs,
					"AutoClsd": "N",
					"AuclDate": this.obj1.AuclDate,
					"Systatusline": this.obj1.Systatusline,
					"Ustatusline": this.obj1.Ustatusline,
					"Stufe": this.obj1.Stufe,
					"Wbsowner1": this.obj1.Wbsowner1,
					"FinApp": this.obj1.FinApp,
					"PrjAc": this.obj1.PrjAc,
					"Zzpgid": this.obj1.Zzpgid,
					"Zkunnr": this.obj1.Zkunnr,
					"Plakz": this.obj1.Plakz,
					"Belkz": this.obj1.Belkz,
					"Fakkz": this.obj1.Fakkz,
					"PoCheck": this.obj1.PoCheck,
					"SoCheck": this.obj1.SoCheck,
					"FinCheck": this.obj1.FinCheck,
					"TimCheck": this.obj1.TimCheck,
					"Open_iwo": this.obj1.Open_iwo,
					"OpenChildwbs": this.obj1.OpenChildwbs,
					"FaCheck": this.obj1.FaCheck,
					"BalCheck": this.obj1.BalCheck,
					"UrCheck": this.obj1.UrCheck,
					"AlsCheck": this.obj1.AlsCheck,
					"ActSord": this.obj1.ActSord,
					"ChkAgain": CheckAgainOn,
					"IgFurun": "Y",
					"AskPm": this.obj1.AskPm,
					"CldComnt": DoNotClose
				};

				// this.closeWBSArray.push(obj);
			} else if (closeWBSStatus === false && CheckAgainOn === "" && DNC === true) {

				if (DoNotClose === "") {
					MessageBox.error("Please input 'Do Not close Comment' field for the WBS");
					return;
				}

				payload = {
					"SysId": this.obj1.SysId,
					"Zposid": this.obj1.Zposid,
					"Zpspid": this.obj1.Zpspid,
					"Zbukrs": this.obj1.Zbukrs,
					"AutoClsd": "N",
					"AuclDate": this.obj1.AuclDate,
					"Systatusline": this.obj1.Systatusline,
					"Ustatusline": this.obj1.Ustatusline,
					"Stufe": this.obj1.Stufe,
					"Wbsowner1": this.obj1.Wbsowner1,
					"FinApp": this.obj1.FinApp,
					"PrjAc": this.obj1.PrjAc,
					"Zzpgid": this.obj1.Zzpgid,
					"Zkunnr": this.obj1.Zkunnr,
					"Plakz": this.obj1.Plakz,
					"Belkz": this.obj1.Belkz,
					"Fakkz": this.obj1.Fakkz,
					"PoCheck": this.obj1.PoCheck,
					"SoCheck": this.obj1.SoCheck,
					"FinCheck": this.obj1.FinCheck,
					"TimCheck": this.obj1.TimCheck,
					"Open_iwo": this.obj1.Open_iwo,
					"OpenChildwbs": this.obj1.OpenChildwbs,
					"FaCheck": this.obj1.FaCheck,
					"BalCheck": this.obj1.BalCheck,
					"UrCheck": this.obj1.UrCheck,
					"AlsCheck": this.obj1.AlsCheck,
					"ActSord": this.obj1.ActSord,
					"ChkAgain": this.obj1.ChkAgain,
					"IgFurun": "Y",
					"AskPm": this.obj1.AskPm,
					"CldComnt": DoNotClose
				};

				// this.closeWBSArray.push(obj);
			} else if (closeWBSStatus === false && CheckAgainOn === "" && DoNotClose === "") {
				MessageBox.error("Please Select any input");
				return;
			} else {
				MessageBox.error("You can only choose either Close WBS (" + WBSID + ") or Do not Close.");
				return;
			}

			// Update Code 

			var CreateoModel = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			sap.ui.core.BusyIndicator.show();
			var erp = "COMPASS";
			CreateoModel.update("/ZCDS_AUTO_WBS_CLSSet(SysId=" + "'" + erp + "',Zposid=" + "'" + WBSID + "')", payload, {
				success: function (response) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.success("The Action is succesfully completed");

				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error in Saving data");

				}
			});
		},
		onSelectC1: function (oEvent) {

			var that = this;
			//var oTable = this.byId("CompassTable");
			//var currentRowContext = oEvent.getParameter("rowContext");
			//debugger;
			var tableData = that.getView().byId("C1Table");
			this.SelC1Index = this.byId("C1Table").getSelectedIndex();

			// add
			// for (var i = 0; i < tableData.getRows().length; i++) {
			// 	tableData.getRows()[i].getCells()[1].setEditable(false);
			// 	tableData.getRows()[i].getCells()[2].setEditable(false);
			// 	tableData.getRows()[i].getCells()[3].setEditable(false);

			// }
			//Add
			//this.objC1 = oEvent.getSource().getBinding().getContexts()[0].getModel().getData()[oEvent.getSource().getSelectedIndex()];
			this.objC1 = oEvent.getSource().getBinding().getContexts()[0].getModel().getData().C1TableDataSet[this.SelC1Index];

			if (this.SelC1Index !== -1) {

				if (this.z !== undefined && this.SelCompIndex !== this.z) {
					var obj = oEvent.getSource().getBinding().getContexts()[0].getModel().getData().C1TableDataSet[this.z];
					obj.UserCheck1 = "";
					obj.UserCheck2 = "";
					obj.UserCheck3 = "";
				}

				this.z = this.SelC1Index;

				var x = this.objC1.AutoClsd;
				//add
				// var CheckAgainOn = tableData.getRows()[this.SelC1Index].getCells()[1].getValue();
				// var igFutRun = tableData.getRows()[this.SelC1Index].getCells()[2].getProperty("selected");
				// var askPM = tableData.getRows()[this.SelC1Index].getCells()[3].getProperty("selected");

				var CheckAgainOn = this.objC1.ChkAgain;
				var igFutRun = this.objC1.IgFurun;
				var askPM = this.objC1.AskPm;

				if (CheckAgainOn === "0000-00-00") {
					CheckAgainOn = "";
				} else {
					CheckAgainOn = CheckAgainOn;
				}
				if (igFutRun === "Y") {
					igFutRun = true;
				} else {
					igFutRun = false;
				}
				if (askPM === "Y") {
					askPM = true;
				} else {
					askPM = false;
				}

				//End

				if (x === "X") {
					MessageBox.information("The WBS is already closed");

				} else {
					if (CheckAgainOn !== "" && igFutRun === false) {
						this.objC1.UserCheck1 = "true";
						//tableData.getRows()[this.SelC1Index].getCells()[1].setEditable(true);
					} else if (CheckAgainOn === "" && igFutRun === true) {
						this.objC1.UserCheck2 = "true";
						//tableData.getRows()[this.SelC1Index].getCells()[2].setEditable(true);
						// tableData.getRows()[this.SelC1Index].getCells()[3].setEditable(true);
					} else {
						this.objC1.UserCheck1 = "true";
						this.objC1.UserCheck2 = "true";
						//tableData.getRows()[this.SelC1Index].getCells()[1].setEditable(true);
						//tableData.getRows()[this.SelC1Index].getCells()[2].setEditable(true);
					}

					// if (askPM === false) {
					//tableData.getRows()[this.SelC1Index].getCells()[3].setEditable(true);
					this.objC1.UserCheck3 = "true";
					// }
				}
			}
			this.getView().getModel("C1TableModel").refresh(true);
		},
		onSaveC1: function (oEvent) {

			var that = this;
			var tableData = that.getView().byId("C1Table");
			var index = tableData.getSelectedIndex();
			// debugger;

			this.objC1 = this.getView().byId("C1Table").getModel("C1TableModel").getData().C1TableDataSet[index];

			// var CheckAgainOn = tableData.getRows()[index].getCells()[1].getValue();
			// var igFutRun = tableData.getRows()[index].getCells()[2].getProperty("selected");
			// var askPM = tableData.getRows()[index].getCells()[3].getProperty("selected");
			// var WBSID = tableData.getRows()[index].getCells()[0].getProperty("text");

			var WBSID = this.objC1.Zposid;
			var CheckAgainOn = this.objC1.ChkAgain;
			var igFutRun = this.objC1.IgFurun;
			var askPM = this.objC1.AskPm;

			if (CheckAgainOn === "0000-00-00") {
				CheckAgainOn = "";
			} else {
				CheckAgainOn = CheckAgainOn;
			}

			if (igFutRun === "Y") {
				igFutRun = true;
			} else {
				igFutRun = false;
			}
			if (askPM === "Y") {
				askPM = true;
			} else {
				askPM = false;
			}

			// var obj1 = oEvent.getSource().getBinding().getContexts()[0].getModel().getData()[oEvent.getSource().getSelectedIndex()];
			var payload = {};
			var PM;
			if (CheckAgainOn !== "" && igFutRun === false) {
				if (askPM === false) {
					PM = "N";
				} else {
					PM = "Y";
				}
				payload = {
					// "SysId" : "COMPASS",
					// "Zposid" : WBSID,
					// "AutoClsd" : "Y"
					"SysId": this.objC1.SysId,
					"Zposid": this.objC1.Zposid,
					"Zpspid": this.objC1.Zpspid,
					"Zbukrs": this.objC1.Zbukrs,
					"AutoClsd": this.objC1.AutoClsd,
					"AuclDate": this.objC1.AuclDate,
					"Systatusline": this.objC1.Systatusline,
					"Ustatusline": this.objC1.Ustatusline,
					"Stufe": this.objC1.Stufe,
					"Wbsowner1": this.objC1.Wbsowner1,
					"FinApp": this.objC1.FinApp,
					"PrjAc": this.objC1.PrjAc,
					"Zzpgid": this.objC1.Zzpgid,
					"Zkunnr": this.objC1.Zkunnr,
					"Plakz": this.objC1.Plakz,
					"Belkz": this.objC1.Belkz,
					"Fakkz": this.objC1.Fakkz,
					"PoCheck": this.objC1.PoCheck,
					"SoCheck": this.objC1.SoCheck,
					"FinCheck": this.objC1.FinCheck,
					"TimCheck": this.objC1.TimCheck,
					"Open_iwo": this.objC1.Open_iwo,
					"OpenChildwbs": this.objC1.OpenChildwbs,
					"FaCheck": this.objC1.FaCheck,
					"BalCheck": this.objC1.BalCheck,
					"UrCheck": this.objC1.UrCheck,
					"AlsCheck": this.objC1.AlsCheck,
					"ActSord": this.objC1.ActSord,
					"ChkAgain": CheckAgainOn,
					"IgFurun": "N",
					"AskPm": PM,
					"CldComnt": this.objC1.CldComnt

				};
				// this.closeWBSArray.push(obj);
			} else if (CheckAgainOn === "" && igFutRun === true) {

				// var PM;
				if (askPM === false) {
					PM = "N";
				} else {
					PM = "Y";
				}
				payload = {
					"SysId": this.objC1.SysId,
					"Zposid": this.objC1.Zposid,
					"Zpspid": this.objC1.Zpspid,
					"Zbukrs": this.objC1.Zbukrs,
					"AutoClsd": this.objC1.AutoClsd,
					"AuclDate": this.objC1.AuclDate,
					"Systatusline": this.objC1.Systatusline,
					"Ustatusline": this.objC1.Ustatusline,
					"Stufe": this.objC1.Stufe,
					"Wbsowner1": this.objC1.Wbsowner1,
					"FinApp": this.objC1.FinApp,
					"PrjAc": this.objC1.PrjAc,
					"Zzpgid": this.objC1.Zzpgid,
					"Zkunnr": this.objC1.Zkunnr,
					"Plakz": this.objC1.Plakz,
					"Belkz": this.objC1.Belkz,
					"Fakkz": this.objC1.Fakkz,
					"PoCheck": this.objC1.PoCheck,
					"SoCheck": this.objC1.SoCheck,
					"FinCheck": this.objC1.FinCheck,
					"TimCheck": this.objC1.TimCheck,
					"Open_iwo": this.objC1.Open_iwo,
					"OpenChildwbs": this.objC1.OpenChildwbs,
					"FaCheck": this.objC1.FaCheck,
					"BalCheck": this.objC1.BalCheck,
					"UrCheck": this.objC1.UrCheck,
					"AlsCheck": this.objC1.AlsCheck,
					"ActSord": this.objC1.ActSord,
					"ChkAgain": null,
					"IgFurun": "Y",
					"AskPm": PM,
					"CldComnt": this.objC1.CldComnt
				};
				// this.closeWBSArray.push(obj);

			} else if (CheckAgainOn === "" && igFutRun === false && askPM === true) {

				payload = {
					// "SysId" : "COMPASS",
					// "Zposid" : WBSID,
					// "AutoClsd" : "Y"
					"SysId": this.objC1.SysId,
					"Zposid": this.objC1.Zposid,
					"Zpspid": this.objC1.Zpspid,
					"Zbukrs": this.objC1.Zbukrs,
					"AutoClsd": this.objC1.AutoClsd,
					"AuclDate": this.objC1.AuclDate,
					"Systatusline": this.objC1.Systatusline,
					"Ustatusline": this.objC1.Ustatusline,
					"Stufe": this.objC1.Stufe,
					"Wbsowner1": this.objC1.Wbsowner1,
					"FinApp": this.objC1.FinApp,
					"PrjAc": this.objC1.PrjAc,
					"Zzpgid": this.objC1.Zzpgid,
					"Zkunnr": this.objC1.Zkunnr,
					"Plakz": this.objC1.Plakz,
					"Belkz": this.objC1.Belkz,
					"Fakkz": this.objC1.Fakkz,
					"PoCheck": this.objC1.PoCheck,
					"SoCheck": this.objC1.SoCheck,
					"FinCheck": this.objC1.FinCheck,
					"TimCheck": this.objC1.TimCheck,
					"Open_iwo": this.objC1.Open_iwo,
					"OpenChildwbs": this.objC1.OpenChildwbs,
					"FaCheck": this.objC1.FaCheck,
					"BalCheck": this.objC1.BalCheck,
					"UrCheck": this.objC1.UrCheck,
					"AlsCheck": this.objC1.AlsCheck,
					"ActSord": this.objC1.ActSord,
					"ChkAgain": this.objC1.ChkAgain,
					"IgFurun": this.objC1.IgFurun,
					"AskPm": "Y",
					"CldComnt": this.objC1.CldComnt

				};
			} else if (CheckAgainOn === "" && igFutRun === false && askPM === false) {
				// MessageBox.error("Please select any input for the selected WBS");
				// return;
				payload = {
					// "SysId" : "COMPASS",
					// "Zposid" : WBSID,
					// "AutoClsd" : "Y"
					"SysId": this.objC1.SysId,
					"Zposid": this.objC1.Zposid,
					"Zpspid": this.objC1.Zpspid,
					"Zbukrs": this.objC1.Zbukrs,
					"AutoClsd": this.objC1.AutoClsd,
					"AuclDate": this.objC1.AuclDate,
					"Systatusline": this.objC1.Systatusline,
					"Ustatusline": this.objC1.Ustatusline,
					"Stufe": this.objC1.Stufe,
					"Wbsowner1": this.objC1.Wbsowner1,
					"FinApp": this.objC1.FinApp,
					"PrjAc": this.objC1.PrjAc,
					"Zzpgid": this.objC1.Zzpgid,
					"Zkunnr": this.objC1.Zkunnr,
					"Plakz": this.objC1.Plakz,
					"Belkz": this.objC1.Belkz,
					"Fakkz": this.objC1.Fakkz,
					"PoCheck": this.objC1.PoCheck,
					"SoCheck": this.objC1.SoCheck,
					"FinCheck": this.objC1.FinCheck,
					"TimCheck": this.objC1.TimCheck,
					"Open_iwo": this.objC1.Open_iwo,
					"OpenChildwbs": this.objC1.OpenChildwbs,
					"FaCheck": this.objC1.FaCheck,
					"BalCheck": this.objC1.BalCheck,
					"UrCheck": this.objC1.UrCheck,
					"AlsCheck": this.objC1.AlsCheck,
					"ActSord": this.objC1.ActSord,
					"ChkAgain": "",
					"IgFurun": "N",
					"AskPm": "N",
					"CldComnt": this.objC1.CldComnt

				};
			} else {
				// alert("Please Enter Correct Value");
				MessageBox.error("You can only either choose Check Again On or Ignore for future runs for the (" + WBSID + ")");
				return;
			}

			// Update Code 
			var erp = "C1";
			var CreateoModel = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			sap.ui.core.BusyIndicator.show();
			// CreateoModel.update("/ZCDS_AUTO_WBS_CLSSet?$filter=SysId eq '" + erp + "' and Zposid eq '" + WBSID + "'"
			CreateoModel.update("/ZCDS_AUTO_WBS_CLSSet(SysId=" + "'" + erp + "',Zpspid=" + "'" + payload.Zpspid + "',Zposid=" + "'" + WBSID +
				"')", payload, {
					success: function (response) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.success("The Action is succesfully completed");

					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error in Saving data");

					}
				});

		},
		onSearch: function () {
			// this.CompassPspidunique = [];
			this.selWBSNumber = [];
			this.selPerResp = [];
			this.selFinanceAnalyst = [];
			this.selProj = [];

			var that = this;
			var tableData = that.getView().byId("CompassTable");
			tableData.clearSelection();
			debugger;
			this.finalFilters = [];
			this.finalFilters.push(new sap.ui.model.Filter("AutoClsd", sap.ui.model.FilterOperator.NE, "Y"));
			if (that.flagCompass !== null) {
				// this.finalFilters.push(new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, that.flagCompass));
				that.finalFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, that.flagCompass),
					new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, that.flagCompass)
				], false));
			}

			// if (this.selWBSNumber) {
			// for (var i = 0; i < this.selWBSNumber.length; i++) {
			if (that.flagCompass !== null) {
				var itemProj = this.byId("inpProjNrml").getValue();
				if (itemProj !== "") {
					this.finalFilters.push(new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.EQ, itemProj));
				}
			} else {
				var itemProj = this.byId("inpProj").getValue();
				if (itemProj !== "") {
					this.finalFilters.push(new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.EQ, itemProj));
				} else {
					this.finalFilters.push(new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.EQ, "NoData"));
					sap.m.MessageToast.show("Please fill Mandatory fields");
				}
			}

			var items = this.byId("inpCompWBS").getValue();
			var required = this.getView().byId("inpProj").getProperty("required");
			if (items !== "") {
				// if (required === true) {
				// 	if (itemProj !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, items));
				// 	}
				// } else {
				// 	this.finalFilters.push(new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, items));
				// }
			}

			var itemsPR = this.byId("inpCompPR").getValue();
			if (itemsPR !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, itemsPR));
			}

			var itemsFA = this.byId("inpCompFA").getValue();
			if (itemsFA !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, itemsFA));
			}

			// if (required === true) {
			// 	if (itemProj === "" || (itemsFA !== "" && itemProj === "") || (itemsPR !== "" && itemProj === "") || (items !== "" && itemProj ===
			// 			"")) {
			// 		sap.m.MessageToast.show("Please fill Mandatory fields");
			// 		this.finalFilters.push(new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, "NoData"));
			// 		// return;
			// 	}
			// } else {
			// 	if (itemProj !== "" && itemsFA !== "" && itemsPR !== "" && items !== "") {
			// 		sap.m.MessageToast.show("Please fill Mandatory fields");
			// 		this.finalFilters.push(new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, "NoData"));
			// 		// return;
			// 	}
			// }
			// for (var i = 0; i < items.length; i++) {
			// 	var selWBSNumber = items[i].getKey();
			// 	}
			// }
			// if (this.selProj) {
			// 	// for (var i = 0; i < this.selWBSNumber.length; i++) {
			// 	var itemProj = this.byId("inpProj").getSelectedItems();
			// 	for (i = 0; i < itemProj.length; i++) {
			// 		var Proj = itemProj[i].getKey();
			// 		this.finalFilters.push(new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.EQ, Proj));
			// 	}
			// }
			// if (this.selPerResp) {
			// 	for (i = 0; i < itemsPR.length; i++) {
			// 		var selPerResp = itemsPR[i].getKey();
			// 	}
			// }

			// if (this.selFinanceAnalyst) {
			// 	var itemsFA = this.byId("inpCompFA").getSelectedItems();
			// 	for (i = 0; i < itemsFA.length; i++) {
			// 		var selFinanceAnalyst = itemsFA[i].getKey();
			// 		this.finalFilters.push(new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, selFinanceAnalyst));
			// 	}
			// }

			var validClosure = this.byId("vClosure").getProperty("selected");

			if (validClosure === false) {

				this.finalFilters.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS"));
			} else {
				this.finalFilters.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS"));
				this.finalFilters.push(new sap.ui.model.Filter("FinCheck", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("BalCheck", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("PoCheck", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("SoCheck", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("FaCheck", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("TimCheck", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("Open_iwo", sap.ui.model.FilterOperator.NE, "Y"));
				this.finalFilters.push(new sap.ui.model.Filter("OpenChildwbs", sap.ui.model.FilterOperator.NE, "Y"));
				// debugger;
			}

			if (this.finalFilters.length !== 0) {
				var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");

				BusyIndicator.show();
				var sorter = new sap.ui.model.Sorter("Zposid", false);
				oDta.read("/ZCDS_AUTO_WBS_CLSSet", {
					filters: this.finalFilters,
					sorters: [sorter],
					success: function (oData, oResponse) {
						BusyIndicator.hide();
						//that.byId("CompassTable").setVisibleRowCount(oData.results.length);
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}
						//Sam
						// that.tableModel = new JSONModel(oData.results);
						// that.getView().byId("CompassTable").setModel(that.tableModel);

						that.getView().getModel("CompassTableModel").setProperty("/CompassTableDataSet", oData.results);
						this.z = 0;
						this.SelCompIndex = 0;
						// var oModel = this.getView().getModel("Auto_WBS_Closure");
						// var oModel1 = new sap.ui.model.json.JSONModel(oData.results);
						// oModel.setProperty("/", oModel1.getData());
						this.getView().byId("idCompass").setText("Compass WBS Reports (" + oData.results.length + ")")

					}.bind(this),
					error: function (err) {
						BusyIndicator.hide();
					}
				});
			} else {

				this.initiateCompass();
				BusyIndicator.hide();
			}
		},

		onSearchC1: function () {
			this.selWBSNumberC1 = [];
			this.selCoCodeC1 = [];

			this.selPerRespC1 = [];
			this.selFinanceAnalystC1 = [];

			var that = this;
			var tableData = that.getView().byId("C1Table");
			tableData.clearSelection();
			this.finalFiltersC1 = [];

			if (that.flag !== null) {
				// this.finalFiltersC1.push(new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, that.flag));
				that.finalFiltersC1.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, that.flag),
					new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, that.flag)
				], false));
			}
			debugger;
			var fromDate = this.byId("DRS3").getProperty("dateValue");
			var toDate = this.byId("DRS3").getProperty("secondDateValue");

			if (fromDate !== null && toDate !== null) {
				var a = new Date(+fromDate + 86400000).toISOString().split("T")[0].split("-");
				var b = new Date(+toDate + 86400000).toISOString().split("T")[0].split("-");
				fromDate = a[0] + a[1] + a[2];
				toDate = b[0] + b[1] + b[2];

				this.finalFiltersC1.push(new sap.ui.model.Filter("AuclDate", sap.ui.model.FilterOperator.BT, fromDate, toDate));
				// this.finalFiltersC1.push(new sap.ui.model.Filter("AutoClsd", sap.ui.model.FilterOperator.EQ, "X"));

			}

			// if (this.selWBSNumberC1) {
			// for (var i = 0; i < this.selWBSNumber.length; i++) {
			var itemsWBSC1 = this.byId("inpC1WBS").getValue();
			// for (var i = 0; i < itemsWBSC1.length; i++) {
			// var selWBSNumberC1 = itemsWBSC1[i].getKey();
			if (itemsWBSC1 !== "") {
				this.finalFiltersC1.push(new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, itemsWBSC1));
			}
			// }
			// }
			// for (var i = 0; i < this.selWBSNumber.length; i++) {
			var itemsCCodeC1 = this.byId("inpC1CoCode").getValue();
			// for (var i = 0; i < itemsCCodeC1.length; i++) {
			// 	var selCoCodeC1 = itemsCCodeC1[i].getKey();
			if (itemsCCodeC1 !== "") {
				this.finalFiltersC1.push(new sap.ui.model.Filter("Zbukrs", sap.ui.model.FilterOperator.EQ, itemsCCodeC1));
			}
			// }
			// if (this.selPerRespC1) {
			// for (var i = 0; i < this.selWBSNumber.length; i++) {
			var itemsPRC1 = this.byId("inpC1PR").getValue();
			// for (i = 0; i < itemsPRC1.length; i++) {
			// var selPerRespC1 = itemsPRC1[i].getKey();
			if (itemsPRC1 !== "") {
				this.finalFiltersC1.push(new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, itemsPRC1));
			}
			// }
			// if (this.selFinanceAnalystC1) {
			// for (var i = 0; i < this.selWBSNumber.length; i++) {
			var itemsFAC1 = this.byId("inpC1FA").getValue();
			// for (i = 0; i < itemsFAC1.length; i++) {
			// var selFinanceAnalystC1 = itemsFAC1[i].getKey();
			if (itemsFAC1 !== "") {
				this.finalFiltersC1.push(new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, itemsFAC1));
			}
			// }
			debugger;
			if (itemsWBSC1.length === 0 && itemsCCodeC1.length === 0 && itemsPRC1.length === 0 && itemsFAC1.length === 0 && fromDate ===
				null &&
				toDate === null) {
				sap.m.MessageToast.show("Please input values in filters");
				this.finalFiltersC1.push(new sap.ui.model.Filter("Zposid", sap.ui.model.FilterOperator.EQ, "NoData"));
				// return;
			}

			var DNSClosedWBS = this.byId("DNSClosedWBS").getProperty("selected");
			if (DNSClosedWBS === false) {

				this.finalFiltersC1.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1"));
			} else {
				this.finalFiltersC1.push(new sap.ui.model.Filter("AutoClsd", sap.ui.model.FilterOperator.NE, "X"));
				this.finalFiltersC1.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1"));

			}

			if (this.finalFiltersC1.length !== 0) {
				var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
				//var oDta = this.getView().getModel("projectFilterModel");
				BusyIndicator.show();
				var sorter = new sap.ui.model.Sorter("Zposid", false);
				oDta.read("/ZCDS_AUTO_WBS_CLSSet", {
					filters: this.finalFiltersC1,
					sorters: [sorter],
					success: function (oData, oResponse) {
						BusyIndicator.hide();
						//this.byId("C1Table").setVisibleRowCount(oData.results.length);
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}

						that.tableModel = new JSONModel(oData.results);
						this.getView().byId("idC1").setText("C1 WBS Reports (" + oData.results.length + ")")
						that.getView().getModel("C1TableModel").setProperty("/C1TableDataSet", oData.results);
						this.SelC1Index = 0;
						this.z = 0;
						//debugger;
						//this.getView().byId("C1Table").setModel(that.tableModel);
						// that.getView().getModel("appView").setProperty("/oCount", oData.results.length);
					}.bind(this),
					error: function (err) {
						BusyIndicator.hide();
					}
				});
			} else {

				this.initiateC1();

				BusyIndicator.hide();
			}
		},

		onCloseWBS: function (oEvent) {
			var that = this;
			var tableData = that.getView().byId("CompassTable");
			var SelCompIndex = tableData.getSelectedIndex();
			var RowObj = this.getView().byId("CompassTable").getModel("CompassTableModel").getData().CompassTableDataSet[SelCompIndex];
			var closeWBSStatus = RowObj.AutoClsd;
			if (closeWBSStatus === "Y") {
				closeWBSStatus = true;
			} else {
				closeWBSStatus = false;
			}

			//var closeWBSStatus = tableData.getRows()[this.SelCompIndex].getCells()[1].getProperty("selected");
			if (closeWBSStatus === false) {

				RowObj.UserCheck2 = "";
				RowObj.UserCheck3 = "";
				RowObj.AutoClsd = "Y"
					// alert("msg");
					//tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(false);
					//tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(false);
			} else {
				RowObj.UserCheck2 = "true";
				RowObj.UserCheck3 = "true";
				RowObj.AutoClsd = "N"
					//tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(true);
					//tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(true);
			}

			this.getView().getModel("CompassTableModel").refresh(true);
			// MessageBox.error("Please select any input for the selected row");
		},

		// onDoNotClose: function (oEvent) {

		// 	var that = this;
		// 	var tableData = that.getView().byId("CompassTable");
		// 	// var CheckAgainOn = tableData.getRows()[this.SelCompIndex].getCells()[2].getValue();
		// 	var DNC = tableData.getRows()[this.SelCompIndex].getCells()[3].getProperty("selected");

		// 	if (DNC === true) {
		// 		// alert("msg");
		// 		tableData.getRows()[this.SelCompIndex].getCells()[1].setEditable(false);
		// 		// tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(false);

		// 	} else {
		// 		tableData.getRows()[this.SelCompIndex].getCells()[1].setEditable(true);
		// 		// tableData.getRows()[this.SelCompIndex].getCells()[2].setEditable(true);

		// 	}
		// },
		CheckDateCompass: function (oEvent) {
			var that = this;
			var tableData = that.getView().byId("CompassTable");
			//Add -Sam
			var SelCompIndex = tableData.getSelectedIndex();
			var RowObj = this.getView().byId("CompassTable").getModel("CompassTableModel").getData().CompassTableDataSet[SelCompIndex];
			var dateChange = oEvent.getSource().getValue();
			var CheckAgainOn;
			CheckAgainOn = dateChange;
			RowObj.ChkAgain = dateChange;

			var DNC = RowObj.IgFurun;
			if (DNC === "Y") {
				DNC = true;
			} else {
				DNC = false;
			}
			if (CheckAgainOn === "0000-00-00") {
				CheckAgainOn = "";
			} else {
				CheckAgainOn = CheckAgainOn;
			}
			if (CheckAgainOn !== "" || DNC === true) {
				// alert("msg");

				RowObj.UserCheck1 = "";
				//comment
				//tableData.getRows()[this.SelCompIndex].getCells()[1].setEditable(false);

				// tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(false);
			} else {
				RowObj.UserCheck1 = "true";
				//tableData.getRows()[this.SelCompIndex].getCells()[1].setEditable(true);
				// tableData.getRows()[this.SelCompIndex].getCells()[3].setEditable(true);
			}

			this.getView().getModel("CompassTableModel").refresh(true);
		},
		CheckDNCCompass: function (oEvent) {
			var that = this;
			var tableData = that.getView().byId("CompassTable");
			//Add -Sam
			var SelCompIndex = tableData.getSelectedIndex();
			var RowObj = this.getView().byId("CompassTable").getModel("CompassTableModel").getData().CompassTableDataSet[SelCompIndex];
			var DNC = oEvent.getSource().getSelected();
			if (DNC === false) {
				RowObj.UserCheck1 = "true";
				RowObj.UserCheck4 = "";
				RowObj.IgFurun = "";
				//tableData.getRows()[this.SelCompIndex].getCells()[4].setEditable(true);
			} else {
				RowObj.UserCheck4 = "true";
				RowObj.IgFurun = "Y";
				RowObj.UserCheck1 = "";
				//tableData.getRows()[this.SelCompIndex].getCells()[4].setEditable(false);
			}

			this.getView().getModel("CompassTableModel").refresh(true);
		},
		ignoreFR: function (oEvent) {
			var that = this;
			var tableData = that.getView().byId("C1Table");
			var SelC1pIndex = tableData.getSelectedIndex();
			var IGFR = oEvent.getSource().getSelected();

			var RowObj = this.getView().byId("C1Table").getModel("C1TableModel").getData().C1TableDataSet[SelC1pIndex];
			if (IGFR === true) {
				RowObj.UserCheck1 = "";
				RowObj.IgFurun = "Y"
					//tableData.getRows()[this.SelC1Index].getCells()[1].setEditable(false);
			} else {
				RowObj.UserCheck1 = "true";
				RowObj.IgFurun = ""
					//tableData.getRows()[this.SelC1Index].getCells()[1].setEditable(true);
			}

			this.getView().getModel("C1TableModel").refresh(true);
		},

		CheckDateC1: function (oEvent) {
			var that = this;
			var tableData = that.getView().byId("C1Table");
			var CheckAgainOn = oEvent.getSource().getValue();
			var SelC1pIndex = tableData.getSelectedIndex();
			if (CheckAgainOn === "0000-00-00") {
				CheckAgainOn = "";
			} else {
				CheckAgainOn = CheckAgainOn;
			}
			if (SelC1pIndex !== -1) {
				var RowObj = this.getView().byId("C1Table").getModel("C1TableModel").getData().C1TableDataSet[SelC1pIndex];
				RowObj.ChkAgain = CheckAgainOn;
				//var CheckAgainOn = tableData.getRows()[this.SelC1Index].getCells()[1].getValue();

				if (CheckAgainOn !== "") {
					RowObj.UserCheck2 = "";
					//tableData.getRows()[this.SelC1Index].getCells()[2].setEditable(false);

				} else {
					RowObj.UserCheck2 = "true";
					//tableData.getRows()[this.SelC1Index].getCells()[2].setEditable(true);

				}

				this.getView().getModel("C1TableModel").refresh(true);
			}

		},
		onSuggestionWBS: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var proj = this.byId("inpProj").getValue();

			var oSource = oEvent.getSource();

			var aFilters = [];

			aFilters.push(new Filter("Zposid", sap.ui.model.FilterOperator.Contains, sTerm));
			if (proj !== "") {
				aFilters.push(new Filter("Zpspid", sap.ui.model.FilterOperator.Contains, proj));
			}
			aFilters.push(new Filter("SysId", sap.ui.model.FilterOperator.EQ, "COMPASS"));
			aFilters.push(new Filter("AutoClsd", sap.ui.model.FilterOperator.NE, "Y"));

			if (this.flagCompass !== null) {
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, this.flagCompass),
					new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, this.flagCompass)
				], false));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionWBSC1: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");

			var oSource = oEvent.getSource();

			var aFilters = [];

			aFilters.push(new Filter("Zposid", sap.ui.model.FilterOperator.Contains, sTerm));

			aFilters.push(new Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1"));

			if (this.flag !== null) {
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.EQ, this.flag),
					new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.EQ, this.flag)
				], false));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionProj: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();

			var aFilters = [];

			aFilters.push(new Filter("SysId", sap.ui.model.FilterOperator.Contains, "COMPASS"));
			aFilters.push(new Filter("Zpspid", sap.ui.model.FilterOperator.Contains, sTerm));

			// var aFilters = new sap.ui.model.Filter({
			// 	filters: [
			// 		new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.Contains, sTerm),
			// 		new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "COMPASS")
			// 	],
			// 	and: true
			// });
			// if(this.flagCompass!== null){
			// aFilters.push(new sap.ui.model.Filter([
			// 					new sap.ui.model.Filter("WBSOWNER1", sap.ui.model.FilterOperator.EQ, this.flagCompass),
			// 					new sap.ui.model.Filter("FIN_APP", sap.ui.model.FilterOperator.EQ, this.flagCompass)
			// 				], false));
			// }
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);

			// var oDta = this.getOwnerComponent().getModel("Auto_WBS_Closure");
			// var that = this;
			// debugger;

			// oDta.read("/ZCDS_AUTO_WBS_CLSSet", {
			// 	filters: [aFilters],
			//             urlParameters: {
			//                 "$top": 500
			//             },
			// 	success: function (oData, oResponse) {
			// 		that.CompassPspid = [];
			// 		that.CompassPspidunique = [];
			// 		var x = new JSONModel(oData.results);

			// 		for (var i = 0; i < oData.results.length; i++) {

			// 			if (that.CompassPspid.indexOf(oData.results[i].Zpspid) === -1) {
			// 				// that.CompassPspid.find(o => o.pspid === WBS)
			// 				that.CompassPspid.push(oData.results[i].Zpspid);
			// 				that.CompassPspidunique.push({
			// 					"pspid": oData.results[i].Zpspid
			// 				});
			// 			}
			// 		}
			// 		that.projModel = [];
			// 		that.projModel = new JSONModel(that.CompassPspidunique);
			// 		that.byId("inpProj").setSuggestionItems(that.projModel, "namedmodel");
			// 		oSource.getBinding("suggestionItems").filter(aFilters);
			// 		BusyIndicator.hide();
			// 	},
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });
			// var data = [...new Map(oData.d.results.map(item => [item["Iwono"], item])).values()];

		},
		onSuggestionPR: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			// var proj = this.byId("inpProj").getValue();
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.Contains, sTerm),
					// new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.Contains, proj),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "COMPASS")
				],
				and: true
			});

			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionCCodeC1: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "C1")
				],
				and: true
			});

			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionFA: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			// var proj = this.byId("inpProj").getValue();
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.Contains, sTerm),
					// new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.Contains, proj),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "COMPASS")
				],
				and: true
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionFAC1: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("FinApp", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "C1")
				],
				and: true
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onInputValidation: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			//get the field ID
			var fieldid = oEvent.getParameter("id");
			if (newValue === "") {
				sap.ui.getCore().byId(fieldid).setValueState("Error");
				sap.ui.getCore().byId(fieldid).setValueStateText("Please enter the value.");
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");
			}
		},
		onInputValid: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			//get the field ID
			var fieldid = oEvent.getParameter("id");
			if (newValue === "") {
				// sap.ui.getCore().byId(fieldid).setValueState("Error");
				// sap.ui.getCore().byId(fieldid).setValueStateText("Please enter the value.");
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");
			}
		},
		onSuggestionPRC1: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Wbsowner1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "C1")
				],
				and: true
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		}

	});

});