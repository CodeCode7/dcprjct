sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Core",
	"sap/ui/layout/HorizontalLayout",
	"sap/ui/layout/VerticalLayout",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Label",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/BusyIndicator", "sap/m/Token",
	"sap/ui/model/json/JSONModel", "sap/ui/model/odata/v2/ODataModel",
	"sap/m/SearchField",
	"sap/m/MessageBox",
	"OppData/model/formatter"

], function (Controller, Core, HorizontalLayout, VerticalLayout, Dialog, DialogType, Button, ButtonType, Label, MessageToast, Text,
	TextArea, Filter, FilterOperator, BusyIndicator, Token, JSONModel, ODataModel, SearchField, MessageBox, formatter) {
	"use strict";

	return Controller.extend("OppData.controller.View1", {
		formatter: formatter,
		onInit: function () {

			this.oModel = this.getOwnerComponent().getModel("oDataModel");

			//set the model on view to be used by the UI controls
			this.getView().setModel(this.oModel);
			/*	var tableData = this.getView().byId("ManageOpportunityTable");
								var x = tableData.getBinding("items");
								var filt = new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.EQ, "NoData");
								x.filter(filt);*/

		},

		// Filter new code

		onSuggestionOppId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.Contains, sTerm),

				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onSuggestionCCODE: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Zbukrs", sap.ui.model.FilterOperator.Contains, sTerm)
					// new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "COMPASS")
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onSuggestionPerAssi: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("PerAsn", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("PerAsnEmail", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onSuggestionStatus: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, sTerm)
					// new sap.ui.model.Filter("PerAsnEmail", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		// Filter new code

		// *****************f4 HelpFilter code Start

		onSuggestionF4CCode: function (oEvent1) {
			var sTerm = oEvent1.getParameter("suggestValue");
			// var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sTerm)
					// new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "C")
				],
				and: false
			});
			oEvent1.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onSuggestionF4PersonAss: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			// var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Cname", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		// onSuggestionF4CCode: function (oEvent) {
		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var oSource = oEvent.getSource();
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sTerm),
		// 			new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, sTerm)
		// 		],
		// 		and: false
		// 	});
		// 	// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		// },

		// onSuggestionF4PersonAss: function (oEvent) {
		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var oSource = oEvent.getSource();
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
		// 			new sap.ui.model.Filter("Cname", sap.ui.model.FilterOperator.Contains, sTerm)
		// 		],
		// 		and: false
		// 	});
		// 	// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		// },

		// var itemProj = this.byId("F4PerAss").getValue();
		// if (itemProj !== "") {
		// 	this.finalFilters.push(new sap.ui.model.Filter("PerAsn", sap.ui.model.FilterOperator.EQ, itemProj));
		// }

		// *****************f4 HelpFilter code End
		addRow: function (oEvent) {

			debugger;
			var oList = this.getView().byId("ManageOpportunityTable");
			var length = oList.getSelectedContexts("tabModel").length;

			if (this.ind === "") {
				if (length > 1) {
					sap.m.MessageToast.show("Please select only one line item at a time");
					return;
				}
			}

			// if (length > 1) {
			// 	sap.m.MessageToast.show("Please select only one line item at a time");
			// 	return;
			// }
			var obj = oList.getSelectedContexts()[0].getObject();
			// obj.Ind = "X";
			var data = oList.getModel("tabModel").getData();

			//	var str = data.toString();

			//	var lastNumber = str.charAt(str.length + 1);

			//var res = data.slice(0, 14 && lastNumber );
			var unqId = data[data.length - 1].UniqId;
			var val = Number(unqId.split("-")[2]);
			var val2 = (unqId).split("-");
			val2.pop(val2[2]);
			val2.push(val + 1);
			//var obj1 = obj;
			var obj1 = {

				ChangedAt: obj.ChangedAt,
				ChangedOn: obj.ChangedOn,

				CrtdOn: obj.CrtdOn,
				CrtdAt: obj.CrtdAt,
				Sysid: obj.Sysid,
				// WiId: obj.WiId,
				Status: obj.Status,
				PrjReqNo: obj.PrjReqNo,
				DoNotprs: obj.DoNotprs,
				DisPos: obj.DisPos,
				DispChCmt: obj.DispChCmt,
				NotPrssCmt: obj.NotPrssCmt,
				TcvVal: obj.TcvVal,
				PerAsnEmail: obj.PerAsnEmail,
				PerAsn: obj.PerAsn,
				OmpEmail: obj.OmpEmail,
				OmpId: obj.OmpId,
				AgmEmail: obj.AgmEmail,
				ActGm: obj.ActGm,
				FinAnl: obj.FinAnl,
				FinEmail: obj.FinEmail,
				PerResp: obj.PerResp,
				PerEmail: obj.PerEmail,
				// SalStage: obj.SalStage,
				Salesstage: obj.Salesstage,

				CasesafeId: obj.CasesafeId,
				Zbukrs: obj.Zbukrs,
				ContModl: obj.ContModl,
				SolTyp: obj.SolTyp,
				Zzsolseid: obj.Zzsolseid,
				Mandt: obj.Mandt,

				OptId: obj.OptId,
				// OptManag: obj.OptManag,

				// ReqNum: obj.ReqNum,

				// Soldto: obj.Soldto,

				ind: "X"
			};

			obj1.UniqId = val2.join("-");

			oList.getModel("tabModel").getData().push(obj1);
			oList.getModel("tabModel").refresh(true);

			if (this.ind === "") {
				oList.getSelectedItem().setSelected(false);
			}

			this.ind = "X";
			oList.getItems()[oList.getItems().length - 1].setSelected(true);

		},
		// 		// **************************Code for Search functionality************************************
		onSearch: function () {
			var Model1 = new JSONModel([]);
			var tableId = this.getView().byId("ManageOpportunityTable");
			tableId.setModel(Model1, "tabModel");

			this.selOppId = [];
			// this.selChangedate = [];
			this.selCompany = [];
			this.selStatus = [];
			this.selPA = [];

			var that = this;
			// tableData.clearSelection();
			this.finalFilters = [];
			this.ind = "";
			var itemProj = this.byId("inpOppId").getValue();
			if (itemProj !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.EQ, itemProj));
			}

			var itemProj = this.byId("inpCcode").getValue();
			if (itemProj !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("Zbukrs", sap.ui.model.FilterOperator.EQ, itemProj));
			}

			var fromDate = this.byId("DRS3").getProperty("dateValue");
			var toDate = this.byId("DRS3").getProperty("secondDateValue");
			if (fromDate !== null && toDate !== null) {
				// debugger;
				this.finalFilters.push(new sap.ui.model.Filter("CrtdOn", sap.ui.model.FilterOperator.BT, fromDate, toDate));

			}

			var itemProj = this.byId("inpPerAss").getValue();
			if (itemProj !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("PerAsn", sap.ui.model.FilterOperator.EQ, itemProj));
			}

			var itemProj = this.byId("inpStatus").getValue();
			if (itemProj !== "") {
				this.finalFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, itemProj));
			}

			// if (this.selOppId) {
			// 	// for (var i = 0; i < this.selWBSNumber.length; i++) {
			// 	var items = this.byId("inpOppId").getSelectedItems();
			// 	for (var i = 0; i < items.length; i++) {
			// 		var OppID = items[i].getKey();
			// 		this.finalFilters.push(new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.EQ, OppID));
			// 	}
			// }
			// if (this.selChangedate) {
			// var	oDRS3 = this.byId("DRS3").getSelectedItems();
			// for (i = 0; i < itemsPR.length; i++) {
			// 	var Changedate = itemsPR[i].getKey();
			// this.finalFilters.push(new sap.ui.model.Filter("DRS3", sap.ui.model.FilterOperator.EQ, Changedate));
			// 	}
			//  }

			// if (this.selCompany) {
			// 	var itemsFA = this.byId("inpCcode").getSelectedItems();
			// 	for (i = 0; i < itemsFA.length; i++) {
			// 		var selCompany = itemsFA[i].getKey();
			// 		this.finalFilters.push(new sap.ui.model.Filter("Zbukrs", sap.ui.model.FilterOperator.EQ, selCompany));
			// 	}
			// }
			// if (this.selStatus) {
			// 	var itemstat = this.byId("status").getSelectedItems();
			// 	for (i = 0; i < itemstat.length; i++) {
			// 		var Status = itemstat[i].getKey();
			// 		this.finalFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, Status));
			// 	}

			// }
			// if (this.selPA) {
			// 	var itemsPA = this.byId("inpPerAss").getSelectedItems();
			// 	for (i = 0; i < itemsPA.length; i++) {
			// 		var PersonAssigned = itemsPA[i].getKey();
			// 		this.finalFilters.push(new sap.ui.model.Filter("PerAsn", sap.ui.model.FilterOperator.EQ, PersonAssigned));
			// 	}
			// }

			if (this.finalFilters.length !== 0) {
				var oDta = this.getOwnerComponent().getModel("oDataModel");

				BusyIndicator.show();
				oDta.read("/OPPORTUNITYID_NOTIFICATIONSet", {
					filters: this.finalFilters,
					success: function (oData, oResponse) {
						BusyIndicator.hide();
						// this.byId("ManageOpportunityTable").setVisibleRowCount(oData.results.length);
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}

						var tableModel = new JSONModel(oData.results);
						var tableData = that.getView().byId("ManageOpportunityTable");
						tableData.setModel(tableModel, "tabModel");
						//	var x = tableData.getBinding("items");
						//	x.filter(that.finalFilters);

					},
					error: function (err) {
						BusyIndicator.hide();
					}
				});
			} else {

				// this.initiateCompass();
				this.onInit();
				BusyIndicator.hide();
			}

		},
		onGarbageValue: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				oInput.setValueState("Error");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				oInput.setValueState("None");
			}
		},

		// onInputValidation: function (oEvent) {
		// 	var newValue = oEvent.getParameter("value");
		// 	//get the field ID
		// 	var fieldid = oEvent.getParameter("id");
		// 	if (newValue === "") {
		// 		sap.ui.getCore().byId(fieldid).setValueState("Error");
		// 		sap.ui.getCore().byId(fieldid).setValueStateText("Please enter the value.");
		// 	} else {
		// 		sap.ui.getCore().byId(fieldid).setValueState("None");
		// 	}
		// },

		// **************************************************************
		// ********************Code for Add Line items********************************
		// onAddLine: function (oEvent) {

		// 	sap.ui.core.BusyIndicator.show(0);

		// 	var sRevenueTable = this.getView().byId("idTravel").getVisible();
		// 	// var sInternalTable = this.getView().byId("idInternal").getVisible();

		// 	if (sRevenueTable === true) {
		// 		var oModel = this.getView().getModel();
		// 		var itemRow = {
		// 			// "Requestid": "",
		// 			// "Iwo": "10105",
		// 			// "IwoguidItem": "",
		// 			// "Item": "",
		// 			// "ErrType": "W",
		// 			// "AccntMgr": "",
		// 			// "ProjManager": [],
		// 		};
		// 		var itab = oModel.getProperty("/iwoTabTravel");
		// 		itab.push(itemRow);
		// 		oModel.setProperty("/iwoTabTravel", itab);
		// 		var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
		// 		var sSeqNum = 1;
		// 		for (var i = 0; i < sRowCount; i++) {
		// 			this.getView().byId("idTravel").getModel().getData().iwoTabTravel[i].Posnr = String(sSeqNum);
		// 			//Defaulting Payment Term on Sold To Customer at Header to Item Level
		// 			this.getView().byId("idTravel").getModel().getData().iwoTabTravel[i].Zterm = this.getView().byId("idPaymt").getValue();
		// 			sSeqNum = sSeqNum + 1;
		// 		}

		// 		sap.ui.core.BusyIndicator.hide();
		// 	}
		// 	// else if (sInternalTable === true) {
		// 	// 	var oModel = this.getView().getModel();
		// 	// 	var itemRow = {
		// 	// 		// "Requestid": "",
		// 	// 		// "Iwo": "10105",
		// 	// 		// "IwoguidItem": "",
		// 	// 		// "Item": "",
		// 	// 		// "ErrType": "W",
		// 	// 		// "AccntMgr": "",
		// 	// 		// "ProjManager": [],
		// 	// 	};
		// 	// 	var itab = oModel.getProperty("/iwoTabTravel");
		// 	// 	itab.push(itemRow);
		// 	// 	oModel.setProperty("/iwoTabTravel", itab);
		// 	// 	var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
		// 	// 	var sSeqNum = 1;
		// 	// 	for (var i = 0; i < sRowCount; i++) {
		// 	// 		this.getView().byId("idInternal").getModel().getData().iwoTabTravel[i].Posnr = String(sSeqNum);
		// 	// 		this.getView().byId("idInternal").getModel().getData().iwoTabTravel[i].Pstyv = "ZPRJ";
		// 	// 		sSeqNum = sSeqNum + 1;
		// 	// 	}

		// 	// 	sap.ui.core.BusyIndicator.hide();
		// 	// }

		// },

		// save option********************************************************************************

		// save option******************************************************************************************

		// onClick: function (oEvent) {
		// 	debugger;
		// 	var check = oEvent.getParameter("selected");
		// 	if (check === true) {

		// 		var X = this.byId("ManageOpportunityTable").getSelectedIndex();
		// 		this.byId("ManageOpportunityTable").getRows()[X].getCells()[16].setEditable(true);

		// 	} else {

		// 		return "";
		// 	}

		// },

		// checkDone: function (oEvent) {

		// 	debugger;
		// 	var check = oEvent.getParameter("selected");
		// 	if (check === true) {

		// 		// var X = this.byId("ManageOpportunityTable");
		// 		this.getView().byId("id1")setEnabled(true);
		// 		// this.byId("id1").setEditable(true);

		// 	} else {
		// 		// this .getView().byId("id1").setEnabled(false);
		// 		// this.getView().byId("id1").getSelectedItem().setEditable(true);
		// 	}
		// },

		checkDone: function (oEvent) {

			// var check = oEvent.getSource().getSelectedIndices();

			var check = oEvent.getParameter("selected");
			// var cxt = check.getBindingContext();
			// var obj = cxt.getObject();
			if (oEvent.oSource.oParent.getSelected() === false) {
				oEvent.oSource.setSelected(false);
				return;
			}
			var rowData = this.byId("ManageOpportunityTable").getSelectedItem();
			if (check === true) {
				// this.byId("ManageOpportunityTable").getRows()[obj].getCells()[16].setEditable(true);
				// this.getView().byId("id1").setEnabled(true);

				rowData.getCells()[15].setEditable(true);

			} else {
				rowData.getCells()[15].setEditable(false);
			}

			// for (var i = 0; i < rowData.length; i++) {

			// }

		},

		initiate: function () {

			// var that = this;

			// var oDta = this.getOwnerComponent().getModel("oDataModel");

			BusyIndicator.show();
			// oDta.read("/HEADER_CCODESet", {
			// 	// filters: this.finalFilters,
			// 	success: function (oData, oResponse) {
			// 		BusyIndicator.hide();

			// 		if (oData === null || oData === undefined) {
			// 			var sMessage = "WARNING. Received a null or undefined response object.";
			// 			sap.m.MessageToast.show(sMessage);
			// 			return;
			// 		}
			// 		var result = oData.results;

			// 		// var i;

			// 		// // for (i = 0; i < result.length; i++) {
			// 		// // 	// text += result[i] + "<br>";
			// 		// 	result[i].NOTPRSSCMT = "";
			// 		// }

			// 		that.tableModel = new JSONModel(result);
			// 		this.getView().byId("ManageOpportunityTable").setModel(that.tableModel);
			// 		// that.getView().getModel("appView").setProperty("/oCount", oData.results.length);
			// 	}.bind(this),
			// 	error: function (err) {
			// 		BusyIndicator.hide();
			// 	}
			// });

		},

		// Save button code start
		onSave: function (evt1) {

			var id = this.byId("ManageOpportunityTable");
			var items = id.getSelectedItems();
			// var oppOwner = id.getSelectedItem().getCells()[2].getValue();
			var cocode = id.getSelectedItem().getCells()[4].getValue();
			if (cocode === "") {
				sap.m.MessageToast.show("Please Enter Mandatory Fields ");

				if (cocode === "") {
					id.getSelectedItem().getCells()[6].setValueState("Error");
					// id.getSelectedItem().getCells()[6].setEditable(true);
				}
				return;
			}

			var id = this.byId("ManageOpportunityTable");
			var items = id.getSelectedItems();
			var oModel = this.getOwnerComponent().getModel("oDataModel");

			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["foo"]);
			var mParameters = {
				groupId: "foo",
				success: function (oResponse) {
					// debugger;
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Data saved", {
						duration: 5000
					});

				},

				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			};

			for (var i = 0; i < items.length; i++) {
				// var a = aContexts[i]; // getting selected row number.
				var obj = items[i].getBindingContext("tabModel").getObject();
				var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj.UniqId + "',OptId='" + obj.OptId + "')";
				if (obj.ind === "X") {
					sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet";
				}
				var oData = {
					"d": {

						"OptId": obj.OptId,
						"DispChCmt": obj.DispChCmt,
						"PerAsn": obj.PerAsn,
						"UniqId": obj.UniqId,
						"Zbukrs": obj.Zbukrs,
						"NotPrssCmt": obj.NotPrssCmt
					}
				};

				if (obj.ind === "X") {
					delete(obj.ind);
					oData = {
						"d": {
							"Mandt": obj.Mandt,
							"UniqId": obj.UniqId,
							"OptId": obj.OptId,
							"Zzsolseid": obj.Zzsolseid,
							"SolTyp": obj.SolTyp,
							"ContModl": obj.ContModl,
							"Zbukrs": obj.Zbukrs,
							"CasesafeId": obj.CasesafeId,
							"Salesstage": obj.Salesstage,
							"PerResp": obj.PerResp,
							"PerEmail": obj.PerEmail,
							"FinAnl": obj.FinAnl,
							"FinEmail": obj.FinEmail,
							"ActGm": obj.ActGm,
							"AgmEmail": obj.AgmEmail,
							"OmpId": obj.OmpId,
							"OmpEmail": obj.OmpEmail,
							"PerAsn": obj.PerAsn,
							"PerAsnEmail": obj.PerAsnEmail,
							"TclVal": obj.TclVal,
							"DisPos": obj.DisPos,
							"DispChCmt": obj.DispChCmt,
							"DoNotprs": obj.DoNotprs,
							"NotPrssCmt": obj.NotPrssCmt,
							"PrjReqNo": obj.PrjReqNo,
							"Status": obj.Status,
							"WiId": obj.WiId,
							"Sysid": obj.Sysid,
							"CrtdOn": obj.CrtdOn,
							"CrtdAt": obj.CrtdAt,
							"ChangedOn": obj.ChangedOn,
							"ChangedAt": obj.ChangedAt

						}
					};
					oModel.create(sPath1, oData, mParameters);
				} else {
					oModel.update(sPath1, oData, mParameters);
				}

			}

			oModel.submitChanges(mParameters);

		},

		// },

		// End of save button

		onSelect: function (evt) {
			this.ary = []
				//	evt.oSource.getSelectedItems()[0].getBindingContext("tabModel").getObject()
				/*	var selItems = evt.oSource.getSelectedItems();
					for(var i=0;i<selItems.length;i++){
						
						var obj = selItems[i].getBindingContext("tabModel").getObject();
						
						this.ary.push(obj);
					}*/

			var tabItems = this.byId("ManageOpportunityTable").getItems();
			for (var j = 0; j < tabItems.length; j++) {

				var selected = tabItems[j].getSelected();

				if (selected === false) {
					tabItems[j].getCells()[14].setSelected(false);
					tabItems[j].getCells()[15].setEditable(false);
				} else {
					var obj = tabItems[j].getBindingContext("tabModel").getObject();

					this.ary.push(obj);
				}

			}

			this.byId("NPR").setEnabled(true);
			this.byId("MEP1").setEnabled(true);

		},

		onPress: function (oEvent) {
			debugger;
			var id = this.byId("ManageOpportunityTable");
			var items = id.getSelectedItems();
			// var oppOwner = id.getSelectedItem().getCells()[2].getValue();
			var cocode = id.getSelectedItem().getCells()[4].getValue();
			if (cocode === "") {
				sap.m.MessageToast.show("Company Code Fields is Mandator ");

				if (cocode === "") {
					id.getSelectedItem().getCells()[4].setValueState("Error");
					// id.getSelectedItem().getCells()[6].setEditable(true);
				}

				// if( !cocode == ""){

				// 	sap.m.MessageToast.show("Company Code");
				// }
				return;
			}

			var that = this;
			var rowSelected = this.getView().byId("ManageOpportunityTable");
			var rowid = rowSelected.getSelectedItems();
			var arry = [];
			var navAryy1 = [];
			var logicInd = "";
			var logicInd1 = "";
			// var org = {};
			var Action = "";
			for (var i = 0; i < rowid.length; i++) {

				var org = {};
				var obj = rowid[i].getBindingContext("tabModel").getObject();
				arry.push(obj);

				// var obj = rowid[i].getBindingContext("tabModel").getObject();

				if (obj.Sysid === "COMPASS") {
					Action = "create";
				}
				if (obj.Sysid === "C1") {
					Action = "createC1";
				}

				// arry.push(obj);
				org.Zbukrs = obj.Zbukrs;
				org.UniqId = obj.UniqId;
				org.CasesafeId = obj.CasesafeId;
				org.OptId = obj.OptId;
				navAryy1.push(org);
				// obj.clear();
				// if (obj.SolTyp.toUpperCase() === "UP SELL" || obj.SolTyp.toUpperCase() === "RENEWAL" || obj.SolTyp.toUpperCase() ===
				// 	"RENEWAL+NEW WORK") {

				if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE" ||
					obj.DisPos.toUpperCase() === "") {

					logicInd = "X";

				} else {
					logicInd1 = "Y";
				}

			}
			// var flag = "";
			// ***********
			// var Create = "X";
			// ***********
			if (logicInd === "X" && logicInd1 === "Y") {

				// flag = "X"
			}

			var counts = {};
			var a = arry;

			var track = {};
			var op = [];
			var ind = ""

			// debugger;
			// ************************
			var results = a.reduce((op, inp) => {

				if (!track[inp.OptId]) {
					op.push(inp)
					track[inp.OptId] = inp
						//	ind="Y"
				} else {
					//	ind = "X"
				}
				return op
			}, [])

			if (results.length > 1) {
				sap.m.MessageToast.show("Dont select Different Opprtunity Id");
				return;
			}
			// ***************************
			var results = a.reduce((op, inp) => {

				if (!track[inp.Zbukrs]) {
					op.push(inp)
					track[inp.Zbukrs] = inp
						//	ind="Y"
				} else {
					//	ind = "X"
				}
				return op
			}, [])

			if (results.length > 1) {
				sap.m.MessageToast.show("Dont select Different Company codes");
				return;
			}
			// ***************************

			var navAryy = JSON.stringify(navAryy1);
			/*	if (this.SolTyp.toUpperCase() === "NEW LOGO" || this.SolTyp.toUpperCase() === "CROSS SELL" || this.SolTyp.toUpperCase() ===
					"NEW WORK")*/
			if (logicInd1 === "Y" && logicInd === "") {

				// if (this.SolTyp === "NEW LOGO" || this.SolTyp === "CROSS SELL" || this.SolTyp === "NEW WORK") {

				// MessageBox.information("Do you want to Navigation create new project request .", {
				// 	actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				// 	emphasizedAction: MessageBox.Action.OK,
				// 	onClose: function (sAction) {
				// 		if (sAction === "OK") {

				var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
				navigationService.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: Action
					},
					params: {

						"navAryy": navAryy
					}

				});

			} else {

				var dialog = new Dialog({
					title: 'Warning - Disposition Change',
					type: 'Message',
					content: [
						new Label({
							text: 'Please enter reason for changing disposition',
							labelFor: 'submitDialogTextarea'
						}),
						new TextArea('submitDialogTextarea', {
							liveChange: function (oEvent) {
								var sText = oEvent.getParameter('value');
								var parent = oEvent.getSource().getParent();

								parent.getBeginButton().setEnabled(sText.length > 0);
							},
							width: '100%',
							placeholder: 'Disposition Change comments (Mandatory)'
						})
					],
					beginButton: new Button({
						text: 'Submit',
						enabled: false,
						press: function (evt) {
							debugger;
							var text = evt.oSource.oParent.getContent()[1].getValue();

							// var children = create.concat(text);
							var create = "X";

							var children = create.concat(text);
							// var children = text.endsWith("X");

							var id = that.byId("ManageOpportunityTable");
							var items = id.getSelectedItems();
							var oModel = that.getOwnerComponent().getModel("oDataModel");

							oModel.setUseBatch(true);
							oModel.setDeferredGroups(["foo"]);
							var mParameters = {
								groupId: "foo",
								success: function (oResponse) {

									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("Data saved", {
										// duration: 5000

									});

									var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
									navigationService.toExternal({
										target: {
											semanticObject: "DXCGPRS",
											action: Action
										},
										params: {

											"navAryy": navAryy
										}

									});

								},

								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										// duration: 5000
									});
								}
							};

							for (var k = 0; k < items.length; k++) {
								// var a = aContexts[i]; // getting selected row number.
								var obj1 = items[k].getBindingContext("tabModel").getObject();

								var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj1.UniqId + "',OptId='" + obj1.OptId + "')/";

								var oData = {
									"d": {

										"OptId": obj1.OptId,
										"DispChCmt": children,
										//	"PerAsn": obj.PerAsn,
										"UniqId": obj1.UniqId,
										// "DoNotprs": children
										///	"Zbukrs": obj.Zbukrs,
										//	"NotPrssCmt": obj.NotPrssCmt
									}
								};

								oModel.update(sPath1, oData, mParameters);
							}
							oModel.submitChanges(mParameters);

						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});

				dialog.open();

			}

		},

		onPress1: function () {

			var id = this.byId("ManageOpportunityTable");
			var items = id.getSelectedItems();
			// var oppOwner = id.getSelectedItem().getCells()[2].getValue();
			var cocode = id.getSelectedItem().getCells()[4].getValue();
			if (cocode === "") {
				sap.m.MessageToast.show("Company Code Fields is Mandator ");

				if (cocode === "") {
					id.getSelectedItem().getCells()[6].setValueState("Error");
					// id.getSelectedItem().getCells()[6].setEditable(true);
				}
				return;
			}

			var that = this;

			var rowSelected = this.getView().byId("ManageOpportunityTable");
			var rowid = rowSelected.getSelectedItems();
			var arry = [];
			var navAryy1 = [];
			var logicInd = "";
			var logicInd1 = "";

			for (var i = 0; i < rowid.length; i++) {
				var org = {};
				var obj = rowid[i].getBindingContext("tabModel").getObject();
				arry.push(obj);
				org.Zbukrs = obj.Zbukrs;
				org.UniqId = obj.UniqId;
				org.CasesafeId = obj.CasesafeId;
				org.OptId = obj.OptId;
				navAryy1.push(org);

				// if (obj.SolTyp.toUpperCase() === "UP SELL" || obj.SolTyp.toUpperCase() === "RENEWAL" || obj.SolTyp.toUpperCase() ===
				// 	"RENEWAL+NEW WORK")
				// var flag = "";
				if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE" ||
					obj.DisPos.toUpperCase() === "")

				{
					logicInd = "X";
				} else {
					logicInd1 = "Y"
				}

			}

			if (logicInd === "X" && logicInd1 === "Y") {
				// flag = "Y"
			}

			var counts = {};
			var a = arry;

			var track = {};
			var op = [];
			var ind = ""

			var results = a.reduce((op, inp) => {

				if (!track[inp.OptId]) {
					op.push(inp)
					track[inp.OptId] = inp
						//	ind="Y"
				} else {
					//	ind = "X"
				}
				return op
			}, [])

			if (results.length > 1) {
				sap.m.MessageToast.show("Dont select Different Opprtunity Id");
				return;
			}

			var results = a.reduce((op, inp) => {

				if (!track[inp.Zbukrs]) {
					op.push(inp)
					track[inp.Zbukrs] = inp
						//	ind="Y"
				} else {
					//	ind = "X"
				}
				return op
			}, [])

			if (results.length > 1) {
				sap.m.MessageToast.show("Dont select Different Company codes");
				return;
			}

			// var results = a.reduce((op, inp) => {
			// 	if (!track[inp.Zbukrs]) {
			// 		op.push(inp)
			// 		track[inp.Zbukrs] = inp
			// 	} else {
			// 		ind = "X"
			// 	}
			// 	return op
			// }, [])

			// if (ind === "X") {
			// 	sap.m.MessageToast.show("dsjkfdjskds");
			// 	return;
			// }

			/*	if (this.SolTyp.toUpperCase() === "NEW LOGO" || this.SolTyp.toUpperCase() === "CROSS SELL" || this.SolTyp.toUpperCase() ===
					"NEW WORK")*/
			var navAryy = JSON.stringify(navAryy1);
			if (logicInd === "X" && logicInd1 === "") {

				var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
				navigationService.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "manage"
					},
					params: {

						"navAryy": navAryy
					}

				});

			} else {

				var dialog = new Dialog({
					title: 'Warning - Disposition Change',
					type: 'Message',
					content: [
						new Label({
							text: 'Please enter reason for changing disposition',
							labelFor: 'submitDialogTextarea'
						}),
						new TextArea('submitDialogTextarea', {
							liveChange: function (oEvent) {
								var sText = oEvent.getParameter('value');
								var parent = oEvent.getSource().getParent();

								parent.getBeginButton().setEnabled(sText.length > 0);
							},
							width: '100%',
							placeholder: 'Disposition Change comments (Mandatory)'
						})
					],
					beginButton: new Button({
						text: 'Submit',
						enabled: false,
						press: function (evt) {
							debugger;
							var text = evt.oSource.oParent.getContent()[1].getValue();

							var create = "Y";

							var children = create.concat(text);
							var id = that.byId("ManageOpportunityTable");
							var items = id.getSelectedItems();
							var oModel = that.getOwnerComponent().getModel("oDataModel");

							oModel.setUseBatch(true);
							oModel.setDeferredGroups(["foo"]);
							var mParameters = {
								groupId: "foo",
								success: function (oResponse) {
									debugger;
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("Data Saved", {
										// duration: 5000

									});

									var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
									navigationService.toExternal({
										target: {
											semanticObject: "DXCGPRS",
											action: "manage"
										},
										params: {

											"navAryy": navAryy
										}

									});

								},

								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							};

							for (var k = 0; k < items.length; k++) {
								// var a = aContexts[i]; // getting selected row number.
								var obj1 = items[k].getBindingContext("tabModel").getObject();

								var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj1.UniqId + "',OptId='" + obj1.OptId + "')/";

								var oData = {
									"d": {
										"OptId": obj1.OptId,
										"DispChCmt": children,
										"UniqId": obj1.UniqId,
										// "DoNotprs": flag
									}
								};

								oModel.update(sPath1, oData, mParameters);
							}
							oModel.submitChanges(mParameters);

						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});

				dialog.open();

			}

		},

	});

});