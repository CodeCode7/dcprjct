sap.ui.define([
	], function () {
		//"use strict";

		var formatterObj = {
			/**
			 * Rounds the currency value to 2 digits
			 *
			 * @public
			 * @param {string} sValue value to be formatted
			 * @returns {string} formatted currency value with 2 digits
			 */
			currencyValue : function (sValue) {
				if (!sValue) {
					return "";
				}

				return parseFloat(sValue).toFixed(2);
			},
			
			digits: function(val) {
				if(val) {
					return parseFloat(val).toFixed(2);
				}
			},
			
			inputValid:function(val){
				if(val == "X"){
					return true;
				}
				return false;
			},
			
			ModeFn :function(val){
				if(val == "D99"){
					return "None"
				}
				return "Delete"
			},
			
			Date11:function(value){
				if(value == null){
					return ""	
					}
					var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern : "dd MMM yyyy"
					});
					return oDateFormat.format(new Date(value));
				},
			
				
				Date14:function(value){
					if(value == null){
						return ""	
						}
						var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
							pattern : "yyyy-MM-ddT00:00:00"
						});
						return oDateFormat.format(new Date(value));
					},
				
			
			enabledValue:function(val){
				if(val == "X"){
					return false;
				}
				return true;
			},
			
			parseIntREq2:function(val2){
				if(val2 === undefined || val2 === ""){
					return ""
				}
					val2=Number(val2).toFixed(2);  
		             var dec=val2.substring(val2.indexOf("."));
		             val2= val2.substring(0,val2.indexOf(".")).toString();
		             var lastThree = val2.substring(val2.length-3);
		             var otherNumbers = val2.substring(0,val2.length-3);
		             if(otherNumbers != '')
		                      lastThree = ',' + lastThree;
		             val2 = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree; 
		             return val2;
			},
			
			parseIntREq1:function(val2){
				if(val2 === undefined || val2 === ""){
					return ""
				}
				
				val2=Number(val2).toFixed(2);  
	             var dec=val2.substring(val2.indexOf("."));
	             val2= val2.substring(0,val2.indexOf(".")).toString();
	             var lastThree = val2.substring(val2.length-3);
	             var otherNumbers = val2.substring(0,val2.length-3);
	             if(otherNumbers != '')
	                      lastThree = ',' + lastThree;
	             val2 = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree; 
	             return val2;
			},
			
			fnAmount:function(val2){
				if(val2 === undefined || val2 === ""){
					return ""
				}
				val2=Number(val2).toFixed(2);  
	             var dec=val2.substring(val2.indexOf("."));
	             val2= val2.substring(0,val2.indexOf(".")).toString();
	             var lastThree = val2.substring(val2.length-3);
	             var otherNumbers = val2.substring(0,val2.length-3);
	             if(otherNumbers != '')
	                      lastThree = ',' + lastThree;
	             val2 = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree; 
		             return "₹ "+val2;
			},
			
			fnAmount1:function(val2){
				if(val2 === undefined || val2 === ""){
					return ""
				}
				val2=Number(val2).toFixed(2);  
	             var dec=val2.substring(val2.indexOf("."));
	             val2= val2.substring(0,val2.indexOf(".")).toString();
	             var lastThree = val2.substring(val2.length-3);
	             var otherNumbers = val2.substring(0,val2.length-3);
	             if(otherNumbers != '')
	                      lastThree = ',' + lastThree;
	             val2 = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree; 
		             return "Value : "+"₹ "+val2;
			},
			
			DT2digit : function(n){
				return n < 10 ? '0' + n : n;
			},
			setDateDashFormat : function(val){
				var day = formatterObj.DT2digit(val.getDate());
				var month = formatterObj.DT2digit(val.getMonth() + 1);
				var year = formatterObj.DT2digit(val.getFullYear());
				var date = year + "-" + month + "-" + day;
				return date;
			},
			setDate : function(val){
				var day = formatterObj.DT2digit(val.getDate());
				var month = formatterObj.DT2digit(val.getMonth() + 1);
				var year = formatterObj.DT2digit(val.getFullYear());
				var date = day + "." + month + "." + year;
				return date;
			},
			formatDate : function (sValue) {
				
				if (!sValue) {
					return "";
				}
				else if(sValue instanceof Date){
					
					return formatterObj.setDate(sValue);
				}
				else{
					
					var date = parseInt(sValue.match(/\d/g).join(''),10);
					return formatterObj.setDate(new Date(date));
				}
				
			},
			
			iconVisiblFn:function(val){
				if(val == "D99"){
					return false
				}
				return true
			},
			
			ModeFn :function(val){
				if(val == "D99"){
					return "None"
				}
				return "Delete"
			},
			
			Date1:function(value){
				if(value == null){
					return ""	
					}
					var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
						pattern : "dd MMM yyyy"
					});
					return oDateFormat.format(new Date(value));
				},
			
				
				Date4:function(value){
					if(value == null){
						return ""	
						}
						var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
							pattern : "dd MMM yyyy"
						});
						return oDateFormat.format(new Date(value));
					},
				
			fnStatus:function(val){
				if(val === "A"){
					return "Not Yet Processed"
				}else if (val=== "B"){
					return "partially Processed"
				}else if (val === "C"){
					return "Completely Processed"
				}
				return "Not Relevant"
			},
			
			colorFn:function(val){
				if(val == "2"){
					return "#ff1a1a"
				}
				return "#009933"
			},
			
			Netduestatus:function(val){
				if(val == "2"){
					return "sap-icon://time-overtime"
				}
				return "sap-icon://future"
				
			},
			
			mobileValid:function(val){
				if(val !=null){
					 return val.slice(0,5) + "XXXX"
				}
				
			},
			
			MakingChargesTotal:function(val,val1,val2,val3,val4,val5,val6,val7,val8,val9){
				var total = parseFloat(val)+parseFloat(val1)+parseFloat(val2)+parseFloat(val3)+parseFloat(val4)+parseFloat(val5)+parseFloat(val6)+parseFloat(val7)+parseFloat(val8)+parseFloat(val9)
				return total.toFixed(2).toString()
			},
			
			netValue:function(value,quantity){
				return parseInt(value) * parseInt(quantity);
			}
		};
		return formatterObj;
	}
);