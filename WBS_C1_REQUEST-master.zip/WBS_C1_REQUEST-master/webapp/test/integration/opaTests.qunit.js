/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"WBS/C1/WbsC1Request/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});