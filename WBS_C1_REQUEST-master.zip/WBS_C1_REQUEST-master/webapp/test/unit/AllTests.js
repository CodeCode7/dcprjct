sap.ui.define([
	"WBS/C1/WbsC1Request/test/unit/controller/View1.controller"
], function () {
	"use strict";
});