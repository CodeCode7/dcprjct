/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"WBS/C1/WbsC1Request/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});