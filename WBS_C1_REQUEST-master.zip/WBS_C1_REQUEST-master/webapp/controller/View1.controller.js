sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/Token",
	"sap/m/Dialog",
	"sap/ui/table/RowAction",
	"sap/ui/table/RowActionItem",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/table/library",
	"sap/ushell/services/UserInfo",
	"WBS/C1/WbsC1Request/util/Formatter",
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/ui/core/Item",
	"WBS/C1/WbsC1Request/util/ErrorFormatter"
], function (Controller, MessageToast, MessageBox, Fragment, JSONModel, Token, Dialog, RowAction, RowActionItem, Filter, FilterOperator,
	library,
	UserInfo, Formatter, Label, TextArea, Item) {
	"use strict";
	return Controller.extend("WBS.C1.WbsC1Request.controller.View1", {
		formatter: Formatter,

		onInit: function () {
			var oView = this.getOwnerComponent();

			// rohit - set multi input email model
			var that = this;
			var emptyModel = new sap.ui.model.json.JSONModel([]);
			sap.ui.getCore().setModel(emptyModel, "sug");
			// end of multi input email model
			var autoPop = new JSONModel({
				Requestid: "",
				IwoGuidItem: "",
			});
			oView.setModel(autoPop, "autoPopData");
			this.getView().setModel(new JSONModel({
				"iwoTabTravel": []
			}), "localModel");

			this.getView().setModel(new JSONModel({
				"Items": []
			}), "summaryTabModel");

			var oError = new JSONModel();
			oView.setModel(oError, "oErrorAppView");

			var summ = new JSONModel();
			oView.setModel(summ, "summary");
			var oSoldTo = this.getView().byId('idSoldTo');
			oSoldTo.setSuggestionRowValidator(this.suggestionRowValidator);

			var oPayer = this.getView().byId('idPayer');
			oPayer.setSuggestionRowValidator(this.suggestionRowValidator);

			var oShip = this.getView().byId('idship');
			oShip.setSuggestionRowValidator(this.suggestionRowValidator);

			var oBill = this.getView().byId('idbill');
			oBill.setSuggestionRowValidator(this.suggestionRowValidator);

			var oAgm = this.getView().byId('idAccMan');
			oAgm.setSuggestionRowValidator(this.suggestionRowValidator);

			var oWbs1 = this.getView().byId('idWBS1');
			oWbs1.setSuggestionRowValidator(this.suggestionRowValidator);

			var oWbs2 = this.getView().byId('idWBS2');
			oWbs2.setSuggestionRowValidator(this.suggestionRowValidator);

			var oDraftInvoice = this.getView().byId('idDrftInv');
			oDraftInvoice.setSuggestionRowValidator(this.suggestionRowValidator);

			var oFinaceApp = this.getView().byId('idFinApp');
			oFinaceApp.setSuggestionRowValidator(this.suggestionRowValidator);

			var oProjectAcc = this.getView().byId('idProAc');
			oProjectAcc.setSuggestionRowValidator(this.suggestionRowValidator);

			var oBDS = this.getView().byId('idBillStw');
			oBDS.setSuggestionRowValidator(this.suggestionRowValidator);

			var oInvoiceR = this.getView().byId('idInv');
			oInvoiceR.setSuggestionRowValidator(this.suggestionRowValidator);
			//Inter project Type

			var aAccgmInt = this.getView().byId('idAccManInt');
			aAccgmInt.setSuggestionRowValidator(this.suggestionRowValidator);

			var aWbsInt = this.getView().byId('idWBS1Int');
			aWbsInt.setSuggestionRowValidator(this.suggestionRowValidator);

			var aWbs2Int = this.getView().byId('idWBS2Int');
			aWbs2Int.setSuggestionRowValidator(this.suggestionRowValidator);

			var aDraftIntV = this.getView().byId('idDr');
			aDraftIntV.setSuggestionRowValidator(this.suggestionRowValidator);

			var aFinappInt = this.getView().byId('idFinAppInt');
			aFinappInt.setSuggestionRowValidator(this.suggestionRowValidator);

			var aProjectAccInt = this.getView().byId('idProAcInt');
			aProjectAccInt.setSuggestionRowValidator(this.suggestionRowValidator);

			var aSoldToInt = this.getView().byId('idIntSold');
			aSoldToInt.setSuggestionRowValidator(this.suggestionRowValidator);

			var oMultiInput2 = this.getView().byId('wbsEmail');
			//*** add checkbox validator

			oMultiInput2.addValidator(function (args) {
				if (args.suggestionObject) {
					var key = args.suggestionObject.getCells()[0].getText();
					var text = key + "(" + args.suggestionObject.getCells()[1].getText() + ")";

					return new Token({
						key: key,
						text: text
					});
				}
				return null;
			});
			oMultiInput2.setSuggestionRowValidator(this.suggestionRowValidator);
			// var oModel = this.getView().getModel("oDataModel");
			var oModel = this.getView().getModel("oDataModel").setSizeLimit(180);
			var that = this;
			var oUser = new UserInfo();
			var ouserId = oUser.getId();
			var oViewModel = null;
			// vinu
			if (ouserId != "DEFAULT_USER") {
				var ofullName = oUser.getUser().getFullName();
				var oemail = oUser.getUser().getEmail();
				oViewModel = new JSONModel({
					Owner: ouserId,
					Originator: ouserId,
					Submitter: "",
					ReqDate: new Date().toDateString(),
					email: oemail,
					iwoNo: "",
					Requestid: "",
					Contractid: "",
					System: "",
					oAppType: "",
					RejectType: "",
					IWOAdmin: "",
					reqID: "",
					oErrorCount: 0,
					EstatTxt: "CREATE",
					OriginatorName: ofullName,
					OwnerName: ofullName,
					AdminName: "",
					type: "",
					actionType: "",
					statusCode: "E0001",
					PerfFinPOCNName: "",
					PerfManager: "",
					PerfManagerName: "",
					ProjectManagerName: "",
					ProjManagerName: "",
					OrigFinPOCName: "",
					FrasDis: "",
					FrasBtn: "",
					ProjectType: "",
					ZProjectID: "",
					taskFlg: "",
					//phase2 flag
					EnableflagArktx: "",
					EnableflagZsfdcOppid: "",
					FlagPstyv: "",
					FlagRaKey: "",
					FlagMat: "",
					FlagItemCat: "",
					FlagSDate: "",
					FlagEDate: "",
					FlagPlRevenue: "",
					FlagPlCost: "",
					FlagDip: "",
					FlagCaseId: "",
					FlagLinePay: "",
					FlagWBS: "",
					FlagIndia: "",
					FlagPo: "",
					FlagPoDate: "",
					FlagReCost: "",
					FlagPCS: "",
					FlagIFISCost: "",
					FlagIFSCDes: "",
					FlagPayer: "",
					FlagShipto: "",
					FlagBIllto: "",
					FlagAgm: "",
					FlagWBS1: "",
					FlagWBS2: "",
					FlagFinApp: "",
					SyslineFlag: "",
					StatusCLSD: "",
					FrasDateDis: "",
					downloadBun: ""
						//TitleName: "New Project Request",
				});
				oView.setModel(oViewModel, "appView");
			} else {
				oViewModel = new JSONModel({
					Owner: "11500386",
					Originator: "11500386",
					ReqDate: new Date().toDateString(),
					email: "kim.john@dxc.com",
					Submitter: "",
					iwoNo: "",
					Requestid: "",
					Contractid: "",
					oAppType: "",
					RejectType: "",
					IWOAdmin: "",
					reqID: "",
					totalCount: 0,
					tableBusyDelay: 0,
					oErrorCount: 0,
					EstatTxt: "Create",
					OriginatorName: "John, Kim",
					OwnerName: "John, Kim",
					AdminName: "",
					type: "",
					actionType: "",
					statusCode: "E0001",
					PerfFinPOCNName: "",
					PerfManager: "",
					PerfManagerName: "",
					ProjectManagerName: "",
					ProjManagerName: "",
					OrigFinPOCName: "",
					FrasDis: "",
					FrasBtn: "",
					ProjectType: "",
					ZProjectID: "",
					taskFlg: "",
					//phase2 flag
					EnableflagArktx: "",
					EnableflagZsfdcOppid: "",
					FlagPstyv: "",
					FlagRaKey: "",
					FlagMat: "",
					FlagItemCat: "",
					FlagSDate: "",
					FlagEDate: "",
					FlagPlRevenue: "",
					FlagPlCost: "",
					FlagDip: "",
					EnableflagZterm: "",
					FlagCaseId: "",
					FlagLinePay: "",
					FlagWBS: "",
					FlagIndia: "",
					FlagPo: "",
					FlagPoDate: "",
					FlagReCost: "",
					FlagPCS: "",
					FlagIFISCost: "",
					FlagIFSCDes: "",
					FlagPayer: "",
					FlagShipto: "",
					FlagBIllto: "",
					FlagAgm: "",
					FlagWBS1: "",
					FlagWBS2: "",
					FlagFinApp: "",
					SyslineFlag: "",
					StatusCLSD: "",
					FrasDateDis: "",
					downloadBun: ""
						//TitleName: "New Project Request",
				});
				oView.setModel(oViewModel, "appView");
			}

			var oLength = window.location.href.split("#")[1].split("?").length;
			if (oLength > 1) {
				var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
				if (oLength1 === 1) {
					// Scenario2 : Begin of changes  Srinivas Vallepu.
					if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().type = "OpprAppC1";
						this.getView().getModel("appView").refresh(true);
						jQuery.sap.require("jquery.sap.storage");
						var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
						if (oStorage.get("oppData")) {
							var obj = oStorage.get("oppData");
							// oStorage.clear();
						}
						var comCode = obj[0].Zbukrs;
						this.getView().byId("comCode").setValue(comCode);
						this.getView().byId("idComCo2").setValue(comCode);
						this.getView().byId("idComFormInt").setValue(comCode);
						this.getView().byId("idUSD").setValue("USD");
						this.getView().byId("idUSDInt").setValue("USD");
						var oProjectBox = this.getView().byId("idProjTyp");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, comCode),
							],
							and: true
						});
						oBindingBox.filter(aFilters);
						//
						var oModel = this.getView().getModel("oDataModel");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, comCode),
							],
							and: true
						});
						var that = this;
						oModel.read("/SearchCompCodeSet", {
							filters: [aFilters],
							success: function (oData) {
								// var splitDes = oData.results[0].Des_sys;
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().System = oData.results[0].Des_sys;
								that.getView().getModel("appView").refresh(true);
							},
							error: function (oError) {}
						});

						//
						this.onSelectSafecaseID(obj);
						// this.onLoadOppData(obj);
						//phase 2
						// that.getView().setModel(new JSONModel({}), "EnableDesable");
						// that.getView().setModel(new JSONModel({}), "EnableDesableIn");

					} else if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryyManage") {
						var oViewModel = this.getView().getModel("appView");

						// oViewModel.getData().type = "ChangeProject";
						oViewModel.getData().type = "OpprAppC1Mng";
						oViewModel.getData().oAppType = "ChangeProject";
						this.getView().getModel("appView").refresh(true);
						jQuery.sap.require("jquery.sap.storage");
						var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
						if (oStorage.get("oppData")) {
							var obj = oStorage.get("oppData");
							// oStorage.clear();
						}
						var ReqNo = obj[0].Projectid;
						var oAppType = "ChangeProject";
						oViewModel.getData().Requestid = ReqNo;
						oViewModel.getData().ZProjectID = ReqNo;
						this.getView().getModel().setProperty("/toOpprData", obj);
						this.onSelectSafecaseID(obj);
						this.onLoadChangeProjectOppdata(ReqNo, oAppType, obj);
						// phase 2
						// that.getView().setModel(new JSONModel({}), "EnableDesable");
						// that.getView().setModel(new JSONModel({}), "EnableDesableIn");
					} else {
						// Scenario2 : End of changes  Srinivas Vallepu.
						var sComCode = window.location.href.split("#")[1].split("?")[1].split("&")[0].split("=")[1];
						this.getView().byId("idUSD").setValue("USD");
						this.getView().byId("idUSDInt").setValue("USD");
						if (sComCode) {
							this.getView().byId("comCode").setValue(sComCode);
							this.getView().byId("idComCo2").setValue(sComCode);
							this.getView().byId("idComFormInt").setValue(sComCode);
							var oProjectBox = that.getView().byId("idProjTyp");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sComCode),
								],
								and: true
							});
							oBindingBox.filter(aFilters);
							var oModel = this.getView().getModel("oDataModel");
							oModel.read("/SearchCompCodeSet", {
								filters: [aFilters],
								success: function (oData) {
									// var splitDes = oData.results[0].Des_sys;
									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().System = oData.results[0].Des_sys;
									that.getView().getModel("appView").refresh(true);
								},
								error: function (oError) {}
							});
						}
						// this.onSelectSafecaseID(obj)
						//// Scenario2 : Begin of changes  Srinivas Vallepu.
					}
					//// Scenario2 : End of changes  Srinivas Vallepu.
				} else if (oLength1 === 3) {
					var oAppType = window.location.href.split("#")[1].split("?")[1].split("&")[1].split("=")[1];
					var ReqNo = window.location.href.split("#")[1].split("?")[1].split("&")[0].split("=")[1];
					if (oAppType === "CSIReview") {
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().type = "CSIReview";
						oViewModel.getData().oAppType = oAppType;
						this.getView().getModel("appView").refresh(true);
						this.onLoadAppData(ReqNo, oAppType);
						//phase 2
						that.getView().setModel(new JSONModel({}), "EnableDesable");
						that.getView().setModel(new JSONModel({}), "EnableDesableIn");
						that.getView().setModel(new JSONModel({}), "EnableDesableTask");
						that.getView().setModel(new JSONModel({}), "EnableDesableLabor");
					} else if (oAppType === "BILLReview") {
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().oAppType = oAppType;
						oViewModel.getData().type = "BILLReview";
						// oViewModel.getData().type = "PopupTypeDisable";
						this.getView().getModel("appView").refresh(true);
						this.onLoadAppData(ReqNo, oAppType);
						//phase 2
						that.getView().setModel(new JSONModel({}), "EnableDesable");
						that.getView().setModel(new JSONModel({}), "EnableDesableIn");
						that.getView().setModel(new JSONModel({}), "EnableDesableTask");
						that.getView().setModel(new JSONModel({}), "EnableDesableLabor");
					}
				} else if (oLength1 === 2) {
					var oAppType = window.location.href.split("#")[1].split("?")[1].split("&")[1].split("=")[1];
					var ReqNo = window.location.href.split("#")[1].split("?")[1].split("&")[0].split("=")[1];
					if (oAppType === "ChangeRequest") {
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().type = "ChangeRequest";
						oViewModel.getData().oAppType = oAppType;
						this.getView().getModel("appView").refresh(true);
						this.onLoadAppData(ReqNo, oAppType);
						// that.getView().setModel(new JSONModel({}), "EnableDesable");
						// that.getView().setModel(new JSONModel({}), "EnableDesableIn");
					} else if (oAppType === "View") {
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().type = "View";
						oViewModel.getData().oAppType = oAppType;
						this.getView().getModel("appView").refresh(true);
						this.onLoadAppData(ReqNo, oAppType);
						that.getView().setModel(new JSONModel({}), "EnableDesable");
						that.getView().setModel(new JSONModel({}), "EnableDesableIn");
						that.getView().setModel(new JSONModel({}), "EnableDesableTask");
						that.getView().setModel(new JSONModel({}), "EnableDesableLabor");
					} else if (ReqNo === "ChangeProject") {
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().type = "ChangeProject";
						this.getView().getModel("appView").refresh(true);
						var reqNoTemp = ReqNo;
						ReqNo = oAppType;
						oAppType = reqNoTemp;
						oViewModel.getData().Requestid = ReqNo;
						oViewModel.getData().ZProjectID = ReqNo;
						oViewModel.getData().oAppType = oAppType;
						this.onLoadChangeProjectData(ReqNo, oAppType);
						//phase 2
						that.getView().setModel(new JSONModel({}), "EnableDesable");
						that.getView().setModel(new JSONModel({}), "EnableDesableIn");
						// that.getView().setModel(new JSONModel({}), "EnableDesableTask");
					}
				}
			}
			// =========== murali code change===================
			// ================= Srini ===============

			// obj = [{
			// 	CasesafeId: "00k2J00000laognQAA",
			// 	OptId: "OPX-0020770065",
			// 	Projectid: "R-010222288",
			// 	UniqId: "OPX-0020770065-25",
			// 	Zbukrs: "1105"

			// }];

			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().type = "OpprAppC1"; //OpprAppC1  OpprAppC1Mng
			// oViewModel.getData().oAppType = "ChangeProject";
			// this.onLoadChangeProjectOppdata("R-010222288", "ChangeProject", obj);
			// ========================================

			// this.onLoadAppData("0000003678", "CSIReview");
			// // this.onLoadAppData("0000003371", "CSIReview");
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().type = "CSIReview";
			// oViewModel.getData().oAppType = "CSIReview";
			// //that.getView().setModel(new JSONModel({}), "EnableDesable");
			//  that.getView().setModel(new JSONModel({}), "EnableDesableIn");
			// that.getView().setModel(new JSONModel({}), "EnableDesableTask");
			// that.getView().setModel(new JSONModel({}), "EnableDesableLabor");

			// that.getView().setModel(new JSONModel({}), "EnableDesableIn");

			// this.onLoadAppData("0000003472", "BILLReview");
			// // this.onLoadAppData("0000002162", "BILLReview");
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().type = "BILLReview";
			// oViewModel.getData().oAppType = "BILLReview";
			// that.getView().setModel(new JSONModel({}), "EnableDesable");
			// that.getView().setModel(new JSONModel({}), "EnableDesableTask");
			// that.getView().setModel(new JSONModel({}), "EnableDesableLabor");

			// this.onLoadAppData("0000003295", "View"); //0000003313 0000003580 0000003647
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().type = "View";
			// oViewModel.getData().oAppType = "View";
			// that.getView().setModel(new JSONModel({}), "EnableDesable");
			// that.getView().setModel(new JSONModel({}), "EnableDesableIn");
			// that.getView().setModel(new JSONModel({}), "EnableDesableTask");
			//  that.getView().setModel(new JSONModel({}), "EnableDesableLabor");

			//MDD Num //Hardcode data load
			//saveasdraft Project = 0000001609
			//REQUEST id:  (Revenue) 0000001529 ,0000001963 =ZCGC ,1224, 1368 , 1403, 1427,0000001506,0000001944,1555(Internal) 0000000101, 0000001513, 731 ,0000001269 ,1289   
			//PROJECT ID: (Revenue) R-010222066, R-010004015, R-010222080 , (Internal) L-010044590 (ChnageProject Internal MDD B-010221278)

			//==========================Change Request ====================================

			//BILLRej =
			//CSIRej =
			// SaveasDraftDND-0000003142
			// this.onLoadAppData("0000002345", "ChangeRequest"); //Internal= 0000002460  //Project reuest = 2834
			// this.onLoadAppData("0000003762", "ChangeRequest"); //Revenue 0000002949, 0000002705,0000003135 //Project reuest = 0000002944,0000002985,3111,0000003157
			// this.onLoadAppData("0000003135", "ChangeRequest"); //3158//0000003159,0000003313,R-010004007 //internal 0000003362 with project
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().oAppType = "ChangeRequest";
			// oViewModel.getData().type = "ChangeRequest";

			// that.getView().setModel(new JSONModel({}), "EnableDesable");
			// that.getView().setModel(new JSONModel({}), "EnableDesableIn");

			// that.getView().setModel(new JSONModel({}), "EnableDesableTask");
			// that.getView().setModel(new JSONModel({}), "EnableDesableLabor");

			//this.onLoadAppData("0000003605", "View");
			//this.onLoadAppData("", "View");
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().oAppType = "View";
			// oViewModel.getData().type = "View";

			// this.onLoadAppData("0000003032", "BILLRej");
			// // this.onLoadAppData("", "View");
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().oAppType = "BILLRej";
			// oViewModel.getData().type = "BILLRej";

			// this.onLoadAppData("0000003678", "CSIRej");
			// // this.onLoadAppData("", "View");
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().oAppType = "CSIRej";
			// oViewModel.getData().type = "CSIRej";

			//===========================Change Project===================================

			//MDI Num
			//REQUEST id:  (Revenue)  , 663,355 (Internal) 0000000101, 730, 731 ,    
			//PROJECT ID: (Revenue) R-010222066, R-010004015, R-010222080,R-010011707 , R-010222031,R-010222226,R-010222346,R-010221278,R-010222113(Internal) L-010044590

			// this.onLoadChangeProjectData("B-010221278", "ChangeProject"); //L-010044590//(ChnageProject Internal MDD B-010221278),O-010222287

			// this.onLoadChangeProjectData("O-010222287", "ChangeProject");//L-010044590
			// this.onLoadChangeProjectData("R-010222535", "ChangeProject"); //R-010000062(missing fields)R-010222351 ,R-010222517//R-010222031(full fiels)//R-010222518
			// // // var oViewModel = this.getView().getModel("appView"); R-010004007
			// // // // // // // //oViewModel.getData().type3448 = "PopupTypeEnable";

			// oViewModel.getData().type = "ChangeProject";
			// oViewModel.getData().oAppType = "ChangeProject";
			// oViewModel.getData().Requestid = "R-010222535";
			// oViewModel.getData().ZProjectID = "R-010222535";
			// this.getView().getModel("appView").refresh(true);
			// that.getView().setModel(new JSONModel({}), "EnableDesable");
			// that.getView().setModel(new JSONModel({}), "EnableDesableIn");

			//Phase 2 issue reported 10/4
			// R-010222351 ,O-010222286

			// ==== Internal Project =======
			// this.onLoadChangeProjectData("O-010222286", "ChangeProject"); //R-010000062(missing fields) //R-010222031(full fiels),
			// // var oViewModel = this.getView().getModel("appView");
			// //oViewModel.getData().type3448 = "PopupTypeEnable";
			// oViewModel.getData().type = "ChangeProject";
			// oViewModel.getData().oAppType = "ChangeProject";
			// oViewModel.getData().Requestid = "O-010222286";
			// oViewModel.getData().ZProjectID = "O-010222286";
			// this.getView().getModel("appView").refresh(true);
			// //that.getView().setModel(new JSONModel({}), "EnableDesable");
			// that.getView().setModel(new JSONModel({}), "EnableDesableIn");

			//============================================================
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().type = "PopupTypeEnable";
			// oViewModel.getData().Requestid = "R-010222518";
			// oViewModel.getData().oAppType = "ChangeProject";
			// this.onLoadChangeProjectData("R-010222518", "ChangeProject")
			// this.getView().getModel("appView").refresh(true);

			// var oViewModel = this.getView().getModel("appView");
			// 		oViewModel.getData().type = "PopupTypeEnable";
			// 		this.getView().getModel("appView").refresh(true);
			// 		var reqNoTemp = ReqNo;
			// 		ReqNo = oAppType;
			// 		oAppType = reqNoTemp;
			// 		oViewModel.getData().Requestid = ReqNo;
			// 		oViewModel.getData().oAppType = oAppType;
			// 		this.onLoadChangeProjectData(ReqNo, oAppType);

			//this.onLoadChangeProjectData("R-010004043","ChangeProject")

		},

		//Material search start

		onOpenAdvanceSearchDialog: function (oEvent) {
			this.selectedRow = oEvent.getSource().getBindingContext("localModel");
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment(this.createId("idAdvMaterialSearch"), "WBS.C1.WbsC1Request.fragments.AdvMaterialSearch", this);
				this.getView().addDependent(this.oDialog);
			}
			var oData = JSON.parse(JSON.stringify(this.getOwnerComponent().getModel("matSearch").getData()));
			this.oDialog.setModel(new JSONModel(oData), "MatSearchModel");
			this.oDialog.getModel("MatSearchModel").setSizeLimit(2000);
			this.oDialog.getModel("MatSearchModel").setProperty("/rowObject", oEvent.getSource().getBindingContext("localModel").getObject());
			this.oDialog.getModel("MatSearchModel").setProperty("/isBusy", true);
			this._fnPopulateMaterialSearchDropDowns();
			this.oDialog.open();
		},

		_fnGetOppIdOffering: function (key) {
			var that = this;
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("Oppid", sap.ui.model.FilterOperator.EQ, key)]
			});
			oModel.read("/DefOppidOfferingSet", {
				filters: [aFilters],
				success: function (oResponse) {
					if (oResponse && oResponse.results.length > 0) {
						var oControlSegment = sap.ui.core.Fragment.byId(that.createId("idAdvMaterialSearch"), "cbSegment");
						var oControlOffFamily = sap.ui.core.Fragment.byId(that.createId("idAdvMaterialSearch"), "cbOffering");
						var oControlMajorOff = sap.ui.core.Fragment.byId(that.createId("idAdvMaterialSearch"), "cbMajorOff");
						var segmentFilter = [];
						var offFamilyFilter = [];
						var majorOffFilter = [];
						if (oResponse.results && oResponse.results.length > 0) {
							for (var i = 0; i < oResponse.results.length; i++) {
								segmentFilter.push(new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.EQ, oResponse.results[i].Sgmnt));
								var offFamKey = oResponse.results[i].Sgmnt + oResponse.results[i].OffFam;
								offFamilyFilter.push(new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.EQ, offFamKey));
								var majOffKey = offFamKey + oResponse.results[i].MajOff;
								majorOffFilter.push(new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.EQ, majOffKey));
							}
							var finalSegmentFilter = new sap.ui.model.Filter({
								filters: segmentFilter,
								and: false
							});
							oControlSegment.getBinding("items").filter(finalSegmentFilter);
							
							var finalOffFamilyFilter = new sap.ui.model.Filter({
								filters: offFamilyFilter,
								and: false
							});
							oControlOffFamily.getBinding("items").filter(finalOffFamilyFilter);
							
							var finalMajorOffFilter = new sap.ui.model.Filter({
								filters: majorOffFilter,
								and: false
							});
							oControlMajorOff.getBinding("items").filter(finalMajorOffFilter);
						}
					}
					that.oDialog.getModel("MatSearchModel").setProperty("/isBusy", false);

				},
				error: function (oError) {
					that.oDialog.getModel("MatSearchModel").setProperty("/isBusy", false);
				}
			});
		},

		onAdvMaterialCancel: function () {
			this.oDialog.close();
		},

		onAdvMaterialReset: function () {
			this._fnResetAdvMaterialSearch(1);
			this._fnMatSearchSuccessHandler();
		},

		_fnPopulateMaterialSearchDropDowns: function () {
			var that = this;
			Promise.all([this._fnPopulateDD(null, "1", "/SegmentDD"),
				this._fnPopulateDD(null, "2", "/OfferingFamilyDD"),
				this._fnPopulateDD(null, "3", "/MajorOfferingDD")
			]).then(that._fnMatSearchSuccessHandler.bind(that));
		},

		_fnMatSearchSuccessHandler: function () {
			this._fnGetOppIdOffering(this.oDialog.getModel("MatSearchModel").getProperty("/rowObject").ZsfdcOppid);
		},

		_fnPopulateDD: function (filter, stage, dropDownName) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					filter = filter || [];
					filter.push(new sap.ui.model.Filter("Stufe", sap.ui.model.FilterOperator.EQ, stage));
					var aFilters = new sap.ui.model.Filter({
						filters: filter,
						and: true
					});
					var oModel = that.getView().getModel("oDataModel");
					oModel.read("/SearchProdhSet", {
						filters: [aFilters],
						success: function (oResponse) {
							that.oDialog.getModel("MatSearchModel").setProperty("/" + stage + dropDownName, oResponse.results);
							resolve(oResponse);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
		},

		_fnPopulateContractTypeDD: function () {
			var that = this;
			var sProdhKey = this.oDialog.getModel("MatSearchModel").getProperty("/5/offeringLineKey");
			var sBukrsKey = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.EQ, sProdhKey),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrsKey)
				],
				and: true
			});
			var oModel = this.getView().getModel("oDataModel");
			oModel.read("/SearchMtposSet", {
				filters: [aFilters],
				success: function (oResponse) {
					that.oDialog.getModel("MatSearchModel").setProperty("/6/ContractTypeDD", oResponse.results);
				},
				error: function (oError) {}
			});
		},

		_fnPopulateMaterialDD: function (sContractKey) {
			var that = this;
			var sProdhKey = this.oDialog.getModel("MatSearchModel").getProperty("/5/offeringLineKey");
			var sBukrsKey = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("Mtpos", sap.ui.model.FilterOperator.EQ, sContractKey),
					new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.EQ, sProdhKey),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrsKey)
				],
				and: true
			});
			var oModel = this.getView().getModel("oDataModel");
			oModel.read("/SearchOffMatSet", {
				filters: [aFilters],
				success: function (oResponse) {
					that.oDialog.getModel("MatSearchModel").setProperty("/7/MaterialDD", oResponse.results);
				},
				error: function (oError) {}
			});
		},

		onSegmentChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			var aFilter = [new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.StartsWith, sKey)];
			this._fnResetAdvMaterialSearch(2);
			var newFilter = [new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.StartsWith, sKey)];
			this._fnPopulateDD(aFilter, "2", "/OfferingFamilyDD");
			this._fnPopulateDD(newFilter, "3", "/MajorOfferingDD");
		},

		onOfferingFamilyChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			var aFilter = [new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.StartsWith, sKey)];
			if (sKey && sKey.length > 0) {
				this.oDialog.getModel("MatSearchModel").setProperty("/1/segmentKey", sKey.substring(0, 2));
			}
			this._fnResetAdvMaterialSearch(3);
			this._fnPopulateDD(aFilter, "3", "/MajorOfferingDD");
		},

		onMajorOfferingChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			this._fnResetAdvMaterialSearch(4);
			if (sKey && sKey.length > 0) {
				this.oDialog.getModel("MatSearchModel").setProperty("/1/segmentKey", sKey.substring(0, 2));
				this.oDialog.getModel("MatSearchModel").setProperty("/2/offeringFamilyKey", sKey.substring(0, 4));
				this.oDialog.getModel("MatSearchModel").setProperty("/4/isOfferingDDEnable", true);
			}
			var aFilter = [new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.StartsWith, sKey)];
			this._fnPopulateDD(aFilter, "4", "/OfferingDD");
		},

		onOfferingChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			this._fnResetAdvMaterialSearch(5);
			var bFlag = (sKey && sKey.length > 0) ? true : false;
			this.oDialog.getModel("MatSearchModel").setProperty("/5/isOfferingLineDDEnable", bFlag);
			var aFilter = [new sap.ui.model.Filter("Prodh", sap.ui.model.FilterOperator.StartsWith, sKey)];
			this._fnPopulateDD(aFilter, "5", "/OfferingLineDD");
		},

		onOfferingLineChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			this._fnResetAdvMaterialSearch(6);
			var bFlag = (sKey && sKey.length > 0) ? true : false;
			this.oDialog.getModel("MatSearchModel").setProperty("/6/isContractTypeDDEnable", bFlag);
			this._fnPopulateContractTypeDD();
		},

		onContractTypeChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			this._fnResetAdvMaterialSearch(7);
			var bFlag = (sKey && sKey.length > 0) ? true : false;
			this.oDialog.getModel("MatSearchModel").setProperty("/7/isMaterialDDEnable", bFlag);
			this._fnPopulateMaterialDD(sKey);
		},

		onMaterialChange: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			var aData = this.oDialog.getModel("MatSearchModel").getProperty("/7/MaterialDD");
			var selectedObj = aData.find(function (obj) {
				return obj.Matnr === sKey;
			});
			this.oDialog.getModel("MatSearchModel").setProperty("/Material", [selectedObj]);
		},

		onAdvMaterialSave: function (oEvent) {
			var that = this;
			var sTableId = sap.ui.core.Fragment.createId("idAdvMaterialSearch", "idAdvMatSearchTable");
			var aSelectedContext = this.getView().byId(sTableId).getSelectedContexts();
			if (!aSelectedContext || aSelectedContext.length === 0) {
				sap.m.MessageToast.show("Please select material from table");
				return;
			}
			var sPath = this.selectedRow.getPath();
			var obj = aSelectedContext[0].getObject();
			var sTerm = Number(obj.Matnr).toString();
			var sOppId = this.getView().getModel("localModel").getProperty(sPath + "/ZsfdcOppid");
			var sCaseSafeId = this.getView().getModel("localModel").getProperty(sPath + "/CaseSafeId");
			var sZBUKRSMat = this.getView().byId("comCode").getValue();
			var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sZBUKRSMat),
					new sap.ui.model.Filter("OppId", sap.ui.model.FilterOperator.EQ, sOppId),
					new sap.ui.model.Filter("caseId", sap.ui.model.FilterOperator.EQ, sCaseSafeId)
				],
				and: true
			});
			var oModel = this.getView().getModel("oDataModel");
			oModel.read("/SearchMatMastSet", {
				filters: [aFilters],
				success: function (oData) {
					var sItemBill = oData.results[0].Mtpos;
					that.getView().getModel("localModel").setProperty(sPath + "/Matnr", oData.results[0].Matnr);
					that.getView().getModel("localModel").setProperty(sPath + "/Maktx", oData.results[0].Maktx);
					that.getView().getModel("localModel").setProperty(sPath + "/majOffDesc", oData.results[0].majOffDesc);
					that.getView().getModel("localModel").setProperty(sPath + "/Prodh", oData.results[0].Prdha);
					that.getView().getModel("localModel").setProperty(sPath + "/Prctr", oData.results[0].Prctr);
					that.getView().getModel("localModel").setProperty(sPath + "/Pstyv", sItemBill);

					if (sItemBill === "ZFIX") {
						that.getView().getModel("localModel").setProperty(sPath + "/Pstyv", "ZPER");
					} else if (sItemBill === "ZTME") {
						that.getView().getModel("localModel").setProperty(sPath + "/Ffprf", "ZRRB0001");
					}
					if (sPrjTyp === 'ZCGC') {
						sItemBill = sPrjTyp;
						that.getView().getModel("localModel").setProperty(sPath + "/Pstyv", "ZCGC");
						that.getView().getModel("localModel").setProperty(sPath + "/RaKey", "ZRA01");
						that.getView().getModel("localModel").setProperty(sPath + "/Ffprf", "");
						that.getView().getModel("localModel").setProperty(sPath + "/isRevRAKeyEditable", true);

					}
					var oItem = that.getView().getModel("localModel").getProperty(sPath + "/Pstyv");
					var sState = oItem === "" ? "Error" : "None";
					that.getView().getModel("localModel").setProperty(sPath + "/revItmBillCatValueState", sState);
					that.onAdvMaterialCancel();
				},
				error: function (oError) {}
			});

		},

		_fnResetAdvMaterialSearch: function (startLevel) {
			var oModel = this.oDialog.getModel("MatSearchModel");
			for (var i = startLevel; i <= 8; i++) {
				switch (i) {
				case 1:
					oModel.setProperty("/1/segmentKey", "");
					break;
				case 2:
					oModel.setProperty("/2/offeringFamilyKey", "");
					break;
				case 3:
					oModel.setProperty("/3/majorOfferingKey", "");
					break;
				case 4:
					oModel.setProperty("/4/offeringKey", "");
					oModel.setProperty("/4/isOfferingDDEnable", false);
					break;
				case 5:
					oModel.setProperty("/5/offeringLineKey", "");
					oModel.setProperty("/5/isOfferingLineDDEnable", false);
					break;
				case 6:
					oModel.setProperty("/6/contractTypeKey", "");
					oModel.setProperty("/6/isContractTypeDDEnable", false);
					break;
				case 7:
					oModel.setProperty("/7/materialKey", "");
					oModel.setProperty("/7/isMaterialDDEnable", false);
					break;
				case 8:
					oModel.setProperty("/Material", []);
					break;
				}
			}
		},

		// End material search

		onLoadAppData: function (ReqNo, TYPE) {
			sap.ui.core.BusyIndicator.show(0);

			var that = this;
			that.aAgm = "X";
			that.aWbsowner1 = "X";
			that.aWbsowner2 = "X";
			that.aFinApp = "X";
			that.aPrjAc = "X";
			that.aDraftIa = "X";
			that.aBds = "X";
			that.aInvRec = "X";
			that.aVbegdat = "X";
			that.aVenddat = "X";

			var oViewModel = this.getView().getModel("appView");
			oViewModel.getData().Requestid = ReqNo;
			that.getView().byId("idReq1").setVisible(true);
			this.getView().getModel("appView").refresh(true);

			Promise.all([this._fnReadHeaderData(ReqNo, TYPE),
				this._fnReadCustomerName(ReqNo)
			]).then(that._fnSuccessHandler.bind(that));
		},

		_fnSuccessHandler: function (bFlag) {
			if (bFlag === "False") {
				sap.ui.core.BusyIndicator.hide();
			}
		},

		_fnReadHeaderData: function (ReqNo, TYPE) {
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			return new Promise(
				function (resolve, reject) {
					oModel.read("/WBSRequestHeaderSet('" + ReqNo + "')", {
						urlParameters: {
							'$expand': "WBSRequestDetails,WBSRequestItemSet,WBSLaborTypeSet,WBSTaskSet,WBSErrorSet,WBSAttachSet,WBSReqStatusDetSet,WBSLaborTypeItemSet,WBSChngSummarySet"
						},
						success: function (oData, oResponse) {
							if (oData === null || oData === undefined) {
								var sMessage = "WARNING. Received a null or undefined response object.";
								sap.m.MessageToast.show(sMessage);
							}

							var oViewModel = that.getView().getModel("appView");
							var AppType = oViewModel.getData().oAppType;

							var isSummaryTabVisible = oData.WBSRequestDetails && oData.WBSRequestDetails.results[0].TypeReq !== 'CREATE' ? true : false;
							oViewModel.getData().showSummaryTab = isSummaryTabVisible;

							var tempapptype = AppType;
							oViewModel.getData().OriginatorName = "";
							oViewModel.getData().RequestorEmail = "";

							that.getView().getModel("summaryTabModel").setProperty("/Items", oData.WBSChngSummarySet.results);

							if (!oData.Changed_on) {
								oViewModel.getData().ReqDate = "";
							} else {
								oViewModel.getData().ReqDate = oData.Changed_on.toDateString();
							}
							//Later need to check vinodh
							if (!oData.WBSReqStatusDetSet.results[0].Status) {
								oViewModel.getData().EstatTxt = "";
							} else {
								oViewModel.getData().EstatTxt = oData.WBSReqStatusDetSet.results[0].Status;
								// var oStatus = oData.WBSReqStatusDetSet.results[0].Status;
								// oViewModel.getData().EstatTxt = oStatus;
								// if(oStatus === "Rejected" && AppType === "ChangeProject" ){
								// 	that.getView().byId("comCode").setEditable(false);
								// 	that.getView().byId("idProjTyp").setEditable(false);
								// }else{
								// 	that.getView().byId("comCode").setEditable(true);
								// 	that.getView().byId("idProjTyp").setEditable(true);
								// }
							}
							that.oStatus = oData.WBSReqStatusDetSet.results[0].Status;
							if (oData.WBSReqStatusDetSet.results[0].ActType === "BIL_APR" && oData.WBSReqStatusDetSet.results[0].Status === "REJECTED") {
								oViewModel.getData().oAppType = "BILLRej";
								oViewModel.getData().RejectType = "BILLRej";
								//TYPE = "BILLRej";
								AppType = "BILLRej";
								that.getView().setModel(new JSONModel({}), "EnableDesable");
								that.getView().setModel(new JSONModel({}), "EnableDesableTask");
								that.getView().setModel(new JSONModel({}), "EnableDesableLabor");
								// that.getView().getModel("appView").refresh(true);

							}
							if (oData.WBSReqStatusDetSet.results[0].ActType === "CSI_APR" && oData.WBSReqStatusDetSet.results[0].Status === "REJECTED") {
								oViewModel.getData().oAppType = "CSIRej";
								oViewModel.getData().RejectType = "CSIRej";
								//TYPE = "CSIRej";
								AppType = "CSIRej";
								// that.getView().setModel(new JSONModel({}), "EnableDesable");
							}
							if (oData.WBSReqStatusDetSet.results[0].ActType === "AUTO_APPRL" && oData.WBSReqStatusDetSet.results[0].Status ===
								"AUTOREJECT") {
								oViewModel.getData().oAppType = "CSIRej";
								oViewModel.getData().RejectType = "CSIRej";
								//TYPE = "CSIRej";
								AppType = "CSIRej";
							}

							if (!oData.Des_sys) {
								oViewModel.getData().System = "";
							} else {
								oViewModel.getData().System = oData.Des_sys;
							}
							that.getView().getModel("appView").refresh(true);
							//Tab 1

							var oRejectType = oViewModel.getData().RejectType;

							var sCode = oData.Zbukrs;
							var sProType = oData.PrjTyp;
							oViewModel.getData().ProjectType = sProType;
							var sReqCmnts = oData.WBSRequestDetails.results[0].ReqCom;
							that.getView().byId("comCode").setValue(sCode);
							that.getView().byId("idComCo2").setValue(sCode);

							var oProjectBox = that.getView().byId("idProjTyp");
							var oBindingBox = oProjectBox.getBinding("items");
							oBindingBox.attachChange(function (sReason) {
								that._fnSuccessHandler("False");
							});
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sCode)
								],
								and: true
							});
							oBindingBox.filter(aFilters);
							that.getView().byId("idProjTyp").setSelectedKey(sProType);
							var key = that.getView().byId("idProjTyp").getSelectedKey();
							that.getView().getModel().setProperty("/WBSAttachSet", oData.WBSAttachSet.results);

							if (key === "ZPRJ") {
								that.getView().byId("SimpleFormInternal").setVisible(true);
								that.getView().byId("SimpleFormChangewbs").setVisible(false);
								that.getView().byId("subTyp").setVisible(true);
								that.getView().byId("idSubTyp").setVisible(true);
								if (TYPE === "CSIReview" || TYPE === "BILLReview" || TYPE === "View") {
									that.getView().byId("idSubTyp").setEditable(false);
									that.getView().byId("idDelInternal").setEnabled(false);
								}
								for (var i = 0; i < oData.WBSRequestItemSet.results.length; i++) {
									var oZentyType = oData.WBSRequestItemSet.results[i].Zentry_tp;
									if (TYPE === "ChangeRequest" && (oZentyType === "E" || oZentyType === "C")) {
										that.getView().byId("idSubTyp").setEditable(false);
										that.getView().byId("idUSDInt").setEnabled(false);
									}
								}
								that.getView().byId("idInternal").setVisible(true);
								that.getView().byId("idTravel").setVisible(false);

								//Tab 1	
								var sSubType = oData.PrjStp;
								that.getView().byId("idSubTyp").setSelectedKey(sSubType);
								if (sSubType === "ST" || sSubType === "IN" || sSubType === "LT" || sSubType === "SU" || sSubType === "SB") {
									that.getView().byId("idIntSold").setEditable(false);
								} else {
									if (sSubType === "OH" || sSubType === "BP" || sSubType === "BN" || sSubType === "BS") {
										that.getView().byId("idIntSold").setEditable(true);

									}
								}
								//================ Internal Form =====================
								//Tab 2

								that.getView().getModel().getData().wbsInternal.Ktext = oData.Ktext;
								//that.getView().getModel().getData().wbsInternal.Zbukrs = oData.Zbukrs;
								that.getView().byId("idComFormInt").setValue(sCode);
								that.getView().getModel().getData().wbsInternal.Waers = oData.Waers;
								var sPrjCur = oData.Waers;
								that.getView().byId("idUSDInt").setValue(sPrjCur);
								that.getView().getModel().getData().wbsInternal.Zterm = oData.Zterm;
								var MinEndDate = oData.Guebg;
								that.byId("idEndInt").setMinDate(MinEndDate);
								that.getView().getModel().getData().wbsInternal.Guebg = oData.Guebg;
								that.getView().getModel().getData().wbsInternal.Gueen = oData.Gueen;
								that.oHeaderStartDateInt = oData.Guebg;
								that.oHeaderEndDateInt = oData.Gueen;

							} else {
								if (key === "ZBC" || key === "ZCGC") {

									that.getView().byId("SimpleFormInternal").setVisible(false);
									that.getView().byId("SimpleFormChangewbs").setVisible(true);
									that.getView().byId("subTyp").setVisible(false);
									that.getView().byId("idSubTyp").setVisible(false);
									that.getView().byId("idInternal").setVisible(false);
									that.getView().byId("idTravel").setVisible(true);
									that.getView().getModel().getData().wbsRevenue.Ktext = oData.Ktext;
									if (oData.ZriskInd === "X") {
										oData.ZriskInd = true;
										that.getView().byId("ch2").setSelected(oData.ZriskInd);
										that.getView().byId("idSign").setRequired(false);

									}
									that.getView().getModel().getData().wbsRevenue.ZriskInd = oData.ZriskInd;
									that.getView().getModel().getData().wbsRevenue.ZzCasId = oData.ZzCasId;
									that.getView().getModel().getData().wbsRevenue.Bstnk = oData.Bstnk;
									var sProCur = oData.Waers;
									that.getView().byId("idUSD").setValue(sProCur);
									//that.getView().getModel().getData().wbsRevenue.Waers = oData.Waers;
									that.getView().getModel().getData().wbsRevenue.Bstdk = oData.Bstdk;
									that.BillCalR = oData.Perfk;
									that.getView().getModel().getData().wbsRevenue.Perfk = that.BillCalR;
									var sPymntTerm = oData.Zterm;
									that.getView().byId("idPaymt").setValue(sPymntTerm);
									that.getView().getModel().getData().wbsRevenue.ZPtReason = oData.ZPtReason;
									var MinEndDate = oData.Guebg;
									that.byId("dateCtrlEnd").setMinDate(MinEndDate);
									that.getView().getModel().getData().wbsRevenue.Guebg = oData.Guebg;
									that.getView().getModel().getData().wbsRevenue.Gueen = oData.Gueen;
									that.oHeaderStartDate = oData.Guebg;
									that.oHeaderEndDate = oData.Gueen;
									that.EndDateFlag = true;
								}

							}
							//phase 2
							// if (TYPE !== "View" || oRejectType !== "BILLRej") {
							// var oEntryType = oData.WBSRequestItemSet.results[0].Zentry_tp;
							if (TYPE !== "View" && oRejectType !== "BILLRej" && AppType !== "CSIReview" && AppType !== "BILLReview") {
								if (oData.WBSRequestItemSet.results[0].Zposid) {
									//Phase 2 Code Start
									that.oHeaderType = true;
									var oModelE = that.getView().getModel("oDataModel");
									if (key === "ZBC" || key === "ZCGC") {
										oModelE.read("/WBSHeaderChngFlgSet('" + key + "')", {
											success: function (oData, oResponse) {
												var eAgm = oData.Agm;
												if (eAgm === 'X') {
													that.getView().byId("idAccMan").setEditable(true);
												} else {
													that.getView().byId("idAccMan").setEditable(false);
												}

												// var eBds = oData.Bds;
												// if (eBds === 'X') {
												// 	that.getView().byId("idBillStw").setEditable(true);
												// } else {
												// 	that.getView().byId("idBillStw").setEditable(false);
												// }

												var eBillTo = oData.BillTo;
												if (eBillTo === 'X') {
													that.getView().byId("idbill").setEditable(true);
												} else {
													that.getView().byId("idbill").setEditable(false);
												}
												var eBstdk = oData.Bstdk; //PO Date
												if (eBstdk === 'X') {
													that.getView().byId("dateCtrlPo").setEditable(true);
												} else {
													that.getView().byId("dateCtrlPo").setEditable(false);
												}
												var eBstnk = oData.Bstnk; //PO Number
												if (eBstnk) {
													that.getView().byId("idpo").setEditable(true);
												} else {
													that.getView().byId("idpo").setEditable(false);
												}
												var eDraftIa = oData.DraftIa;
												if (eDraftIa === 'X') {
													that.getView().byId("idDrftInv").setEditable(true);
												} else {
													that.getView().byId("idDrftInv").setEditable(false);
												}
												var eFinApp = oData.FinApp;
												if (eFinApp === 'X') {
													that.getView().byId("idFinApp").setEditable(true);
												} else {
													that.getView().byId("idFinApp").setEditable(false);
												}
												var eGuebg = oData.Guebg;
												if (eGuebg === 'X') {
													that.getView().byId("dateCtrlStr").setEditable(true);
												} else {
													that.getView().byId("dateCtrlStr").setEditable(false);
												}
												var eGueen = oData.Gueen;
												if (eGueen === 'X') {
													that.getView().byId("dateCtrlEnd").setEditable(true);
												} else {
													that.getView().byId("dateCtrlEnd").setEditable(false);
												}
												// var eInvRec = oData.InvRec;
												// if (eInvRec === 'X') {
												// 	that.getView().byId("idInv").setEditable(true);
												// } else {
												// 	that.getView().byId("idInv").setEditable(false);
												// }
												var eKtext = oData.Ktext; //Project Description
												if (eKtext === 'X') {
													that.getView().byId("idProjDes").setEditable(true);
												} else {
													that.getView().byId("idProjDes").setEditable(false);
												}
												var eKvgr1 = oData.Kvgr1;
												if (eKvgr1 === 'X') {
													that.getView().byId("idInvLay").setEditable(true);
												} else {
													that.getView().byId("idInvLay").setEditable(false);
												}
												var ePayer = oData.Payer;
												if (ePayer === 'X') {
													that.getView().byId("idPayer").setEditable(true);
												} else {
													that.getView().byId("idPayer").setEditable(false);
												}
												var ePerfk = oData.Perfk;
												if (ePerfk === 'X') {
													that.getView().byId("idBillCal").setEditable(true);
												} else {
													that.getView().byId("idBillCal").setEditable(false);
												}
												// var ePrjAc = oData.PrjAc;
												// if (ePrjAc === 'X') {
												// 	that.getView().byId("idProAc").setEditable(true);
												// } else {
												// 	that.getView().byId("idProAc").setEditable(false);
												// }
												var eShipTo = oData.ShipTo;
												if (eShipTo === 'X') {
													that.getView().byId("idship").setEditable(true);
												} else {
													that.getView().byId("idship").setEditable(false);
												}
												var eSoldto = oData.Soldto;
												if (eSoldto === 'X') {
													that.getView().byId("idSoldTo").setEditable(true);
												} else {
													that.getView().byId("idSoldTo").setEditable(false);
												}
												// var eWaers = oData.Waers;
												// if (eWaers === 'X') {
												// 	that.getView().byId("idUSD").setEditable(true);
												// } else {
												// 	that.getView().byId("idUSD").setEditable(false);
												// }
												var eWbsowner1 = oData.Wbsowner1;
												if (eWbsowner1 === 'X') {
													that.getView().byId("idWBS1").setEditable(true);
												} else {
													that.getView().byId("idWBS1").setEditable(false);
												}
												var eWbsowner2 = oData.Wbsowner2;
												if (eWbsowner2 === 'X') {
													that.getView().byId("idWBS2").setEditable(true);
												} else {
													that.getView().byId("idWBS2").setEditable(false);
												}
												var eZPtReason = oData.ZPtReason;
												if (eZPtReason === 'X') {
													that.getView().byId("idReason").setEditable(true);
												} else {
													that.getView().byId("idReason").setEditable(false);
												}
												var eZterm = oData.Zterm;
												if (eZterm === 'X') {
													that.getView().byId("idPaymt").setEditable(true);
												} else {
													that.getView().byId("idPaymt").setEditable(false);
												}
												var eZzCasId = oData.ZzCasId;
												if (eZzCasId === 'X') {
													that.getView().byId("idSign").setEditable(true);
												} else {
													that.getView().byId("idSign").setEditable(false);
												}

											},
											error: function (oError, oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
													duration: 5000
												});
											}
										}); //Header Group A&B
										oModelE.read("/WBSItemChngFlgSet('" + key + "')", {

											success: function (oResponse) {
												// delete oResponse.__metadata;
												// delete oResponse.toItmChngFlg.__metadata;
												var EnableDesable = new JSONModel(oResponse);
												that.getView().setModel(EnableDesable, "EnableDesable");

												// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
												// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

												sap.ui.core.BusyIndicator.hide();
											},
											error: function (oError, oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
													duration: 5000
												});
											}
										}); //Item Group A&B
									}

									//Internal Project Type
									if (key === "ZPRJ") {
										//Header Internal
										oModelE.read("/WBSHeaderChngFlgSet('" + key + "')", {
											success: function (oData, oResponse) {

												var KtextInt = oData.Ktext;
												if (KtextInt === 'X') {
													that.getView().byId("idProIntDs").setEditable(true);
												} else {
													that.getView().byId("idProIntDs").setEditable(false);
												}
												var GuebgInt = oData.Guebg;
												if (GuebgInt) {
													that.getView().byId("idStarInt").setEditable(true);
												} else {
													that.getView().byId("idStarInt").setEditable(false);
												}
												var GueenInt = oData.Gueen;
												if (GueenInt === 'X') {
													that.getView().byId("idEndInt").setEditable(true);
												} else {
													that.getView().byId("idEndInt").setEditable(false);
												}
												var AgmInt = oData.Agm;
												if (AgmInt === 'X') {
													that.getView().byId("idAccManInt").setEditable(true);
												} else {
													that.getView().byId("idAccManInt").setEditable(false);
												}
												var Wbsowner1Int = oData.Wbsowner1;
												if (Wbsowner1Int === 'X') {
													that.getView().byId("idWBS1Int").setEditable(true);
												} else {
													that.getView().byId("idWBS1Int").setEditable(false);
												}
												var Wbsowner2Int = oData.Wbsowner2;
												if (Wbsowner2Int === 'X') {
													that.getView().byId("idWBS2Int").setEditable(true);
												} else {
													that.getView().byId("idWBS2Int").setEditable(false);
												}
												var DraftIaInt = oData.DraftIa;
												if (DraftIaInt === 'X') {
													that.getView().byId("idDr").setEditable(true);
												} else {
													that.getView().byId("idDr").setEditable(false);
												}
												var FinAppInt = oData.FinApp;
												if (FinAppInt === 'X') {
													that.getView().byId("idFinAppInt").setEditable(true);
												} else {
													that.getView().byId("idFinAppInt").setEditable(false);
												}
												var PrjAcInt = oData.PrjAc;
												if (PrjAcInt === 'X') {
													that.getView().byId("idProAcInt").setEditable(true);
												} else {
													that.getView().byId("idProAcInt").setEditable(false);
												}

											},
											error: function (oError, oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
													duration: 5000
												});
											}
										});
										//Line Item Internal
										oModelE.read("/WBSItemChngFlgSet('" + key + "')", {

											success: function (oResponse) {
												// delete oResponse.__metadata;
												// delete oResponse.toItmChngFlg.__metadata;
												var EnableDesableIn = new JSONModel(oResponse);
												that.getView().setModel(EnableDesableIn, "EnableDesableIn");

												// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
												// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

												sap.ui.core.BusyIndicator.hide();
											},
											error: function (oError, oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
													duration: 5000
												});
											}
										});

									}
									//Phase 2 End

								}
							}

							that.getView().byId("TypeHere").setValue(sReqCmnts);

							var oEmail = oData.WBSRequestDetails.results[0].Email;
							var aLen = oEmail.length;
							if (aLen != 0) {
								var data = oEmail.split(",");
								var tokenValue = [];
								for (var i = 0; i < data.length; i++) {
									tokenValue.push(new Token({
										text: data[i],
										key: data[i]
									}));
								}
								var oMultiInput1 = that.getView().byId("wbsEmail");
								oMultiInput1.setTokens(tokenValue);
							}

							//attachment
							var attach = oData.WBSAttachSet.results.length;
							if (attach === 1) {
								var fName = oData.WBSAttachSet.results[0].Filename;
								that.getView().byId("fileUploader").setValue(fName);
								sap.ui.core.BusyIndicator.hide();
							} else if (attach === 0) {
								sap.ui.core.BusyIndicator.hide();
							}
							that.getView().getModel("localModel").setProperty("/iwoTabTravel", oData.WBSRequestItemSet.results);

							that.oZpspid = oData.Zpspid;
							that.oZvbeln = oData.Zvbeln;

							that.Zentry_tp = oData.Zentry_tp;
							var oLocalModel = that.getView().getModel("localModel").getData();
							var oRevRowIndex = oLocalModel.iwoTabTravel.length;
							for (var i = 0; i < oRevRowIndex; i++) {
								oLocalModel.iwoTabTravel[i].Agm = oData.WBSRequestItemSet.results[i].agmName;
								oLocalModel.iwoTabTravel[i].Bds = oData.WBSRequestItemSet.results[i].bdsName;
								oLocalModel.iwoTabTravel[i].Wbsowner1 = oData.WBSRequestItemSet.results[i].wbsowner1Name;
								oLocalModel.iwoTabTravel[i].Wbsowner2 = oData.WBSRequestItemSet.results[i].wbsowner2Name;
								oLocalModel.iwoTabTravel[i].PrjAc = oData.WBSRequestItemSet.results[i].prjAcName;
								oLocalModel.iwoTabTravel[i].InvRec = oData.WBSRequestItemSet.results[i].invRecName;
								oLocalModel.iwoTabTravel[i].FinApp = oData.WBSRequestItemSet.results[i].finAppName;
								oLocalModel.iwoTabTravel[i].DraftIa = oData.WBSRequestItemSet.results[i].draftIAName;
								oLocalModel.iwoTabTravel[i].isRevRAKeyEditable = false;
								oLocalModel.iwoTabTravel[i].isRevenueMatEditable = false;

								var sPlannedRevenue = oLocalModel.iwoTabTravel[i].Zplnrev;
								var nRevStr = sPlannedRevenue.replace(/,/g, '');
								var sRevenueValue = nRevStr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
								oLocalModel.iwoTabTravel[i].Zplnrev = sRevenueValue;
								oLocalModel.iwoTabTravel[i].SavePopup = 'X';
								var sPlannedCost = that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplncst;
								var nCostStr = sPlannedCost.replace(/,/g, '');
								var sCostValue = nCostStr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
								that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplncst = sCostValue;
							}
							//PlannedCost
							// for (var i = 0; i < oRevRowIndex; i++) {
							// 	var ItemLaborIconToolTip = oData.WBSRequestItemSet.results[i].laborFlg;
							// 	var TaskIconToolTip = oData.WBSRequestItemSet.results[i].taskFlg;
							// 	if (!ItemLaborIconToolTip && !TaskIconToolTip) {} else {
							// 		if (ItemLaborIconToolTip === "X") {
							// 			var LaborTooltipText = "ItemLabour Present ,";
							// 			that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].laborFlg = LaborTooltipText;
							// 		} else {
							// 			var LaborTooltipText = "";
							// 			that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].laborFlg = LaborTooltipText;
							// 		}

							// 		if (TaskIconToolTip === "X") {
							// 			var TaskTooltipText = "Task Present";
							// 			that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].taskFlg = TaskTooltipText;
							// 		} else {
							// 			var TaskTooltipText = "";
							// 			that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].taskFlg = TaskTooltipText;
							// 		}
							// 	}

							// }
							that.getView().getModel().setProperty("/laborData", oData.WBSLaborTypeSet.results);

							that.getView().getModel().setProperty("/taskData", oData.WBSTaskSet.results);
							that.getView().getModel().getData().task = that.getView().getModel().getData().taskData;

							that.getView().getModel().setProperty("/itemLaborData", oData.WBSLaborTypeItemSet.results);
							that.getView().getModel().getData().labor = that.getView().getModel().getData().itemLaborData;

							that.oiwotabtravel = that.getView().getModel("localModel").getData().iwoTabTravel;
							for (var i = 0; i < that.oiwotabtravel.length; i++) {
								var oPosnr = that.oiwotabtravel[i].Posnr;
								var oItemLabData = that.getView().getModel().getData().itemLaborData;
								var oitemDataTab = oItemLabData.filter(function (a) {
									return a.Posnr === oPosnr;
								});
								that.oiwotabtravel[i].labor = oitemDataTab;
							}

							that.oiwotabtravelT = that.getView().getModel("localModel").getData().iwoTabTravel;
							for (var i = 0; i < that.oiwotabtravelT.length; i++) {
								var oPosnr = that.oiwotabtravelT[i].Posnr;
								var oTaskoData = that.getView().getModel().getData().taskData;
								var oDataTabTask = oTaskoData.filter(function (a) {
									return a.Posnr === oPosnr;
								});
								that.oiwotabtravelT[i].task = oDataTabTask;
							}

							//TAB 1 and TAB 2 End
							if (TYPE === "ChangeRequest") {
								var oStatus = oData.WBSReqStatusDetSet.results[0].Status;
								var sExistingRecord = oData.WBSRequestItemSet.results.length > 0 ? oData.WBSRequestItemSet.results[0].Zentry_tp : null;
								that.changeRequestType = sExistingRecord ? "ChangeProject" : undefined;
								oViewModel.getData().FrasDis = "oDisplay";
								oViewModel.getData().FrasBtn = "oEdit";
								if (!sExistingRecord && TYPE === "ChangeRequest") {
									that.ChangeReuestFlagC = "ChangeRequestFlagC";
								}
								// else if(sExistingRecord !=="E" && TYPE === "ChangeRequest"){
								// 	that.ChangeReuestFlagE = "ChangeRequestFlagE";
								// }
								if ((oStatus === "AUTOREJECT" || oStatus === "REJECTED") && (sExistingRecord === "C" || sExistingRecord === "E")) {
									that.getView().byId("comCode").setEditable(false);
									that.getView().byId("idProjTyp").setEditable(false);
								} else {
									that.getView().byId("comCode").setEditable(true);
									that.getView().byId("idProjTyp").setEditable(true);
								}
								if (sExistingRecord === "E" || sExistingRecord === "C") {
									that.onDraftChangeRequestDisable();
								}
								for (var i = 0; i < oData.WBSRequestItemSet.results.length; i++) {
									var oNewLineitem = oData.WBSRequestItemSet.results[i].Zentry_tp;
									//Status LineItem Start
									var oSysLine = oData.WBSRequestItemSet.results[i].Systatusline;
									that.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline = oSysLine;
									that.getView().getModel("appView").refresh(true);
									//Status LineItem End
									if (oNewLineitem === "N") {
										// oViewModel.getData().SyslineFlag = "oSysDisplay";
										that.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp = oNewLineitem;
										that.getView().getModel("localModel").refresh(true);
									}
								}
							}

							if (TYPE === "CSIReview") {
								that.onDisplayData(TYPE);
								that.getView().byId("fileUploader").setEnabled(false);
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().FrasDis = "oDisplay";
								oViewModel.getData().FrasBtn = "oDisplay";

							} else if (TYPE === "BILLReview") {
								that.onDisplayData();
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().FrasDis = "oDisplay";
								oViewModel.getData().FrasBtn = "oDisplay";

							} else if (TYPE === "View") {

								// oData.WBSRequestItemSet.results.forEach(function (oItem) {
								// 	oItem.Zentry_tp = "E";
								// });

								that.onDisableCompleteFields();
								var oViewModel = that.getView().getModel("appView");

								oViewModel.getData().FrasDis = "oDisplay";
								oViewModel.getData().FrasBtn = "oDisplay";
							} else if (oRejectType === "BILLRej") {
								var oViewModel0 = that.getView().getModel("appView");
								that.onDisableCompleteFields();
							}
							// var TYPE = "BILLRej";
							//warranty 27/01/2022  TYPE === "View"
							//var oModelExt = that.getView().getModel("localModel").getData().iwoTabTravel;
							//var oExtline1 = oModelExt.length > 0 ? oModelExt[0].Zentry_tp : null;

							var sTitle = oData.WBSRequestDetails && oData.WBSRequestDetails.results[0].TypeReq !== 'CREATE' ? "Manage Project Request" :
								"New Project Request";
							var oView1 = that.getView().getParent();
							oView1.getService("ShellUIService").then(
								function (oService) {
									oService.setTitle(sTitle); //warranty
								}
							);
							that.byId("HeaderID").setObjectTitle(sTitle); //warranty
							// if ((oExtline1 === "E" || oExtline1 === "C") && (TYPE === "ChangeRequest" || TYPE === "CSIReview" || TYPE === "BILLReview" ||
							// 		AppType === "BILLRej" || TYPE === "View" ||
							// 		AppType === "CSIRej")) {
							// 	//To Change app  title 
							// 	var oView1 = that.getView().getParent();
							// 	oView1.getService("ShellUIService").then(
							// 		function (oService) {
							// 			oService.setTitle("Manage Project Request"); //warranty
							// 		}
							// 	);
							// 	that.byId("HeaderID").setObjectTitle("Manage Project Request"); //warranty

							// 	//
							// } else {

							// 	if (AppType === "BILLRej" || AppType === "CSIRej") {
							// 		//To Change app  title 
							// 		var oView1 = that.getView().getParent();
							// 		oView1.getService("ShellUIService").then(
							// 			function (oService) {
							// 				oService.setTitle("Manage Project Request"); //warranty
							// 			}
							// 		);
							// 		that.byId("HeaderID").setObjectTitle("Manage Project Request"); //warranty

							// 		//
							// 	} else {
							// 		//To Change app  title 
							// 		var oView1 = that.getView().getParent();
							// 		oView1.getService("ShellUIService").then(
							// 			function (oService) {
							// 				oService.setTitle("New Project Request");
							// 			}
							// 		);
							// 		that.byId("HeaderID").setObjectTitle("New Project Request");
							// 		//
							// 	}
							// }
							resolve(oData);
						},
						error: function (oError, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
								duration: 5000
							});
							reject(oResponse);
						}
					});
				});
		},

		_fnReadCustomerName: function (ReqNo) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					that.oManageRequestModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
					var Zpspid = "";
					that.oManageRequestModel.read("/Customer_NameSet(ReqNo='" + ReqNo + "',Zpspid='" + Zpspid + "')", {
						success: function (oData1, oResponse1) {

							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().Originator = "";
							oViewModel.getData().Originator = oData1.Changedby;
							if (oData1.Payer === ",,,") {
								oData1.Payer = "";
							}
							that.getView().getModel().getData().wbsInternal.Soldto = oData1.SoldTo;
							that.getView().getModel().getData().wbsInternal.Agm = oData1.AccGenMan;
							that.getView().getModel().getData().wbsInternal.Wbsowner1 = oData1.WbsOwnr1;
							that.getView().getModel().getData().wbsInternal.Wbsowner2 = oData1.WbsOwnr2;
							that.getView().getModel().getData().wbsInternal.FinApp = oData1.FinApp;
							that.getView().getModel().getData().wbsInternal.DraftIa = oData1.DraftInvApp;
							that.getView().getModel().getData().wbsInternal.PrjAc = oData1.ProAcc;
							// } else {
							that.getView().getModel().getData().wbsRevenue.Soldto = oData1.SoldTo;
							that.getView().getModel().getData().wbsRevenue.Payer = oData1.Payer;
							that.getView().getModel().getData().wbsRevenue.ShipTo = oData1.ShipTo;
							that.getView().getModel().getData().wbsRevenue.BillTo = oData1.BillTo;
							that.getView().getModel().getData().wbsRevenue.Kvgr1 = oData1.InvLay;
							var oBillCalR = oData1.BillCal;
							if (oBillCalR) {
								that.getView().getModel().getData().wbsRevenue.Perfk = oData1.BillCal;
							} else {
								that.getView().getModel().getData().wbsRevenue.Perfk = that.BillCalR;
							}
							that.getView().getModel().getData().wbsRevenue.Agm = oData1.AccGenMan;
							that.getView().getModel().getData().wbsRevenue.Wbsowner1 = oData1.WbsOwnr1;
							that.getView().getModel().getData().wbsRevenue.Wbsowner2 = oData1.WbsOwnr2;
							that.getView().getModel().getData().wbsRevenue.FinApp = oData1.FinApp;
							that.getView().getModel().getData().wbsRevenue.DraftIa = oData1.DraftInvApp;
							that.getView().getModel().getData().wbsRevenue.PrjAc = oData1.ProAcc;
							that.getView().getModel().getData().wbsRevenue.Bds = oData1.BillDataSte;
							that.getView().getModel().getData().wbsRevenue.InvRec = oData1.InvRec;
							resolve(oData1);
							// sap.ui.core.BusyIndicator.hide();
						},
						error: function (oError, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
								duration: 5000
							});
							reject(oResponse);
						}
					});
				});
		},

		onLoadChangeProjectData: function (Zpspid, TYPE) {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			that.aAgm = "X";
			that.aWbsowner1 = "X";
			that.aWbsowner2 = "X";
			that.aFinApp = "X";
			that.aPrjAc = "X";
			that.aDraftIa = "X";
			that.aBds = "X";
			that.aInvRec = "X";
			that.aVbegdat = "X";
			that.aVenddat = "X";

			this.getView().getModel("appView").refresh(true);
			this.oManageRequestModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
			this.oManageRequestModel.read("/ManageProjectC1Set('" + Zpspid + "')", {
				urlParameters: {
					'$expand': "toManageItemC1"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
					}
					var oViewModel = that.getView().getModel("appView");
					var Zvbeln = oData.Zvbeln;
					var Zpspid = oData.Zpspid;

					that.oZvbeln = oData.Zvbeln;
					that.oZpspid = oData.Zpspid;

					that.getView().getModel("localModel").setProperty("/iwoTabTravel", oData.toManageItemC1.results);
					that.onLoadHeaderLabourProject(Zpspid, Zvbeln);
					for (var i = 0; i < oData.toManageItemC1.results.length; i++) {
						var Zposid = oData.toManageItemC1.results[i].Zposid;
						that.onLoadTaskProject(Zpspid, Zposid);
					}
					that.onLoadItemLabourProject(Zpspid, Zvbeln);
					that.getView().byId("idContractNo").setVisible(true);
					oViewModel.getData().OriginatorName = "";
					that.oContractID = oData.Zvbeln;
					oViewModel.getData().Contractid = that.oContractID;
					oViewModel.getData().RequestorEmail = "";

					if (!oData.ChangedOn) {
						oViewModel.getData().ReqDate = "";
					} else {
						oViewModel.getData().ReqDate = oData.ChangedOn.toDateString();
					}
					if (!oData.Des_sys) {
						oViewModel.getData().System = "";
					} else {
						oViewModel.getData().System = oData.Des_sys;
					}
					that.getView().getModel("appView").refresh(true);
					var sCode = oData.Zbukrs;
					var sTerm = oData.Zterm;
					that.getView().byId("comCode").setValue(sCode);
					that.getView().byId("idComCo2").setValue(sCode);
					that.getView().byId("idPaymt").setValue(sTerm);
					if (oData.Email) {
						var oEmail = oData.Email;
						var aLen = oEmail.length;
						if (aLen !== 0) {
							var data = oEmail.split(",");
							var tokenValue = [];
							for (var i = 0; i < data.length; i++) {
								tokenValue.push(new Token({
									text: data[i],
									key: data[i]
								}));
							}
							var oMultiInput1 = that.getView().byId("wbsEmail");
							oMultiInput1.setTokens(tokenValue);
						}
					}
					var prjType = oData.toManageItemC1.results[0].Prart;
					var oProjectBox = that.getView().byId("idProjTyp");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sCode)
						],
						and: true
					});
					oBindingBox.filter(aFilters);

					if (prjType === "RV") {
						prjType = "ZBC";
					} else if (prjType === "GB") {
						prjType = "ZCGC";
					} else if (prjType === "LT" || prjType === "OH" || prjType === "ST" || prjType === "BP" || prjType ===
						"SU" || prjType === "SB" || prjType === "BS" || prjType === "BN" || prjType === "IN") {
						prjType = "ZPRJ";

					}
					that.getView().byId("idProjTyp").setSelectedKey(prjType);
					var key = that.getView().byId("idProjTyp").getSelectedKey();

					// //Tab 2

					if (key === "ZPRJ") {
						sap.m.MessageToast.show("Internal Project Selected", {
							duration: 5000
						});
						that.getView().byId("SimpleFormInternal").setVisible(true);
						that.getView().byId("SimpleFormChangewbs").setVisible(false);
						that.getView().byId("subTyp").setVisible(true);
						that.getView().byId("idSubTyp").setVisible(true);
						if (TYPE === "CSIReview" || TYPE === "BILLReview" || TYPE === "View" || TYPE === "ChangeProject") {
							that.getView().byId("idSubTyp").setEditable(false);
							// that.getView().byId("idDelInternal").setEnabled(false);
						}

						that.getView().byId("idInternal").setVisible(true);
						that.getView().byId("idTravel").setVisible(false);

						//Tab 1	
						var sSubType = oData.PrjStp;
						that.getView().byId("idSubTyp").setSelectedKey(sSubType);
						//================ Internal Form =====================
						//Tab 2
						that.getView().getModel().getData().wbsInternal.Ktext = oData.Ktext;
						that.getView().byId("idComFormInt").setValue(sCode);
						that.getView().getModel().getData().wbsInternal.Waers = oData.Waers;
						var sPrjCur = oData.Waers;
						that.getView().byId("idUSDInt").setValue(sPrjCur);
						that.getView().getModel().getData().wbsInternal.Zterm = oData.Zterm;
						that.getView().getModel().getData().wbsInternal.Guebg = oData.Guebg;
						that.oHeaderStartDateInt = oData.Guebg;
						that.getView().getModel().getData().wbsInternal.Gueen = oData.Gueen;
						that.oHeaderEndDateInt = oData.Gueen;

					} else {
						sap.m.MessageToast.show("Revenue Project Selected", {
							duration: 5000
						});
						if (key === "ZBC" || key === "ZCGC") {

							that.getView().byId("SimpleFormInternal").setVisible(false);
							that.getView().byId("SimpleFormChangewbs").setVisible(true);
							that.getView().byId("subTyp").setVisible(false);
							that.getView().byId("idSubTyp").setVisible(false);
							that.getView().byId("idInternal").setVisible(false);
							that.getView().byId("idTravel").setVisible(true);

							that.getView().getModel().getData().wbsRevenue.Ktext = oData.Ktext;
							if (oData.ZriskInd === "X") {
								oData.ZriskInd = true;
								that.getView().byId("ch2").setSelected(oData.ZriskInd);
								that.getView().byId("idSign").setRequired(false);

							}
							that.getView().getModel().getData().wbsRevenue.ZriskInd = oData.ZriskInd;
							that.getView().getModel().getData().wbsRevenue.ZzCasId = oData.ZzCasId;
							that.getView().getModel().getData().wbsRevenue.Bstnk = oData.Bstnk;
							var sProCur = oData.Waers;
							that.getView().byId("idUSD").setValue(sProCur);
							that.getView().getModel().getData().wbsRevenue.Bstdk = oData.Bstdk;

							that.oBillcall = oData.Perfk;

							that.getView().getModel().getData().wbsRevenue.Perfk = that.oBillcall;
							var sPymntTerm = oData.Zterm;
							that.getView().byId("idPaymt").setValue(sPymntTerm);
							that.getView().getModel().getData().wbsRevenue.ZPtReason = oData.ZPtReason;
							that.getView().getModel().getData().wbsRevenue.Agm = oData.Agm;
							that.getView().getModel().getData().wbsRevenue.Guebg = oData.Guebg;
							that.oHeaderStartDate = oData.Guebg;
							that.getView().getModel().getData().wbsRevenue.Gueen = oData.Gueen;
							that.oHeaderEndDate = oData.Gueen;

						}
					}
					if (TYPE === "ChangeProject") {
						oData.toManageItemC1.results.forEach(function (oItem) {
							oItem.Zentry_tp = oItem.Zentry_tp || "E";
						});
						that.getView().getModel("localModel").setProperty("/iwoTabTravel", oData.toManageItemC1.results);
						var oRevRowIndex = that.getView().getModel("localModel").getData().iwoTabTravel.length;
						for (var i = 0; i < oRevRowIndex; i++) {
							if (oData.toManageItemC1.results[i].payerName === ",,,") {
								oData.toManageItemC1.results[i].payerName = "";
							}
							if (oData.toManageItemC1.results[i].billToName === ",,,") {
								oData.toManageItemC1.results[i].billToName = "";
							}
							if (oData.toManageItemC1.results[i].shipToName === ",,,") {
								oData.toManageItemC1.results[i].shipToName = "";
							}
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Agm = oData.toManageItemC1.results[i].agmName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Bds = oData.toManageItemC1.results[i].bdsName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = oData.toManageItemC1.results[i].wbsowner1Name;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = oData.toManageItemC1.results[i].wbsowner2Name;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].PrjAc = oData.toManageItemC1.results[i].prjAcName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].InvRec = oData.toManageItemC1.results[i].invRecName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].FinApp = oData.toManageItemC1.results[i].finAppName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].DraftIa = oData.toManageItemC1.results[i].draftIAName;
							var oEndDateLItem = oData.toManageItemC1.results[i].Venddat;
							// var oLineItemEndYear = oEndDateLItem.getFullYear();
							// var oLineItemEndMonth = oEndDateLItem.getMonth();
							// var oLineItemEndDay = oEndDateLItem.getDate();
							// var oEndDateLineItem = oLineItemEndYear.toString() + oLineItemEndMonth.toString() + oLineItemEndDay.toString();
							// that.oEndDateLineItem = oEndDateLineItem;

							var oSysLine = oData.toManageItemC1.results[i].Systatusline;
							// var oSystatusline = oSysLine.split("/")[0];
							// that.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline = oSystatusline;
							if (oSysLine === "REL" || oSysLine === "TECO" || oSysLine === "CLSD") {
								// oViewModel.getData().SyslineFlag = "oSysDisplay";
								that.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline = oSysLine;
								that.getView().getModel("appView").refresh(true);
							} else if (oSysLine === "DLFL") {
								that.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline = oSysLine;
								// oViewModel.getData().SyslineFlag = "oSysEdit";
								that.getView().getModel("appView").refresh(true);
							}

							// if (oSystatusline === "REL" || oSystatusline === "TECO" || oSystatusline === "CLSD") {
							// 	// oViewModel.getData().SyslineFlag = "oSysDisplay";
							// 	that.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline = oSystatusline;
							// 	that.getView().getModel("appView").refresh(true);
							// } else if (oSystatusline === "DLFL") {
							// 	that.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline = oSystatusline;
							// 	// oViewModel.getData().SyslineFlag = "oSysEdit";
							// 	that.getView().getModel("appView").refresh(true);
							// }

						}
						//Phase 2 Code Start
						var oModelE = that.getView().getModel("oDataModel");
						if (prjType === "ZBC" || prjType === "ZCGC") {
							oModelE.read("/WBSHeaderChngFlgSet('" + prjType + "')", {
								success: function (oData, oResponse) {
									var eAgm = oData.Agm;
									if (eAgm === 'X') {
										that.getView().byId("idAccMan").setEditable(true);
									} else {
										that.getView().byId("idAccMan").setEditable(false);
									}

									// var eBds = oData.Bds;
									// if (eBds === 'X') {
									// 	that.getView().byId("idBillStw").setEditable(true);
									// } else {
									// 	that.getView().byId("idBillStw").setEditable(false);
									// }

									var eBillTo = oData.BillTo;
									if (eBillTo === 'X') {
										that.getView().byId("idbill").setEditable(true);
									} else {
										that.getView().byId("idbill").setEditable(false);
									}
									var eBstdk = oData.Bstdk; //PO Date
									if (eBstdk === 'X') {
										that.getView().byId("dateCtrlPo").setEditable(true);
									} else {
										that.getView().byId("dateCtrlPo").setEditable(false);
									}
									var eBstnk = oData.Bstnk; //PO Number
									if (eBstnk) {
										that.getView().byId("idpo").setEditable(true);
									} else {
										that.getView().byId("idpo").setEditable(false);
									}
									var eDraftIa = oData.DraftIa;
									if (eDraftIa === 'X') {
										that.getView().byId("idDrftInv").setEditable(true);
									} else {
										that.getView().byId("idDrftInv").setEditable(false);
									}
									var eFinApp = oData.FinApp;
									if (eFinApp === 'X') {
										that.getView().byId("idFinApp").setEditable(true);
									} else {
										that.getView().byId("idFinApp").setEditable(false);
									}
									var eGuebg = oData.Guebg;
									if (eGuebg === 'X') {
										that.getView().byId("dateCtrlStr").setEditable(true);
									} else {
										that.getView().byId("dateCtrlStr").setEditable(false);
									}
									var eGueen = oData.Gueen;
									if (eGueen === 'X') {
										that.getView().byId("dateCtrlEnd").setEditable(true);
									} else {
										that.getView().byId("dateCtrlEnd").setEditable(false);
									}
									// var eInvRec = oData.InvRec;
									// if (eInvRec === 'X') {
									// 	that.getView().byId("idInv").setEditable(true);
									// } else {
									// 	that.getView().byId("idInv").setEditable(false);
									// }
									var eKtext = oData.Ktext; //Project Description
									if (eKtext === 'X') {
										that.getView().byId("idProjDes").setEditable(true);
									} else {
										that.getView().byId("idProjDes").setEditable(false);
									}
									var eKvgr1 = oData.Kvgr1;
									if (eKvgr1 === 'X') {
										that.getView().byId("idInvLay").setEditable(true);
									} else {
										that.getView().byId("idInvLay").setEditable(false);
									}
									var ePayer = oData.Payer;
									if (ePayer === 'X') {
										that.getView().byId("idPayer").setEditable(true);
									} else {
										that.getView().byId("idPayer").setEditable(false);
									}
									var ePerfk = oData.Perfk;
									if (ePerfk === 'X') {
										that.getView().byId("idBillCal").setEditable(true);
									} else {
										that.getView().byId("idBillCal").setEditable(false);
									}
									// var ePrjAc = oData.PrjAc;
									// if (ePrjAc === 'X') {
									// 	that.getView().byId("idProAc").setEditable(true);
									// } else {
									// 	that.getView().byId("idProAc").setEditable(false);
									// }
									var eShipTo = oData.ShipTo;
									if (eShipTo === 'X') {
										that.getView().byId("idship").setEditable(true);
									} else {
										that.getView().byId("idship").setEditable(false);
									}
									// var eSoldto = oData.Soldto;
									// if (eSoldto === 'X') {
									// 	that.getView().byId("idSoldTo").setEditable(true);
									// } else {
									// 	that.getView().byId("idSoldTo").setEditable(false);
									// }
									// var eWaers = oData.Waers;
									// if (eWaers === 'X') {
									// 	that.getView().byId("idUSD").setEditable(true);
									// } else {
									// 	that.getView().byId("idUSD").setEditable(false);
									// }
									var eWbsowner1 = oData.Wbsowner1;
									if (eWbsowner1 === 'X') {
										that.getView().byId("idWBS1").setEditable(true);
									} else {
										that.getView().byId("idWBS1").setEditable(false);
									}
									var eWbsowner2 = oData.Wbsowner2;
									if (eWbsowner2 === 'X') {
										that.getView().byId("idWBS2").setEditable(true);
									} else {
										that.getView().byId("idWBS2").setEditable(false);
									}
									var eZPtReason = oData.ZPtReason;
									if (eZPtReason === 'X') {
										that.getView().byId("idReason").setEditable(true);
									} else {
										that.getView().byId("idReason").setEditable(false);
									}
									var eZterm = oData.Zterm;
									if (eZterm === 'X') {
										that.getView().byId("idPaymt").setEditable(true);
									} else {
										that.getView().byId("idPaymt").setEditable(false);
									}
									var eZzCasId = oData.ZzCasId;
									if (eZzCasId === 'X') {
										that.getView().byId("idSign").setEditable(true);
									} else {
										that.getView().byId("idSign").setEditable(false);
									}

								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							}); //Header Group A&B
							oModelE.read("/WBSItemChngFlgSet('" + prjType + "')", {

								success: function (oResponse) {
									// delete oResponse.__metadata;
									// delete oResponse.toItmChngFlg.__metadata;
									var EnableDesable = new JSONModel(oResponse);
									that.getView().setModel(EnableDesable, "EnableDesable");

									// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
									// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

									sap.ui.core.BusyIndicator.hide();
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							}); //Item Group A&B
						}

						//Internal Project Type
						if (prjType === "ZPRJ") {
							//Header Internal
							oModelE.read("/WBSHeaderChngFlgSet('" + prjType + "')", {
								success: function (oData, oResponse) {

									var KtextInt = oData.Ktext;
									if (KtextInt === 'X') {
										that.getView().byId("idProIntDs").setEditable(true);
									} else {
										that.getView().byId("idProIntDs").setEditable(false);
									}
									var GuebgInt = oData.Guebg;
									if (GuebgInt) {
										that.getView().byId("idStarInt").setEditable(true);
									} else {
										that.getView().byId("idStarInt").setEditable(false);
									}
									var GueenInt = oData.Gueen;
									if (GueenInt === 'X') {
										that.getView().byId("idEndInt").setEditable(true);
									} else {
										that.getView().byId("idEndInt").setEditable(false);
									}
									var AgmInt = oData.Agm;
									if (AgmInt === 'X') {
										that.getView().byId("idAccManInt").setEditable(true);
									} else {
										that.getView().byId("idAccManInt").setEditable(false);
									}
									var Wbsowner1Int = oData.Wbsowner1;
									if (Wbsowner1Int === 'X') {
										that.getView().byId("idWBS1Int").setEditable(true);
									} else {
										that.getView().byId("idWBS1Int").setEditable(false);
									}
									var Wbsowner2Int = oData.Wbsowner2;
									if (Wbsowner2Int === 'X') {
										that.getView().byId("idWBS2Int").setEditable(true);
									} else {
										that.getView().byId("idWBS2Int").setEditable(false);
									}
									var DraftIaInt = oData.DraftIa;
									if (DraftIaInt === 'X') {
										that.getView().byId("idDr").setEditable(true);
									} else {
										that.getView().byId("idDr").setEditable(false);
									}
									var FinAppInt = oData.FinApp;
									if (FinAppInt === 'X') {
										that.getView().byId("idFinAppInt").setEditable(true);
									} else {
										that.getView().byId("idFinAppInt").setEditable(false);
									}
									var PrjAcInt = oData.PrjAc;
									if (PrjAcInt === 'X') {
										that.getView().byId("idProAcInt").setEditable(true);
									} else {
										that.getView().byId("idProAcInt").setEditable(false);
									}

								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							});
							//Line Item Internal
							oModelE.read("/WBSItemChngFlgSet('" + prjType + "')", {

								success: function (oResponse) {
									// delete oResponse.__metadata;
									// delete oResponse.toItmChngFlg.__metadata;
									var EnableDesableIn = new JSONModel(oResponse);
									that.getView().setModel(EnableDesableIn, "EnableDesableIn");

									// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
									// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

									sap.ui.core.BusyIndicator.hide();
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							});

						}
						//Phase 2 End

						var oLoadProjRec = that.getView().getModel("localModel").getData().iwoTabTravel.length;
						for (var i = 0; i < oLoadProjRec; i++) {
							var oExistingRec = oData.toManageItemC1.results[i].Zentry_tp;
							// if (oExistingRec === "E") {
							// 	oViewModel.getData().FrasDis = "oDisplay";  //change while ph2 code
							// }

							//Phase 2 Enable and disable code
							// var oModelE = that.getView().getModel("oDataModel");

						}
						var oRevRowIndex = that.getView().getModel("localModel").getData().iwoTabTravel.length;
						for (var i = 0; i < oRevRowIndex; i++) {
							var sPlannedRevenue = that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplnrev;
							// var sPlannedRevenue = that.getView().getModel().getProperty("/iwoTabTravel")[0].Zplnrev;
							var nRevStr = sPlannedRevenue.replace(/,/g, '');
							var oSplit = nRevStr.split(".");
							var sRevenueValue = nRevStr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
							that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplnrev = sRevenueValue;
							that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].SavePopup = 'X';

						}
						//PlannedCost

						var oCosRowIndex = that.getView().getModel("localModel").getData().iwoTabTravel.length;
						for (var i = 0; i < oRevRowIndex; i++) {
							var sPlannedCost = that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplncst;
							var nCostStr = sPlannedCost.replace(/,/g, '');
							var oSplit = nCostStr.split(".");
							var sCostValue = nCostStr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
							that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplncst = sCostValue;
							// var ItemLaborIconToolTip = oData.toManageItemC1.results[i].laborFlg;
							// var TaskIconToolTip = oData.toManageItemC1.results[i].taskFlg;
							// if (!ItemLaborIconToolTip && !TaskIconToolTip) {} else {
							// 	if (ItemLaborIconToolTip === "X") {
							// 		var LaborTooltipText = "ItemLabour Present ,";
							// 		that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].laborFlg = LaborTooltipText;
							// 	} else {
							// 		var LaborTooltipText = "";
							// 		that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].laborFlg = LaborTooltipText;
							// 	}

							// 	if (TaskIconToolTip === "X") {
							// 		var TaskTooltipText = "Task Present";
							// 		that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].taskFlg = TaskTooltipText;
							// 	} else {
							// 		var TaskTooltipText = "";
							// 		that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].taskFlg = TaskTooltipText;
							// 	}
							// }
						}

						var iwotab = that.getView().getModel("localModel").getData().iwoTabTravel;
						var oViewModel = that.getView().getModel("appView");
						for (var i = 0; i < iwotab.length; i++) {
							if (that.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp === "E") {
								that.getView().byId("Itemlabor").setEnabled(false);
								that.getView().byId("tasks").setEnabled(false);
							}
						}
						that.onDisplayData(TYPE);
					}
					var oModelExt = that.getView().getModel("localModel").getData().iwoTabTravel;
					var oExtline1 = oModelExt[0].Zentry_tp;
					if (oExtline1 === "E" || TYPE === "ChangeProject") {
						//To Change app  title 
						var oView1 = that.getView().getParent();
						oView1.getService("ShellUIService").then(
							function (oService) {
								oService.setTitle("Manage Project Request"); //warranty(Description)
							}
						);
						that.byId("HeaderID").setObjectTitle("Manage Project Request"); //warranty

						//
					} else {
						//To Change app  title 
						var oView1 = that.getView().getParent();
						oView1.getService("ShellUIService").then(
							function (oService) {
								oService.setTitle("New Project Request");
							}
						);
						that.byId("HeaderID").setObjectTitle("New Project Request");
						//
					}
					// if (oExtline1 === "E" || TYPE === "ChangeProject") {
					// 	//To Change app  title 
					// 	var oView1 = that.getView().getParent();
					// 	oView1.getService("ShellUIService").then(
					// 		function (oService) {
					// 			oService.setTitle("Manage Project Request");
					// 		}
					// 	);
					// 	that.byId("HeaderID").setObjectTitle("Manage Project Request");

					// 	//
					// } else {
					// 	//To Change app  title 
					// 	var oView1 = that.getView().getParent();
					// 	oView1.getService("ShellUIService").then(
					// 		function (oService) {
					// 			oService.setTitle("New Project Request");
					// 		}
					// 	);
					// 	that.byId("HeaderID").setObjectTitle("New Project Request");
					// 	//
					// }
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});

			var ReqNo = "";
			this.oManageRequestModel.read("/Customer_NameSet(ReqNo='" + ReqNo + "',Zpspid='" + Zpspid + "')", {
				success: function (oData1, oResponse1) {
					var oViewModel = that.getView().getModel("appView");
					oViewModel.getData().Originator = oData1.Changedby;
					that.getView().getModel("appView").refresh(true);

					that.getView().getModel().getData().wbsInternal.Soldto = oData1.SoldTo;
					that.getView().getModel().getData().wbsInternal.Agm = oData1.AccGenMan;
					that.getView().getModel().getData().wbsInternal.Wbsowner1 = oData1.WbsOwnr1;
					that.getView().getModel().getData().wbsInternal.Wbsowner2 = oData1.WbsOwnr2;
					that.getView().getModel().getData().wbsInternal.FinApp = oData1.FinApp;
					that.getView().getModel().getData().wbsInternal.DraftIa = oData1.DraftInvApp;

					that.getView().getModel().getData().wbsInternal.PrjAc = oData1.ProAcc;

					that.getView().getModel().getData().wbsRevenue.Soldto = oData1.SoldTo;
					that.getView().getModel().getData().wbsRevenue.Payer = oData1.Payer;
					that.getView().getModel().getData().wbsRevenue.ShipTo = oData1.ShipTo;

					that.getView().getModel().getData().wbsRevenue.BillTo = oData1.BillTo;

					that.getView().getModel().getData().wbsRevenue.Kvgr1 = oData1.InvLay;
					var oBillcal1 = oData1.BillCal;
					if (oBillcal1) {
						that.getView().getModel().getData().wbsRevenue.Perfk = oData1.BillCal;
					} else {
						that.getView().getModel().getData().wbsRevenue.Perfk = that.oBillcall;
					}
					// that.getView().getModel().getData().wbsRevenue.Perfk = oData1.BillCal;
					that.getView().getModel().getData().wbsRevenue.Agm = oData1.AccGenMan;
					that.getView().getModel().getData().wbsRevenue.Wbsowner1 = oData1.WbsOwnr1;
					that.getView().getModel().getData().wbsRevenue.Wbsowner2 = oData1.WbsOwnr2;
					that.getView().getModel().getData().wbsRevenue.FinApp = oData1.FinApp;
					that.getView().getModel().getData().wbsRevenue.DraftIa = oData1.DraftInvApp;
					that.getView().getModel().getData().wbsRevenue.PrjAc = oData1.ProAcc;
					that.getView().getModel().getData().wbsRevenue.Bds = oData1.BillDataSte;
					that.getView().getModel().getData().wbsRevenue.InvRec = oData1.InvRec;

					sap.ui.core.BusyIndicator.hide();
					// }
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},
		onLoadHeaderLabourProject: function (sZpspid, sZvbeln) {
			var sZposid = "";
			var that = this;
			that.oManageRequestModel.read("/ManageProjectItemC1Set(Zpspid='" + sZpspid + "',Zposid='" + sZposid + "',Zvbeln='" + sZvbeln +
				"')/toC1Labor", {

					success: function (oData, oResponse) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}

						that.getView().getModel().setProperty("/laborData", oData.results);
						oData.results.forEach(function (oItem) {
							oItem.HRowType = "E";
							oItem.Zentry_lab = oItem.Zentry_lab || "E";
						});
						sap.ui.core.BusyIndicator.hide();
						//Phase 2 Header Labor E/D
						var oModelE = that.getView().getModel("oDataModel");
						var pProjectTyp = that.getView().byId("idProjTyp").getSelectedKey();
						//|| pProjectTyp === "ZPRJ"
						if (pProjectTyp === "ZBC") {
							oModelE.read("/WBSHeaderChngFlgSet('" + pProjectTyp + "')/toLaborChng", {

								success: function (oResponse) {
									// delete oResponse.__metadata;
									// delete oResponse.toItmChngFlg.__metadata;
									var EnableDesableLabor = new JSONModel(oResponse);
									that.getView().setModel(EnableDesableLabor, "EnableDesableLabor");

									// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
									// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

									sap.ui.core.BusyIndicator.hide();
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							});
						}
					},
					error: function (error) {
						sap.ui.core.BusyIndicator.hide();
					}
				});
		},
		onLoadItemLabourProject: function (sZpspid, sZvbeln) {
			var oModel = this.getView().getModel("oDataModel");
			var sZposid = "";
			var that = this;
			that.oManageRequestModel.read("/ManageProjectItemC1Set(Zpspid='" + sZpspid + "',Zposid='" + sZposid + "',Zvbeln='" + sZvbeln +
				"')/toC1LaborItems", {
					success: function (oData, oResponse) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}
						oData.results.forEach(function (oItem) {
							oItem.Zentry_lab = oItem.Zentry_lab || "E";
						});
						that.getView().getModel().setProperty("/itemLaborData", oData.results);
						that.getView().getModel().getData().labor = that.getView().getModel().getData().itemLaborData;
						that.oiwotabtravel = that.getView().getModel("localModel").getData().iwoTabTravel;
						for (var i = 0; i < that.oiwotabtravel.length; i++) {
							var oPosnr = that.oiwotabtravel[i].Posnr;
							var oItemLabData = that.getView().getModel().getData().itemLaborData;
							var oitemDataTab = oItemLabData.filter(function (a) {
								return a.Posnr === oPosnr;
							});
							that.oiwotabtravel[i].labor = oitemDataTab;
						}
						that.getView().getModel("localModel").refresh(true);
						sap.ui.core.BusyIndicator.hide();
					},
					error: function (error) {
						sap.ui.core.BusyIndicator.hide();
					}
				});
		},
		onLoadTaskProject: function (sZpspid, sZposid) {
			var oModel = this.getView().getModel("oDataModel");
			var sZvbeln = "";
			var that = this;
			that.oManageRequestModel.read("/ManageProjectItemC1Set(Zpspid='" + sZpspid + "',Zposid='" + sZposid + "',Zvbeln='" + sZvbeln +
				"')/toC1Tasks", {
					success: function (oData, oResponse) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}
						oData.results.forEach(function (oItem) {
							oItem.Zentry_tsk = oItem.Zentry_tsk || 'E';
						});
						var oTaskData = that.getView().getModel().getProperty("/taskData");
						var totalData = oTaskData.concat(oData.results);
						that.getView().getModel().setProperty("/taskData", totalData);
						that.getView().getModel().getData().task = that.getView().getModel().getData().taskData;
						that.oiwotabtravelT = that.getView().getModel("localModel").getData().iwoTabTravel;
						for (var i = 0; i < that.oiwotabtravelT.length; i++) {
							var oPosnr = that.oiwotabtravelT[i].Posnr;
							var oTaskoData = that.getView().getModel().getData().taskData;
							var oDataTabTask = oTaskoData.filter(function (a) {
								return a.Posnr === oPosnr;
							});
							that.oiwotabtravelT[i].task = oDataTabTask;
						}
						that.getView().getModel("localModel").refresh(true);
						//Phase 2 Header Task E/D
						var oModelE = that.getView().getModel("oDataModel");
						var pProjectTyp = that.getView().byId("idProjTyp").getSelectedKey();
						if (pProjectTyp === "ZBC" || pProjectTyp === "ZPRJ") {
							oModelE.read("/WBSHeaderChngFlgSet('" + pProjectTyp + "')/toTaskChng", {

								success: function (oResponse) {
									// delete oResponse.__metadata;
									// delete oResponse.toItmChngFlg.__metadata;
									var EnableDesableTask = new JSONModel(oResponse);
									that.getView().setModel(EnableDesableTask, "EnableDesableTask");

									// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
									// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

									sap.ui.core.BusyIndicator.hide();
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							});
						}
						sap.ui.core.BusyIndicator.hide();
					},
					error: function (error) {
						sap.ui.core.BusyIndicator.hide();
					}
				});
		},
		onDraftChangeRequestDisable: function () {
			var aIds = ["comCode", "idProjTyp", "idSoldTo", "idPayer", "idship", "idbill", "idProjDes", "ch2", "idSign", "idUSD", "idpo",
				"dateCtrlPo", "idPaymt", "idReason", "idInvLay", "idBillCal", "dateCtrlStr", "dateCtrlEnd", "idAccMan", "idWBS1", "idWBS2",
				"idDrftInv", "idFinApp"
			];
			this._fnSetEditableFalse(aIds);
		},

		onDisplayData: function (TYPE) {
			// ====== Tab 1 =========
			var that = this;
			that.getView().byId("comCode").setEditable(false);
			that.getView().byId("idProjTyp").setEditable(false);
			if (TYPE === "ChangeProject") {
				that.getView().byId("TypeHere").setEditable(true);
				that.getView().byId("wbsEmail").setEditable(true);
				that.getView().byId("fileUploader").setEnabled(true);
				that.getView().byId("idAddiHeader").setVisible(false);
			} else {
				that.getView().byId("TypeHere").setEditable(false);
				that.getView().byId("wbsEmail").setEditable(false);
				that.getView().byId("idAddiHeader").setVisible(true);
				if (TYPE === "View") {
					that.getView().byId("fileUploader").setEnabled(true);
				} else {
					that.getView().byId("fileUploader").setEnabled(false);
				}
			}
			//======= Tab 2 ======= Revenue =====
			var aIds = ["idSoldTo", "idPayer", "idship", "idbill", "idProjDes", "idComCo2", "ch2", "idSign", "idUSD", "idpo", "dateCtrlPo",
				"idPaymt", "idReason", "idInvLay", "idBillCal", "idAccMan", "idWBS1", "idWBS2", "idDrftInv", "dateCtrlStr", "dateCtrlEnd",
				"idFinApp", "idProAc", "idBillStw", "idInv"
			];
			this._fnSetEditableFalse(aIds);

			//==== Tab 2 ======= Internal ==========

			that.getView().byId("idIntSold").setEditable(false);
			that.getView().byId("idProIntDs").setEditable(false);
			that.getView().byId("idUSDInt").setEditable(false);

			that.getView().byId("idAccManInt").setEditable(false);
			that.getView().byId("idWBS1Int").setEditable(false);
			that.getView().byId("idWBS2Int").setEditable(false);
			that.getView().byId("idDr").setEditable(false);
			that.getView().byId("idFinAppInt").setEditable(false);

			if (TYPE === "BILLReview") {
				// that.getView().byId("idSaveBtn").setVisible(true);
				that.getView().byId("idProAc").setEditable(true);
				that.getView().byId("idBillStw").setEditable(true);
				that.getView().byId("idInv").setEditable(true);
				that.getView().byId("fileUploader").setEnabled(true);
				that.getView().byId("massUpload").setEnabled(true);
				that.getView().byId("idSubBtnRevision").setEnabled(true);
				that.getView().byId("idIWODownload").setEnabled(false);
				that.getView().byId("idSentBackBtn").setEnabled(false);
				that.getView().byId("idIWODownload").setEnabled(false);
				that.getView().byId("validBtn").setEnabled(false);
				that.getView().byId("SDBtn").setEnabled(false);
				that.getView().byId("SubBtn").setEnabled(false);
			}
			if (TYPE === "CSIReview") {
				that.getView().byId("idSaveBtn").setVisible(true);
				that.getView().byId("idSaveBtn").setEnabled(false);
				that.getView().byId("idProAc").setEditable(true);
				that.getView().byId("idBillStw").setEditable(true);
				that.getView().byId("idInv").setEditable(true);
				that.getView().byId("fileUploader").setEnabled(true);
				that.getView().byId("massUpload").setEnabled(true);
				that.getView().byId("idSubBtnRevision").setEnabled(true);
				that.getView().byId("idDelInternal").setEnabled(false);
				that.getView().byId("idStarInt").setEditable(false);
				that.getView().byId("idEndInt").setEditable(false);
				that.getView().byId("idProAcInt").setEditable(true);
			} else {
				that.getView().byId("idSaveBtn").setVisible(false);
				that.getView().byId("idProAc").setEditable(false);
				that.getView().byId("idBillStw").setEditable(false);
				that.getView().byId("idInv").setEditable(false);
				that.getView().byId("idDelInternal").setEnabled(true);
				that.getView().byId("idProAcInt").setEditable(false);
			}
			//Table Disable 

			// //=======  Buttons==========
			that.getView().byId("idIWODownload").setEnabled(false);
			that.getView().byId("idSentBackBtn").setEnabled(false);
			that.getView().byId("idIWODownload").setEnabled(false);
			that.getView().byId("validBtn").setEnabled(false);
			that.getView().byId("SDBtn").setEnabled(false);
			that.getView().byId("SubBtn").setEnabled(false);
			if (TYPE === "ChangeProject") {
				that.getView().byId("addrecord11").setEnabled(true);
				that.getView().byId("addInternal").setEnabled(true);
				that.getView().byId("validBtn").setEnabled(true);
				that.getView().byId("SDBtn").setEnabled(true);
				that.getView().byId("SubBtn").setEnabled(true);

			} else {
				that.getView().byId("addrecord11").setEnabled(false);
				that.getView().byId("addInternal").setEnabled(false);
				that.getView().byId("idRDelete").setEnabled(false);
			}
		},
		onDisableCompleteFields: function (TYPE) {
			//	====== Tab 1 ========= Revenue  =======
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oRejectType = oViewModel.getData().RejectType;
			var that = this;
			that.getView().byId("comCode").setEditable(false);
			that.getView().byId("idProjTyp").setEditable(false);
			// that.getView().byId("idSubType").setEditable(false);
			that.getView().byId("TypeHere").setEditable(false);
			that.getView().byId("wbsEmail").setEditable(false);
			if (oRejectType === "BILLRej" || that.oStatus === "CSIRej") {
				that.getView().byId("fileUploader").setEnabled(true);
			} else {
				that.getView().byId("fileUploader").setEnabled(false);
			}
			//======= Tab 2 ======= Revenue =====

			var aIds = ["idSoldTo", "idPayer", "idship", "idbill", "idProjDes", "idComCo2", "ch2", "idSign", "idUSD", "idpo", "dateCtrlPo",
				"idPaymt", "idReason", "idInvLay", "idBillCal", "dateCtrlStr", "dateCtrlEnd", "idAccMan", "idWBS1", "idWBS2", "idDrftInv",
				"idFinApp"
			];
			this._fnSetEditableFalse(aIds);

			//==== Tab 2 ======= Internal ==========
			aIds = ["idIntSold", "idProIntDs", "idUSDInt", "idStarInt", "idEndInt", "idAccManInt", "idWBS1Int", "idWBS2Int", "idDr",
				"idFinAppInt", "idProAcInt"
			];
			this._fnSetEditableFalse(aIds);

			// //=======  Buttons==========
			that.getView().byId("idSaveBtn").setVisible(false);
			that.getView().byId("idIWODownload").setEnabled(false);
			that.getView().byId("idSentBackBtn").setEnabled(false);
			that.getView().byId("idIWODownload").setEnabled(false);
			that.getView().byId("validBtn").setEnabled(false);
			that.getView().byId("SDBtn").setEnabled(false);
			that.getView().byId("SubBtn").setEnabled(false);
			that.getView().byId("idSubBtnRevision").setEnabled(false);

			// if (TYPE === "BILLReview" || AppType === "BILLRej"|| that.oStatus === "APPROVED") {
			that.getView().byId("massUpload").setEnabled(true);
			// } else {
			// that.getView().byId("massUpload").setEnabled(false);
			// }

			that.getView().byId("addrecord11").setEnabled(false);
			that.getView().byId("idRDelete").setEnabled(false);
		},

		onPopUpCompleteIntDisable: function () {
			var aIds = ["idIFLegacy", "idIFcheck", "idLineAGMInter", "idOwner1Int", "idOwner2Int", "idFinanceAppInt", "idProjAccInt",
				"idDIAInt", "idStartDateInt", "idEndDateInt"
			];
			this._fnSetEditableFalse(aIds);
		},

		onSaveCSI: function () {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var oViewModel = this.getView().getModel("appView");
			var reqID = oViewModel.getData().Requestid;
			var draftData = this.onGetData("SAVE", reqID);
			var oModel = this.getView().getModel("oDataModel");
			oModel.create("/WBSRequestHeaderSet", draftData, {
				//    method: PUT,
				success: function (oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Data Saved Successfully", {
						duration: 5000
					});
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},

		onTokenUpdate: function (oEvent) {

			var sType = oEvent.getParameter("selectedItem").getKey();
			if (sType === "Existing") {
				sType = "E";
			} else if (sType === "Change") {
				sType = "C";
			} else if (sType === "New") {
				sType = "N";
			} else {
				sType = "";
			}
			//sap.ui.core.BusyIndicator.show(0);
			// var tskType = oEvent.getSource().getValue().split("/")[0];
			// if(tskType === "Existing"){
			// 	sType = "E";
			// }else if(tskType === "Change"){
			// 	sType = "C";
			// }else{
			// 	sType = "N";
			// }
			//var oiwotravel = this.getView().getModel("localModel").getData().iwoTabTravel.length;
			//var oZentry_tsk = this.oItemContext.getObject().Zentry_tsk;
			var otasklen = this.oItemContext.getObject().task.length;
			//var otasklen = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;
			for (var j = 0; j < otasklen; j++) {

				var Zentry_tsk = this.oItemContext.getObject().task[j].Zentry_tsk;

				var aFilters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Zentry_tsk", sap.ui.model.FilterOperator.Contains, sType),
						new sap.ui.model.Filter("Zentry_tsk", sap.ui.model.FilterOperator.Contains, sType)
					],
					and: false
				});

			}
			sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getBinding("rows").filter(aFilters);
			//sap.ui.core.BusyIndicator.hide();
			var oTasklength = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getBinding("rows").filter(aFilters).getLength();
			this._oTaskLabor.getModel("taskFragmodel").setProperty("/oCount", oTasklength);

			//var Zentry_tsk = this.getView().getModel("localModel").getData().iwoTabTravel[0].task[0].Zentry_tsk;
			// if(Zentry_tsk === "E"){
			// 	sType = "E";
			// }else if(Zentry_tsk === "C"){
			// 	sType = "C";
			// }

		},

		onTokenUpdateL1: function (oEvent) {
			var sType = oEvent.getParameter("type");
			var sKey = oEvent.getParameter("addedTokens")[0].getProperty("key");
			var oProjManager = this.getView().byId("idTable").getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).ProjManager;
			if (sType === "added") {
				oProjManager.push({
					"key": sKey,
					"text": sKey
				});
			} else if (sType === "removed") { // the same did for removed 
				oProjManager.pop({
					"key": sKey,
					"text": sKey
				});
			}
		},
		onTokenUpdateL2: function (oEvent) {
			var sType = oEvent.getParameter("type");
			var sKey = oEvent.getParameter("addedTokens")[0].getProperty("key");
			var oProjManager = this.getView().byId("idNonTrack").getModel().getProperty(oEvent.getSource().getBindingContext().getPath()).ProjManager;
			if (sType === "added") {
				oProjManager.push({
					"key": sKey,
					"text": sKey
				});
			} else if (sType === "removed") { // the same did for removed 
				oProjManager.pop({
					"key": sKey,
					"text": sKey
				});
			}
		},
		onTokenUpdateL3: function (oEvent) {
			var sType = oEvent.getParameter("type");
			var sKey = oEvent.getParameter("removedTokens")[0].getProperty("key");
			var oProjManager = this.getView().byId("idTravel").getModel("localModel").getProperty(oEvent.getSource().getBindingContext().getPath())
				.ProjManager;
			if (sType === "added") {
				oProjManager.push({
					"key": sKey,
					"text": sKey
				});
			} else if (sType === "removed") { // the same did for removed
				oProjManager.pop({
					"key": sKey,
					"text": sKey
				});
			}
		},

		onSuggestion1: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Cname", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			var oModel = this.getView().getModel("oDataModel");
			oModel.read("/SearchEmployeeSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onSuggestionmul: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionCoCode: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onSuggestionProfit: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("ProfitCentre", sap.ui.model.FilterOperator.Contains, sTerm));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		OnprofitCoCoValTime: function (oEvent) {
			this.onChangeTimeValidation(oEvent);
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var keyID = oEvent.getParameter("value");
			var aFilters = [];
			aFilters.push(new Filter("Pernr", sap.ui.model.FilterOperator.EQ, keyID));
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchEmployeeSet", {
				filters: aFilters,
				success: function (oResponse) {
					if (oResponse.results.length >= 1) {
						that.getView().byId("idTable").getRows()[iRowIndex].getCells()[10].setValue(oResponse.results[0].Bukrs);
						that.getView().byId("idTable").getRows()[iRowIndex].getCells()[10].fondisp(false);
						that.getView().byId("idTable").getRows()[iRowIndex].getCells()[10].setValueState("None");
						if (oResponse.results[0].Zsystem === "C1" || oResponse.results[0].Zsystem === "GSAP") {
							var proValue = that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].getValue();
							if (proValue === "") {
								that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("Error");
							} else {
								that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("Error");
								that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValue(proValue);
								that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("None");
							}
						} else {
							that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("None");
						}

					} else if (oResponse.results.length === 0) {
						that.getView().byId("idTable").getRows()[iRowIndex].getCells()[0].setValueState("Error");
					}
				},
				error: function (oError) {}
			});
		},
		OnSOWvalidationCheckTime: function (oEvent) {
			this.onChangeTimeValidation(oEvent);
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var keyID = oEvent.getSource().getSelectedKey();
			var getData = this.getView().getModel("oSowAppView").oData;
			var oTableData = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[3];
			var json = getData.filter(function (a) {
				return a.Jobsubcat === keyID;
			});
			if (json.length === 1) {
				var getStatus = json[0].Required;
				if (!getStatus) {
					oTableData.setValueState("None");
				} else {
					if (oTableData.getValue() === "") {
						oTableData.setValueState("Error");
					}
				}
			} else if (json.length === 0 || json.length >= 2) {
				this.getView().byId("idTable").getRows()[iRowIndex].getCells()[2].setValueState("Error");
			}

		},
		OnSOWvalidationCheckNonTime: function (oEvent) {
			this.onChangeTimeValidation(oEvent);
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var keyID = oEvent.getSource().getSelectedKey();
			var getData = this.getView().getModel("oSowAppView").oData;
			var oTableDataL2 = this.getView().byId("idNonTrack").getRows()[iRowIndex].getCells()[4];
			var json = getData.filter(function (a) {
				return a.Jobsubcat === keyID;
			});
			if (json.length === 1) {
				var getStatus = json[0].Required;
				if (!getStatus) {
					oTableDataL2.setValueState("None");
				} else {
					if (oTableDataL2.getValue() === "") {
						oTableDataL2.setValueState("Error");
					}
				}
			} else if (json.length === 0 || json.length >= 2) {
				this.getView().byId("idNonTrack").getRows()[iRowIndex].getCells()[3].setValueState("Error");
			}

		},
		onSelectChange: function (oEvent) {
			var keyID = oEvent.getParameter("value");
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			if (this.getView().getModel("appView").getData().userID === keyID) {
				this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].setValueState("Error");
				this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].setValueStateText("You Can't be a Approver!!!");
			} else {
				this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].setValueState("None");
			}
		},
		multiinputTimeTrack: function (oEvent) {

			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oMultiInpuidNonTrack = oView.byId(newID);
			var fValidator = function (args) {
				var text = args.text;

				return new Token({
					key: text,
					text: text
				});
			};
			oMultiInpuidNonTrack.addValidator(fValidator);
		},
		onRowCount: function (oEvent) {
			var oRow = oEvent.getSource().getParent(); //Get Row
			var oTable = oRow.getParent(); // Get Table
			return oTable.indexOfRow(oRow); //Get Row index
		},

		onSentBackBtnEnable: function (oStatSendBack) {
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/CurrentUserAdminCheckSet", {
				success: function (oResponse) {
					if (oResponse.results[0].AdminGroup === "GLOBALDXC" && (oStatSendBack === "E1100" | oStatSendBack === "E1101")) {
						that.byId("idSentBackBtn").setVisible(true);
					}
				},
				error: function (oError) {

				}
			});
		},

		fnAfterSubmission: function () {
			this.onClearData();
			sap.ui.core.BusyIndicator.hide();
			// var IWoID = oResponse.Iwo;
			sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("XMSG_SUBMISSIONOK"), {
				duration: 5000
			});
			var oViewModel = this.getView().getModel("appView");
			var oUser = new UserInfo();
			var ouserId = oUser.getId();
			oViewModel.getData().iwoNo = "";
			//oViewModel.getData().Requestid = "";
			oViewModel.getData().oErrorCount = 0;
			oViewModel.getData().OriginatorName = oUser.getUser().getFullName();
			oViewModel.getData().OwnerName = oUser.getUser().getFullName();
			oViewModel.getData().AdminName = "";
			oViewModel.getData().Owner = ouserId;
			oViewModel.getData().Originator = ouserId;
			oViewModel.getData().Submitter = "";
			oViewModel.getData().EstatTxt = "Draft";
			oViewModel.getData().statusCode = "E0001";
			this.getView().getModel("appView").refresh(true);
		},
		onSubmitRevisionBtnPress: function () {
			var oViewModel = this.getView().getModel("appView");
			var iwoId = oViewModel.getData().iwoNo;
			if (iwoId === "") {
				iwoId = "23183474";
			}
			var actionType = oViewModel.getData().actionType;
			if (actionType === "additionRes") {
				var action = "REVSUBMIT";
			} else {
				var action = "SUBMIT";
			}

			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			if (this.onCheckRowAvailablw()) {
				if (this.newValidation()) {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: [
							new Label({
								text: 'Please enter reason for revision.',
								labelFor: 'submitDialogTextarea'
							}),
							new TextArea('submitDialogTextarea', {
								maxLength: 60,
								liveChange: function (oEvent) {
									var sText = oEvent.getParameter('value');
									var parent = oEvent.getSource().getParent();

									parent.getBeginButton().setEnabled(sText.length > 0);
								},
								width: '100%',
								placeholder: 'Add note (required and max length: 60 Char.)'
							})
						],
						beginButton: new sap.m.Button({
							text: 'Submit',
							enabled: false,
							press: function () {
								var sStatus = that.getView().getModel("appView").oData.statusCode;

								var draftData = that.onGetData(sStatus, iwoId, action);
								var oModel = that.getView().getModel("oDataModel");
								var that1 = that;
								oModel.create("/IWORequestSet", draftData, {
									success: function (oResponse) {
										if (oResponse.toErrors.results.length > 0) {
											var oViewModel = that1.getView().getModel("appView");
											oViewModel.getData().iwoNo = oResponse.Iwo;
											oViewModel.getData().Requestid = oResponse.Requestid;
											oViewModel.getData().oErrorCount = oResponse.toErrors.results.length;
											that1.getView().setModel(oViewModel, "appView");
											that1.getView().getModel("appView").refresh(true);

											sap.ui.core.BusyIndicator.hide();
											sap.m.MessageToast.show("Please check the error log.", {
												duration: 5000
											});

											/*this for storing the error data*/
											var oErrorViewModel = that1.getView().getModel("oErrorAppView");
											oErrorViewModel = oResponse.toErrors.results;
											that1.getView().setModel(oErrorViewModel, "oErrorAppView");
											// that.getView().getModel("oErrorAppView").refresh(true);

											var L1 = oResponse.toLabor1.results;
											var L2 = oResponse.toLabor2.results;
											var L3 = oResponse.toOther.results;

											for (var i = 0; i < L1.length; i++) {
												var aLen = L1[i].ProjManager.length
												if (aLen != 0) {
													var data = L1[i].ProjManager.split(",");
													var projMan = [];
													for (var j = 0; j < data.length; j++) {
														var d = {
															key: data[j],
															text: data[j]
														};
														projMan.push(d);
													}
													delete oResponse.toLabor1.results[i].ProjManager;
													oResponse.toLabor1.results[i].ProjManager = projMan;
												}
											}
											for (var i = 0; i < L2.length; i++) {
												var aLen = L2[i].ProjManager.length
												if (aLen != 0) {
													var data = L2[i].ProjManager.split(",");
													var projMan = [];
													for (var j = 0; j < data.length; j++) {
														var d = {
															key: data[j],
															text: data[j]
														};
														projMan.push(d);
													}
													delete oResponse.toLabor2.results[i].ProjManager;
													oResponse.toLabor2.results[i].ProjManager = projMan;
												}
											}
											for (var i = 0; i < L3.length; i++) {
												var aLen = L3[i].ProjManager.length
												if (aLen != 0) {
													var data = L3[i].ProjManager.split(",");
													var projMan = [];
													for (var j = 0; j < data.length; j++) {
														var d = {
															key: data[j],
															text: data[j]
														};
														projMan.push(d);
													}
													delete oResponse.toOther.results[i].ProjManager;
													oResponse.toOther.results[i].ProjManager = projMan;
												}
											}
											var oModel = that.getView().getModel();
											var oModel1 = new sap.ui.model.json.JSONModel(oResponse.toLabor1.results);
											oModel.setProperty("/iwoTab", oModel1.getData());

											var oModel2 = new sap.ui.model.json.JSONModel(oResponse.toLabor2.results);
											oModel.setProperty("/iwoTabNonTrack", oModel2.getData());

											var oModel3 = new sap.ui.model.json.JSONModel(oResponse.toOther.results);
											oModel.setProperty("/iwoTabTravel", oModel3.getData());
										} else {
											that1.fnAfterSubmission();
										}
									},
									error: function (oError, oResponse) {
										sap.ui.core.BusyIndicator.hide();
										sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
											duration: 5000
										});
									}
								});
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
								sap.ui.core.BusyIndicator.hide();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Please, enter all the Mandatory fields...");
				}
			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please, add one record to perform the action...");
			}
		},

		onSentBack: function () {
			sap.ui.core.BusyIndicator.show(0);
			var oViewModel = this.getView().getModel("appView");
			var Iwo = oViewModel.getData().iwoNo;
			var Requestid = oViewModel.getData().Requestid;
			var oModel = this.getView().getModel("oDataModel");
			var sPath = "/IWORequestSet(Requestid='" + Requestid + "',Iwo='" + Iwo + "')";
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Confirm",
				type: "Message",
				content: [
					new Label({
						text: 'Please enter reason for Send Back.',
						labelFor: 'submitDialogTextarea'
					}),
					new TextArea('submitDialogTextarea', {
						maxLength: 60,
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();

							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: '100%',
						placeholder: 'Add note (required and max length: 60 Char.)'
					})
				],
				beginButton: new sap.m.Button({
					text: 'Submit',
					enabled: false,
					press: function () {
						var sPath = "/IWORequestSet(Requestid='" + Requestid + "',Iwo='" + Iwo + "')";
						var sendBackReason = sap.ui.getCore().byId("submitDialogTextarea").getValue();
						var oData = {
							"d": {
								"Iwo": Iwo,
								"Requestid": Requestid,
								"Send_Back_Reason": sendBackReason
							}
						};
						// var that = this;
						oModel.update(sPath, oData, {
							success: function (oResponse) {
								that.onClearData();
								sap.ui.core.BusyIndicator.hide();
								// var IWoID = oResponse.Iwo;
								sap.m.MessageToast.show("IWO request Send-Back Successfully.", {
									duration: 5000
								});
								// this.byId("idSentBackBtn").setVisible(true);
								var oUser = new UserInfo();
								var ouserId = oUser.getId();
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().iwoNo = "";
								//oViewModel.getData().Requestid = "";
								oViewModel.getData().oErrorCount = 0;
								oViewModel.getData().OriginatorName = oUser.getUser().getFullName();
								oViewModel.getData().OwnerName = oUser.getUser().getFullName();
								oViewModel.getData().AdminName = "";
								oViewModel.getData().Owner = ouserId;
								oViewModel.getData().Originator = ouserId;
								oViewModel.getData().Submitter = "";
								oViewModel.getData().EstatTxt = "Draft",
									oViewModel.getData().statusCode = "E0001";
								that.getView().getModel("appView").refresh(true);
							},
							error: function (oError) {
								sap.ui.core.BusyIndicator.hide();
								var msg = oError.responseText.split("value")[1].split("}")[0].split(":")[1];
								if (msg) {
									sap.m.MessageToast.show(msg, {
										duration: 5000
									});
								} else {
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							}
						});
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						dialog.close();
						sap.ui.core.BusyIndicator.hide();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		newValidation: function () {
			var oModel = this.getView().getModel();
			var itab = oModel.getProperty("/iwoTab");
			var itab2 = oModel.getProperty("/iwoTabNonTrack");
			var itab3 = oModel.getProperty("/iwoTabTravel");
			for (var i = 0; i < itab.length; i++) {
				if (itab[i].Employee !== undefined) {
					if (undefined !== itab[i].ProfitCentre) {
						if (itab[i].Employee !== "" && itab[i].OrigWbs !== "" && itab[i].JobSubCat !== undefined && itab[i].StartDate !== undefined &&
							itab[i].EndDate !== undefined && itab[i].Zhours !== "" && itab[i].ProjManager.length !== 0 && itab[i].PerfManager !== "" &&
							itab[i].PrefComCode !== "") {

						} else {
							return false;
						}
					} else {
						var empID = itab[i].Employee;
						var oStatus = this.OnprofitValidationL1(empID);
						if (oStatus) {
							return true;
						} else {
							if (itab[i].Employee !== "" && itab[i].OrigWbs !== "" && itab[i].JobSubCat !== undefined && itab[i].StartDate !== undefined &&
								itab[i].EndDate !== undefined && itab[i].Zhours !== "" && itab[i].ProjManager.length !== 0 && itab[i].PerfManager !== "" &&
								itab[i].PrefComCode !== "") {

							} else {
								return false;
							}
						}
					}

				} else {
					return false;
				}

			}
			for (var i = 0; i < itab2.length; i++) {

				if (itab2[i].FullName !== "" && itab2[i].OrigWbs !== "" && itab2[i].JobSubCat !== undefined && itab2[i].StartDate !== undefined &&
					itab2[i].EndDate !== undefined && itab2[i].Zhours !== "" && itab2[i].ProjManager.length !== 0 && itab2[i].Rate !== "" && itab2[
						i]
					.PerfManager !== "" && itab2[i].PerfCoCode !== "") {

				} else {
					return false;
				}
			}
			for (var i = 0; i < itab3.length; i++) {

				if (itab3[i].CostSubcat !== undefined && itab3[i].OrigWbs !== "" && itab3[i].GrossAmt !== "" && itab3[i].SowText !== "" && itab3[
						i]
					.StartDate !== undefined && itab3[i].EndDate !== undefined && itab3[i].PerfBukrs !== "" && itab3[i].ProjManager.length !== 0 &&
					itab3[i].PerfManager !== "") {

				} else {
					return false;
				}
			}
			return true;
		},
		OnprofitValidationL1: function (empID) {
			var aFilters = [];
			aFilters.push(new Filter("Pernr", sap.ui.model.FilterOperator.EQ, empID));
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchEmployeeSet", {
				filters: aFilters,
				success: function (oResponse) {
					if (oResponse.results.length >= 1) {
						if (oResponse.results[0].Zsystem === "C1" || oResponse.results[0].Zsystem === "GSAP") {
							return true;
						} else {
							return false;
						}
					} else if (oResponse.results.length === 0) {
						return true;
					}
				},
				error: function (oError) {}
			});
		},

		onCheckRowAvailablw: function () {
			var oTable = this.getView().byId("idTable").getModel();
			var oTable1 = this.getView().byId("idNonTrack").getModel();
			var oTable2 = this.getView().byId("idTravel").getModel("localModel");
			var oRows1 = oTable.getData().iwoTab.length - 1;
			var oRows2 = oTable1.getData().iwoTabNonTrack.length - 1;
			var oRows3 = oTable2.getData().iwoTabTravel.length - 1;
			if (oRows1 >= 0) {
				return true;
			} else if (oRows2 >= 0) {
				return true;
			} else if (oRows3 >= 0) {
				return true;
			} else {
				return false;
			}
		},

		onClearData: function () {
			var oTable = this.getView().byId("idTable");
			var oTable1 = this.getView().byId("idNonTrack");
			var oTable2 = this.getView().byId("idTravel");

			var oModel = oTable1.getModel();
			var oRows = oModel.getData().iwoTabNonTrack;
			var oModel1 = oTable.getModel();
			var oRows1 = oModel1.getData().iwoTab;
			var oModel2 = oTable2.getModel();
			var oRows2 = oModel2.getData().iwoTabTravel;
			for (var i = oRows.length - 1; i >= 0; i--) {
				var idx = oRows[i];
				oRows.splice(idx, 1);
			}
			for (var j = oRows1.length - 1; j >= 0; j--) {
				var idx1 = oRows1[j];
				oRows1.splice(idx1, 1);
			}
			for (var k = oRows2.length - 1; k >= 0; k--) {
				var idx2 = oRows2[k];
				oRows2.splice(idx2, 1);
			}
			oModel.setData({
				iwoTab: oRows1,
				iwoTabNonTrack: oRows,
				iwoTabTravel: oRows2
			});
			oTable.clearSelection();
		},

		/* For Create Non Time Track record  */
		onAddNonTimeTRack: function () {
			var oTable = this.getView().byId("idNonTrack");
			var oModel1 = oTable.getModel();
			var oRows = oModel1.getData().iwoTabNonTrack.length;
			var currRow = oTable.getVisibleRowCount();
			// ---> Adding code below  started 
			if (oTable.getVisibleRowCount() === oRows) {
				this.onCreateIwoNonTimeTrack();
			} else {
				this.onCreateIwoNonTimeTrack();
			}
		},

		onCreateIwoNonTimeTrack: function () {
			sap.ui.core.BusyIndicator.show(0);
			var oModel = this.getView().getModel();
			var itemRow = {
				"Requestid": "",
				"Iwo": "10104",
				"IwoguidItem": "",
				"Item": "",
				"ErrType": "W",
				"ProjManager": [],
			};
			var itab = oModel.getProperty("/iwoTabNonTrack");
			itab.push(itemRow);
			oModel.setProperty("/iwoTabNonTrack", itab);
			sap.ui.core.BusyIndicator.hide();
		},
		/* For Create travel and expence record  */
		onAddTravel: function () {
			this.onCreateIwoTravel();
		},

		onCreateIwoTravel: function () {

			// sap.ui.core.BusyIndicator.show(0);
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;

			var sRevenueTable = this.getView().byId("idTravel").getVisible();
			var sInternalTable = this.getView().byId("idInternal").getVisible();
			var oEnteryType = this.Zentry_tp;

			if (sRevenueTable === true) {
				var oModel = this.getView().getModel("localModel");

				if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && oEnteryType === "C") || (AppType === "ChangeRequest" &&
						oEnteryType === "E") || (AppType === "CSIRej" && oEnteryType === "E") || (AppType === "CSIRej" && oEnteryType === "C")) {
					var itemRow = {
						"Zentry_tp": "N",
						"UniqueId": "",
						"taskFlg": "",
						"laborFlg": "",
						"Zvbeln": this.oZvbeln,
						"Zpspid": this.oZpspid
					};
				} else {
					var itemRow = {
						"Zentry_tp": "N",
						"UniqueId": "",
						"taskFlg": "",
						"laborFlg": ""
					};
				}

				var itab = oModel.getProperty("/iwoTabTravel");
				itab.push(itemRow);
				oModel.setProperty("/iwoTabTravel", itab);
				var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
				this.getView().getModel("localModel").getData().iwoTabTravel[sRowCount - 1].Zentry_tp = "N";

				if (AppType === "ChangeProject" || AppType === "ChangeRequest") {
					var Num = null;
					var SeqNum = null;
					var sSeqNum = null;
					if (sRowCount > 1) {
						var lastRow = sRowCount - 1;
						Num = this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[lastRow - 1].Posnr;
						SeqNum = parseInt(Num, 10) + 1;
						sSeqNum = String(SeqNum).padStart;
					} else {
						SeqNum = parseInt(0, 10) + 1;
					}
					sSeqNum = String(SeqNum).padStart(6, '0');
					var oLocalModel = this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[sRowCount - 1];

					oLocalModel.Posnr = sSeqNum;
					oLocalModel.Zterm = this.getView().byId("idPaymt").getValue();
					oLocalModel.Bstnk = this.getView().byId("idpo").getValue();
					var ZPoDate = this.getView().byId("dateCtrlPo").getDateValue();
					oLocalModel.Agm = this.getView().byId("idAccMan").getValue();
					oLocalModel.DraftIa = this.getView().byId("idDrftInv").getValue();
					oLocalModel.FinApp = this.getView().byId("idFinApp").getValue();
					oLocalModel.Wbsowner1 = this.getView().byId("idWBS1").getValue();
					oLocalModel.Wbsowner2 = this.getView().byId("idWBS2").getValue();
					oLocalModel.Vbegdat = this.dateFormatter(this.getView().byId("dateCtrlStr").getDateValue());
					oLocalModel.Venddat = this.dateFormatter(this.getView().byId("dateCtrlEnd").getDateValue());
					oLocalModel.minEndDate = this.dateFormatter(this.getView().byId("dateCtrlStr").getDateValue());
					oLocalModel.payerName = this.getView().byId("idPayer").getValue();
					oLocalModel.shipToName = this.getView().byId("idship").getValue();
					oLocalModel.billToName = this.getView().byId("idbill").getValue();
					oLocalModel.PrjAc = this.getView().byId("idProAc").getValue();
					oLocalModel.Bds = this.getView().byId("idBillStw").getValue();
					oLocalModel.InvRec = this.getView().byId("idInv").getValue();

					if (!ZPoDate) {
						oLocalModel.Bstdk = null;
					} else {
						oLocalModel.Bstdk = this.dateFormatter(ZPoDate);
					}
					var oOppC1type = oViewModel.getData().type;
					// OpprAppC1Mng
					if (oOppC1type === "OpprAppC1" || oOppC1type === "OpprAppC1Mng") {
						oLocalModel.isRevenueMatEditable = true;
						oLocalModel.CaseSafeId = "";
					}

					//Added for sceanrio2 srini vallepu
					var that = this;
					var oLength = window.location.href.split("#")[1].split("?").length;
					if (oLength > 1) {
						var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
						if (oLength1 === 1) {
							if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryyManage") {
								jQuery.sap.require("jquery.sap.storage");
								var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
								if (oStorage.get("oppData")) {
									var obj = oStorage.get("oppData");
								}
								oLocalModel.ZsfdcOppid = obj[0].OptId;
								this.getView().byId("idTravel").getRows()[sRowCount - 1].getCells()[3].setEnabled(false);
								this.getView().byId("idTravel").getRows()[sRowCount - 1].getCells()[4].setEditable(true);
								var safeCaseFilters = [];
								for (var i in obj) {
									safeCaseFilters.push(new sap.ui.model.Filter("CaseSafeId", sap.ui.model.FilterOperator.EQ, obj[i].CasesafeId));
								}
								var aSafeCaseFilters = new sap.ui.model.Filter({
									filters: safeCaseFilters,
									and: false
								});
								var aFilters = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Optid", sap.ui.model.FilterOperator.EQ, obj[0].OptId),
										aSafeCaseFilters
									],
									and: true
								});
								that.getView().getModel("oDataModel").read("/SearchCaseSafeIdSet", {
									filters: [aFilters],
									success: function (oData) {
										that.getView().getModel("localModel").setProperty("/" + (sRowCount - 1) + "/oCaseSafeModel", oData.results);
									},
									error: function (oError) {}
								});
							}
						}
					}

					// end of chnges sceanrio2 srini vallepu.

				} else {
					var sSeqNum = 1;
					var oLocalModel = this.getView().byId("idTravel").getModel("localModel").getData();
					for (var i = 0; i < sRowCount; i++) {
						oLocalModel.iwoTabTravel[i].Posnr = String(sSeqNum);
						//Defaulting Payment Term on Sold To Customer at Header to Item Level
						sSeqNum = sSeqNum + 1;
					}
					oLocalModel.iwoTabTravel[sRowCount - 1].Agm = this.getView().byId("idAccMan").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].DraftIa = this.getView().byId("idDrftInv").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].FinApp = this.getView().byId("idFinApp").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].Wbsowner1 = this.getView().byId("idWBS1").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].Wbsowner2 = this.getView().byId("idWBS2").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].Vbegdat = this.dateFormatter(this.getView().byId("dateCtrlStr").getDateValue());
					oLocalModel.iwoTabTravel[sRowCount - 1].Venddat = this.dateFormatter(this.getView().byId("dateCtrlEnd").getDateValue());
					oLocalModel.iwoTabTravel[sRowCount - 1].minEndDate = this.dateFormatter(this.getView().byId("dateCtrlStr").getDateValue());
					oLocalModel.iwoTabTravel[sRowCount - 1].payerName = this.getView().byId("idPayer").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].shipToName = this.getView().byId("idship").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].billToName = this.getView().byId("idbill").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].PrjAc = this.getView().byId("idProAc").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].Bds = this.getView().byId("idBillStw").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].InvRec = this.getView().byId("idInv").getValue();

					oLocalModel.iwoTabTravel[sRowCount - 1].Zterm = this.getView().byId("idPaymt").getValue();
					oLocalModel.iwoTabTravel[sRowCount - 1].Bstnk = this.getView().byId("idpo").getValue();

					var oOppC1type = oViewModel.getData().type;
					if (oOppC1type === "OpprAppC1") {
						oLocalModel.iwoTabTravel[sRowCount - 1].isRevenueMatEditable = true;
						oLocalModel.iwoTabTravel[sRowCount - 1].CaseSafeId = "";
					}
					var zPoDateCreate = this.getView().byId("dateCtrlPo").getDateValue();
					if (!zPoDateCreate) {
						oLocalModel.iwoTabTravel[sRowCount - 1].Bstdk = null;
					} else {
						oLocalModel.iwoTabTravel[sRowCount - 1].Bstdk = this.dateFormatter(zPoDateCreate);
					}
					//Added for sceanrio2 srini vallepu
					var oLength = window.location.href.split("#")[1].split("?").length;
					if (oLength > 1) {
						var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
						if (oLength1 === 1) {
							if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {

								jQuery.sap.require("jquery.sap.storage");
								var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
								if (oStorage.get("oppData")) {
									var obj = oStorage.get("oppData");
									// oStorage.clear();
								}
								this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[sRowCount - 1].ZsfdcOppid = obj[0].OptId;
								// this.getView().byId("idTravel").getRows()[sRowCount - 1].getCells()[3].setEditable(false);
								this.getView().byId("idTravel").getRows()[sRowCount - 1].getCells()[3].setEnabled(false);
								this.getView().byId("idTravel").getRows()[sRowCount - 1].getCells()[4].setEditable(true);
							}
						}
					}

					// end of chnges sceanrio2 srini vallepu.
				}
				// Added  by  Srini vallepu  -  Scenario2  code 

				var oOppC1type = oViewModel.getData().type;
				// OpprAppC1Mng
				if (oOppC1type === "OpprAppC1" || oOppC1type === "OpprAppC1Mng") {
					var oSafeCaseModel = this.getView().getModel("oCaseSafeModel").oData.results;
					var oBillModel = this.getView().getModel("oBillModel").oData.results;
					var oTbale = this.getView().getModel("localModel").getProperty("/iwoTabTravel");
					// this.getView().getModel("localModel").setProperty( 0 + "/oCaseSafeModel", oJon );
					// var contextid = "/iwoTabTravel/" + 0.toString();
					for (var m = 0; m < oTbale.length; m++) {
						var contextid = "/iwoTabTravel/" + m.toString();
						this.getView().getModel("localModel").setProperty(contextid + "/oCaseSafeModel", oSafeCaseModel);
						this.getView().getModel("localModel").setProperty(contextid + "/oBillModel", oBillModel);
					}

				}
				// end of  code  srini  vallepu 
				this.getView().getModel("localModel").refresh(true);
				sap.ui.core.BusyIndicator.hide();
			} else if (sInternalTable === true) {

				//this.getView().byId("idDelInternal").setEnabled(true);
				var oModel = this.getView().getModel("localModel");

				if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && oEnteryType === "C") || (AppType === "ChangeRequest" &&
						oEnteryType === "E") || (AppType === "CSIRej" && oEnteryType === "E") || (AppType === "CSIRej" && oEnteryType === "C")) {
					var itemRow = {
						"Zentry_tp": "N",
						"UniqueId": "",
						"taskFlg": "",
						"Zvbeln": this.oZvbeln,
						"Zpspid": this.oZpspid
					};
				} else {
					var itemRow = {
						"Zentry_tp": "N",
						"UniqueId": "",
						"taskFlg": ""
					};
				}

				var itab = oModel.getProperty("/iwoTabTravel");
				itab.push(itemRow);
				oModel.setProperty("/iwoTabTravel", itab);
				var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();

				if (AppType === "ChangeProject" || AppType === "ChangeRequest") {
					var lastRow = sRowCount - 1;
					var Num = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[lastRow - 1].Posnr;
					var SeqNum = parseInt(Num) + 1;
					var sSeqNum = String(SeqNum).padStart(6, '0');
					this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[sRowCount - 1].Posnr = sSeqNum;
					//Added for sceanrio2 srini vallepu
					var oLength = window.location.href.split("#")[1].split("?").length;
					if (oLength > 1) {
						var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
						if (oLength1 === 1) {
							if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryyManage") {
								jQuery.sap.require("jquery.sap.storage");
								var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
								if (oStorage.get("oppData")) {
									var obj = oStorage.get("oppData");
									// oStorage.clear();
								}
								this.getView().byId("idInternal").getModel().getData("localModel").iwoTabTravel[sRowCount - 1].ZsfdcOppid = obj[0].OptId;
								// this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[6].setEditable(false);
								this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[6].setEnabled(false);
								var osTyp = this.getView().byId("idSubTyp").getSelectedKey();
								if (osTyp === "BP") {
									this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[10].setEditable(true);
								} else {
									this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[7].setEditable(true);
								}
							}
						}
					}
				} else {
					var sSeqNum = 1;
					for (var i = 0; i < sRowCount; i++) {
						this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Posnr = String(sSeqNum);
						sSeqNum = sSeqNum + 1;
					}
				}

				var oViewModel = this.getView().getModel("appView");
				var sType = this.getView().byId("idSubTyp").getSelectedKey();
				var osystemid = oViewModel.getData().System;
				var Sysid = osystemid.split("(")[1].split(")")[0];
				this.getView().getModel("appView").refresh(true);
				var aFilters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Sysid", sap.ui.model.FilterOperator.EQ, Sysid),
						new sap.ui.model.Filter("Subtyp", sap.ui.model.FilterOperator.EQ, sType)
					],
					and: true
				});
				var oModel = this.getView().getModel("oDataModel");
				var that = this;
				oModel.read("/SearchIntMatSet", {
					filters: [aFilters],
					urlParameters: {
						"$top": 100
					},
					success: function (oResponse) {
						var oMatnr = oResponse.results[0].Material;
						var oMaktx = oResponse.results[0].Descripton;
						for (var i = 0; i < sRowCount; i++) {

							var oLocalModel = that.getView().byId("idInternal").getModel("localModel").getData();
							var oZentryType = oLocalModel.iwoTabTravel[i].Zentry_tp;
							if (oZentryType === "N" || oZentryType === "") {
								oLocalModel.iwoTabTravel[i].Pstyv = "ZPRJ";
								var oRest = oLocalModel.iwoTabTravel[0].Fkstl;
								var oProfit = oLocalModel.iwoTabTravel[0].Prctr;
								var oktext = oLocalModel.iwoTabTravel[0].Ktext;
								oLocalModel.iwoTabTravel[i].Fkstl = oRest;
								oLocalModel.iwoTabTravel[i].Prctr = oProfit;
								oLocalModel.iwoTabTravel[i].Ktext = oktext;
								oLocalModel.iwoTabTravel[i].DraftIa = that.getView().byId("idDr").getValue();
								oLocalModel.iwoTabTravel[i].FinApp = that.getView().byId("idFinAppInt").getValue();
								oLocalModel.iwoTabTravel[i].Wbsowner1 = that.getView().byId("idWBS1Int").getValue();
								oLocalModel.iwoTabTravel[i].Wbsowner2 = that.getView().byId("idWBS2Int").getValue();
								oLocalModel.iwoTabTravel[i].PrjAc = that.getView().byId("idProAcInt").getValue();
								oLocalModel.iwoTabTravel[i].Agm = that.getView().byId("idAccManInt").getValue();
								oLocalModel.iwoTabTravel[i].Vbegdat = that.dateFormatter(that.getView().byId("idStarInt").getDateValue());
								oLocalModel.iwoTabTravel[i].Venddat = that.dateFormatter(that.getView().byId("idEndInt").getDateValue());
								that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Matnr", oMatnr);
								that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Maktx", oMaktx.substring(0, 40));
							}

							//sSeqNum = parseInt(sSeqNum) + 1;
							// internal code Rajat
							//var osTyp = that.getView().byId("idSubTyp").getSelectedKey();
							//var data = this._fnSetInternalMaterial(osTyp); Ratna commented code 2.
							// var oMatnr = data.oMatnr;
							// var oMaktx = data.oMaktx;

							//Added for sceanrio2 srini vallepu
							var oLength = window.location.href.split("#")[1].split("?").length;
							if (oLength > 1) {
								var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
								if (oLength1 === 1) {
									if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {
										jQuery.sap.require("jquery.sap.storage");
										var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
										if (oStorage.get("oppData")) {
											var obj = oStorage.get("oppData");
											// oStorage.clear();
										}
										this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[sRowCount - 1].ZsfdcOppid = obj[0].OptId;
										this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[6].setEnabled(false);
										var osTyp = this.getView().byId("idSubTyp").getSelectedKey();
										if (osTyp === "BP") {
											this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[10].setEditable(true);
										} else {
											this.getView().byId("idInternal").getRows()[sRowCount - 1].getCells()[7].setEditable(true);
										}
									}
								}
							}
							//End of ceanrio2 srini vallepu
						}
						//return data;

					},

					error: function (oError) {}
				});

				sap.ui.core.BusyIndicator.hide();
			}

		},

		onDeleteTimeTrack: function () {
			var oTable = this.getView().byId("idTable");
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().statusCode;

			if (type === "E0001") {
				var that = this;
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Are you sure you want to delete ?"
					}),
					beginButton: new sap.m.Button({
						text: "Ok",
						press: function () {
							var aContexts = oTable.getSelectedIndices();
							if (aContexts.length < 1) {
								MessageToast.show("Please Select Atleast One Row!!!");
							} else {
								//--> loop backward from the selected Rows
								for (var i = aContexts.length - 1; i >= 0; i--) {
									var idx = aContexts[i];
									var oModel = that.getView().getModel();
									var itab = oModel.getProperty("/iwoTab");
									itab.splice(idx, 1);
									oModel.setProperty("/iwoTab", itab);
								}
								oTable.clearSelection();

								// that.getView().getModel("appView").refresh(true);
								MessageToast.show("Successfully Deleted IWO Record.");
							}
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			} else {
				if (oTable.getSelectedIndices().length === 1) {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: new sap.m.Text({
							text: "Are you sure you want to delete ?"
						}),
						beginButton: new sap.m.Button({
							text: "Ok",
							press: function () {
								var aContexts = oTable.getSelectedIndices();
								if (aContexts.length < 1) {
									MessageToast.show("Please Select Atleast One Row!!!");
								} else {
									var idx = oTable.getSelectedIndices()[0];
									var oModel1 = that.getView().byId("idTable").getModel();
									var IwoguidItem = oModel1.getData().iwoTab[idx].IwoguidItem;
									var Iwo = oModel1.getData().iwoTab[idx].Iwo;
									var Requestid = oModel1.getData().iwoTab[idx].Requestid;
									if (IwoguidItem) {
										var oModel = that.getView().getModel("oDataModel");
										var sPath1 = "/IWOLabor1Set(Requestid='" + Requestid + "',Iwo='" + Iwo + "',IwoguidItem='" + IwoguidItem + "')";
										var that = this;
										oModel.remove(sPath1, {
											success: function (oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("Successfully Deleted IWO Record.", {
													duration: 5000
												});
												for (var i = aContexts.length - 1; i >= 0; i--) {
													var idx = aContexts[i];
													var oModel = that.getView().getModel();
													var itab = oModel.getProperty("/iwoTab");
													itab.splice(idx, 1)
														// itab.push(itemRow);
													oModel.setProperty("/iwoTab", itab);
												}
												oTable.clearSelection();
											},
											error: function (oError) {
												sap.ui.core.BusyIndicator.hide();
												var msg = oError.responseText.split('"value":"')[1].split('"},')[0];
												sap.m.MessageToast.show(msg, {
													duration: 5000
												});
											}
										});
										dialog.close();
									} else {
										for (var i = aContexts.length - 1; i >= 0; i--) {
											var idx = aContexts[i];
											var oModel = that.getView().getModel();
											var itab = oModel.getProperty("/iwoTab");
											itab.splice(idx, 1)
												// itab.push(itemRow);
											oModel.setProperty("/iwoTab", itab);
										}
										oTable.clearSelection();
										MessageToast.show("Successfully Deleted IWO Record.");
									}
								}
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
				} else {
					MessageToast.show("Please Select Only One Row!!!");
				}
			}
		},

		onDeleteNonTimeTrack: function () {
			var oTable = this.getView().byId("idNonTrack");
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().statusCode;
			if (type === "E0001") {
				var that = this;
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Are you sure you want to delete ?"
					}),
					beginButton: new sap.m.Button({
						text: "Ok",
						press: function () {
							var aContexts = oTable.getSelectedIndices();
							if (aContexts.length < 1) {
								MessageToast.show("Please Select Atleast One Row!!!");
							} else {
								//--> loop backward from the selected Rows
								for (var i = aContexts.length - 1; i >= 0; i--) {
									var idx = aContexts[i];
									var oModel = that.getView().getModel();
									var itab = oModel.getProperty("/iwoTabNonTrack");
									itab.splice(idx, 1);
									oModel.setProperty("/iwoTabNonTrack", itab);
								}
								oTable.clearSelection();
								MessageToast.show("Successfully Deleted IWO Record.");
							}
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			} else {
				if (oTable.getSelectedIndices().length <= 1) {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: new sap.m.Text({
							text: "Are you sure you want to delete ?"
						}),
						beginButton: new sap.m.Button({
							text: "Ok",
							press: function () {
								var aContexts = oTable.getSelectedIndices();
								if (aContexts.length < 1) {
									MessageToast.show("Please Select Atleast One Row!!!");
								} else {
									var idx = oTable.getSelectedIndices()[0];
									var oModel1 = that.getView().byId("idNonTrack").getModel();
									var IwoguidItem = oModel1.getData().iwoTabNonTrack[idx].IwoguidItem;
									var Iwo = oModel1.getData().iwoTabNonTrack[idx].Iwo;
									var Requestid = oModel1.getData().iwoTabNonTrack[idx].Requestid;
									if (IwoguidItem) {
										var oModel = that.getView().getModel("oDataModel");
										var sPath1 = "/IWOLabor1Set(Requestid='" + Requestid + "',Iwo='" + Iwo + "',IwoguidItem='" + IwoguidItem + "')";
										var that = this;
										oModel.remove(sPath1, {
											success: function (oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("Successfully Deleted IWO Record.", {
													duration: 5000
												});
												for (var i = aContexts.length - 1; i >= 0; i--) {
													var idx = aContexts[i];
													var oModel = that.getView().getModel();
													var itab = oModel.getProperty("/iwoTabNonTrack");
													itab.splice(idx, 1);
													oModel.setProperty("/iwoTabNonTrack", itab);
												}
												oTable.clearSelection();
											},
											error: function (oError) {
												sap.ui.core.BusyIndicator.hide();
												var msg = oError.responseText.split('"value":"')[1].split('"},')[0];
												sap.m.MessageToast.show(msg, {
													duration: 5000
												});
											}
										});
										dialog.close();
									} else {
										for (var i = aContexts.length - 1; i >= 0; i--) {
											var idx = aContexts[i];
											var oModel = that.getView().getModel();
											var itab = oModel.getProperty("/iwoTabNonTrack");
											itab.splice(idx, 1);
											oModel.setProperty("/iwoTabNonTrack", itab);
										}
										oTable.clearSelection();
										MessageToast.show("Successfully Deleted IWO Record.");
									}
								}
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
				} else {
					MessageToast.show("Please Select Only One Row!!!");
				}
			}
		},
		onDeleteTravel: function () {
			var oTable = this.getView().byId("idTravel");
			var oModel = oTable.getModel("localModel");
			var modelName = "iwoTabTravel";
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var type = oViewModel.getData().statusCode;
			if (type === "E0001") {
				var oRowCount = oModel.getData().iwoTabTravel.length;
				var that = this;
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Are you sure you want to delete ?"
					}),
					beginButton: new sap.m.Button({
						text: "Ok",
						press: function () {
							var aContexts = oTable.getSelectedIndices();
							if (aContexts.length < 1) {
								MessageToast.show("Please Select Atleast One Row!!!");
							} else {
								//--> loop backward from the selected Rows
								for (var i = aContexts.length - 1; i >= 0; i--) {
									var idx = aContexts[i];
									var oModel = that.getView().getModel("localModel");
									var itab = oModel.getProperty("/iwoTabTravel");
									itab.splice(idx, 1);
									oModel.setProperty("/iwoTabTravel", itab);

								}
								oTable.clearSelection();

								MessageToast.show("Successfully Deleted the Record.");

							}
							dialog.close();

							var sRowCount = that.getView().byId("idTravel").getBinding("rows").getLength();
							if (AppType === "ChangeProject" || AppType === "ChangeRequest") {
								var oPrvalue = 0;
								for (var i = 0; i < sRowCount; i++) {
									var oEnType = that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
									if (oEnType === "E") {
										oPrvalue = that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Posnr;

									} else {
										oPrvalue = parseInt(oPrvalue, 10) + 1;
										var sSeqNum = String(oPrvalue).padStart(6, '0');
										that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Posnr = sSeqNum;
									}
								}
							} else {
								var sSeqNum = 1;
								for (var i = 0; i < sRowCount; i++) {
									that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Posnr = String(sSeqNum);
									sSeqNum = sSeqNum + 1;
								}
							}
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
						that.getView().getModel("appView").setProperty("/count", that.getView().getModel("localModel").getProperty("/iwoTabTravel").length);
					}
				});
				dialog.open();
			} else {
				if (oTable.getSelectedIndices().length <= 1) {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: new sap.m.Text({
							text: "Are you sure you want to delete ?"
						}),
						beginButton: new sap.m.Button({
							text: "Ok",
							press: function () {
								var aContexts = oTable.getSelectedIndices();
								if (aContexts.length < 1) {
									MessageToast.show("Please Select Atleast One Row!!!");
								} else {
									var idx = oTable.getSelectedIndices()[0];
									var oModel1 = that.getView().byId("idTravel").getModel("localModel");
									var IwoguidItem = oModel1.getData().iwoTabTravel[idx].IwoguidItem;
									var Iwo = oModel1.getData().iwoTabTravel[idx].Iwo;
									var Requestid = oModel1.getData().iwoTabTravel[idx].Requestid;
									if (IwoguidItem) {
										var oModel = that.getView().getModel("oDataModel");
										var sPath1 = "/IWOOtherSet(Requestid='" + Requestid + "',Iwo='" + Iwo + "',IwoguidItem='" + IwoguidItem + "')";
										oModel.remove(sPath1, {
											success: function (oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("Successfully Deleted IWO Record.", {
													duration: 5000
												});
												for (var i = aContexts.length - 1; i >= 0; i--) {
													var idx = aContexts[i];
													var oModel = that.getView().getModel("localModel");
													var itab = oModel.getProperty("/iwoTabTravel");
													itab.splice(idx, 1)
														// itab.push(itemRow);
													oModel.setProperty("/iwoTabTravel", itab);
												}
												oTable.clearSelection();
											},
											error: function (oError) {
												sap.ui.core.BusyIndicator.hide();
												var msg = oError.responseText.split('"value":"')[1].split('"},')[0];
												sap.m.MessageToast.show(msg, {
													duration: 5000
												});
											}
										});
										dialog.close();
									} else {
										for (var i = aContexts.length - 1; i >= 0; i--) {
											var idx = aContexts[i];
											var oModel = that.getView().getModel("localModel");
											var itab = oModel.getProperty("/iwoTabTravel");
											itab.splice(idx, 1);
											oModel.setProperty("/iwoTabTravel", itab);
										}
										oTable.clearSelection();
										MessageToast.show("Successfully Deleted IWO Record.");
									}
								}
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
				} else {
					MessageToast.show("Please Select Only One Row!!!");
				}
			}

		},

		onCancel: function (oEvent) {
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			oDailog.destroy();
		},

		onCancelHL: function (oEvent) {
			this._oDialogHLB.close();
		},

		onCancelMass: function (oEvent) {
			var itab = this.getView().getModel().getProperty("/iwoMassChange");
			itab.pop(0);
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			oDailog.destroy();
		},

		onCancelIWORecord: function () {
			var oTable = this.getView().byId("idTable");
			var oTable1 = this.getView().byId("idNonTrack");
			var oTable2 = this.getView().byId("idTravel");

			var oModel = oTable1.getModel();
			var oRows = oModel.getData().iwoTabNonTrack;
			var oModel1 = oTable.getModel();
			var oRows1 = oModel1.getData().iwoTab;
			var oModel2 = oTable2.getModel();
			var oRows2 = oModel2.getData().iwoTabTravel;
			var dialog = new sap.m.Dialog({
				title: "Confirm",
				type: "Message",
				content: new sap.m.Text({
					text: "Are you sure you want to Cancel IWO Request ?"
				}),
				beginButton: new sap.m.Button({
					text: "Ok",
					press: function () {
						for (var i = oRows.length - 1; i >= 0; i--) {
							var idx = oRows[i];
							oRows.splice(idx, 1);
						}
						for (var j = oRows1.length - 1; j >= 0; j--) {
							var idx1 = oRows1[j];
							oRows1.splice(idx1, 1);
						}
						for (var k = oRows2.length - 1; k >= 0; k--) {
							var idx2 = oRows2[k];
							oRows2.splice(idx2, 1);
						}
						oModel.setData({
							iwoTab: oRows1,
							iwoTabNonTrack: oRows,
							iwoTabTravel: oRows2
						});
						oTable.clearSelection();
						MessageToast.show("Successfully deleted IWO Request...");
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		/*This method for open Additional data popup*/

		onUpdateAutoL1: function (oEvent) {
			// MessageToast.show("Comming soon.");
			sap.ui.core.BusyIndicator.show(0);
			var oDailog = oEvent.getSource().getParent();
			var oViewModel = this.getView().getModel("autoPopData");
			var reqID = oViewModel.getData().Requestid;
			var IwoGuidItem = oViewModel.getData().IwoGuidItem;
			var oData = {
				"d": {
					"Requestid": reqID,
					"IwoGuidItem": IwoGuidItem,
					"ProjectName": this.getView().byId("projName").getValue(),
					"ClientName": this.getView().byId("clieName").getValue(),
					"Rate": this.getView().byId("rate").getValue(),
					"PerfWbs": this.getView().byId("chiWBS").getValue()
				}
			};
			var oModel = this.getView().getModel("oDataModel");
			var sPath = "/IWOAutoPopulateL1Set(Requestid='" + reqID + "',IwoGuidItem='" + IwoGuidItem + "')";
			oModel.update(sPath, oData, {
				success: function (oResponse) {
					sap.ui.core.BusyIndicator.hide();
					oDailog.close();
					oDailog.destroy();
					sap.m.MessageToast.show("IWO Data changed sucessfully.", {
						duration: 5000
					});
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					oDailog.close();
					oDailog.destroy();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},
		onUpdateAutoL2: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var oDailog = oEvent.getSource().getParent();
			var oViewModel = this.getView().getModel("autoPopData");
			var reqID = oViewModel.getData().Requestid;
			var IwoGuidItem = oViewModel.getData().IwoGuidItem;
			var oModel = this.getView().getModel("oDataModel");
			var oData = {
				"d": {
					"Requestid": reqID,
					"IwoGuidItem": IwoGuidItem,
					"ProjectName": this.getView().byId("projNamel2").getValue(),
					"ClientName": this.getView().byId("clieNamel2").getValue(),
					"PerfWbs": this.getView().byId("chiWBSl2").getValue()
				}
			};
			var sPath = "/IWOAutoPopulateL2Set(Requestid='" + reqID + "',IwoGuidItem='" + IwoGuidItem + "')";
			oModel.update(sPath, oData, {
				success: function (oResponse) {
					sap.ui.core.BusyIndicator.hide();
					oDailog.close();
					oDailog.destroy();
					sap.m.MessageToast.show("IWO Data changed sucessfully.", {
						duration: 5000
					});
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					oDailog.close();
					oDailog.destroy();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},
		onUpdateAutoOthers: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var oDailog = oEvent.getSource().getParent();
			var oViewModel = this.getView().getModel("autoPopData");
			var reqID = oViewModel.getData().Requestid;
			var IwoGuidItem = oViewModel.getData().IwoGuidItem;
			var oModel = this.getView().getModel("oDataModel");
			var oData = {
				"d": {
					"Requestid": reqID,
					"IwoGuidItem": IwoGuidItem,
					"BillFrmLocation": this.getView().byId("BilFrLoc").getValue(),
					"PerfSrvOffering": this.getView().byId("PerfSrvOffOth").getValue(),
					"ProjectName": this.getView().byId("projNameOth").getValue(),
					"ClientName": this.getView().byId("clieNameOth").getValue(),
					"PerfWbs": this.getView().byId("chiWBSOth").getValue()
				}
			};
			var sPath = "/IWOAutoPopulateOtherSet(Requestid='" + reqID + "',IwoGuidItem='" + IwoGuidItem + "')";
			oModel.update(sPath, oData, {
				success: function (oResponse) {
					sap.ui.core.BusyIndicator.hide();
					oDailog.close();
					oDailog.destroy();
					sap.m.MessageToast.show("IWO Data changed sucessfully.", {
						duration: 5000
					});
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					oDailog.close();
					oDailog.destroy();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},

		onErrorBtnHeaderPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var oView = that.getView();
			var oDialog = oView.byId("errorLog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.ErrorDisplay", that);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var oErrors = this.getView().getModel().getData().errorResults;
			var oModel = new sap.ui.model.json.JSONModel(oErrors);
			var oTable = this.byId("errorLog1");
			oTable.setModel(oModel);
			sap.ui.core.BusyIndicator.hide();
		},

		onErrorBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var oView = that.getView();
			var oDialog = oView.byId("errorLog");
			var sPosnr = oEvent.getSource().getBindingContext("localModel").getObject().Posnr;
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.ErrorDisplay", that);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var oErrors = this.getView().getModel().getData().errorResults;
			var oFilteredErrors = oErrors.filter(function (e) {
				return Number(e.MsgN0) === Number(sPosnr);
			});
			var oModel = new sap.ui.model.json.JSONModel(oFilteredErrors);
			var oTable = this.byId("errorLog1");
			oTable.setModel(oModel);
			sap.ui.core.BusyIndicator.hide();
		},

		_onSettingButtonPress: function () {
			sap.ui.core.BusyIndicator.show(0);
			var oView = this.getView();
			var oDialog = oView.byId("idDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "iwo.request.fragments.Setting", this);
				var timetrac = this.byId("timeTrackRes").getEnabled();
				this.byId("timetracsett").setState(timetrac);
				var nonTim = this.byId("nonTimeTrackRes").getEnabled();
				this.byId("nonTimesett").setState(nonTim);
				var travel = this.byId("travelExp").getEnabled();
				this.byId("travelsett").setState(travel);
				oView.addDependent(oDialog);
				oDialog.open();
				sap.ui.core.BusyIndicator.hide();
			}
		},

		_onsettingSavePress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var oData = {
				istimetrac: this.byId("timetracsett").getState(),
				isnonTime: this.byId("nonTimesett").getState(),
				isTravel: this.byId("travelsett").getState()
			};
			this.byId("timeTrackRes").setEnabled(oData.istimetrac);
			this.byId("idTable").setVisible(oData.istimetrac);
			this.byId("nonTimeTrackRes").setEnabled(oData.isnonTime);
			this.byId("idNonTrack").setVisible(oData.isnonTime);
			this.byId("travelExp").setEnabled(oData.isTravel);
			this.byId("idTravel").setVisible(oData.isTravel);
			sap.ui.core.BusyIndicator.hide();
			MessageToast.show("Successfully Changed Setting...");
			this.onCancel(oEvent);
		},

		handleFragDateChange: function (oEvent) {
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			this.byId("endMassDate").setValue("").setValueState("Error");
			this.byId("endMassDate").setMinDate(new Date(Year, month, day));
		},
		onChangeTimeValidation: function (oEvent) {
			var endDateID = oEvent.getParameter("id");
			sap.ui.getCore().byId(endDateID).setValueState("None");
		},

		onInputVelidationL1: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			//get the field ID
			var fieldid = oEvent.getParameter("id");
			if (newValue === "") {
				sap.ui.getCore().byId(fieldid).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(fieldid).setValueStateText("Please enter the value."); // Add record button disable
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None"); // Add record button Enable
			}
		},

		onNoValidation: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var fieldid = oEvent.getParameter("id");
			var regex = /^[0-9]*$/;
			if (newValue === "") {
				sap.ui.getCore().byId(fieldid).setValueState("Error");
				sap.ui.getCore().byId(fieldid).setValueStateText("Enter Number only.");
			} else if (!newValue.match(regex)) {
				sap.ui.getCore().byId(fieldid).setValue(newValue.replace(/[^0-9-]/g, ""));
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");
			}
		},

		//unused
		onProCenValidation: function (oEvent) {
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var newValue = oEvent.getParameter("value");

			if (newValue === "") {
				var keyID = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[0].getValue();
				var oModel = this.getView().getModel("oDataModel");
				var aFilters = [];
				aFilters.push(new Filter("Pernr", sap.ui.model.FilterOperator.EQ, keyID));
				var that = this;
				oModel.read("/SearchEmployeeSet", {
					filters: aFilters,
					success: function (oResponse) {
						if (oResponse.results.length === 1) {
							if (oResponse.results[0].Zsystem === "C1" || oResponse.results[0].Zsystem === "GSAP") {
								that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("Error");
							} else {
								that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("None");
							}
						} else {
							that.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("None");
						}
					},
					error: function (oError) {}
				});
			} else {
				this.getView().byId("idTable").getRows()[iRowIndex].getCells()[6].setValueState("None");
			}
		},

		//unused
		onSowTextValiTimeTrack: function (oEvent) {
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var newValue = oEvent.getParameter("value");
			var fieldid = oEvent.getParameter("id");
			if (newValue === "") {
				var keyID = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[2].getSelectedKey();
				var getData = this.getView().getModel("oSowAppView").getData();
				var json = getData.filter(function (a) {
					return a.Jobsubcat === keyID;
				});
				if (json.length === 1) {
					var getStatus = json[0].Required;
					if (!getStatus) {
						this.getView().byId("idTable").getRows()[iRowIndex].getCells()[3].setValueState("None");
					} else {
						this.getView().byId("idTable").getRows()[iRowIndex].getCells()[3].setValueState("Error");
					}
				} else if (json.length === 0 || json.length >= 2) {
					this.getView().byId("idTable").getRows()[iRowIndex].getCells()[3].setValueState("Error");
				}

			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");
			}
		},
		onSowTextValiNonTimeTrack: function (oEvent) {
			var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var newValue = oEvent.getParameter("value");
			var fieldid = oEvent.getParameter("id");
			if (newValue === "") {
				var keyID = this.getView().byId("idNonTrack").getRows()[iRowIndex].getCells()[3].getSelectedKey();
				var getData = this.getView().getModel("oSowAppView").getData();
				var json = getData.filter(function (a) {
					return a.Jobsubcat === keyID;
				});
				if (json.length === 1) {
					var getStatus = json[0].Required;
					if (!getStatus) {
						this.getView().byId("idNonTrack").getRows()[iRowIndex].getCells()[4].setValueState("None");
					} else {
						this.getView().byId("idNonTrack").getRows()[iRowIndex].getCells()[4].setValueState("Error");
					}
				} else if (json.length === 0 || json.length >= 2) {
					this.getView().byId("idNonTrack").getRows()[iRowIndex].getCells()[4].setValueState("Error");
				}

			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");
			}
		},

		checkSpwText: function (sowKey) {
			var getData = this.getView().getModel().getData().sowData;
			for (var i = 0; i < getData.length; i++) {
				if (getData[i].Jobsubcat === sowKey) {
					return getData[i].Required;
				}
			}
		},

		onMassChangeButton: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var newID = oEvent.getParameter("id");
			var tabID;
			var oTable;
			if (newID.includes("massChangwTimeTrack")) {
				oTable = this.getView().byId("idTable");
				tabID = "/iwoTab";

			} else if (newID.includes("massChangwNonTimeTrack")) {
				oTable = this.getView().byId("idNonTrack");
				tabID = "/iwoTabNonTrack";

			} else if (newID.includes("massChangwTravel")) {
				oTable = this.getView().byId("idTravel");
				tabID = "/iwoTabTravel";
				var check = "massChangwTravel";
			}
			var aContexts = oTable.getSelectedIndices(); //Get selected index
			if (aContexts.length === 0) {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please Select Atleast Two Row!!!");
			} else {
				var i = oTable.getSelectedIndices()[0];
				if (tabID === "/iwoTabTravel") {
					var oModel = this.getView().getModel();
					var itab = oModel.getProperty("/iwoTabTravel");
					var oData1 = itab[i];
				} else if (tabID === "/iwoTabNonTrack") {
					var oModel = this.getView().getModel();
					var itab = oModel.getProperty("/iwoTabNonTrack");
					var oData1 = itab[i];
				} else {
					var oModel = this.getView().getModel();
					var itab = oModel.getProperty("/iwoTab");
					var oData1 = itab[i];
				}
				var oData = {
					"Employee": oData1.Employee,
					"OrigWbs": oData1.OrigWbs,
					"JobSubCat": oData1.JobSubCat,
					"SowText": oData1.SowText,
					"StartDate": oData1.StartDate,
					"EndDate": oData1.EndDate,
					"ProfitCentre": oData1.ProfitCentre,
					"Zhours": oData1.Zhours,
					"Rate": oData1.Rate,
					"GrossAmt": oData1.GrossAmt,
					"PerfManager": oData1.PerfManager,
					"PrefComCode": oData1.PrefComCode,
					"OrigFinpoc": oData1.OrigFinpoc,
					"PerfFinpoc": oData1.PerfFinpoc
				};
				var itab = oModel.getProperty("/iwoMassChange");
				itab.push(oData);
				oModel.setProperty("/iwoMassChange", itab);
				if (aContexts.length >= 2) {
					var oView = this.getView();
					var oDialog = oView.byId("idDialog");
					// create dialog lazily
					if (!oDialog) {
						// create dialog via fragment factory
						oDialog = sap.ui.xmlfragment(oView.getId(), "iwo.request.fragments.massChange", this);
						// connect dialog to view (models, lifecycle)
						oView.addDependent(oDialog);
					}
					oDialog.open();
					if (tabID === "/iwoTab") {
						this.byId("totalcoastTravel").setVisible(false);
						this.byId("HoRateNonTime").setVisible(false);
						this.byId("hoTimNonTime").setVisible(true);
						this.byId("sowTimNonTime").setVisible(true);
						this.byId("massChanTime").setVisible(true);
						this.byId("massChanNonTime").setVisible(false);
						this.byId("massChanTravel").setVisible(false);
					} else if (tabID === "/iwoTabNonTrack") {
						this.byId("totalcoastTravel").setVisible(false);
						this.byId("HoRateNonTime").setVisible(true);
						this.byId("hoTimNonTime").setVisible(true);
						this.byId("sowTimNonTime").setVisible(true);
						this.byId("massChanTime").setVisible(false);
						this.byId("massChanNonTime").setVisible(true);
						this.byId("massChanTravel").setVisible(false);

					} else if (tabID === "/iwoTabTravel") {
						this.byId("totalcoastTravel").setVisible(true);
						this.byId("HoRateNonTime").setVisible(false);
						this.byId("hoTimNonTime").setVisible(false);
						this.byId("sowTimNonTime").setVisible(false);
						this.byId("massChanTime").setVisible(false);
						this.byId("massChanNonTime").setVisible(false);
						this.byId("massChanTravel").setVisible(true);
					}
					sap.ui.core.BusyIndicator.hide();
				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Please Select Atleast Two Row!!!");
				}
			}
		},
		onSaveMassChangeTime: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var that1 = this.getView();
			var oData = this.getView().getModel().getData();
			var data;
			var oTable = that1.byId("idTable");
			var aContexts = oTable.getSelectedIndices();
			var itab = this.getView().getModel().getProperty("/iwoMassChange");
			if (aContexts.length >= 2) {
				for (var i = 0; i <= aContexts.length - 1; i++) {
					var field = aContexts[i];
					if (that1.byId("a1").getSelected()) {
						data = itab[0].OrigWbs;
						oData.iwoTab[field].OrigWbs = data;
					}
					if (that1.byId("a2").getSelected()) {
						data = itab[0].JobSubCat;
						oData.iwoTab[field].JobSubCat = data;
					}
					if (that1.byId("a3").getSelected()) {
						data = itab[0].SowText;
						oData.iwoTab[field].SowText = data;
					}
					if (that1.byId("a4").getSelected()) {
						data = itab[0].StartDate;
						oData.iwoTab[field].StartDate = new Date(data);
					}
					if (that1.byId("a5").getSelected()) {
						data = itab[0].EndDate;
						oData.iwoTab[field].EndDate = new Date(data);
					}
					if (that1.byId("a6").getSelected()) {
						data = itab[0].ProfitCentre;
						oData.iwoTab[field].ProfitCentre = data;
					}
					if (that1.byId("a7").getSelected()) {
						data = itab[0].Zhours;
						oData.iwoTab[field].Zhours = data;
					}
					if (that1.byId("a8").getSelected()) {
						data = itab[0].PerfManager;
						oData.iwoTab[field].PerfManager = data;
					}
					if (that1.byId("a10").getSelected()) {
						data = itab[0].OrigFinpoc;
						oData.iwoTab[field].OrigFinpoc = data;
					}
					if (that1.byId("a11").getSelected()) {
						data = itab[0].PerfFinpoc;
						oData.iwoTab[field].PerfFinpoc = data;
					}
				}
			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please Select Atleast Two Row!!!");
				this.onCancel(oEvent);
			}
			var oModel = this.getView().getModel();
			var itab = oModel.getData().iwoTab;
			oModel.setProperty("/iwoTab", itab);
			sap.ui.core.BusyIndicator.hide();
			MessageToast.show("Mass Changes successfully completed.");
			this.onCancelMass(oEvent);
		},
		onSaveMassChangeNonTime: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var that1 = this.getView();
			var oData = this.getView().getModel().getData();
			var data;
			var oTable = that1.byId("idNonTrack");
			var aContexts = oTable.getSelectedIndices();
			var itab = this.getView().getModel().getProperty("/iwoMassChange");
			if (aContexts.length >= 2) {
				for (var i = 0; i <= aContexts.length - 1; i++) {
					var field = aContexts[i];
					if (that1.byId("a1").getSelected()) {
						data = itab[0].OrigWbs;
						oData.iwoTabNonTrack[field].OrigWbs = data;
					}
					if (that1.byId("a2").getSelected()) {
						data = itab[0].JobSubCat;
						oData.iwoTabNonTrack[field].JobSubCat = data;
					}
					if (that1.byId("a3").getSelected()) {
						data = itab[0].SowText;
						oData.iwoTabNonTrack[field].SowText = data;
					}
					if (that1.byId("a4").getSelected()) {
						data = itab[0].StartDate;
						oData.iwoTabNonTrack[field].StartDate = new Date(data);
					}
					if (that1.byId("a5").getSelected()) {
						data = itab[0].EndDate;
						oData.iwoTabNonTrack[field].EndDate = new Date(data);
					}
					if (that1.byId("a6").getSelected()) {
						data = itab[0].ProfitCentre;
						oData.iwoTabNonTrack[field].ProfitCentre = data;
					}
					if (that1.byId("a7").getSelected()) {
						data = itab[0].Zhours;
						oData.iwoTabNonTrack[field].Zhours = data;
					}

					if (that1.byId("a12").getSelected()) {
						data = that1.byId("a12").getModel().getData().Rate;
						oData.iwoTabNonTrack[field].Rate = data;
					}
					if (that1.byId("a8").getSelected()) {
						data = itab[0].PerfManager;
						oData.iwoTabNonTrack[field].PerfManager = data;
					}
					if (that1.byId("a10").getSelected()) {
						data = itab[0].OrigFinpoc;
						oData.iwoTabNonTrack[field].OrigFinpoc = data;
					}
					if (that1.byId("a11").getSelected()) {
						data = itab[0].PerfFinpoc;
						oData.iwoTabNonTrack[field].PerfFinpoc = data;
					}
				}
			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please Select Atleast Two Row!!!");
				this.onCancel(oEvent);
			}
			var oModel = this.getView().getModel();
			var itab = oModel.getData().iwoTabNonTrack;
			oModel.setProperty("/iwoTabNonTrack", itab);
			sap.ui.core.BusyIndicator.hide();
			MessageToast.show("Mass Changes successfully completed.");
			this.onCancelMass(oEvent);
		},
		onSaveMassChangeTravel: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var that1 = this.getView();
			var oData = this.getView().getModel().getData();
			var data;
			var oTable = that1.byId("idTravel");
			var aContexts = oTable.getSelectedIndices();
			var itab = this.getView().getModel().getProperty("/iwoMassChange");
			if (aContexts.length >= 2) {
				for (var i = 0; i <= aContexts.length - 1; i++) {
					var field = aContexts[i];
					if (that1.byId("a1").getSelected()) {
						data = itab[0].OrigWbs;
						oData.iwoTabTravel[field].OrigWbs = data;
						// oTable.getRows()[field].getCells()[2].setValue(data);
					}

					if (that1.byId("a3").getSelected()) {
						data = itab[0].SowText;
						oData.iwoTabTravel[field].SowText = data;
						// oTable.getRows()[field].getCells()[3].setValue(data);
					}
					if (that1.byId("a4").getSelected()) {
						data = itab[0].StartDate;
						oData.iwoTabTravel[field].StartDate = new Date(data);
						// oTable.getRows()[field].getCells()[4].setValue(data);
					}
					if (that1.byId("a5").getSelected()) {
						data = itab[0].EndDate;
						oData.iwoTabTravel[field].EndDate = new Date(data);
						// oTable.getRows()[field].getCells()[5].setValue(data);
					}
					if (that1.byId("a6").getSelected()) {
						data = itab[0].ProfitCentre;
						oData.iwoTabTravel[field].ProfitCentre = data;
						// oTable.getRows()[field].getCells()[6].setValue(data);
					}
					if (that1.byId("a13").getSelected()) {
						data = itab[0].GrossAmt;
						oData.iwoTabTravel[field].GrossAmt = data;
						// oTable.getRows()[field].getCells()[7].setValue(data);
					}
					if (that1.byId("a8").getSelected()) {
						data = itab[0].PerfManager;
						oData.iwoTabTravel[field].PerfManager = data;
						// oTable.getRows()[field].getCells()[9].setValue(data);
					}
					if (that1.byId("a10").getSelected()) {
						data = itab[0].OrigFinpoc;
						oData.iwoTabTravel[field].OrigFinpoc = data;
						// oTable.getRows()[field].getCells()[10].setValue(data);
					}
					if (that1.byId("a11").getSelected()) {
						data = itab[0].PerfFinpoc;
						oData.iwoTabTravel[field].PerfFinpoc = data;
						// oTable.getRows()[field].getCells()[11].setValue(data);
					}
				}
			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please Select Atleast Two Row!!!");
				this.onCancel(oEvent);
			}
			var oModel = this.getView().getModel();
			var itab = oModel.getData().iwoTabTravel;
			oModel.setProperty("/iwoTabTravel", itab);
			sap.ui.core.BusyIndicator.hide();
			MessageToast.show("Mass Changes successfully completed.");
			this.onCancelMass(oEvent);
		},
		onFileAction: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			// switch (oItem.data("action")) {
			// case "Download":
			// 	this._downloadFileDialog(oEvent);
			// 	break;
			// case "Upload":
			// 	this._uploadFileDialog();
			// 	break;
			// }
		},
		_downloadFileDialog: function (oEvent) {
			var oOrgModel = this.getOwnerComponent().getModel("oDataModel");
			var oModel = new sap.ui.model.odata.ODataModel(oOrgModel.sServiceUrl);
			var Iwo = this.getView().getModel("appView").getData().iwoNo;
			oModel.read("/IWOFileUploadSet(Uploadid='" + Iwo + "')/$value", {
				success: function (oData, response) {
					var file = response.requestUri;
					window.open(file);
				},
				error: function (odata) {
					console.error("error");

				}
			});
		},
		_uploadFileDialog: function () {
			var oView = this.getView();
			var oDialog = oView.byId("idUploadDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "iwo.request.fragments.uploadFile", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
		},
		onUploadComplete: function (oEvent) {
			this.getView().byId("idFileUploader").clear();
			if (oEvent.getParameter("status") == '201') {
				var oResponse = JSON.parse(oEvent.getParameter("responseRaw"));
				var oModel = this.getOwnerComponent().getModel("oDataModel");
				var that = this;
				// if not error displayed and load new one
				if (oResponse.d.Requestid.length > 0 && oResponse.d.Iwo.length > 0) {
					this.getView().byId("idUploadDialog").close();
					this.getView().setBusy(false);
					if (this.byId("idSubBtnRevision").getVisible() === true)
						this.fnAfterSubmission();
					else
						this.onLoadData(oResponse.d.Iwo, oResponse.d.Requestid, false);
				} else {
					oModel.read("/IWOFileUploadSet(Uploadid='" + oResponse.d.Uploadid + "')", {
						urlParameters: {
							"$expand": "toError"
						},
						success: function (oResponse) {
							oMessagePopover.setModel(new JSONModel(oResponse.toError.results));
							that.getView().byId("messBtn").setVisible(true);
							that.getView().byId("idUploadDialog").close();
							that.getView().setBusy(false);
						},
						error: function (oError) {
							that.getView().byId("idUploadDialog").close();
							that.getView().setBusy(false);
						}
					});
				}
			} else {
				this.getView().byId("idUploadDialog").close();
				this.getView().setBusy(false);
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
				MessageToast.show(oBundle.getText("XMSG_UPLOADERROR", [oEvent.getParameter("status")]));
			}
		},
		onValueChange: function (oEvent) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			MessageToast.show(oBundle.getText("XMSG_VALUECHANGE", [oEvent.getParameter("newValue")]));
		},
		onTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			MessageToast.show(oBundle.getText("XMSG_TYPEMISSMATCH", [oEvent.getParameter("fileType"), sSupportedFileTypes]));
		},

		onUploadPress: function (oEvent) {
			var oFileUploader = this.getView().byId("idFileUploader");
			//disable message popover before another call
			this.getView().byId("messBtn").setVisible(false);
			oMessagePopover.setModel(new JSONModel([]));
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			if (!oFileUploader.getValue()) {
				MessageToast.show(oBoundle.getText("XMSG_CHOOSEFILE"));
				return;
			}
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getView().getModel("oDataModel").getSecurityToken()
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "accept",
				value: "application/json"
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.getView().getModel("appView").getData().iwoNo
			}));
			this.getView().setBusy(true);
			oFileUploader.setSendXHR(true);
			oFileUploader.upload();
		},

		/*IWO File Upload and Download*/
		onUploadFileIWO: function () {
			var oView = this.getView();
			var oDialog = oView.byId("idDialog");
			// create dialog lazily
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(oView.getId(), "iwo.request.fragments.uploadFileIWO", this);
				oView.addDependent(oDialog);
			}
			oDialog.open();
		},
		onUploadPressIWO: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var Iwo = oViewModel.getData().iwoNo;

			var oFileUploader = this.getView().byId("idFileUploader");
			var fName = oFileUploader.getValue();
			var oDFileData = Iwo + "@" + fName;
			oFileUploader.setUploadUrl("/sap/opu/odata/sap/ZODATA_IWO_REQUEST_SRV/IWOAttachSet");
			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first...");
				return;
			}
			var oModel = this.getView().getModel("oDataModel");
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: oDFileData
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "po",
				value: "12234"
			}));

			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: oModel.getSecurityToken()
			}));
			oFileUploader.setSendXHR(true);

			oFileUploader.upload();
		},
		onUploadCompleteIWO: function () {
			this.onCancelIWO();
			sap.m.MessageToast.show("File Uploaded Successfully...");
		},
		onCancelIWO: function () {
			var oDailog = this.byId("idDialog");
			oDailog.close();
			oDailog.destroy();
		},
		onDownladFileBtn: function () {
			sap.ui.core.BusyIndicator.show(0);
			var oView = this.getView();
			var oDialog = oView.byId("idDialog");
			var oViewModel = this.getView().getModel("appView");
			var Iwo = oViewModel.getData().iwoNo;
			// var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZFILE_SRV");
			var aFilters = [];
			aFilters.push(new Filter("Iwo", sap.ui.model.FilterOperator.EQ, Iwo));
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/IWOAttachSet", {
				filters: aFilters,
				success: function (oResponse) {
					// create dialog lazily
					if (!oDialog) {
						// create dialog via fragment factory
						oDialog = sap.ui.xmlfragment(oView.getId(), "iwo.request.fragments.downloadAttac", that);
						oView.addDependent(oDialog);
					}
					oDialog.open();
					var oModel3 = new sap.ui.model.json.JSONModel(oResponse.results);
					oDialog.setModel(oModel3, "oData");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		// ***************WBS Methods TAB Project Definition**********************
		checkAtRisk: function (oEvent) {
			var check = oEvent.getParameter("selected");
			if (check) {
				this.getView().byId("idSign").setEnabled(false);
				this.getView().byId("idSign").setValue();
				this.getView().byId("idSign").setRequired(false);
			} else {
				this.getView().byId("idSign").setEnabled(true);
				this.getView().byId("idSign").setRequired(true);
			}
		},
		checkDone: function (oEvent) {
			var check = oEvent.getParameter("selected");
			var bFlag = check ? true : false;
			this.getView().byId("idPayer").setEnabled(bFlag);
			this.getView().byId("idship").setEnabled(bFlag);
			this.getView().byId("idbill").setEnabled(bFlag);
		},

		onDatePickerValidation: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			// var AppType = oViewModel.getData().oAppType;
			var oHeaderSDate;
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			this.oSelectedstartDate = new Date(Year, month, day);
			if (this.oStartDateFlag === true) {
				oHeaderSDate = this.oPreviousStartDate;
			} else {
				oHeaderSDate = this.oHeaderStartDate;
			}
			var oTableData = this.getView().getModel("localModel").getData().iwoTabTravel;
			// this.byId("dateCtrlEnd").setValue("");
			this.byId("dateCtrlEnd").setMinDate(new Date(Year, month, day));
			var bFlag = oEvent.getParameter("valid") ? "None" : "Error";
			oEvent.getSource().setValueState(bFlag);
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[0].Zentry_tp;
			// if(){=========   EndDate popup Code Start =========//	
			//if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && oEntryType !== "N")) {
			if ((oViewModel.getData().type === "ChangeProject") || (oViewModel.getData().type === "ChangeRequest" && oEntryType !== "N")) {
				if (this.oSelectedstartDate < oHeaderSDate) {
					var oModel = this.getView().getModel();
					var oView = this.getView();
					this.oStartDateDialog = oView.byId("idFWBSStartDate");
					// create dialog lazily
					if (!this.oStartDateDialog) {
						// create dialog via fragment factory
						this.oStartDateDialog = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.StartDate", this);
						oView.addDependent(this.oStartDateDialog);
					}
					var oTableRowCount = this.getView().getModel("localModel").getData().iwoTabTravel.length;
					// var oHeaderSDate = this.oHeaderStartDate;
					var oHeaderStartYear = oHeaderSDate.getFullYear();
					var oHeaderStartMonth = oHeaderSDate.getMonth();
					var oHeaderStartDay = oHeaderSDate.getDate();
					var oHeaderStartDate = oHeaderStartYear.toString() + oHeaderStartMonth.toString() + oHeaderStartDay.toString();
					var ArrayFilteredStartDates = [];
					var StartDateObj = {};
					for (var i = 0; i < oTableRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							var oTableSDate = oTableData[i].Vbegdat;
							var oTableStartYear = oTableSDate.getFullYear();
							var oTableStartmonth = oTableSDate.getMonth();
							var oTablestartday = oTableSDate.getDate();
							var oTableStartDate = oTableStartYear.toString() + oTableStartmonth.toString() + oTablestartday.toString();
							if (oHeaderStartDate === oTableStartDate) {
								StartDateObj = {
									"Posnr": oTableData[i].Posnr,
									"Zposid": oTableData[i].Zposid,
									"Tasktext": oTableData[i].Arktx,
									"Vbegdat": oTableData[i].Vbegdat,
									"Venddat": oTableData[i].Venddat,
									"oContext": "/iwoTabTravel/" + i
								};
								ArrayFilteredStartDates.push(StartDateObj);
							}
						}
					}
					this.oStartDateDialog.setModel(new JSONModel({}), "oStartDateFragmentModel");
					this.oStartDateDialog.getModel("oStartDateFragmentModel").setProperty("/iwoTabTravel", ArrayFilteredStartDates);

					if (this.oStartDateDialog.getModel("oStartDateFragmentModel").getData().iwoTabTravel.length > 0) {

						this.oStartDateDialog.open();
					}

				} else if (this.oSelectedstartDate > oHeaderSDate) {
					for (var i = 0; i < sRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							if (!Year && !day && !month) {

							} else {

								var oLocalModel = this.getView().getModel("localModel");
								var rStartDate = this.getView().byId("dateCtrlStr").getDateValue();
								var oStartdateForm = this.dateFormatter(rStartDate);
								oLocalModel.setProperty("/iwoTabTravel/" + i + "/Vbegdat", oStartdateForm);
							}
						}
					}
				}

				// end date code	
			} else {
				for (var i = 0; i < sRowCount; i++) {
					if (!Year && !day && !month) {

					} else {
						var oLocalModel = this.getView().getModel("localModel");
						var rStartDate = this.getView().byId("dateCtrlStr").getDateValue();
						var oStartdateForm = this.dateFormatter(rStartDate);
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/Vbegdat", oStartdateForm);

					}
				}
			}
			this.oPreviousStartDate = this.getView().byId("dateCtrlStr").getDateValue();
			this.oStartDateFlag = true;

			// }
		},
		// onSelectStartDateRow: function (oEvent) {
		// 	var oRowCount = this.getView().byId("idStartDateTable").getSelectedContextPaths();
		// 	this.ArrayStartDate = [];
		// 	for (var i = 0; i < oRowCount.length; i++) {
		// 		var oStartSelectedData = this.getView().byId("idStartDateTable").getModel("oStartDateFragmentModel").getProperty(oRowCount[i]);
		// 		this.ArrayStartDate.push(oStartSelectedData.Posnr);
		// 	}
		// },
		onUpdatePopupStartDate: function (oEvent) {
			var oTableModel = this.getView().byId("idTravel").getModel("localModel");
			var oRowCount = this.getView().byId("idStartDateTable").getSelectedContextPaths();
			for (var i = 0; i < oRowCount.length; i++) {
				var oSelectedContext = this.getView().byId("idStartDateTable").getModel("oStartDateFragmentModel").getProperty(oRowCount[i]).oContext;
				oTableModel.setProperty(oSelectedContext + "/Vbegdat", this.dateFormatter(this.oSelectedstartDate));
			}
			// for (var i = 0; i < oTableRowCount; i++) {
			// 	if (this.ArrayStartDate[i] !== undefined) {
			// 		var oFragPosnr = this.ArrayStartDate[i];
			// 	}
			// 	var oTablPosnr = this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Posnr;
			// 	if (oFragPosnr === oTablPosnr) {
			// 		var a1 = this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel;
			// 		var addPosition = a1.map(function (o) {
			// 			return o.Posnr;
			// 		}).indexOf(oTablPosnr);
			// 		this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[addPosition].Vbegdat = this.dateFormatter(this.oSelectedstartDate);
			// 		this.getView().getModel("localModel").refresh(true);
			// 	}
			// }
			this.oStartDateDialog.close();
		},
		onCloseStartDatePopup: function (oEvent) {
			this.oStartDateDialog.close();
		},

		onDatePickerValidationEndDate: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oHeaderEDate;
			// var oEDateFlag = "oEndDateFalg";
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var month = oEvent.getSource().getDateValue().getMonth();
			var day = oEvent.getSource().getDateValue().getDate();
			this.oSelectedEndDate = new Date(Year, month, day);
			if (this.oEndDateFlag === true) {
				oHeaderEDate = this.oPreviousEndDate;
			} else {
				oHeaderEDate = this.oHeaderEndDate;

			}

			this.byId("dateCtrlStr").setMaxDate(this.oSelectedEndDate);
			var bFlag = oEvent.getParameter("valid") ? "None" : "Error";
			oEvent.getSource().setValueState(bFlag);
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[0].Zentry_tp;
			// if(){=========   EndDate popup Code Start =========//	
			//if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && oEntryType !== "N")) {
			if ((oViewModel.getData().type === "ChangeProject") || (oViewModel.getData().type === "ChangeRequest" && oEntryType !== "N")) {
				if (this.oSelectedEndDate >= oHeaderEDate) {
					var oModel = this.getView().getModel();
					var oView = this.getView();
					this.oEndDateDialog = oView.byId("idFWBSEndDate");
					// create dialog lazily
					if (!this.oEndDateDialog) {
						// create dialog via fragment factory
						this.oEndDateDialog = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.EndDate", this);
						oView.addDependent(this.oEndDateDialog);
					}
					var oTableRowCount = this.getView().getModel("localModel").getData().iwoTabTravel.length;
					var oTableData = this.getView().getModel("localModel").getData().iwoTabTravel;
					// if(this.oSelectedEndDate){
					// 	oHeaderEDate = this.oSelectedEndDate;
					// }
					var oHeaderEndYear = oHeaderEDate.getFullYear();
					var oHeaderEndMonth = oHeaderEDate.getMonth();
					var oHeaderEndDay = oHeaderEDate.getDate();
					var oHeaderEndDate = oHeaderEndYear.toString() + oHeaderEndMonth.toString() + oHeaderEndDay.toString();
					var ArrayFilteredEndDates = [];
					var EndDateObj = {};
					for (var i = 0; i < oTableRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							var oTableEDate = oTableData[i].Venddat;
							var oTableEndYear = oTableEDate.getFullYear();
							var oTableEndMonth = oTableEDate.getMonth();
							var oTableEndDay = oTableEDate.getDate();
							var oTableEndtDate = oTableEndYear.toString() + oTableEndMonth.toString() + oTableEndDay.toString();
							// var oTableEndDate = new Date(oDateTable.toString());
							if (oHeaderEndDate === oTableEndtDate) {
								EndDateObj = {
									"Posnr": oTableData[i].Posnr,
									"Zposid": oTableData[i].Zposid,
									"Tasktext": oTableData[i].Arktx,
									"Vbegdat": oTableData[i].Vbegdat,
									"Venddat": oTableData[i].Venddat,
									"oContext": "/iwoTabTravel/" + i
								};
								ArrayFilteredEndDates.push(EndDateObj);
							}
						}
					}
					this.oEndDateDialog.setModel(new JSONModel({}), "oEndDateFragmentModel");
					this.oEndDateDialog.getModel("oEndDateFragmentModel").setProperty("/iwoTabTravel", ArrayFilteredEndDates);

					if (this.oEndDateDialog.getModel("oEndDateFragmentModel").getData().iwoTabTravel.length > 0) {
						this.oEndDateDialog.open();

					}
					// else{
					// 		sap.m.MessageToast.show("No lineItems matches to HeaderDate ", {
					// 	duration: 3000
					// });
					// 	}
					// this.oPreviousEndDate = this.getView().byId("dateCtrlEnd").getDateValue();
				} else if (this.oSelectedEndDate <= oHeaderEDate) {
					for (var i = 0; i < sRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							if (!Year && !day && !month) {} else {
								var oLocalModel = this.getView().getModel("localModel");
								var rEndDate = this.getView().byId("dateCtrlEnd").getDateValue();
								var oEnddateForm = this.dateFormatter(rEndDate);
								oLocalModel.setProperty("/iwoTabTravel/" + i + "/Venddat", oEnddateForm);
							}
						}
					}
				}
			} else {
				for (var i = 0; i < sRowCount; i++) {
					if (!Year && !day && !month) {} else {
						var rEndDate = this.getView().byId("dateCtrlEnd").getDateValue();
						this.getView().byId("idTravel").getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Venddat", this.dateFormatter(
							rEndDate));
					}
				}
			}
			this.oPreviousEndDate = this.getView().byId("dateCtrlEnd").getDateValue();
			this.oEndDateFlag = true;
			// }=========   EndDate popup Code Start =========//

		},

		onUpdatePopupEndDate: function (oEvent) {

			var oTableModel = this.getView().byId("idTravel").getModel("localModel");
			var oRowCount = this.getView().byId("idEndDateTable").getSelectedContextPaths();
			for (var i = 0; i < oRowCount.length; i++) {
				var oSelectedContext = this.getView().byId("idEndDateTable").getModel("oEndDateFragmentModel").getProperty(oRowCount[i]).oContext;
				oTableModel.setProperty(oSelectedContext + "/Venddat", this.dateFormatter(this.oSelectedEndDate));
			}
			this.oEndDateDialog.close();
		},
		onCloseEndDatePopup: function (oEvent) {
			this.oEndDateDialog.close();
		},

		onDatePickerValidationInt: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oHeaderSDateInt;
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			this.oSelectedstartDateInt = new Date(Year, month, day);
			if (this.oStartDateFlagInt === true) {
				oHeaderSDateInt = this.oPreviousStartDateInt;
			} else {
				oHeaderSDateInt = this.oHeaderStartDateInt;
			}

			var oTableDataInt = this.getView().getModel("localModel").getData().iwoTabTravel;
			// this.byId("idEndInt").setValue("");
			this.byId("idEndInt").setMinDate(new Date(Year, month, day));
			var bFlag = oEvent.getParameter("valid") ? "None" : "Error";
			oEvent.getSource().setValueState(bFlag);
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[0].Zentry_tp;
			// if(){=========   EndDate popup Code Start =========//

			if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && oEntryType !== "N")) {
				if (this.oSelectedstartDateInt <= oHeaderSDateInt) {
					var oModel = this.getView().getModel();
					var oView = this.getView();
					this.oStartDateDialogInt = oView.byId("idFWBSStartDateInt");
					// create dialog lazily
					if (!this.oStartDateDialogInt) {
						// create dialog via fragment factory
						this.oStartDateDialogInt = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.StartDateInt", this);
						oView.addDependent(this.oStartDateDialogInt);
					}
					var oTableRowCountInt = this.getView().getModel("localModel").getData().iwoTabTravel.length;
					// var oHeaderSDateInt = this.oHeaderStartDateInt;
					var oHeaderStartYearInt = oHeaderSDateInt.getFullYear();
					var oHeaderStartMonthInt = oHeaderSDateInt.getMonth();
					var oHeaderStartDayInt = oHeaderSDateInt.getDate();
					var oHeaderStartDateInt = oHeaderStartYearInt.toString() + oHeaderStartMonthInt.toString() + oHeaderStartDayInt.toString();
					var ArrayFilteredStartDatesInt = [];
					var StartDateObjInt = {};
					for (var i = 0; i < oTableRowCountInt; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							var oTableSDateInt = oTableDataInt[i].Vbegdat;
							var oTableStartYearInt = oTableSDateInt.getFullYear();
							var oTableStartMonthInt = oTableSDateInt.getMonth();
							var oTablestartDayInt = oTableSDateInt.getDate();
							var oTableStartDateInt = oTableStartYearInt.toString() + oTableStartMonthInt.toString() + oTablestartDayInt.toString();
							if (oHeaderStartDateInt === oTableStartDateInt) {
								StartDateObjInt = {
									"Posnr": oTableDataInt[i].Posnr,
									"Zposid": oTableDataInt[i].Zposid,
									"Tasktext": oTableDataInt[i].Arktx,
									"Vbegdat": oTableDataInt[i].Vbegdat,
									"Venddat": oTableDataInt[i].Venddat,
									"oContext": "/iwoTabTravel/" + i
								};
								ArrayFilteredStartDatesInt.push(StartDateObjInt);
							}
						}
					}
					this.oStartDateDialogInt.setModel(new JSONModel({}), "oStartDateFragmentModelInt");
					this.oStartDateDialogInt.getModel("oStartDateFragmentModelInt").setProperty("/iwoTabTravel", ArrayFilteredStartDatesInt);

					if (this.oStartDateDialogInt.getModel("oStartDateFragmentModelInt").getData().iwoTabTravel.length > 0) {
						this.oStartDateDialogInt.open();
					}
				} else if (this.oSelectedstartDateInt >= oHeaderSDateInt) {
					for (var i = 0; i < sRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							if (!Year && !day && !month) {} else {

								var oLocalModel = this.getView().getModel("localModel");
								var rStartDateInt = this.getView().byId("idStarInt").getDateValue();
								var oStartdateFormInt = this.dateFormatter(rStartDateInt);
								oLocalModel.setProperty("/iwoTabTravel/" + i + "/Vbegdat", oStartdateFormInt);

								// var rStartDate = this.getView().byId("idStarInt").getDateValue();
								// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Vbegdat = this.dateFormatter(rStartDate);
								// var rEndDate = this.getView().byId("idEndInt").getDateValue();
								// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Venddat = this.dateFormatter(rEndDate);
								// this.getView().getModel("localModel").refresh(true);
							}
						}
					}
				}
			} else {
				for (var i = 0; i < sRowCount; i++) {
					if (!Year && !day && !month) {} else {

						var oLocalModelInt = this.getView().getModel("localModel");
						var rStartDateInt = this.getView().byId("idStarInt").getDateValue();
						var oStartdateFormInt = this.dateFormatter(rStartDateInt);
						oLocalModelInt.setProperty("/iwoTabTravel/" + i + "/Vbegdat", oStartdateFormInt);
					}
				}
			}
			this.oPreviousStartDateInt = this.getView().byId("idStarInt").getDateValue();
			this.oStartDateFlagInt = true;
			// }

		},
		// onSelectStartDateRowInt: function (oEvent) {
		// 	var oRowCount = this.getView().byId("idStartDateTableInt").getSelectedContextPaths();
		// 	this.ArrayStartDateInt = [];
		// 	for (var i = 0; i < oRowCount.length; i++) {
		// 		var oStartSelectedDataInt = this.getView().byId("idStartDateTableInt").getModel("oStartDateFragmentModelInt").getProperty(
		// 			oRowCount[i]);
		// 		this.ArrayStartDateInt.push(oStartSelectedDataInt.Posnr);
		// 	}
		// },
		onUpdatePopupStartDateInt: function (oEvent) {

			var oTableModel = this.getView().byId("idInternal").getModel("localModel");
			var oRowCount = this.getView().byId("idStartDateTableInt").getSelectedContextPaths();
			for (var i = 0; i < oRowCount.length; i++) {
				var oSelectedContext = this.getView().byId("idStartDateTableInt").getModel("oStartDateFragmentModelInt").getProperty(oRowCount[i])
					.oContext;
				oTableModel.setProperty(oSelectedContext + "/Vbegdat", this.dateFormatter(this.oSelectedstartDateInt));
			}

			// var oTableRowCountInt = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel.length;
			// for (var i = 0; i < oTableRowCountInt; i++) {
			// 	if (this.ArrayStartDateInt[i] !== undefined) {
			// 		var oFragPosnrInt = this.ArrayStartDateInt[i];
			// 	}
			// 	var oTablPosnrInt = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Posnr;
			// 	if (oFragPosnrInt === oTablPosnrInt) {
			// 		var b1 = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel;
			// 		var addPosition = b1.map(function (o) {
			// 			return o.Posnr;
			// 		}).indexOf(oTablPosnrInt);
			// 		this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[addPosition].Vbegdat = this.dateFormatter(this.oSelectedstartDateInt);
			// 		this.getView().getModel("localModel").refresh(true);
			// 	}
			// }
			this.oStartDateDialogInt.close();
		},
		onCloseStartDatePopupInt: function (oEvent) {
			this.oStartDateDialogInt.close();
		},

		onDatePickerValidationEndDateInt: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oHeaderEDateInt;
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			this.oSelectedEndDateInt = new Date(Year, month, day);

			if (this.oEndDateFlagInt === true) {
				oHeaderEDateInt = this.oPreviousEndDateInt;
			} else {
				oHeaderEDateInt = this.oHeaderEndDateInt;
			}
			var bFlag = oEvent.getParameter("valid") ? "None" : "Error";
			oEvent.getSource().setValueState(bFlag);
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();

			var oTableData = this.getView().getModel("localModel").getData().iwoTabTravel;
			var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[0].Zentry_tp;
			// if(){=========   EndDate popup Code Start =========//	
			if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && oEntryType !== "N")) {
				if (this.oSelectedEndDateInt >= oHeaderEDateInt) {
					var oModel = this.getView().getModel();
					var oView = this.getView();
					this.oEndDateDialogInt = oView.byId("idFWBSEndDateInt");
					// create dialog lazily
					if (!this.oEndDateDialogInt) {
						// create dialog via fragment factory
						this.oEndDateDialogInt = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.EndDateInt", this);
						oView.addDependent(this.oEndDateDialogInt);
					}
					var oTableRowCount = this.getView().getModel("localModel").getData().iwoTabTravel.length;
					var oHeaderEndYear = oHeaderEDateInt.getFullYear();
					var oHeaderEndMonth = oHeaderEDateInt.getMonth();
					var oHeaderEndDay = oHeaderEDateInt.getDate();
					var oHeaderEndDateInt = oHeaderEndYear.toString() + oHeaderEndMonth.toString() + oHeaderEndDay.toString();
					var ArrayFilteredEndDatesInt = [];
					var EndDateObjInt = {};
					for (var i = 0; i < oTableRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							var oTableEDate = oTableData[i].Venddat;
							var oTableEndYear = oTableEDate.getFullYear();
							var oTableEndMonth = oTableEDate.getMonth();
							var oTableEndDay = oTableEDate.getDate();
							var oTableEndtDateInt = oTableEndYear.toString() + oTableEndMonth.toString() + oTableEndDay.toString();
							// var oTableEndDate = new Date(oDateTable.toString());
							if (oHeaderEndDateInt === oTableEndtDateInt) {
								EndDateObjInt = {
									"Posnr": oTableData[i].Posnr,
									"Zposid": oTableData[i].Zposid,
									"Tasktext": oTableData[i].Arktx,
									"Vbegdat": oTableData[i].Vbegdat,
									"Venddat": oTableData[i].Venddat,
									"oContext": "/iwoTabTravel/" + i
								};
								ArrayFilteredEndDatesInt.push(EndDateObjInt);
							}
						}
					}
					this.oEndDateDialogInt.setModel(new JSONModel({}), "oEndDateFragmentModelInt");
					this.oEndDateDialogInt.getModel("oEndDateFragmentModelInt").setProperty("/iwoTabTravel", ArrayFilteredEndDatesInt);

					if (this.oEndDateDialogInt.getModel("oEndDateFragmentModelInt").getData().iwoTabTravel.length > 0) {
						this.oEndDateDialogInt.open();
					}
				} else if (this.oSelectedEndDateInt < oHeaderEDateInt) {
					for (var i = 0; i < sRowCount; i++) {
						var zEntry = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
						var oSysLine = this.getView().getModel("localModel").getData().iwoTabTravel[i].Systatusline;
						if (oSysLine === "DLFL" || oSysLine === "REL" || zEntry === "N") {
							if (!Year && !day && !month) {} else {

								var oLocalModel = this.getView().getModel("localModel");
								var rEndDateInt = this.getView().byId("idEndInt").getDateValue();
								var oEnddateFormInt = this.dateFormatter(rEndDateInt);
								oLocalModel.setProperty("/iwoTabTravel/" + i + "/Venddat", oEnddateFormInt);

							}
						}

					}
				}
			} else {
				for (var i = 0; i < sRowCount; i++) {
					if (!Year && !day && !month) {

					} else {

						var oLocalModel = this.getView().getModel("localModel");
						var rEndDateInt = this.getView().byId("idEndInt").getDateValue();
						var oEnddateFormInt = this.dateFormatter(rEndDateInt);
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/Venddat", oEnddateFormInt);

						// var rStartDate = this.getView().byId("idStarInt").getDateValue();
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Vbegdat = this.dateFormatter(rStartDate);
						// var rEndDate = this.getView().byId("idEndInt").getDateValue();
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Venddat = this.dateFormatter(rEndDate);
						// this.getView().getModel("localModel").refresh(true);
					}
				}
			}
			this.oPreviousEndDateInt = this.getView().byId("idEndInt").getDateValue();
			this.oEndDateFlagInt = true;
			// }=========   EndDate popup Code Start =========//

		},
		// onSelectEndDateRowInt: function (oEvent) {
		// 	var oRowCount = this.getView().byId("idEndDateTableInt").getSelectedContextPaths();
		// 	this.ArrayEndDateInt = [];
		// 	for (var i = 0; i < oRowCount.length; i++) {
		// 		var oEndSelectedDataInt = this.getView().byId("idEndDateTableInt").getModel("oEndDateFragmentModelInt").getProperty(oRowCount[i]);
		// 		this.ArrayEndDateInt.push(oEndSelectedDataInt.Posnr);
		// 	}
		// },
		onUpdatePopupEndDateInt: function (oEvent) {

			var oTableModel = this.getView().byId("idInternal").getModel("localModel");
			var oRowCount = this.getView().byId("idEndDateTableInt").getSelectedContextPaths();
			for (var i = 0; i < oRowCount.length; i++) {
				var oSelectedContext = this.getView().byId("idEndDateTableInt").getModel("oEndDateFragmentModelInt").getProperty(oRowCount[i]).oContext;
				oTableModel.setProperty(oSelectedContext + "/Venddat", this.dateFormatter(this.oSelectedEndDateInt));
			}

			// var oTableRowCount = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel.length;
			// for (var i = 0; i < oTableRowCount; i++) {
			// 	if (this.ArrayEndDateInt[i] !== undefined) {
			// 		var oFragPosnrInt = this.ArrayEndDateInt[i];
			// 	}
			// 	var oTablPosnrInt = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Posnr;
			// 	if (oFragPosnrInt === oTablPosnrInt) {
			// 		var a1 = this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel;
			// 		var addPosition = a1.map(function (o) {
			// 			return o.Posnr;
			// 		}).indexOf(oTablPosnrInt);
			// 		this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[addPosition].Venddat = this.dateFormatter(this.oSelectedEndDateInt);
			// 		this.getView().getModel("localModel").refresh(true);
			// 	}
			// }
			this.oEndDateDialogInt.close();
		},
		onCloseEndDatePopupInt: function (oEvent) {
			this.oEndDateDialogInt.close();
		},

		onGarbageValueSold: function (oEvent) {
			var soldToSelectedGar = oEvent.getSource().getSelectedKey();
			if (!soldToSelectedGar) {
				this.getView().byId("idSoldTo").setValue("");
			}
		},

		onsetValuePBS: function (oEvent) {
			// var sValue = oEvent.getParameter("selectedItem").getText();
			// var sKey = oEvent.getSource().getSelectedKey();
			// this.getView().byId("idPayer").setValue(sValue);
			// this.getView().byId("idship").setValue(sValue);
			// this.getView().byId("idbill").setValue(sValue);
			// var sZterm = oEvent.getParameter("selectedItem").getAdditionalText().split("-")[1];
			// this.getView().byId("idPaymt").setValue(sZterm);
			var oSoldtoValue = this.getView().byId("idSoldTo").getSelectedKey();
			if (oSoldtoValue) {
				var oDefaultVal = oEvent.getParameters().selectedRow.mAggregations.cells[0].mProperties.text;
				var oPayment = oEvent.getParameters().selectedRow.mAggregations.cells[2].mProperties.text;
			}
			this.getView().byId("idPayer").setValue(oDefaultVal);
			this.getView().byId("idship").setValue(oDefaultVal);
			this.getView().byId("idbill").setValue(oDefaultVal);
			var oValueState = this.getView().byId("idPayer").getValueLiveUpdate();
			if (oValueState === false) {
				this.getView().byId("idPayer").setValueState("None");
				this.getView().byId("idship").setValueState("None");
				this.getView().byId("idbill").setValueState("None");
			}
			this.getView().byId("idPaymt").setValue(oPayment);
			//Invoice Deafulting

			var CoCoT1 = this.getView().byId("comCode").getValue();
			var oSoldto = this.getView().byId("idSoldTo").getSelectedKey();
			var sProject = this.getView().byId("idProjTyp").getSelectedKey();
			var oModel = this.getView().getModel("oDataModel");
			var that = this;

			var aBMTFiltersR = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, CoCoT1),
					new sap.ui.model.Filter("ProjType", sap.ui.model.FilterOperator.EQ, sProject),
					new sap.ui.model.Filter("SoldTo", sap.ui.model.FilterOperator.EQ, oSoldto)
				],
				and: true
			});

			//without client id warranty
			var aBMTFilterNoClient = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, CoCoT1),
					new sap.ui.model.Filter("ProjType", sap.ui.model.FilterOperator.EQ, sProject),
					new sap.ui.model.Filter("SoldTo", sap.ui.model.FilterOperator.EQ, "")

				],
				and: true
			});

			if (sProject === "ZBC" || "ZCGC") {
				if (oPayment) {
					that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + "0" + "/Zterm", this.getView().byId("idPaymt").getValue());
				}
				oModel.read("/SearchInvRecSet", {
					filters: [aBMTFiltersR],
					success: function (oData) {
						var aArrayLengthInv = oData.results.length;
						var sRowCount = that.getView().byId("idTravel").getBinding("rows").getLength();
						if (aArrayLengthInv === 0) {
							// that.getView().byId("idInv").setValue("");
							// for (var i = 0; i < sRowCount; i++) {
							// 	that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].InvRec = "";
							// }
							oModel.read("/SearchInvRecSet", {
								filters: [aBMTFilterNoClient],
								success: function (oData) {
									var pernr = oData.results[0].Pernr;
									var fName = oData.results[0].Vorna;
									var lName = oData.results[0].Nachn;
									// var InvRec = pernr + "," + fName + "," + lName;
									var sInvRec = fName + "," + lName + " (" + pernr + ")";
									that.getView().byId("idInv").setValue(sInvRec);
									for (var i = 0; i < sRowCount; i++) {
										that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].InvRec = sInvRec;
									}

								}
							});

						} else {
							var pernr = oData.results[0].Pernr;
							var fName = oData.results[0].Vorna;
							var lName = oData.results[0].Nachn;
							// var InvRec = pernr + "," + fName + "," + lName;
							var sInvRec = fName + "," + lName + " (" + pernr + ")";
							that.getView().byId("idInv").setValue(sInvRec);

							for (var i = 0; i < sRowCount; i++) {
								that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].InvRec = sInvRec;
							}

						}
					}
				});
			}
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			for (var i = 0; i < sRowCount; i++) {
				this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Payer = oSoldtoValue;
				this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].payerName = oDefaultVal;
				this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].ShipTo = oSoldtoValue;
				this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].shipToName = oDefaultVal;
				this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].BillTo = oDefaultVal;
				this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].billToName = oDefaultVal;
			}
		},

		onGarbageValuePayer: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			var sValue = oEvent.getSource().getValue();
			if (!sKey) {
				this.getView().byId("idSoldTo").setValue("");
			} else {
				var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
				for (var i = 0; i < sRowCount; i++) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Payer = sKey;
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].payerName = sValue;
				}
			}
		},

		onGarbageValueShipTo: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			var sValue = oEvent.getSource().getValue();
			if (!sKey) {
				this.getView().byId("idSoldTo").setValue("");
			} else {
				var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
				for (var i = 0; i < sRowCount; i++) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].ShipTo = sKey;
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].shipToName = sValue;
				}
			}
		},

		onGarbageValueBillTo: function (oEvent) {
			var sKey = oEvent.getSource().getSelectedKey();
			var sValue = oEvent.getSource().getValue();
			if (!sKey) {
				this.getView().byId("idSoldTo").setValue("");
			} else {
				var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
				for (var i = 0; i < sRowCount; i++) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].BillTo = sKey;
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].billToName = sValue;
				}
			}
		},

		SetRequired: function (oEvent) {
			var newValue = oEvent.getSource().getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (newValue) {
				this.getView().byId("idReason").setRequired(true);
			}

			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" || AppType ===
						"CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Zterm", this.getView().byId("idPaymt").getValue());
					// this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Zterm = this.getView().byId("idPaymt").getValue();

				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Zterm", this.getView().byId("idPaymt").getValue());
				}
			}
		},
		onSuggestionSoldTo: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");

			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		onPodateChangeHeader: function (oEvent) {
			this.gPodate = "PD";

			var oPoDate = oEvent.getSource().getDateValue();
			var oLocalModel = this.getView().getModel("localModel");
			var oData = oLocalModel.getProperty("/iwoTabTravel");

			for (var i = 0; i < oData.length; i++) {
				if (oData[i].Zentry_tp !== "E" && oData[i].Zentry_tp !== "C") {
					if (oPoDate) {
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/Bstdk", this.dateFormatter(oPoDate));
					} else {
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/Bstdk", null);
					}
				}
			}
		},
		onLaborSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSoldToSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sBukrs = this.getView().byId("comCode").getValue();
			var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();

			// var andFilter = [];
			// var orFilter = [];
			// andFilter.push(new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, "sBukrs"));
			// andFilter.push(new sap.ui.model.Filter(orFilter, false));
			// andFilter = [];
			// orFilter.push(new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, "sTerm"));
			// orFilter.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, "sTerm"));
			// // orFilter = [];
			// orFilter.push(new sap.ui.model.Filter(orFilter, false));
			// var aFilters = new sap.ui.model.Filter(andFilter, true);

			// var aFilters = new sap.ui.model.Filter({filters: [filter(new sap.ui.model.Filter(andFilter, true));]})

			// Bukrs=filtervalue && (Kunnr=sTerm || Name1=sTerm)
			// var aFilters = new sap.ui.model.Filter({
			// 	filters: [
			// 		new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs),
			// 		// new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
			// 		// new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm)
			// 		// new sap.ui.model.Filter("Prjtyp", sap.ui.model.FilterOperator.EQ, sPrjTyp)
			// 	],
			// 	and: true
			// });
			var bFilters = new sap.ui.model.Filter({
				filters: [
					// new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs),
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm)
					// new sap.ui.model.Filter("Prjtyp", sap.ui.model.FilterOperator.EQ, sPrjTyp)
				],
				and: false
			});

			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs), bFilters
					// new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					// new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm)
					// new sap.ui.model.Filter("Prjtyp", sap.ui.model.FilterOperator.EQ, sPrjTyp)
				],
				and: true
			});
			// var bFilters;
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			var that = this;
			if ((sBukrs === '1571' || sBukrs === '1102') && (sPrjTyp === 'ZCGC')) {
				oModel.read("/SearchGlobalCustSet", {
					filters: [aFilters],
					urlParameters: {
						"$top": 100
					},
					success: function (oResponse) {
						var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
						oSource.setModel(oModel, 'sug');
						oSource._refreshItemsDelayed();
					},
					error: function (oError) {}
				});
			} else {
				oModel.read("/SearchCustomerSet", {
					filters: [aFilters],
					urlParameters: {
						"$top": 100
					},
					success: function (oResponse) {
						var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
						oSource.setModel(oModel, 'sug');
						oSource._refreshItemsDelayed();
					},
					error: function (oError) {}
				});
			}
			// oModel.read("/SearchCustomerSet", {
			// 	filters: [aFilters],
			// 	urlParameters: {
			// 		"$top": 100
			// 	},
			// 	success: function (oResponse) {
			// 		var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
			// 		oSource.setModel(oModel, 'sug');
			// 		oSource._refreshItemsDelayed();
			// 	},
			// 	error: function (oError) {}
			// });
		},

		//Setting selected key in tabular suggest
		suggestionRowValidator: function (oColumnListItem) {
			var aCells = oColumnListItem.getCells();

			return new Item({
				key: aCells[1].getText(),
				text: aCells[0].getText()
			});
		},
		onPayerSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var sBukrs = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchPayerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onShiptoSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var sBukrs = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchShipToSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onBilltoSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sBukrs = this.getView().byId("comCode").getValue();
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchBillToSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		//popup suggest
		onPayerSuggestpopup: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var sBukrs = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchPayerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var mResponse = oResponse.results.length;
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
					if (mResponse === 0) {
						that.getView().byId("idPayerPopup").setValue("");
					}
				},
				error: function (oError) {}
			});
		},
		onShiptoSuggestpopup: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var sBukrs = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchShipToSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var mResponse = oResponse.results.length;
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
					if (mResponse === 0) {
						that.getView().byId("idshipPopup").setValue("");
					}
				},
				error: function (oError) {}
			});
		},
		onBilltoSuggestpopup: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sBukrs = this.getView().byId("comCode").getValue();
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchBillToSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var mResponse = oResponse.results.length;
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
					if (mResponse === 0) {
						that.getView().byId("idbillPopup").setValue("");
					}
				},
				error: function (oError) {}
			});
		},
		onSuggestAgm: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aAgm = "";

		},
		onSuggestWBS1: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aWbsowner1 = "";
		},
		onSuggestWBS2: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aWbsowner2 = "";
		},
		onSuggestDraft: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});

			that.aDraftIa = "";
		},
		onSuggestFinApp: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});

			that.aFinApp = "";
		},
		onProjectAct: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Vorna", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Nachn", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchBMTPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aPrjAc = "";

		},
		onBds: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Vorna", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Nachn", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchBDSSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});

			that.aBds = "";

		},
		onInvRec: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Vorna", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Nachn", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchInvRecSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});

			that.aInvRec = "";
		},
		//PopWindow Suggest
		onSuggestAgmpopup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Name1", "Pernr", "Name2");
			this.aAgm = "";
		},

		onSuggestWBS1popup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Name1", "Pernr", "Name2");
			this.aWbsowner1 = "";
		},

		onSuggestWBS2popup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Name1", "Pernr", "Name2");
			this.aWbsowner2 = "";
		},

		onSuggestDraftpopup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Name1", "Pernr", "Name2");
			this.aDraftIa = "";
		},

		onSuggestFinApppopup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Name1", "Pernr", "Name2");
			this.aFinApp = "";
		},

		onProjectActpopup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Vorna", "Pernr", "Nachn");
			this.aPrjAc = "";

		},
		onBdspopup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Vorna", "Pernr", "Nachn");
			this.aBds = "";
		},

		onInvRecpopup: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sTerm = oEvent.getParameter("suggestValue");
			this._fnFilterData(oSrc, sTerm, "Vorna", "Pernr", "Nachn");
			this.aInvRec = "";
		},

		_fnFilterData: function (oSrc, sTerm, filter1, filter2, filter3) {
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter(filter1, sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter(filter2, sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter(filter3, sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oSrc.getBinding("suggestionItems").filter(aFilters);
		},

		onSuggestOppId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("OptyId", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			var that = this;
			oModel.read("/SearchOppIdSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onIntSuggestOppId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("OptyId", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			var that = this;
			oModel.read("/SearchOppIdSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		//Internal
		onSoldToSuggestInt: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sBukrs = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sBukrs),

				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			var that = this;
			oModel.read("/SearchCustomerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onResCostDefaultInt: function (oEvent) {
			// var sValue = oEvent.getSource().getSelectedKey();
			var sSelected = oEvent.getParameter("value");
			var sComCode = this.getView().byId("comCode").getValue();
			var osTyp = this.getView().byId("idSubTyp").getSelectedKey();
			var sRow = oEvent.getSource().getBindingContext("localModel").getPath();
			var that = this;
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.EQ, sSelected),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sComCode),
					new sap.ui.model.Filter("SubTyp", sap.ui.model.FilterOperator.EQ, osTyp)

				],
				and: true
			});
			var oModel = this.getView().getModel("oDataModel");
			oModel.read("/SearchCostCenterSet", {
				filters: [aFilters],
				success: function (oData) {
					if (oData.results.length === 0) {
						that.getView().getModel("localModel").setProperty(sRow + "/Fkstl", "");
						that.getView().getModel("localModel").setProperty(sRow + "/Ktext", "");
						that.getView().getModel("localModel").setProperty(sRow + "/Prctr", "");
					} else {
						if (oData && oData.results && oData.results.length > 0) {
							var splitDes = oData.results[0].Ktext;
							var splitProfit = oData.results[0].Prctr;
							var sRessCC = oData.results[0].Kostl;
							that.getView().getModel("localModel").setProperty(sRow + "/Fkstl", sRessCC);
							that.getView().getModel("localModel").setProperty(sRow + "/Ktext", splitDes);
							that.getView().getModel("localModel").setProperty(sRow + "/Prctr", splitProfit);
						}
					}
				},
				error: function (oError) {}
			});
		},

		onGarbageCostInt: function (oEvent) {
			// var sCostInt = oEvent.getSource().getSelectedKey();
			// var sCostInt = oEvent.getSource("selectedItem").getSelectedKey();
			var sInternalTable = this.getView().byId("idInternal").getVisible();
			if (sInternalTable) {
				var sRow = oEvent.getSource().getBindingContext().getPath();
				var sPath = sRow.split("/")[2];
				var sCostInt = this.getView().byId("idInternal").getRows()[sPath].getCells()[2].getSelectedKey();
				var sNewValue = this.getView().byId("idInternal").getRows()[sPath].getCells()[2].getValue();
				if (sCostInt != sNewValue) {
					this.getView().byId("idInternal").getRows()[sPath].getCells()[2].setValue("");
				}
			}
		},
		onResCostCenterInt: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sComCode = this.getView().byId("comCode").getValue();
			var osTyp = this.getView().byId("idSubTyp").getSelectedKey();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sComCode),
					new sap.ui.model.Filter("SubTyp", sap.ui.model.FilterOperator.Contains, osTyp)
				],
				and: true
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			var that = this;
			oModel.read("/SearchCostCenterSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'rescc');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onSuggestIntAgm: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aAgm = "";

		},
		onSuggestIntWBS1: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aWbsowner1 = "";
		},
		onSuggestIntWBS2: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aWbsowner2 = "";
		},
		onSuggestIntDraft: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});

			that.aDraftIa = "";
		},
		onSuggestIntFinApp: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchEmpPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});

			that.aFinApp = "";
		},
		onIntProjectAct: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Vorna", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Nachn", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			oModel.read("/SearchBMTPartnerSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
			that.aPrjAc = "";

		},
		//Suggest Pop Internal
		onSuggestIntAgmpopup: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			that.aAgm = "";

		},
		onSuggestIntWBS1popup: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			that.aWbsowner1 = "";
		},
		onSuggestIntWBS2popup: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			that.aWbsowner2 = "";
		},
		onSuggestIntDraftpopup: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			that.aDraftIa = "";
		},
		onSuggestIntFinApppopup: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name2", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			// var oModel = this.getView().getModel("oDataModel");
			// var oSource = oEvent.getSource();
			// oModel.read("/SearchEmpPartnerSet", {
			// 	filters: [aFilters],
			// 	urlParameters: {
			// 		"$top": 100
			// 	},
			// 	success: function (oResponse) {
			// 		var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
			// 		oSource.setModel(oModel, 'sug');
			// 		oSource._refreshItemsDelayed();
			// 	},
			// 	error: function (oError) {}
			// });
			that.aFinApp = "";
		},
		onIntProjectActpopup: function (oEvent) {
			var that = this;
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Vorna", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Nachn", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			// var oModel = this.getView().getModel("oDataModel");
			// var oSource = oEvent.getSource();
			// oModel.read("/SearchBMTPartnerSet", {
			// 	filters: [aFilters],
			// 	urlParameters: {
			// 		"$top": 100
			// 	},
			// 	success: function (oResponse) {
			// 		var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
			// 		oSource.setModel(oModel, 'sug');
			// 		oSource._refreshItemsDelayed();
			// 	},
			// 	error: function (oError) {}
			// });
			that.aPrjAc = "";

		},
		//Garbage Value
		onGarbageValueAgm: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Agm = this.getView().byId("idAccMan").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Agm = this.getView().byId("idAccMan").getValue();
				}
			}
		},
		onGarbageValueWbs1: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = this.getView().byId("idWBS1").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = this.getView().byId("idWBS1").getValue();
				}
			}
		},
		onGarbageValueWbs2: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = this.getView().byId("idWBS2").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = this.getView().byId("idWBS2").getValue();
				}
			}

		},
		onGarbageValueDraftIa: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {
					oInput.setValue("");
				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDrftInv").getValue();

				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDrftInv").getValue();
				}
			}
		},
		onGarbageValueFinApp: function (oEvent) {
			var oSrc = oEvent.getSource();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {
					oInput.setValue("");
				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].FinApp = oSrc.getValue();

				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].FinApp = oSrc.getValue();
				}
			}
		},
		onGarbageValuePrjAc: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAc").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAc").getValue();
				}
			}
		},
		onGarbageValueBds: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Bds = this.getView().byId("idBillStw").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].Bds = this.getView().byId("idBillStw").getValue();
				}
			}
		},
		onGarbageValueInvRec: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].InvRec = this.getView().byId("idInv").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[i].InvRec = this.getView().byId("idInv").getValue();
				}
			}
		},
		onGarbageValue: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				if (oInput1 === "") {
					sap.ui.getCore().byId(newID).setValueState("Error");
					sap.ui.getCore().byId(newID).setValueStateText("Please enter the value."); // Add record button disable
				} else {
					sap.ui.getCore().byId(newID).setValueState("None");
				}

			}
		},

		onGarbageValueAgmInt: function (oEvent) {
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();
			var oSrc = oEvent.getSource();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			if (sInternalForm === true) {
				// for (var i = 0; i < sRowCount; i++) {
				// 	if (!oInput1) {

				// 	} else {
				// 		this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Agm = this.getView().byId("idAccManInt").getValue();
				// 	}
				// }

				for (var i = 0; i < sRowCount; i++) {
					var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
					if (!oInput) {

					} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
							AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
						this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Agm", oSrc.getValue());
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
					} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
						this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Agm", oSrc.getValue());
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
					}
				}
			}
		},

		onGarbageValueWbs1Int: function (oEvent) {
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();
			var oSrc = oEvent.getSource();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			if (sInternalForm === true) {
				// for (var i = 0; i < sRowCount; i++) {
				// 	if (!oInput1) {

				// 	} else {
				// 		var oWbsoner1int = this.getView().byId("idWBS1Int").getValue();
				// 		this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = oWbsoner1int;
				// 	}
				// }
				for (var i = 0; i < sRowCount; i++) {
					var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
					if (!oInput) {

					} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
							AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
						this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Wbsowner1", oSrc.getValue());

						// var oWbsoner1int = this.getView().byId("idWBS1Int").getValue();
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = oWbsoner1int;
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
					} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
						this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Wbsowner1", oSrc.getValue());
						// var oWbsoner1int = this.getView().byId("idWBS1Int").getValue();
						// 	this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = oWbsoner1int;
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
					}
				}
			}
		},

		onGarbageValueWbs2Int: function (oEvent) {
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();
			var oSrc = oEvent.getSource();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			if (sInternalForm === true) {
				// for (var i = 0; i < sRowCount; i++) {
				// 	var oWbsowner2Int = this.getView().byId("idWBS2Int").getValue();
				// 	this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = oWbsowner2Int;

				// }
				for (var i = 0; i < sRowCount; i++) {
					var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
					if (!oInput) {

					} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
							AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {

						this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Wbsowner2", oSrc.getValue());
						// 	var oWbsowner2Int = this.getView().byId("idWBS2Int").getValue();
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = oWbsowner2Int;

						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDr").getValue();
					} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
						this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Wbsowner2", oSrc.getValue());
						// 	var oWbsowner2Int = this.getView().byId("idWBS2Int").getValue();
						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = oWbsowner2Int;

						// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDr").getValue();
					}
				}
			}
		},

		onGarbageValueDraftIaInt: function (oEvent) {
			var oSrc = oEvent.getSource();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			// for (var i = 0; i < sRowCount; i++) {
			// 	this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDr").getValue();
			// }
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/DraftIa", oSrc.getValue());
					// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDr").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/DraftIa", oSrc.getValue());
					// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].DraftIa = this.getView().byId("idDr").getValue();
				}
			}
		},

		onGarbageValueFinAppInt: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sKey = oSrc.getSelectedKey();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (!sKey) {
				oInput.setValue("");
			}
			// for (var i = 0; i < sRowCount; i++) {
			// 	this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/FinApp", oSrc.getValue());
			// }
			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/FinApp", oSrc.getValue());
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/FinApp", oSrc.getValue());
				}
			}
		},

		onGarbageValuePrjAcInt: function (oEvent) {
			var oSrc = oEvent.getSource();
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oInput1 = oView.byId(newID).getSelectedKey();
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (!oInput1) {
				oInput.setValue("");
			}
			// for (var i = 0; i < sRowCount; i++) {
			// 	this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
			// }

			for (var i = 0; i < sRowCount; i++) {
				var oEntryType = this.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
				if (!oInput1) {

				} else if ((AppType === "ChangeRequest" || AppType === "ChangeProject" || AppType === "CSIReview" || AppType === "BILLReview" ||
						AppType === "CSIRej" || AppType === "BILLRej") && (oEntryType === "N")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/PrjAc", oSrc.getValue());
					// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
				} else if ((AppType === "ChangeRequest" && this.ChangeReuestFlag === "ChangeRequestFlagC") || (AppType === "")) {
					this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/PrjAc", oSrc.getValue());
					// this.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].PrjAc = this.getView().byId("idProAcInt").getValue();
				}
			}

		},

		onGarbageValueBox: function (oEvent) {
			var oInput = oEvent.getSource().getSelectedKey();
			if (!oInput) {
				this.getView().byId("idInvLay").setValue("");
			}

		},

		onGarbageBill: function (oEvent) {
			var oInput = oEvent.getSource().getSelectedKey();
			if (!oInput) {
				this.getView().byId("idBillCal").setValue("");
			}
		},

		WBSoneTwoCheck: function (oEvent) {
			var oWBS1 = this.getView().byId("idWBS1").getSelectedKey();
			var oWBS2 = this.getView().byId("idWBS2").getSelectedKey();
			if (oWBS1 === oWBS2) {
				sap.m.MessageToast.show("WBS Owner1 and WBS Owner2 should not be same", {
					duration: 6000
				});
				this.getView().byId("idWBS2").setValueState("Error");
			} else {
				this.getView().byId("idWBS1").setValueState("None");
				this.getView().byId("idWBS2").setValueState("None");
			}
		},

		WBSoneTwoCheckInt: function (oEvent) {
			var oWBS1 = this.getView().byId("idWBS1Int").getSelectedKey();
			var oWBS2 = this.getView().byId("idWBS2Int").getSelectedKey();
			if (oWBS1 === oWBS2) {
				sap.m.MessageToast.show("WBS Owner1 and WBS Owner2 should not be same", {
					duration: 6000
				});
				this.getView().byId("idWBS2Int").setValueState("Error");
			} else {
				this.getView().byId("idWBS1Int").setValueState("None");
				this.getView().byId("idWBS1Int").setValueState("None");
			}
		},
		// ***************WBS Methods TAB New Request Details**********************	
		addEmailLiveChange: function (oEvt) {
			var src1 = oEvt.getSource();
			var srchval = src1.getValue();
			src1.setSelectedKey(srchval);
		},

		onEmailGarbage: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oMultiInpuidNonTrack = oView.byId(newID);
			oMultiInpuidNonTrack.setValue("");
		},

		onSuggestionmulEmail: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm),
				]
			});
			var oModel = this.getView().getModel("oDataModel");
			var oSource = oEvent.getSource();
			var that = this;
			oModel.read("/SearchEmailSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
				},
				error: function (oError) {}
			});
		},

		onSetVlaueTab2: function (oEvent) {
			var that = this;
			var key = oEvent.getSource().getSelectedKey();
			this.getView().byId("idComCo2").setValue(key);
			this.getView().byId("idComFormInt").setValue(key);
			var oModel = this.getView().getModel("oDataModel");
			var sValue = oEvent.getParameter("value");
			var oProjectBox = that.getView().byId("idProjTyp");
			var oBindingBox = oProjectBox.getBinding("items");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sValue),
				],
				and: true
			});
			oBindingBox.filter(aFilters);
			oModel.read("/SearchCompCodeSet", {
				filters: [aFilters],
				success: function (oData) {
					var oViewModel = that.getView().getModel("appView");
					oViewModel.getData().System = oData.results[0].Des_sys
					that.getView().getModel("appView").refresh(true);
				},
				error: function (oError) {}
			});
		},

		onSuggestionProjTyp: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Auart", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onInputProjectType: function (oEvent) {
			var key = oEvent.getSource().getSelectedKey();
			if (key === "ZPRJ") {
				sap.m.MessageToast.show("Internal Project Selected", {
					duration: 5000
				});
				this.getView().byId("SimpleFormInternal").setVisible(true);
				this.getView().byId("SimpleFormChangewbs").setVisible(false);
				this.getView().byId("subTyp").setVisible(true);
				this.getView().byId("idSubTyp").setVisible(true);
				this.getView().byId("idInternal").setVisible(true);
				this.getView().byId("idTravel").setVisible(false);
			} else {
				sap.m.MessageToast.show("Revenue Project Selected", {
					duration: 5000
				});
				if (key === "ZBC" || key === "ZCGC") {
					this.getView().byId("SimpleFormInternal").setVisible(false);
					this.getView().byId("SimpleFormChangewbs").setVisible(true);
					this.getView().byId("subTyp").setVisible(false);
					this.getView().byId("idSubTyp").setVisible(false);
					this.getView().byId("idInternal").setVisible(false);
					this.getView().byId("idTravel").setVisible(true);
				}
			}
			this.onClearProjectType();
			return;
		},

		onClearProjectType: function () {
			var sRevenueForm = this.getView().byId("SimpleFormChangewbs").getVisible();
			if (sRevenueForm === true) {
				this.getView().byId("idSoldTo").setSelectedKey();
				this.getView().byId("idship").setValue();
				this.getView().byId("idbill").setValue();
				this.getView().byId("idPayer").setValue();
				this.getView().byId("idSign").setValue();
				this.getView().byId("idpo").setValue();
				this.getView().byId("dateCtrlPo").setValue();
				this.getView().byId("idPaymt").setValue();
				this.getView().byId("idReason").setValue();
				this.getView().byId("idInvLay").setValue();
				this.getView().byId("idBillCal").setValue();
				this.getView().byId("dateCtrlStr").setValue();

				this.getView().byId("dateCtrlEnd").setValue();

				this.getView().byId("idAccMan").setValue();
				this.getView().byId("idWBS1").setValue();
				this.getView().byId("idWBS2").setValue();
				this.getView().byId("idDrftInv").setValue();
				this.getView().byId("idFinApp").setValue();
				this.getView().byId("idProAc").setValue();
				this.getView().byId("idBillStw").setValue();
				this.getView().byId("idInv").setValue();
				this.getView().byId("idProjDes").setValue();

			}
			// Begin of Changes for Scenario2 srini vallepu
			var oLength = window.location.href.split("#")[1].split("?").length;
			if (oLength > 1) {
				var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
				if (oLength1 === 1) {
					if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {
						jQuery.sap.require("jquery.sap.storage");
						var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
						if (oStorage.get("oppData")) {
							var obj = oStorage.get("oppData");
						}

						this.onLoadOppData(obj);
						// item  cat code 
						var oModel = this.getView().getModel("oDataModel");
						var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();

						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Auart", sap.ui.model.FilterOperator.EQ, sPrjTyp),
							],
							and: false
						});
						var that = this;
						oModel.read("/SearchItemCatSet", {
							filters: [aFilters],
							success: function (oData) {
								var oBillModel = new sap.ui.model.json.JSONModel(oData);
								that.getView().setModel(oBillModel, "oBillModel");
							},
							error: function (oError) {}
						});
					}
				}
			}
			// End of chnaged for scenario2 srini vallepu
			this.getView().getModel("localModel").getData().iwoTabTravel = [];
			this.getView().getModel("localModel").getData().laborData = [];
			this.getView().getModel("localModel").getData().itemLaborData = [];
		},

		F: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Zprjsub", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		setValueOnSelectIntTyp: function (oEvent) {
			var key = oEvent.getSource().getSelectedKey();
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (key) {
				//var data = this._fnSetInternalMaterial(key);//Ratna commented 1.
				var sType = key;
				var oViewModel = this.getView().getModel("appView");
				var osystemid = oViewModel.getData().System;
				var Sysid = osystemid.split("(")[1].split(")")[0];
				this.getView().getModel("appView").refresh(true);

				//Internal Default code Subtype
				if (key === "ST" || key === "IN" || key === "LT" || key === "SU" || key === "SB") {
					this.getView().byId("idIntSold").setValue("10000001");
				} else {
					this.getView().byId("idIntSold").setValue("");
				}

				if (key === "ST" || key === "IN" || key === "LT" || key === "SU" || key === "SB") {
					this.getView().byId("idIntSold").setEditable(false);
				} else {
					if (key === "OH" || key === "BP" || key === "BN" || key === "BS") {
						this.getView().byId("idIntSold").setEditable(true);

					}
				}
				var aFilters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Sysid", sap.ui.model.FilterOperator.EQ, Sysid),
						new sap.ui.model.Filter("Subtyp", sap.ui.model.FilterOperator.EQ, sType)
					],
					and: true
				});
				var oModel = this.getView().getModel("oDataModel");
				var that = this;
				oModel.read("/SearchIntMatSet", {
					filters: [aFilters],
					urlParameters: {
						"$top": 100
					},
					success: function (oResponse) {
						var oMaterial = oResponse.results[0].Material;
						var oMaterialDes = oResponse.results[0].Descripton;
						var data = {
							oMatnr: oMaterial,
							oMaktx: oMaterialDes
						};
						var oMatnr = data.oMatnr;
						var oMaktx = data.oMaktx;
						for (var i = 0; i < sRowCount; i++) {
							var oZentryType = that.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
							if (oZentryType === "N" || oZentryType === "") {
								that.getView().byId("idInternal").getRows()[i].getCells()[2].setValue("");
								that.getView().byId("idInternal").getRows()[i].getCells()[3].setValue("");
								that.getView().byId("idInternal").getRows()[i].getCells()[4].setValue("");
								that.getView().byId("idInternal").getRows()[i].getCells()[5].setValue("");
								// this.getView().byId("idInternal").getRows()[i].getCells()[6].setValue("");
								// this.getView().byId("idInternal").getRows()[i].getCells()[7].setValue("");
								// this.getView().byId("idInternal").getRows()[i].getCells()[8].setValue("");
								that.getView().byId("idInternal").getRows()[i].getCells()[10].setValue("");
								that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Matnr", oMatnr);
								that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Maktx", oMaktx.substring(0, 40));
							}
						}
						//return data;

					},

					error: function (oError) {}
				});
			}
		},

		onCompanyCodeSelect: function (oEvent) {
			var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
			var sComCode = oEvent.getParameter("selectedItem").getKey();
			if (sSystem === "C1") {
				this.getView().byId("idUSD").setValue("USD");
				this.getView().byId("idComFormInt").setValue(sComCode);
				this.getView().byId("idUSDInt").setValue("USD");
				// Filtering Project type on basis of company code select
				this.getView().byId("idProjTyp").setEnabled(true);
			} else {
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Are you sure you want to switch the app ?"
					}),
					beginButton: new sap.m.Button({
						text: "Ok",
						press: function () {
							sap.ushell.Container
								.getService("CrossApplicationNavigation")
								.toExternal({
									target: {
										semanticObject: "DXCGPRS",
										action: "create"
									},
									params: {
										"ComCode": sComCode
									}
								});
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							dialog.close();
							MessageToast.show("Please select C1 related Company code!!!");
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			}
			var sRowCount = this.getView().byId("idInternal").getBinding("rows").getLength();
			if (sComCode) {
				for (var i = 0; i < sRowCount; i++) {
					this.getView().byId("idInternal").getRows()[i].getCells()[2].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[3].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[4].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[5].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[6].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[7].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[8].setValue("");
					this.getView().byId("idInternal").getRows()[i].getCells()[10].setValue("");
				}
			}
		},

		systemDate: function (oEvent) {
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			this.byId("dateSys").setMinDate(new Date(Year, month, day));
		},

		onInputValidationStrDate: function (oEvent) {
			var oSrc = oEvent.getSource();
			if (oSrc.getValue() === "") {
				oSrc.setValueState("Error");
				oSrc.setValueStateText("Please enter the value."); // Add record button disable
			} else {
				oSrc.setValueState("None");
			}
			this.aVbegdat = "";
			this.aVenddat = "";
		},

		onInputValidationStrDateInt: function (oEvent) {
			var oSrc = oEvent.getSource();
			if (oSrc.getValue() === "") {
				oSrc.setValueState("Error");
				oSrc.setValueStateText("Please enter the value."); // Add record button disable
			} else {
				oSrc.setValueState("None");
			}
			this.aVbegdat = "";
			this.aVenddat = "";
		},

		onInputValidation: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var oSrc = oEvent.getSource();
			if (newValue === "") {
				oSrc.setValueState("Error");
				oSrc.setValueStateText("Please enter the value."); // Add record button disable
			} else {
				oSrc.setValueState("None");
			}
		},

		onFilterSelect: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sKey = oEvent.getParameter("key");
			var sprojType = this.getView().byId("idProjTyp").getSelectedKey();
			var osTyp = this.getView().byId("idSubTyp").getSelectedKey();
			/*======Tab 1 mandatory field!!!======*/

			var CoCoT1 = this.getView().byId("comCode").getValue();
			var ProjTyT1 = this.getView().byId("idProjTyp").getValue();
			var Comment = this.getView().byId("TypeHere").getValue();

			/*======Tab 2 mandatory field!!!======*/
			var SoldTo = this.getView().byId("idSoldTo").getValue();
			// var Payer = this.getView().byId("idPayer").getValue();
			// var BillTo = this.getView().byId("idbill").getValue();
			// var ShipTo = this.getView().byId("idship").getValue();
			var ProjDes = this.getView().byId("idProjDes").getValue();
			var SingId = this.getView().byId("idSign").getValue();
			var Curr = this.getView().byId("idUSD").getValue();
			var Payment = this.getView().byId("idPaymt").getValue();
			var Invoice = this.getView().byId("idInvLay").getValue();
			var BillCal = this.getView().byId("idBillCal").getValue();
			var sDateT2 = this.getView().byId("dateCtrlStr").getDateValue();
			var eDateT2 = this.getView().byId("dateCtrlEnd").getDateValue();
			var AccGen = this.getView().byId("idAccMan").getValue();
			var Wbs1 = this.getView().byId("idWBS1").getValue();
			var WBS2 = this.getView().byId("idWBS2").getValue();
			var DraftInv = this.getView().byId("idDrftInv").getValue();
			var Finace = this.getView().byId("idFinApp").getValue();

			// Internal Form Field
			var SoldtoInt = this.getView().byId("idIntSold").getValue();
			var ProjDesInt = this.getView().byId("idProIntDs").getValue();
			var ComCodeInt = this.getView().byId("idComFormInt").getValue();
			var SDateInt = this.getView().byId("idStarInt").getDateValue();
			var EDateInt = this.getView().byId("idEndInt").getDateValue();
			var CurrInt = this.getView().byId("idUSDInt").getValue();
			var WBSInt1 = this.getView().byId("idWBS1Int").getValue();
			var WBSInt2 = this.getView().byId("idWBS2Int").getValue();
			var DraftInvInt = this.getView().byId("idDr").getValue();
			var FinAppInt = this.getView().byId("idFinAppInt").getValue();
			var ProjAccInt = this.getView().byId("idProAcInt").getValue();

			if (sKey === "2") {
				if (sprojType === "ZPRJ") {
					var oTable = this.getView().byId("idInternal");
					var oModel1 = oTable.getModel("localModel");
					var oRows = oModel1.getData().iwoTabTravel.length;
					if (oRows === 0) {
						this.onCreateIwoTravel();
					}
				} else {
					var oTable = this.getView().byId("idTravel");
					var oModel1 = oTable.getModel("localModel");
					var oRows = oModel1.getData().iwoTabTravel.length;
					var currRow = oTable.getVisibleRowCount();
					//PO Date
					if (oRows === 0) {
						this.onCreateIwoTravel();
						// Code for  scenario2 
						// var oOppC1type = oViewModel.getData().type;
						// if (oOppC1type === "OpprAppC1") {
						// 	var oSafeCaseModel = this.getView().getModel("oCaseSafeModel").oData.results;
						// 	var oTbale = this.getView().getModel("localModel").getProperty("/iwoTabTravel");
						// 	// this.getView().getModel("localModel").setProperty( 0 + "/oCaseSafeModel", oJon );
						// 	// var contextid = "/iwoTabTravel/" + 0.toString();
						// 	for (var m = 0; m < oTbale.length; m++) {
						// 		var contextid = "/iwoTabTravel/" + m.toString();
						// 		this.getView().getModel("localModel").setProperty(contextid + "/oCaseSafeModel", oSafeCaseModel);

						// 	}

						// }
					}
				}

				if (CoCoT1 && ProjTyT1 && Comment) {
					var aBMTFiltersI = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, CoCoT1),
							new sap.ui.model.Filter("ProjType", sap.ui.model.FilterOperator.EQ, sprojType),
							new sap.ui.model.Filter("SubType", sap.ui.model.FilterOperator.EQ, osTyp)
						],
						and: true
					});
					var aBMTFiltersR = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, CoCoT1),
							new sap.ui.model.Filter("ProjType", sap.ui.model.FilterOperator.EQ, sprojType)
						],
						and: true
					});
					var that = this;
					if (!AppType) {
						var oModel = this.getView().getModel("oDataModel");
						if (sprojType === "ZPRJ") {
							oModel.read("/SearchBMTPartnerSet", {
								filters: [aBMTFiltersI],
								success: function (oData) {
									var aArrayLengthI = oData.results.length;
									if (aArrayLengthI > 0) {
										var pernr = oData.results[0].Pernr;
										var fName = oData.results[0].Vorna;
										var lName = oData.results[0].Nachn;
										var prjAcc = fName + "," + lName + " (" + pernr + ")";
										that.getView().byId("idProAcInt").setValue(prjAcc);
										if (sRowCount === 1) {
											that.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[0].PrjAc = prjAcc;
										}
									}
								}
							});
						}
						if (sprojType === "ZBC" || sprojType === "ZCGC") {
							var sRowCount = that.getView().byId("idTravel").getBinding("rows").getLength();
							oModel.read("/SearchBMTPartnerSet", {
								filters: [aBMTFiltersR],
								success: function (oData) {
									var aArrayLengthA = oData.results.length;
									if (aArrayLengthA > 0) {
										var pernr = oData.results[0].Pernr;
										var fName = oData.results[0].Vorna;
										var lName = oData.results[0].Nachn;
										var prjAcc = fName + "," + lName + " (" + pernr + ")";
										that.getView().byId("idProAc").setValue(prjAcc);
										if (sRowCount === 1) {
											that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].PrjAc = prjAcc;
										}
									}
								}
							});
							oModel.read("/SearchBDSSet", {
								filters: [aBMTFiltersR],
								success: function (oData) {
									var aArrayLengthA = oData.results.length;
									if (aArrayLengthA > 0) {
										var pernr = oData.results[0].Pernr;
										var fName = oData.results[0].Vorna;
										var lName = oData.results[0].Nachn;
										var sbds = fName + "," + lName + " (" + pernr + ")";
										that.getView().byId("idBillStw").setValue(sbds);
										if (sRowCount === 1) {
											that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].Bds = sbds;
										}
									}
								}
							});
							// oModel.read("/SearchInvRecSet", {
							// 	filters: [aBMTFiltersR],
							// 	success: function (oData) {
							// 		var aArrayLengthA = oData.results.length;
							// 		if (aArrayLengthA > 0) {
							// 			var pernr = oData.results[0].Pernr;
							// 			var fName = oData.results[0].Vorna;
							// 			var lName = oData.results[0].Nachn;
							// 			var invrec = fName + "," + lName + " (" + pernr + ")";
							// 			that.getView().byId("idInv").setValue(invrec);
							// 			if (sRowCount === 1) {
							// 				that.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].InvRec = invrec;
							// 			}
							// 		}
							// 	}
							// });
							oModel = null;

						}
					}
					this.getView().getModel().getData().HeaderData.TabIconNo = 2;
				} else {
					this.getView().byId("idIconTabBar").setSelectedKey("1");
					if (AppType === "ChangeProject") {
						MessageToast.show("Mandatory header fields are missing, please contact AmProjActngCSS@dxc.com team for resolution");
					} else {
						MessageToast.show("Please fill the all mandatory fields");
					}
				}

			} else if (sKey === "3") {
				sap.ui.core.BusyIndicator.show(0);
				if (AppType !== "CSIReview" && AppType !== "BILLReview" && AppType !== "View") {
					this.getView().byId("SubBtn").setEnabled(true);
				}

				if (CoCoT1 && ProjTyT1 && SoldTo && ProjDes && Curr && Payment && Invoice && sDateT2 &&
					eDateT2 && AccGen && Wbs1 && WBS2 && DraftInv && Finace && Finace && BillCal) {
					this.getView().getModel().getData().HeaderData.TabIconNo = 3;
				} else if (sprojType === "ZPRJ") {
					if (AppType !== "CSIReview" && AppType !== "BILLReview" && AppType !== "View") {
						this.getView().byId("SubBtn").setEnabled(true);
					}
					var aRows = this.getView().byId("idInternal").getBinding("rows").getLength();

					//var data = this._fnSetInternalMaterial(osTyp);//ratna added 3
					var sType = this.getView().byId("idSubTyp").getSelectedKey();
					var oViewModel = this.getView().getModel("appView");
					var osystemid = oViewModel.getData().System;
					var Sysid = osystemid.split("(")[1].split(")")[0];
					this.getView().getModel("appView").refresh(true);
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Sysid", sap.ui.model.FilterOperator.EQ, Sysid),
							new sap.ui.model.Filter("Subtyp", sap.ui.model.FilterOperator.EQ, sType)
						],
						and: true
					});
					var oModel = this.getView().getModel("oDataModel");
					var that = this;
					oModel.read("/SearchIntMatSet", {
						filters: [aFilters],
						urlParameters: {
							"$top": 100
						},
						success: function (oResponse) {
							var oMaterial = oResponse.results[0].Material;
							var oMaterialDes = oResponse.results[0].Descripton;
							var data = {
								oMatnr: oMaterial,
								oMaktx: oMaterialDes
							};
							var oMatnr = data.oMatnr;
							var oMaktx = data.oMaktx;
							var oViewModel = that.getView().getModel("appView");
							var AppType = oViewModel.getData().oAppType;
							for (var i = 0; i < aRows; i++) {
								var oZentryType = that.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
								if (oZentryType === "N" || oZentryType === "") {
									that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Matnr", oMatnr);
									that.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Maktx", oMaktx.substring(0, 40));
								}
							}
							if (SoldtoInt && ProjDesInt && ComCodeInt && CurrInt && SDateInt && EDateInt && WBSInt1 &&
								WBSInt2 && FinAppInt && ProjAccInt) {
								that.getView().getModel().getData().HeaderData.TabIconNo = 3;
							} else {
								if (CoCoT1 && ProjTyT1) {
									that.getView().byId("idIconTabBar").setSelectedKey("2");
								} else {
									that.getView().byId("idIconTabBar").setSelectedKey("1");
								}
								if (AppType === "ChangeProject") {
									MessageToast.show("Mandatory header fields are missing, please contact AmProjActngCSS@dxc.com team for resolution");
								} else {
									MessageToast.show("Please fill the all mandatory fields");
								}
							}

							//return data;

						},

						error: function (oError) {}
					});
					sap.ui.core.BusyIndicator.hide();
					return;
					//below
				} else {
					if (CoCoT1 && ProjTyT1) {
						this.getView().byId("idIconTabBar").setSelectedKey("2");
					} else {
						this.getView().byId("idIconTabBar").setSelectedKey("1");
					}
					if (AppType === "ChangeProject") {
						MessageToast.show("Mandatory header fields are missing, please contact AmProjActngCSS@dxc.com team for resolution");
					} else {
						MessageToast.show("Please fill the all mandatory fields");
					}
				}
				var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
				// if (sPrjTyp === "ZCGC" && AppType === "ChangeProject") {
				if (sPrjTyp === "ZCGC") {
					this.getView().byId("Headerlabor").setEnabled(false);
				} else {
					this.getView().byId("Headerlabor").setEnabled(true);
				}

				var sCasId = this.getView().byId("idSign").getValue();

				var sSign = this.getView().byId("ch2").getSelected();
				var sREason = this.getView().byId("idReason").getRequired();
				var sValue = this.getView().byId("idReason").getValue();

				if (!sCasId && sSign === false) {
					this.getView().byId("idIconTabBar").setSelectedKey("2");
					MessageToast.show("Please fill the all mandatory fields");
					this.getView().byId("idSign").setValueState("Error");
				} else {
					this.getView().byId("idSign").setValueState("None");
				}
				if (sREason === true && !sValue) {
					this.getView().byId("idIconTabBar").setSelectedKey("2");
					MessageToast.show("Please fill the all mandatory fields");
					this.getView().byId("idReason").setValueState("Error");
				} else {
					this.getView().byId("idReason").setValueState("None");
				}
				var sRowCount = this.getView().byId("idTravel").getBinding("rows").getLength();
				var oPoHeader = this.getView().byId("dateCtrlPo").getDateValue();
				// var oPonumber1 = this.getView().byId("idpo").getValue();

				//for (var i = 0; i < sRowCount; i++) {

				if (AppType === "" && this.gPodate === "PD") {
					this.gPodate = "";
					this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].Bstnk = this.getView().byId("idpo").getValue();
					if (!oPoHeader) {
						this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].Bstdk = null;
					} else {
						var sBstdk = this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].Bstdk;
						this.getView().byId("idTravel").getModel("localModel").getData().iwoTabTravel[0].Bstdk = this.dateFormatter(sBstdk);
					}
				}
		
				// for (var i = 0; i < sRowCount; i++) {
				// 	this.getView().getModel("localModel").setProperty("/iwoTabTravel/" + i + "/Zterm", this.getView().byId("idPaymt").getValue());
				// }
			}
			this.getView().getModel("appView").setProperty("/count", this.getView().getModel("localModel").getProperty("/iwoTabTravel").length);
			sap.ui.core.BusyIndicator.hide();
		},
		// Validation
		onWbsValidation: function () {
			sap.ui.core.BusyIndicator.show(0);
			// var sType = this.getView().byId("idProjTyp");
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRevenueForm = this.getView().byId("SimpleFormChangewbs").getVisible();
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();

			var sRevenueTable = this.getView().byId("idTravel").getVisible();
			var sInternalTable = this.getView().byId("idInternal").getVisible();

			if (sRevenueForm === true) {
				var allMandt = this.onValidation();
				if (allMandt) {
					if (sRevenueTable === true) {
						var sRec = this.getView().byId("idTravel").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onValidBtnPress();
						} else {
							var draftData = this.onGetData("VALIDATE");
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									sap.ui.core.BusyIndicator.hide();
									// sap.m.MessageToast.show("WBS request Validated Successfully.", {
									// 	duration: 5000
									// });

									var sErrorLog = oResponse.WBSErrorSet.results.length;
									if (sErrorLog === 0) {
										sap.m.MessageToast.show("WBS request Validated Successfully.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(false);
										// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
										var oViewModel = that.getView().getModel("appView");
										that.getView().getModel().getData().errorResults = [];
										oViewModel.getData().ReqID = oResponse.ReqNo;
									} else {
										sap.ui.core.BusyIndicator.hide();
										sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(true);
										that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;

										var wbsElement = that.getView().getModel("localModel").getProperty("/iwoTabTravel");
										// var oTable1 = this.getView().byId("idTable");
										for (var i = 0; i < wbsElement.length; i++) {
											var oWbsIcon = oResponse.WBSErrorSet.results.filter(function (a) {
												return Number(a.MsgN0) === Number(wbsElement[i].Posnr);
											});
											if (oWbsIcon.length > 0) {
												wbsElement[i].IconColor = "E"; // for phase2 table  Adding color  dynamically 
											} else {
												wbsElement[i].IconColor = "S"; // for phase2 table  Adding color  dynamically 	
											}
										}
										var oLocalModel = that.getView().getModel("localModel");
										oLocalModel.refresh(true);
									}
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					} else if (sInternalTable === true) {
						var sRec = this.getView().byId("idInternal").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onValidBtnPress();
						} else {
							var draftData = this.onGetData("VALIDATE");
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									sap.ui.core.BusyIndicator.hide();
									var sErrorLog = oResponse.WBSErrorSet.results.length;
									if (sErrorLog === 0) {
										sap.m.MessageToast.show("WBS request Validated Successfully.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(false);
										// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
										var oViewModel = that.getView().getModel("appView");
										that.getView().getModel().getData().errorResults = [];
										oViewModel.getData().ReqID = oResponse.ReqNo;
									} else {
										sap.ui.core.BusyIndicator.hide();
										sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(true);
										that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;
									}
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					}

				} else {
					sap.ui.core.BusyIndicator.hide();
					if (AppType === "ChangeProject") {
						MessageToast.show("Mandatory header fields are missing, please contact AmProjActngCSS@dxc.com team for resolution");
					} else {
						MessageToast.show("Please fill all the required fields!!!");
					}
				}
			} else if (sInternalForm === true) {
				var allMandtInternal = this.onValidationInternal();
				if (allMandtInternal) {

					if (sRevenueTable === true) {
						var sRec = this.getView().byId("idTravel").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onValidBtnPress();
						} else {
							var draftData = this.onGetData("VALIDATE");
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									sap.ui.core.BusyIndicator.hide();
									// sap.m.MessageToast.show("WBS request Validated Successfully.", {
									// 	duration: 5000
									// });

									// var sValue = oResponse.ReqNo;
									// var aFilters = new sap.ui.model.Filter({
									// 	filters: [
									// 		new sap.ui.model.Filter("ReqNo", sap.ui.model.FilterOperator.Contains, sValue)
									// 	],
									// 	and: false
									// });

									// oModel.read("/WBSErrorSet", {
									// 	// filters: [aFilters],
									// 	// urlParameters: {
									// 	// 	"$top": 100
									// 	// },
									// 	success: function (oData, oResponse) {
									// 		var sError = oData.results.length;
									// 		if (sError === 0) {
									// 			sap.m.MessageToast.show("WBS request Validated Successfully.", {
									// 				duration: 5000
									// 			});
									// 			that.getView().byId("messBtn").setVisible(false);
									// 			// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
									// 			var oViewModel = that.getView().getModel("appView");
									// 			oViewModel.getData().ReqID = oResponse.ReqNo;
									// 		} else {
									// 			sap.ui.core.BusyIndicator.hide();
									// 			sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
									// 				duration: 5000
									// 			});
									// 			that.getView().byId("messBtn").setVisible(true);
									// 			that.getView().getModel().getData().errorResults = oResponse.results;
									// 			var oViewModel = that.getView().getModel("appView");
									// 			oViewModel.getData().ReqID = oResponse.ReqNo;
									// 		}
									// 	},
									// 	error: function (oError) {}
									// });

									var sErrorLog = oResponse.WBSErrorSet.results.length;
									if (sErrorLog === 0) {
										sap.m.MessageToast.show("WBS request Validated Successfully.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(false);
										// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;
									} else {
										sap.ui.core.BusyIndicator.hide();
										sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(true);
										that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;
									}
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					} else if (sInternalTable === true) {
						var sRec = this.getView().byId("idInternal").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onValidBtnPress();
						} else {
							var draftData = this.onGetData("VALIDATE");
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									sap.ui.core.BusyIndicator.hide();

									// var sValue = oResponse.ReqNo;
									// var aFilters = new sap.ui.model.Filter({
									// 	filters: [
									// 		new sap.ui.model.Filter("ReqNo", sap.ui.model.FilterOperator.Contains, sValue)
									// 	],
									// 	and: false
									// });

									// oModel.read("/WBSErrorSet", {
									// 	// filters: [aFilters],
									// 	// urlParameters: {
									// 	// 	"$top": 100
									// 	// },
									// 	success: function (oData, oResponse) {
									// 		var sError = oData.results.length;
									// 		if (sError === 0) {
									// 			sap.m.MessageToast.show("WBS request Validated Successfully.", {
									// 				duration: 5000
									// 			});
									// 			that.getView().byId("messBtn").setVisible(false);
									// 			// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
									// 			var oViewModel = that.getView().getModel("appView");
									// 			oViewModel.getData().ReqID = oResponse.ReqNo;
									// 		} else {
									// 			sap.ui.core.BusyIndicator.hide();
									// 			sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
									// 				duration: 5000
									// 			});
									// 			that.getView().byId("messBtn").setVisible(true);
									// 			that.getView().getModel().getData().errorResults = oResponse.results;
									// 			var oViewModel = that.getView().getModel("appView");
									// 			oViewModel.getData().ReqID = oResponse.ReqNo;
									// 		}
									// 	},
									// 	error: function (oError) {}
									// });

									var sErrorLog = oResponse.WBSErrorSet.results.length;
									if (sErrorLog === 0) {
										sap.m.MessageToast.show("WBS request Validated Successfully.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(false);
										// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;
									} else {
										sap.ui.core.BusyIndicator.hide();
										sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(true);
										that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;
									}
								},
								error: function (oError, oResponse) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					}

				} else {
					sap.ui.core.BusyIndicator.hide();
					if (AppType === "ChangeProject") {
						MessageToast.show("Mandatory header fields are missing, please contact AmProjActngCSS@dxc.com team for resolution");
					} else {
						MessageToast.show("Please fill all the required fields!!!");
					}
				}
			}

		},
		// _fnSetInternalMaterial: function (sType) {

		// 	var oViewModel = this.getView().getModel("appView");
		// 	var osystemid = oViewModel.getData().System;
		// 	var Sysid = osystemid.split("(")[1].split(")")[0];
		// 	this.getView().getModel("appView").refresh(true);
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Sysid", sap.ui.model.FilterOperator.EQ, Sysid),
		// 			new sap.ui.model.Filter("Subtyp", sap.ui.model.FilterOperator.EQ, sType)
		// 		],
		// 		and: true
		// 	});
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	var that = this;
		// 	oModel.read("/SearchIntMatSet", {
		// 		filters: [aFilters],
		// 		urlParameters: {
		// 			"$top": 100
		// 		},
		// 		success: function (oResponse) {
		// 			var oMaterial = oResponse.results[0].Material;
		// 			var oMaterialDes = oResponse.results[0].Descripton;
		// 			var data = {
		// 				oMatnr: oMaterial,
		// 				oMaktx: oMaterialDes
		// 			};
		// 			return data;

		// 		},

		// 		error: function (oError) {}
		// 	});

		// },

		onWbsSubmit: function () {
			this.getView().byId("app").setBusyIndicatorDelay(0);
			this.getView().getModel("appView").setProperty("/isBusy", true);
			var sRevenueForm = this.getView().byId("SimpleFormChangewbs").getVisible();
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();

			var sRevenueTable = this.getView().byId("idTravel").getVisible();
			var sInternalTable = this.getView().byId("idInternal").getVisible();
			var oViewModel = this.getView().getModel("appView");

			if (sRevenueForm === true) {
				var allMandt = this.onValidation();
				if (allMandt) {
					if (sRevenueTable === true) {
						var sRec = this.getView().byId("idTravel").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onSubmitBtnPress();
						} else {

							var draftData = this.onGetData("SUBMIT", oViewModel.getData().Requestid);
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									var sErrorLog = oResponse.WBSErrorSet.results.length;
									if (sErrorLog === 0) {
										sap.m.MessageToast.show("WBS request Validated Successfully.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(false);
										oViewModel.getData().ReqID = oResponse.ReqNo;
									} else {
										sap.ui.core.BusyIndicator.hide();
										sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
											duration: 5000
										});
										that.getView().byId("messBtn").setVisible(true);
										that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
										var oViewModel = that.getView().getModel("appView");
										oViewModel.getData().ReqID = oResponse.ReqNo;
									}
								},
								error: function (oError, oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					} else if (sInternalTable === true) {
						var sRec = this.getView().byId("idInternal").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onSubmitBtnPress();
						} else {
							var draftData = this.onGetData("SUBMIT", oViewModel.getData().Requestid);
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("WBS request Submitted Successfully.", {
										duration: 5000
									});
								},
								error: function (oError, oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});
								}
							});
						}
					}

				} else {
					that.getView().getModel("appView").setProperty("/isBusy", false);
					MessageToast.show("Please fill all the required fields!!!");
				}
			} else if (sInternalForm === true) {
				var allMandtInternal = this.onValidationInternal();
				if (allMandtInternal) {
					if (sRevenueTable === true) {
						var sRec = this.getView().byId("idTravel").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onSubmitBtnPress();
						} else {
							var draftData = this.onGetData("SUBMIT", oViewModel.getData().Requestid);
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("WBS request Subitted Successfully.", {
										duration: 5000
									});
								},
								error: function (oError, oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					} else if (sInternalTable === true) {
						var sRec = this.getView().byId("idInternal").getBinding("rows").getLength();
						if (sRec >= 1) {
							this.onSubmitBtnPress();
						} else {
							var draftData = this.onGetData("SUBMIT", oViewModel.getData().Requestid);
							var oModel = this.getView().getModel("oDataModel");
							var that = this;
							oModel.create("/WBSRequestHeaderSet", draftData, {
								success: function (oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("WBS request Submitted Successfully.", {
										duration: 5000
									});
								},
								error: function (oError, oResponse) {
									that.getView().getModel("appView").setProperty("/isBusy", false);
									sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
										duration: 5000
									});

								}
							});
						}
					}

				} else {
					that.getView().getModel("appView").setProperty("/isBusy", false);
					MessageToast.show("Please fill all the required fields!!!");
				}
			}

		},
		onValidation: function (oEvent) {
			var requiredInputs = this.ListOfRequiredFields();
			var passedValidation = this.validateEventFeedbackForm(requiredInputs);
			// var requiredInputsInt = this.ListOfRequiredFieldsInt();
			// var passedValidationInt = this.validateEventFeedbackFormInt(requiredInputsInt);
			if (passedValidation === false) {
				//show an error message, rest of code will not execute.
				return false;
			} else if (passedValidation === true) {
				//show an error message, rest of code will not execute.
				return true;
			}
		},

		onValidationInternal: function (oEvent) {
			var requiredInputs = this.ListOfRequiredFieldsInternal();
			var passedValidation = this.validateEventFeedbackForm(requiredInputs);
			if (passedValidation === false) {
				//show an error message, rest of code will not execute.
				return false;
			} else if (passedValidation === true) {
				//show an error message, rest of code will not execute.
				return true;
			}
		},

		ListOfRequiredFields: function () {
			return ['comCode', 'idProjTyp', 'TypeHere', 'idSoldTo', 'idPayer', 'idship', 'idbill', 'idProjDes', 'idPaymt',
				'idInvLay', 'idBillCal', 'dateCtrlStr', 'dateCtrlEnd', 'idAccMan', 'idWBS1', 'idWBS2', 'idDrftInv', 'idFinApp'
			];
		},
		ListOfRequiredFieldsInternal: function () {
			return ['idIntSold', 'idProIntDs', 'idUSDInt', 'idStarInt', 'idEndInt',
				'idWBS1Int', 'idWBS2Int', 'idFinAppInt', 'idProAcInt'
			];
		},
		validateEventFeedbackForm: function (requiredInputs) {
			var _self = this;
			var valid = true;
			requiredInputs.forEach(function (input) {
				var sInput = _self.getView().byId(input);
				//||sInput.getValue() == undefined
				if (sInput.getValue() == "") {
					valid = false;
					sInput.setValueState("Error");
				} else {
					sInput.setValueState("None");
				}
			});
			return valid;
		},

		TypeNumber: function (oEvent) {
			var value = oEvent.getSource().getValue();
			var bNotnumber = isNaN(value);
			if (bNotnumber === true) {
				oEvent.getSource().setValue(value.substring(0, value.length - 1));
			}
		},
		// ******************************* WBS METHOD FOR WBS DETAILSSachin *************************************

		onItemLaborPress: function (oEvent) {
			var that = this;
			var oModel = that.getView().getModel("localModel");
			// var oContext = oEvent.getSource().getBindingContext();
			this.sItemPath = this.oItemContext.getPath().split("/")[2];
			var oView = this.getView();
			if (!this._oItemLabor) {
				this._oItemLabor = sap.ui.xmlfragment(that.createId("idItemLaborType"), "WBS.C1.WbsC1Request.fragments.ItemLaborType", that);
				oView.addDependent(this._oItemLabor);
			}
			var aData = this.oItemContext.getObject().labor ? this.oItemContext.getObject().labor : [];
			for (var i = 0; i < aData.length; i++) {
				aData[i].Datab = this.dateFormatter(aData[i].Datab);
				aData[i].Datbi = this.dateFormatter(aData[i].Datbi);
			}
			var oItemFragmodel = new JSONModel(this.oItemContext.getObject());
			this._oItemLabor.setModel(oItemFragmodel, "itemFragmodel");
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			that.getView().getModel("appView").refresh(true);

			if (AppType) {
				var oPosnr = this.oItemContext.getObject().Posnr;
				var wbsElement = this.getView().getModel().getProperty("/itemLaborData");
				var oData = wbsElement.filter(function (a) {
					return a.Posnr === oPosnr;
				});
				var sItemLabCount = oData.length;
				var sItemLabourSeqNum = 1;
				for (var i = 0; i < sItemLabCount; i++) {
					oData[i].SqNum = String(sItemLabourSeqNum);
					sItemLabourSeqNum = sItemLabourSeqNum + 1;
				}

				var addPlusRow = {
					Seqno: "",
					Kschl: "",
					Zmatnr: "",
					Datab: "",
					Datbi: ""

				};
				for (var i = 0; i < this._oItemLabor.getModel().getData().labor.length; i++) {
					if (!this._oItemLabor.getModel().getData().labor[i].Posnr) {
						addPlusRow.Datab = this._oItemLabor.getModel().getData().labor[i].Datab;
						addPlusRow.Datbi = this._oItemLabor.getModel().getData().labor[i].Datbi;
						addPlusRow.Kschl = this._oItemLabor.getModel().getData().labor[i].Kschl;
						addPlusRow.Zmatnr = this._oItemLabor.getModel().getData().labor[i].Zmatnr;
						oData.push(addPlusRow);

					}
				}

				var itemRow = oModel.getProperty("/iwoTabTravel");
				if (itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor === undefined) {
					itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor = oData;
				}
				oModel.setProperty("/iwoTabTravel", itemRow);
				var oItemFragmodel = new JSONModel(this.oItemContext.getObject());
				this._oItemLabor.setModel(oItemFragmodel, "itemFragmodel");
			}
			if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View" || AppType === "BILLRej") {
				oViewModel.getData().FrasDis = "oDisplay";
				oViewModel.getData().FrasBtn = "oDisplay";
				oViewModel.getData().FrasDateDis = "oDateDisplay";
				for (var i = 0; i < this.getView().getModel().getData().itemLaborData.length; i++) {
					if (oPosnr === this.getView().getModel().getData().itemLaborData.oPosnr) {
						sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborTable").getItems()[i].getCells()[3].setEditable(false);
						sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborTable").getItems()[i].getCells()[4].setEditable(false);
						sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborTable").getItems()[i].getCells()[5].setEditable(false);
					}

				}
				that.getView().getModel("appView").refresh(true);
			}
			this._oItemLabor.open();
		},

		onItemLaborCancel: function () {
			//var oitemData = this._oItemLabor.getModel("itemFragmodel").getData().labor;
			//var oIndxTable = this.oItemContext.getPath().split("/")[2];
			// if (oitemData !== undefined && oitemData !== null && oitemData.length !== 0) {
			// 	var oitemLaborlength = oitemData.length;
			// 	if (oitemLaborlength > 0) {
			// 		this.getView().getModel("localModel").getData().iwoTabTravel[oIndxTable].laborFlg = "ItemLabour Present ,";
			// 	}
			// } else {
			// 	this.getView().getModel("localModel").getData().iwoTabTravel[oIndxTable].laborFlg = "";
			// }
			this.getView().getModel("localModel").refresh(true);
			this._oItemLabor.close();
		},

		onTaskPress: function (oEvent) {
			var that = this;
			var oModel = that.getView().getModel("localModel");
			// this.sTaskPath = this.oItemContext.getPath();
			var oView = this.getView();
			var addPlusRow = {
				SqNum: "",
				Task: "",
				Tasktext: "",
				Begda: "",
				Endda: "",
				Pspri: "",
				oCount: 0
			};
			if (!this._oTaskLabor) {
				this._oTaskLabor = sap.ui.xmlfragment(that.createId("idTask"), "WBS.C1.WbsC1Request.fragments.Task", that);
				oView.addDependent(this._oTaskLabor);
			}

			sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskStatus").setSelectedKey("All");

			var aData = this.oItemContext.getObject().task ? this.oItemContext.getObject().task : [];
			for (var i = 0; i < aData.length; i++) {
				aData[i].Begda = this.dateFormatter(aData[i].Begda);
				aData[i].Endda = this.dateFormatter(aData[i].Endda);
			}

			var oTaskFragmodel = new JSONModel();
			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
			this._oTaskLabor.getModel("taskFragmodel").setProperty("/task", aData);
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && this.oHeaderType === true)) {
				oViewModel.getData().TaskScenario = "oDisplay";
			}
			that.getView().getModel("appView").refresh(true);
			if (AppType && AppType !== "ChangeProject") {
				var sRevenueTable = this.getView().byId("idTravel").getVisible();
				var sInternalTable = this.getView().byId("idInternal").getVisible();

				if (sRevenueTable === true) {
					var oPosnr = this.oItemContext.getObject().Posnr;

					var wbsElement = this.getView().getModel().getProperty("/taskData");
					var oData = wbsElement.filter(function (a) {
						return a.Posnr === oPosnr;
					});

					var sTaskCount = oData.length;
					var sTaskSeqNum = 1;
					for (var i = 0; i < sTaskCount; i++) {
						oData[i].SqNum = String(sTaskSeqNum);
						sTaskSeqNum = sTaskSeqNum + 1;
					}
					if (this.oItemContext.getObject().task === undefined) {
						this.getView().getModel("localModel").setProperty(this.oItemContext.getPath() + "/task", oData);
					}
					for (var i = 0; i < this._oTaskLabor.getModel("taskFragmodel").getData().task.length; i++) {

						//this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Posnr
						if (!this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Posnr) {
							addPlusRow.Task = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Task;
							addPlusRow.Tasktext = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Tasktext;
							addPlusRow.Begda = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Begda;
							addPlusRow.Endda = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Endda;
							addPlusRow.Pspri = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Pspri;
							oData.push(addPlusRow);
						}
					}

					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");

				} else if (sInternalTable === true) {

					var oTable = this.getView().byId("idInternal");
					var aContexts = oTable.getSelectedIndices();
					var oPosnr = this.getView().getModel("localModel").getProperty("/iwoTabTravel/" + aContexts[0] + "/Posnr");

					var wbsElement = this.getView().getModel().getProperty("/taskData");
					var oData = wbsElement.filter(function (a) {
						return a.Posnr === oPosnr;
					});

					var sTaskCount = oData.length;
					var sTaskSeqNum = 1;
					for (var i = 0; i < sTaskCount; i++) {
						oData[i].SqNum = String(sTaskSeqNum);
						sTaskSeqNum = sTaskSeqNum + 1;
					}
					for (var i = 0; i < this._oTaskLabor.getModel("taskFragmodel").getData().task.length; i++) {
						if (!this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Posnr) {
							addPlusRow.Datab = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Datab;
							addPlusRow.Datbi = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Datbi;
							addPlusRow.Kschl = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Kschl;
							addPlusRow.Zmatnr = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Zmatnr;
							oData.push(addPlusRow);

						}
					}

					var itemRow = oModel.getProperty("/iwoTabTravel");
					if (itemRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
						itemRow[this.getView().byId("idInternal").getSelectedIndex()].task = oData;
					}
					oModel.setProperty("/iwoTabTravel", itemRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");

				}

				if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View" || AppType === "BILLRej") {
					oViewModel.getData().FrasDis = "oDisplay";
					oViewModel.getData().FrasBtn = "oDisplay";
					that.getView().setModel(new JSONModel({}), "EnableDesableTask");
					// if (this.getView().getModel("localModel").getData().iwoTabTravel[0].task) {
					// 	//var oiwotravel = this.getView().getModel("localModel").getData().iwoTabTravel.length;
					// 	var otasklen = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;

					// 	// if(otasklen === 0){
					// 	// 	this._oTaskLabor.getModel("taskFragmodel").getData().task = [];

					// 	// }
					// 		for (var j = 0; j < otasklen; j++) {
					// 			if (oPosnr === this._oTaskLabor.getModel("taskFragmodel").getData().task[j].Posnr) {
					// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getRows()[j].getCells()[1].setEditable(false);
					// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getRows()[j].getCells()[2].setEditable(false);
					// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getRows()[j].getCells()[3].setEditable(false);
					// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getRows()[j].getCells()[4].setEditable(false);
					// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getRows()[j].getCells()[5].setEditable(false);
					// 			}
					// 		}

					// }

					//that.getView().getModel("appView").refresh(true);
				}
			}

			if (AppType === "ChangeProject") {
				var sRevenueTable = this.getView().byId("idTravel").getVisible();
				var sInternalTable = this.getView().byId("idInternal").getVisible();
				if (sRevenueTable === true) {
					var oPosnr = this.oItemContext.getObject().Posnr;
					var wbsElement = this.getView().getModel().getData().task;
					var oData = wbsElement.filter(function (a) {
						return a.Posnr === oPosnr;
					});
					var sTaskCount = oData.length;
					var sTaskSeqNum = 1;
					for (var i = 0; i < sTaskCount; i++) {
						oData[i].SqNum = String(sTaskSeqNum);
						sTaskSeqNum = sTaskSeqNum + 1;
					}
					for (var i = 0; i < this._oTaskLabor.getModel().getData().task.length; i++) {
						if (!this._oTaskLabor.getModel().getData().task[i].Posnr) {
							addPlusRow.Task = this._oTaskLabor.getModel().getData().task[i].Task;
							addPlusRow.Tasktext = this._oTaskLabor.getModel().getData().task[i].Tasktext;
							addPlusRow.Begda = this._oTaskLabor.getModel().getData().task[i].Begda;
							addPlusRow.Endda = this._oTaskLabor.getModel().getData().task[i].Endda;
							addPlusRow.Pspri = this._oTaskLabor.getModel().getData().task[i].Pspri;
							oData.push(addPlusRow);

						}
					}
					var itemRow = oModel.getProperty("/iwoTabTravel");
					if (itemRow[this.getView().byId("idTravel").getSelectedIndex()].task === undefined) {
						itemRow[this.getView().byId("idTravel").getSelectedIndex()].task = oData;
					}
					oModel.setProperty("/iwoTabTravel", itemRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");

				} else if (sInternalTable === true) {

					var oTable = this.getView().byId("idInternal");
					var aContexts = oTable.getSelectedIndices();

					//var oPosnr = oTable.getRows()[aContexts].getCells()[1].getValue();
					var oPosnr = this.oItemContext.getObject().Posnr;
					var wbsElement = this.getView().getModel().getData().task;
					var oData = wbsElement.filter(function (a) {
						return a.Posnr === oPosnr;
					});
					var sTaskCount = oData.length;
					var sTaskSeqNum = 1;
					for (var i = 0; i < sTaskCount; i++) {
						oData[i].SqNum = String(sTaskSeqNum);
						sTaskSeqNum = sTaskSeqNum + 1;
					}

					for (var i = 0; i < this._oTaskLabor.getModel().getData().task.length; i++) {
						if (!this._oTaskLabor.getModel().getData().task[i].Posnr) {
							addPlusRow.Task = this._oTaskLabor.getModel().getData().task[i].Task;
							addPlusRow.Tasktext = this._oTaskLabor.getModel().getData().task[i].Tasktext;
							addPlusRow.Begda = this._oTaskLabor.getModel().getData().task[i].Begda;
							addPlusRow.Endda = this._oTaskLabor.getModel().getData().task[i].Endda;
							addPlusRow.Pspri = this._oTaskLabor.getModel().getData().task[i].Pspri;
							oData.push(addPlusRow);
						}
					}
					var itemRow = oModel.getProperty("/iwoTabTravel");
					if (itemRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
						itemRow[this.getView().byId("idInternal").getSelectedIndex()].task = oData;
					}
					oModel.setProperty("/iwoTabTravel", itemRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
				}
			}

			if (this._oTaskLabor.getModel("taskFragmodel").getData().task.length === 0) {
				this._oTaskLabor.getModel("taskFragmodel").getData().task = [];
				var oTasklength = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;
			} else {
				var oTasklength = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;
			}
			//var oTasklength = this.oItemContext.getObject().task.length;

			this._oTaskLabor.getModel("taskFragmodel").setProperty("/oCount", oTasklength);
			sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").setVisibleRowCount(10);
			sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").rerender();
			this._oTaskLabor.open();
		},
		// onTaskPress: function (oEvent) {
		// 	var that = this;
		// 	var oModel = that.getView().getModel("localModel");
		// 	this.sTaskPath = this.oItemContext.getPath();
		// 	var oView = this.getView();
		// 	var addPlusRow = {
		// 		SqNum: "",
		// 		Task: "",
		// 		Tasktext: "",
		// 		Begda: "",
		// 		Endda: "",
		// 		Pspri: ""
		// 	};
		// 	if (!this._oTaskLabor) {
		// 		this._oTaskLabor = sap.ui.xmlfragment(that.createId("idTask"), "WBS.C1.WbsC1Request.fragments.Task", that);
		// 		oView.addDependent(this._oTaskLabor);
		// 	}
		// 	var aData = this.oItemContext.getObject().task ? this.oItemContext.getObject().task : [];
		// 	for (var i = 0; i < aData.length; i++) {
		// 		aData[i].Begda = this.dateFormatter(aData[i].Begda);
		// 		aData[i].Endda = this.dateFormatter(aData[i].Endda);
		// 	}

		// 	var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 	this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var AppType = oViewModel.getData().oAppType;
		// 	if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && this.oHeaderType === true)) {
		// 		oViewModel.getData().TaskScenario = "oDisplay";
		// 	}
		// 	that.getView().getModel("appView").refresh(true);
		// 	if (AppType && AppType !== "ChangeProject") {
		// 		var sRevenueTable = this.getView().byId("idTravel").getVisible();
		// 		var sInternalTable = this.getView().byId("idInternal").getVisible();
		// 		if (sRevenueTable === true) {
		// 			var oPosnr = this.oItemContext.getObject().Posnr;

		// 			var wbsElement = this.getView().getModel().getProperty("/taskData");
		// 			var oData = wbsElement.filter(function (a) {
		// 				return a.Posnr === oPosnr;
		// 			});

		// 			var sTaskCount = oData.length;
		// 			var sTaskSeqNum = 1;
		// 			for (var i = 0; i < sTaskCount; i++) {
		// 				oData[i].SqNum = String(sTaskSeqNum);
		// 				sTaskSeqNum = sTaskSeqNum + 1;
		// 			}
		// 			if (this.oItemContext.getObject().task === undefined) {
		// 				this.getView().getModel("localModel").setProperty(this.oItemContext.getPath() + "/task", oData);
		// 			}
		// 			for (var i = 0; i < this._oTaskLabor.getModel("taskFragmodel").getData().task.length; i++) {
		// 				if (!this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Posnr) {
		// 					addPlusRow.Task = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Task;
		// 					addPlusRow.Tasktext = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Tasktext;
		// 					addPlusRow.Begda = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Begda;
		// 					addPlusRow.Endda = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Endda;
		// 					addPlusRow.Pspri = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Pspri;
		// 					oData.push(addPlusRow);
		// 				}
		// 			}

		// 			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 		} else if (sInternalTable === true) {

		// 			var oTable = this.getView().byId("idInternal");
		// 			var aContexts = oTable.getSelectedIndices();
		// 			var oPosnr = this.getView().getModel("localModel").getProperty("/iwoTabTravel/" + aContexts[0] + "/Posnr");

		// 			var wbsElement = this.getView().getModel().getProperty("/taskData");
		// 			var oData = wbsElement.filter(function (a) {
		// 				return a.Posnr === oPosnr;
		// 			});

		// 			var sTaskCount = oData.length;
		// 			var sTaskSeqNum = 1;
		// 			for (var i = 0; i < sTaskCount; i++) {
		// 				oData[i].SqNum = String(sTaskSeqNum);
		// 				sTaskSeqNum = sTaskSeqNum + 1;
		// 			}
		// 			for (var i = 0; i < this._oTaskLabor.getModel("taskFragmodel").getData().task.length; i++) {
		// 				if (!this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Posnr) {
		// 					addPlusRow.Datab = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Datab;
		// 					addPlusRow.Datbi = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Datbi;
		// 					addPlusRow.Kschl = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Kschl;
		// 					addPlusRow.Zmatnr = this._oTaskLabor.getModel("taskFragmodel").getData().task[i].Zmatnr;
		// 					oData.push(addPlusRow);

		// 				}
		// 			}

		// 			var itemRow = oModel.getProperty("/iwoTabTravel");
		// 			if (itemRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
		// 				itemRow[this.getView().byId("idInternal").getSelectedIndex()].task = oData;
		// 			}
		// 			oModel.setProperty("/iwoTabTravel", itemRow);
		// 			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");

		// 		}

		// 		if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View" || AppType === "BILLRej") {
		// 			oViewModel.getData().FrasDis = "oDisplay";
		// 			oViewModel.getData().FrasBtn = "oDisplay";
		// 			if (this.getView().getModel("localModel").getData().task) {
		// 				for (var i = 0; i < this.getView().getModel("localModel").getData().task.length; i++) {
		// 					if (oPosnr === this.getView().getModel("localModel").getData().task[i].oPosnr) {
		// 						sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[1].setEditable(false);
		// 						sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].setEditable(false);
		// 						sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[3].setEditable(false);
		// 						sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[4].setEditable(false);
		// 						sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[5].setEditable(false);
		// 						sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[6].setEditable(false);
		// 					}
		// 				}
		// 			}

		// 			that.getView().getModel("appView").refresh(true);
		// 		}
		// 	}

		// 	if (AppType === "ChangeProject") {
		// 		var sRevenueTable = this.getView().byId("idTravel").getVisible();
		// 		var sInternalTable = this.getView().byId("idInternal").getVisible();
		// 		if (sRevenueTable === true) {
		// 			var oPosnr = this.oItemContext.getObject().Posnr;
		// 			var wbsElement = this.getView().getModel().getData().task;
		// 			var oData = wbsElement.filter(function (a) {
		// 				return a.Posnr === oPosnr;
		// 			});
		// 			var sTaskCount = oData.length;
		// 			var sTaskSeqNum = 1;
		// 			for (var i = 0; i < sTaskCount; i++) {
		// 				oData[i].SqNum = String(sTaskSeqNum);
		// 				sTaskSeqNum = sTaskSeqNum + 1;
		// 			}
		// 			for (var i = 0; i < this._oTaskLabor.getModel().getData().task.length; i++) {
		// 				if (!this._oTaskLabor.getModel().getData().task[i].Posnr) {
		// 					addPlusRow.Task = this._oTaskLabor.getModel().getData().task[i].Task;
		// 					addPlusRow.Tasktext = this._oTaskLabor.getModel().getData().task[i].Tasktext;
		// 					addPlusRow.Begda = this._oTaskLabor.getModel().getData().task[i].Begda;
		// 					addPlusRow.Endda = this._oTaskLabor.getModel().getData().task[i].Endda;
		// 					addPlusRow.Pspri = this._oTaskLabor.getModel().getData().task[i].Pspri;
		// 					oData.push(addPlusRow);

		// 				}
		// 			}
		// 			var itemRow = oModel.getProperty("/iwoTabTravel");
		// 			if (itemRow[this.getView().byId("idTravel").getSelectedIndex()].task === undefined) {
		// 				itemRow[this.getView().byId("idTravel").getSelectedIndex()].task = oData;
		// 			}
		// 			oModel.setProperty("/iwoTabTravel", itemRow);
		// 			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");

		// 		} else if (sInternalTable === true) {

		// 			var oPosnr = this.oItemContext.getObject().Posnr;
		// 			var oTable = this.getView().byId("idInternal");
		// 			var aContexts = oTable.getSelectedIndices();

		// 			// var oPosnr = oTable.getRows()[aContexts].getCells()[1].getValue();
		// 			var wbsElement = this.getView().getModel().getData().task;
		// 			var oData = wbsElement.filter(function (a) {
		// 				return a.Posnr === oPosnr;
		// 			});
		// 			var sTaskCount = oData.length;
		// 			var sTaskSeqNum = 1;
		// 			for (var i = 0; i < sTaskCount; i++) {
		// 				oData[i].SqNum = String(sTaskSeqNum);
		// 				sTaskSeqNum = sTaskSeqNum + 1;
		// 			}

		// 			for (var i = 0; i < this._oTaskLabor.getModel().getData().task.length; i++) {
		// 				if (!this._oTaskLabor.getModel().getData().task[i].Posnr) {
		// 					addPlusRow.Task = this._oTaskLabor.getModel().getData().task[i].Task;
		// 					addPlusRow.Tasktext = this._oTaskLabor.getModel().getData().task[i].Tasktext;
		// 					addPlusRow.Begda = this._oTaskLabor.getModel().getData().task[i].Begda;
		// 					addPlusRow.Endda = this._oTaskLabor.getModel().getData().task[i].Endda;
		// 					addPlusRow.Pspri = this._oTaskLabor.getModel().getData().task[i].Pspri;
		// 					oData.push(addPlusRow);
		// 				}
		// 			}
		// 			var itemRow = oModel.getProperty("/iwoTabTravel");
		// 			if (itemRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
		// 				itemRow[this.getView().byId("idInternal").getSelectedIndex()].task = oData;
		// 			}
		// 			oModel.setProperty("/iwoTabTravel", itemRow);
		// 			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 		}
		// 	}
		// 	this._oTaskLabor.open();
		// },

		onTaskLaborCancel: function () {
			//var otaskData = this._oTaskLabor.getModel("taskFragmodel").getData().task;
			// var oIndxTable = this.oItemContext.getPath().split("/")[2];
			// if (otaskData !== undefined && otaskData !== null && otaskData.length !== 0) {
			// 	var oTasklength = otaskData.length;
			// 	if (oTasklength > 0) {
			// 		this.getView().getModel("localModel").getData().iwoTabTravel[oIndxTable].taskFlg = "Task Present";
			// 	}
			// } else {
			// 	this.getView().getModel("localModel").getData().iwoTabTravel[oIndxTable].taskFlg = "";
			// }
			this.getView().getModel("localModel").refresh(true);
			this._oTaskLabor.close();

		},

		onRowSelected: function (oEvent) {
			var sSelected = oEvent.getSource().getSelectedIndices().length;
			var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var bFlag;
			if (sSelected === 1) {
				var aContexts1 = oEvent.getSource().getSelectedIndices();
				this.oItemContext = this.getView().getModel("localModel").getContext("/iwoTabTravel/" + aContexts1[0]);
				if (this.getView().getModel("localModel").getData().iwoTabTravel[aContexts1[0]].Zentry_tp !== "E" && this.getView().getModel(
						"localModel").getData().iwoTabTravel[aContexts1[0]].Zentry_tp !== "C") {
					if (sPrjTyp !== "ZCGC") {
						this.getView().byId("tasks").setEnabled(true);
						this.getView().byId("Itemlabor").setEnabled(true);
					}
					oViewModel.getData().FrasDis = "oEdit";
					oViewModel.getData().FrasBtn = "oEdit";
					bFlag = AppType === "CSIReview" ? false : true;
					this.getView().byId("idRDelete").setEnabled(bFlag);
					if (AppType === "CSIReview" || AppType === "View" || AppType === "BILLReview") {
						oViewModel.getData().FrasBtn = "oDisplay";
						oViewModel.getData().FrasDis = "oDisplay"; //Phase-3 Ratnakumar added
					} else if (AppType === "BILLRej" || AppType === "CSIRej") {
						oViewModel.getData().FrasBtn = "oEdit";
					}
				} else {
					if (AppType && sPrjTyp !== "ZCGC") {
						this.getView().byId("tasks").setEnabled(true);
						this.getView().byId("Itemlabor").setEnabled(true);
						this.getView().byId("Headerlabor").setEnabled(true);
						this.getView().byId("idRDelete").setEnabled(false);
						oViewModel.getData().FrasDis = "oDisplay";
						oViewModel.getData().FrasBtn = "oEdit";
						if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View") { //Phase 3 Ratnakumar added
							oViewModel.getData().FrasBtn = "oDisplay";
							oViewModel.getData().FrasDis = "oDisplay";
						} else if (AppType === "BILLRej" || AppType === "CSIRej") {
							oViewModel.getData().FrasBtn = "oEdit";
						}
						// if(AppType !== "ChangeProject"){
						oViewModel.getData().FrasDateDis = "oDateEdit";
					} else {
						this.getView().byId("tasks").setEnabled(false);
						this.getView().byId("Itemlabor").setEnabled(false);
						this.getView().byId("idRDelete").setEnabled(false);
					}
				}
				this.getView().getModel("appView").refresh(true);
			} else {
				var aContexts = oEvent.getSource().getSelectedIndices();
				var SselectRowTable = "";
				for (var i = aContexts.length - 1; i >= 0; i--) {
					var idx = aContexts[i];
					if (this.getView().getModel("localModel").getData().iwoTabTravel[idx].Zentry_tp === "E") {
						SselectRowTable = "X";
					}
				}
				bFlag = SselectRowTable === "X" ? false : true;
				this.getView().byId("idRDelete").setEnabled(bFlag);
				this.getView().byId("tasks").setEnabled(false);
				this.getView().byId("Itemlabor").setEnabled(false);
			}
			var oData = this.getView().getModel("appView").getData();
			if (oData.EstatTxt === "INPROGRESS" || AppType === "BILLRej") {
				this.getView().byId("idRDelete").setEnabled(false);
				if (oData.EstatTxt === "INPROGRESS") { // Ratnakumar added Phase 3
					oViewModel.getData().FrasBtn = "oDisplay";
					oViewModel.getData().FrasDis = "oDisplay";
				}
			}
		},

		onRowInternalSelected: function (oEvent) {
			var sSelected = oEvent.getSource().getSelectedIndices().length;
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if (sSelected === 1) {
				var aIndex = oEvent.getSource().getSelectedIndices();
				this.oItemContext = this.getView().getModel("localModel").getContext("/iwoTabTravel/" + aIndex[0]);
				// this.oItemContext = oEvent.getSource().getRows()[aIndex[0]].getBindingContext("localModel");
				if (this.getView().getModel("localModel").getData().iwoTabTravel[aIndex[0]].Zentry_tp !== "E") {
					this.getView().byId("interanlTasks").setEnabled(true);
					oViewModel.getData().FrasDis = "oEdit";
					oViewModel.getData().FrasBtn = "oEdit";
					if (AppType === "CSIReview" || AppType === "View" || AppType === "BILLReview") {
						this.getView().byId("idDelInternal").setEnabled(false);
						oViewModel.getData().FrasBtn = "oDisplay"; //Phase 3 Ratnakumar added.
						oViewModel.getData().FrasDis = "oDisplay"; //Phase 3 Ratnakumar added.
					} else {
						this.getView().byId("idDelInternal").setEnabled(true);
					}
				} else {
					if (AppType === "ChangeProject" || AppType === "ChangeRequest") {
						this.getView().byId("interanlTasks").setEnabled(true);
						this.getView().byId("idDelInternal").setEnabled(false);
						oViewModel.getData().FrasDis = "oDisplay";
						oViewModel.getData().FrasBtn = "oEdit";
					} else if (AppType === "View" || AppType === "BILLReview" || AppType === "CSIReview") {
						this.getView().byId("interanlTasks").setEnabled(true);
						this.getView().byId("idDelInternal").setEnabled(false);
						oViewModel.getData().FrasDis = "oDisplay";
						oViewModel.getData().FrasBtn = "oDisplay";
					} else if (AppType === "CSIRej" || AppType === "BILLRej") {
						this.getView().byId("interanlTasks").setEnabled(true);
						this.getView().byId("idDelInternal").setEnabled(false);
						//oViewModel.getData().FrasDis = "oDisplay";
						oViewModel.getData().FrasBtn = "oEdit";
					} else {
						this.getView().byId("interanlTasks").setEnabled(false);
						this.getView().byId("idDelInternal").setEnabled(false);
					}
				}
			} else {
				var aContexts = oEvent.getSource().getSelectedIndices();
				var SselectRowTable = "";
				for (var i = aContexts.length - 1; i >= 0; i--) {
					var idx = aContexts[i];
					if (this.getView().getModel("localModel").getData().iwoTabTravel[idx].Zentry_tp === "E") {
						SselectRowTable = "X";
					}
				}
				if (SselectRowTable === "X") {
					this.getView().byId("idDelInternal").setEnabled(false);
				} else {
					this.getView().byId("idDelInternal").setEnabled(true);
				}
				this.getView().byId("interanlTasks").setEnabled(false);
			}
			var oData = this.getView().getModel("appView").getData();
			if (oData.EstatTxt === "INPROGRESS") {
				this.getView().byId("idDelInternal").setEnabled(false);
				oViewModel.getData().FrasDis = "oDisplay"; //Ratnakumar phase 3
			}
		},
		onAddTaskRow: function (evt) {
			var that = this;
			var oModel = that.getView().getModel("localModel");
			this.sTaskPath = this.oItemContext.getPath();
			var lineItemData = JSON.parse(JSON.stringify(this.oItemContext.getObject()));
			var oBegda = this.dateFormatter(lineItemData.Vbegdat);
			var oEndda = this.dateFormatter(lineItemData.Venddat);
			var oView = this.getView();
			var addPlusRow = {
				SqNum: "",
				Task: "",
				Tasktext: "",
				Begda: oBegda,
				Endda: oEndda,
				Pspri: "",
				Vbegdat: oBegda,
				Venddat: oEndda
			};
			if (!this._oAddTaskLabor) {
				this._oAddTaskLabor = sap.ui.xmlfragment(that.createId("idAddTask"), "WBS.C1.WbsC1Request.fragments.AddTask", that);
				oView.addDependent(this._oAddTaskLabor);
			}

			//var aData = {}; //this.oItemContext.getObject().task ? this.oItemContext.getObject().task : [];
			// for (var i = 0; i < aData.length; i++) {
			// 	aData[i].Begda = this.dateFormatter(aData[i].Begda);
			// 	aData[i].Endda = this.dateFormatter(aData[i].Endda);
			// }
			//this.oItemContext.getObject().task = addPlusRow;
			//var oAddtaskData = this.oItemContext.getObject().task;
			//addPlusRow.Begda = this.dateFormatter(addPlusRow.Begda);
			//addPlusRow.Endda = this.dateFormatter(addPlusRow.Endda);
			var oTaskFragmodel = new JSONModel(addPlusRow);
			this._oAddTaskLabor.setModel(oTaskFragmodel, "AddtaskFragmodel");
			//this._oAddTaskLabor.getModel("AddtaskFragmodel").setData(addPlusRow);
			// var oViewModel = this.getView().getModel("appView");
			// var AppType = oViewModel.getData().oAppType;
			// if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && this.oHeaderType === true)) {
			// 	oViewModel.getData().TaskScenario = "oDisplay";
			// }
			// that.getView().getModel("appView").refresh(true);
			// if (AppType && AppType !== "ChangeProject") {
			// 	var sRevenueTable = this.getView().byId("idTravel").getVisible();
			// 	var sInternalTable = this.getView().byId("idInternal").getVisible();
			// 	if (sRevenueTable === true) {
			// 		var oPosnr = this.oItemContext.getObject().Posnr;

			// 		var wbsElement = this.getView().getModel().getProperty("/taskData");
			// 		var oData = wbsElement.filter(function (a) {
			// 			return a.Posnr === oPosnr;
			// 		});

			// 		var sTaskCount = oData.length;
			// 		var sTaskSeqNum = 1;
			// 		for (var i = 0; i < sTaskCount; i++) {
			// 			oData[i].SqNum = String(sTaskSeqNum);
			// 			sTaskSeqNum = sTaskSeqNum + 1;
			// 		}
			// 		if (this.oItemContext.getObject().task === undefined) {
			// 			this.getView().getModel("localModel").setProperty(this.oItemContext.getPath() + "/task", oData);
			// 		}
			// 		for (var i = 0; i < this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task.length; i++) {
			// 			if (!this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Posnr) {
			// 				addPlusRow.Task = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Task;
			// 				addPlusRow.Tasktext = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Tasktext;
			// 				addPlusRow.Begda = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Begda;
			// 				addPlusRow.Endda = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Endda;
			// 				addPlusRow.Pspri = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Pspri;
			// 				oData.push(addPlusRow);
			// 			}
			// 		}

			// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 		this._oAddTaskLabor.setModel(oTaskFragmodel, "AddtaskFragmodel");
			// 	} else if (sInternalTable === true) {

			// 		var oTable = this.getView().byId("idInternal");
			// 		var aContexts = oTable.getSelectedIndices();
			// 		var oPosnr = this.getView().getModel("localModel").getProperty("/iwoTabTravel/" + aContexts[0] + "/Posnr");

			// 		var wbsElement = this.getView().getModel().getProperty("/taskData");
			// 		var oData = wbsElement.filter(function (a) {
			// 			return a.Posnr === oPosnr;
			// 		});

			// 		var sTaskCount = oData.length;
			// 		var sTaskSeqNum = 1;
			// 		for (var i = 0; i < sTaskCount; i++) {
			// 			oData[i].SqNum = String(sTaskSeqNum);
			// 			sTaskSeqNum = sTaskSeqNum + 1;
			// 		}
			// 		for (var i = 0; i < this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task.length; i++) {
			// 			if (!this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Posnr) {
			// 				addPlusRow.Datab = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Datab;
			// 				addPlusRow.Datbi = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Datbi;
			// 				addPlusRow.Kschl = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Kschl;
			// 				addPlusRow.Zmatnr = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().task[i].Zmatnr;
			// 				oData.push(addPlusRow);

			// 			}
			// 		}

			// 		var itemRow = oModel.getProperty("/iwoTabTravel");
			// 		if (itemRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
			// 			itemRow[this.getView().byId("idInternal").getSelectedIndex()].task = oData;
			// 		}
			// 		oModel.setProperty("/iwoTabTravel", itemRow);
			// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 		this._oAddTaskLabor.setModel(oTaskFragmodel, "AddtaskFragmodel");

			// 	}

			// 	if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View" || AppType === "BILLRej") {
			// 		oViewModel.getData().FrasDis = "oDisplay";
			// 		oViewModel.getData().FrasBtn = "oDisplay";
			// 		if (this.getView().getModel("localModel").getData().task) {
			// 			for (var i = 0; i < this.getView().getModel("localModel").getData().task.length; i++) {
			// 				if (oPosnr === this.getView().getModel("localModel").getData().task[i].oPosnr) {
			// 					sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems()[i].getCells()[1].setEditable(false);
			// 					sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems()[i].getCells()[2].setEditable(false);
			// 					sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems()[i].getCells()[3].setEditable(false);
			// 					sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems()[i].getCells()[4].setEditable(false);
			// 					sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems()[i].getCells()[5].setEditable(false);
			// 					sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems()[i].getCells()[6].setEditable(false);
			// 				}
			// 			}
			// 		}

			// 		that.getView().getModel("appView").refresh(true);
			// 	}
			// }

			// if (AppType === "ChangeProject") {
			// 	var sRevenueTable = this.getView().byId("idTravel").getVisible();
			// 	var sInternalTable = this.getView().byId("idInternal").getVisible();
			// 	if (sRevenueTable === true) {
			// 		var oPosnr = this.oItemContext.getObject().Posnr;
			// 		var wbsElement = this.getView().getModel().getData().task;
			// 		var oData = wbsElement.filter(function (a) {
			// 			return a.Posnr === oPosnr;
			// 		});
			// 		var sTaskCount = oData.length;
			// 		var sTaskSeqNum = 1;
			// 		for (var i = 0; i < sTaskCount; i++) {
			// 			oData[i].SqNum = String(sTaskSeqNum);
			// 			sTaskSeqNum = sTaskSeqNum + 1;
			// 		}
			// 		for (var i = 0; i < this._oAddTaskLabor.getModel().getData().task.length; i++) {
			// 			if (!this._oAddTaskLabor.getModel().getData().task[i].Posnr) {
			// 				addPlusRow.Task = this._oAddTaskLabor.getModel().getData().task[i].Task;
			// 				addPlusRow.Tasktext = this._oAddTaskLabor.getModel().getData().task[i].Tasktext;
			// 				addPlusRow.Begda = this._oAddTaskLabor.getModel().getData().task[i].Begda;
			// 				addPlusRow.Endda = this._oAddTaskLabor.getModel().getData().task[i].Endda;
			// 				addPlusRow.Pspri = this._oAddTaskLabor.getModel().getData().task[i].Pspri;
			// 				oData.push(addPlusRow);

			// 			}
			// 		}
			// 		var itemRow = oModel.getProperty("/iwoTabTravel");
			// 		if (itemRow[this.getView().byId("idTravel").getSelectedIndex()].task === undefined) {
			// 			itemRow[this.getView().byId("idTravel").getSelectedIndex()].task = oData;
			// 		}
			// 		oModel.setProperty("/iwoTabTravel", itemRow);
			// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 		this._oAddTaskLabor.setModel(oTaskFragmodel, "AddtaskFragmodel");

			// 	} else if (sInternalTable === true) {

			// 		var oTable = this.getView().byId("idInternal");
			// 		var aContexts = oTable.getSelectedIndices();

			// 		var oPosnr = oTable.getRows()[aContexts].getCells()[1].getValue();
			// 		var wbsElement = this.getView().getModel().getData().task;
			// 		var oData = wbsElement.filter(function (a) {
			// 			return a.Posnr === oPosnr;
			// 		});
			// 		var sTaskCount = oData.length;
			// 		var sTaskSeqNum = 1;
			// 		for (var i = 0; i < sTaskCount; i++) {
			// 			oData[i].SqNum = String(sTaskSeqNum);
			// 			sTaskSeqNum = sTaskSeqNum + 1;
			// 		}

			// 		for (var i = 0; i < this._oAddTaskLabor.getModel().getData().task.length; i++) {
			// 			if (!this._oAddTaskLabor.getModel().getData().task[i].Posnr) {
			// 				addPlusRow.Task = this._oAddTaskLabor.getModel().getData().task[i].Task;
			// 				addPlusRow.Tasktext = this._oAddTaskLabor.getModel().getData().task[i].Tasktext;
			// 				addPlusRow.Begda = this._oAddTaskLabor.getModel().getData().task[i].Begda;
			// 				addPlusRow.Endda = this._oAddTaskLabor.getModel().getData().task[i].Endda;
			// 				addPlusRow.Pspri = this._oAddTaskLabor.getModel().getData().task[i].Pspri;
			// 				oData.push(addPlusRow);
			// 			}
			// 		}
			// 		var itemRow = oModel.getProperty("/iwoTabTravel");
			// 		if (itemRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
			// 			itemRow[this.getView().byId("idInternal").getSelectedIndex()].task = oData;
			// 		}
			// 		oModel.setProperty("/iwoTabTravel", itemRow);
			// 		var oAddTaskLabor = new JSONModel(this.oItemContext.getObject());
			// 		this._oAddTaskLabor.setModel(oAddTaskLabor, "AddtaskFragmodel");
			// 	}
			// }
			// if (sRevenueTable === true) {
			// 	// var oViewModel = this.getView().getModel("appView");

			// 	var addTaskRow = [];
			// 	var oModel = this.getView().getModel("localModel");
			// 	var oBegda = this.dateFormatter(lineItemData.Vbegdat);
			// 	var oEndda = this.dateFormatter(lineItemData.Venddat);
			// 	if (AppType === "ChangeProject" || this.changeRequestType === "ChangeProject") {
			// 		var addTaskPlusRow = {
			// 			"Kschl": "ZHAP",
			// 			"Begda": oBegda,
			// 			"Endda": oEndda,
			// 			"Zentry_tsk": "N"
			// 		};
			// 	} else {
			// 		var addTaskPlusRow = {
			// 			"Kschl": "ZHAP",
			// 			"Begda": oBegda,
			// 			"Endda": oEndda,
			// 			"Zentry_tsk": ""

			// 		};
			// 	}
			// 	var AppType = oViewModel.getData().oAppType;
			// 	var itemTaskRow = oModel.getProperty("/iwoTabTravel");
			// 	if (itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task === undefined) {
			// 		addTaskRow.push(addTaskPlusRow);
			// 		itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task = addTaskRow;
			// 	} else {
			// 		addTaskRow = itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task;
			// 		addTaskRow.push(addTaskPlusRow);
			// 		itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task = addTaskRow;
			// 	}

			// 	oModel.setProperty("/iwoTabTravel", itemTaskRow);
			// 	var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 	this._oAddTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
			// 	var sRowCount = sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems().length;
			// 	var sSeqNum = 1;
			// 	for (var i = 0; i < sRowCount; i++) {
			// 		itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task[i].SqNum = String(sSeqNum);
			// 		sSeqNum = sSeqNum + 1;
			// 		oModel.setProperty("/iwoTabTravel", itemTaskRow);
			// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 		this._oAddTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
			// 	}
			// } else if (sInternalTable === true) {
			// 	var oViewModel = this.getView().getModel("appView");
			// 	var addTaskRow = [];
			// 	var oModel = this.getView().getModel("localModel");
			// 	var oBegda = this.dateFormatter(lineItemData.Vbegdat);
			// 	var oEndda = this.dateFormatter(lineItemData.Venddat);
			// 	var addTaskPlusRow = {
			// 		"Kschl": "ZHAP",
			// 		"Begda": oBegda,
			// 		"Endda": oEndda,
			// 		"Zentry_tsk": ""
			// 	};

			// 	var AppType = oViewModel.getData().oAppType;
			// 	var itemTaskRow = oModel.getProperty("/iwoTabTravel");
			// 	if (itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
			// 		addTaskRow.push(addTaskPlusRow);
			// 		itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task = addTaskRow;
			// 	} else {
			// 		addTaskRow = itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task;
			// 		addTaskRow.push(addTaskPlusRow);
			// 		itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task = addTaskRow;
			// 	}

			// 	oModel.setProperty("/iwoTabTravel", itemTaskRow);
			// 	var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 	this._oAddTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
			// 	var sRowCount = sap.ui.core.Fragment.byId(this.createId("idAddTask"), "idAddTaskTable").getItems().length;
			// 	var sSeqNum = 1;
			// 	for (var i = 0; i < sRowCount; i++) {
			// 		itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task[i].SqNum = String(sSeqNum);
			// 		sSeqNum = sSeqNum + 1;
			// 		oModel.setProperty("/iwoTabTravel", itemTaskRow);
			// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			// 		this._oAddTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
			// 	}

			// }
			this._oAddTaskLabor.open();
		},

		onAddTaskSave: function () {
			//sap.ui.core.BusyIndicator.show();
			var sRevenueTable = this.getView().byId("idTravel").getVisible();
			var sInternalTable = this.getView().byId("idInternal").getVisible();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var lineItemData = JSON.parse(JSON.stringify(this.oItemContext.getObject()));

			var oFormTaskData = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData();
			if (!oFormTaskData.Task || !oFormTaskData.Tasktext || !oFormTaskData.Begda || !oFormTaskData.Endda) {
				sap.m.MessageToast.show("Please fill mandatory fields", {
					duration: 1000
				});
			} else {

				if (sRevenueTable === true) {
					// var oViewModel = this.getView().getModel("appView");
					var addTaskRow = [];
					var oModel = this.getView().getModel("localModel");
					// var oBegda = this.dateFormatter(lineItemData.Vbegdat);
					// var oEndda = this.dateFormatter(lineItemData.Venddat);
					var oBegda = this.dateFormatter(oFormTaskData.Begda);
					var oEndda = this.dateFormatter(oFormTaskData.Endda);
					if (AppType === "ChangeProject" || this.changeRequestType === "ChangeProject") {
						var addTaskPlusRow = {
							"SqNum": oFormTaskData.SqNum,
							"Task": oFormTaskData.Task,
							"Tasktext": oFormTaskData.Tasktext,
							"Begda": oBegda,
							"Endda": oEndda,
							"Pspri": oFormTaskData.Pspri,
							"Zentry_tsk": "N"
								// "Kschl": "ZHAP",
								// "Begda": oBegda,
								// "Endda": oEndda,

						};
					} else {
						var addTaskPlusRow = {
							"SqNum": oFormTaskData.SqNum,
							"Task": oFormTaskData.Task,
							"Tasktext": oFormTaskData.Tasktext,
							"Begda": oBegda,
							"Endda": oEndda,
							"Pspri": oFormTaskData.Pspri,
							"Zentry_tsk": ""
								// "Kschl": "ZHAP",
								// "Begda": oBegda,
								// "Endda": oEndda,
								// "Zentry_tsk": ""

						};
					}
					var AppType = oViewModel.getData().oAppType;
					var itemTaskRow = oModel.getProperty("/iwoTabTravel");
					if (itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task === undefined) {
						addTaskRow.push(addTaskPlusRow);
						itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task = addTaskRow;
					} else {
						addTaskRow = itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task;
						addTaskRow.push(addTaskPlusRow);
						itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task = addTaskRow;
					}

					oModel.setProperty("/iwoTabTravel", itemTaskRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
					var sRowCount = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getModel("taskFragmodel").getData().task.length;
					//var sRowCount = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems().length;
					//var sSeqNum = 1;
					//for (var i = ; i < sRowCount; i++) {
					itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task[sRowCount - 1].SqNum = String(sRowCount);
					//sSeqNum = sSeqNum + 1;
					oModel.setProperty("/iwoTabTravel", itemTaskRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
					//}
				} else if (sInternalTable === true) {
					var oViewModel = this.getView().getModel("appView");
					var addTaskRow = [];
					var oModel = this.getView().getModel("localModel");
					// var oBegda = this.dateFormatter(lineItemData.Vbegdat);
					// var oEndda = this.dateFormatter(lineItemData.Venddat);
					var oBegda = this.dateFormatter(oFormTaskData.Begda);
					var oEndda = this.dateFormatter(oFormTaskData.Endda);

					if (AppType === "ChangeProject" || this.changeRequestType === "ChangeProject") {
						var addTaskPlusRow = {
							"SqNum": oFormTaskData.SqNum,
							"Task": oFormTaskData.Task,
							"Tasktext": oFormTaskData.Tasktext,
							"Begda": oBegda,
							"Endda": oEndda,
							"Pspri": oFormTaskData.Pspri,
							"Zentry_tsk": "N"
								// "Kschl": "ZHAP",
								// "Begda": oBegda,
								// "Endda": oEndda,

						};
					} else {

						var addTaskPlusRow = {
							"SqNum": oFormTaskData.SqNum,
							"Task": oFormTaskData.Task,
							"Tasktext": oFormTaskData.Tasktext,
							"Begda": oBegda,
							"Endda": oEndda,
							"Pspri": oFormTaskData.Pspri,
							"Zentry_tsk": ""
								// "Kschl": "ZHAP",
								// "Begda": oBegda,
								// "Endda": oEndda,

						};
					}
					var AppType = oViewModel.getData().oAppType;
					var itemTaskRow = oModel.getProperty("/iwoTabTravel");
					if (itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
						addTaskRow.push(addTaskPlusRow);
						itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task = addTaskRow;
					} else {
						addTaskRow = itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task;
						addTaskRow.push(addTaskPlusRow);
						itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task = addTaskRow;
					}

					oModel.setProperty("/iwoTabTravel", itemTaskRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
					//var sRowCount = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems().length;
					var sRowCount = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getModel("taskFragmodel").getData().task.length;
					//var sSeqNum = 1;
					//for (var i = 0; i < sRowCount; i++) {
					itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task[sRowCount - 1].SqNum = String(sRowCount);
					//sSeqNum = sSeqNum + 1;
					oModel.setProperty("/iwoTabTravel", itemTaskRow);
					var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
					this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
					//}

				}
				if (this._oTaskLabor.getModel("taskFragmodel").getData().task.length === 0) {
					this._oTaskLabor.getModel("taskFragmodel").getData().task = [];
					var oTasklength = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;
				} else {
					var oTasklength = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;
				}

				this._oTaskLabor.getModel("taskFragmodel").setProperty("/oCount", oTasklength);
				this._oTaskLabor.getModel("taskFragmodel").refresh(true);
				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").setVisibleRowCount(10);
				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").rerender();
				this._oAddTaskLabor.close();
			}
			//sap.ui.core.BusyIndicator.hide();
		},

		onAddTaskLaborCancel: function () {
			this._oAddTaskLabor.close();
		},

		onDeleteTaskRow: function (evt) {
			var oModel = this.getView().getModel("localModel");
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sTaskTablePath = this.oItemContext.getPath().split("/")[2];
			if (AppType && AppType !== "ChangeProject") {
				this.getView().getModel("localModel").getData().iwoTabTravel[sTaskTablePath].task = this.oiwotabtravelT[sTaskTablePath].task;
			}
			var data = this.getView().getModel("localModel").getData().iwoTabTravel[sTaskTablePath].task;
			//var deleteRecord = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getSelectedIndices();
			//deleteRecord = Number(deleteRecord) + 1;

			var oTableRecords = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getSelectedIndices();
			//var indexnum = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getSelectedIndices();
			//var objinded = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getContextByIndex(indexnum).getObject();
			var itemRow = oModel.getProperty("/iwoTabTravel");
			// for (var i = 0; i < oTableRecords.length; i++) {
			// 	//var sDeletRecord = oTableRecords[i].getCells()[1].getValue();
			// 	// var sDeletRecord = this.oItemContext.getObject().task[oTableRecords[i]].SqNum;
			// 	var sDeletRecord = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getContextByIndex(oTableRecords[i]).getObject().SqNum;
			// 	//sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getRows()[i].getCells()[2].setValueState("Error");
			// 	//var sDeletRecord = oTableRecords[i].getCells()[0].getValue();
			// 	for (var s = 0; s < data.length; s++) {
			// 		if (sDeletRecord === data[s].SqNum) {
			// 			data.splice(s, 1);
			// 			this.getView().getModel().refresh();
			// 		}
			// 	}
			// }
			//var i = selected.length -1; i >= 0; --i
			for (var i = oTableRecords.length - 1; i >= 0; --i) {

				data.splice(oTableRecords[i], 1);
				this.getView().getModel().refresh();
			}

			var sSeqNum = 1;
			for (var i = 0; i < itemRow[sTaskTablePath].task.length; i++) {
				itemRow[sTaskTablePath].task[i].SqNum = String(sSeqNum);
				sSeqNum = sSeqNum + 1;
			}

			oModel.setProperty("/iwoTabTravel", itemRow);
			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
			var oTasklength = this._oTaskLabor.getModel("taskFragmodel").getData().task.length;
			this._oTaskLabor.getModel("taskFragmodel").setProperty("/oCount", oTasklength);
		},
		// onAddTaskRow: function (evt) {
		// 	var sRevenueTable = this.getView().byId("idTravel").getVisible();
		// 	var sInternalTable = this.getView().byId("idInternal").getVisible();
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var AppType = oViewModel.getData().oAppType;
		// 	var lineItemData = JSON.parse(JSON.stringify(this.oItemContext.getObject()));
		// 	if (sRevenueTable === true) {
		// 		// var oViewModel = this.getView().getModel("appView");
		// 		var addTaskRow = [];
		// 		var oModel = this.getView().getModel("localModel");
		// 		var oBegda = this.dateFormatter(lineItemData.Vbegdat);
		// 		var oEndda = this.dateFormatter(lineItemData.Venddat);
		// 		if (AppType === "ChangeProject" || this.changeRequestType === "ChangeProject") {
		// 			var addTaskPlusRow = {
		// 				"Kschl": "ZHAP",
		// 				"Begda": oBegda,
		// 				"Endda": oEndda,
		// 				"Zentry_tsk": "N"
		// 			};
		// 		} else {
		// 			var addTaskPlusRow = {
		// 				"Kschl": "ZHAP",
		// 				"Begda": oBegda,
		// 				"Endda": oEndda,
		// 				"Zentry_tsk": ""

		// 			};
		// 		}
		// 		var AppType = oViewModel.getData().oAppType;
		// 		var itemTaskRow = oModel.getProperty("/iwoTabTravel");
		// 		if (itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task === undefined) {
		// 			addTaskRow.push(addTaskPlusRow);
		// 			itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task = addTaskRow;
		// 		} else {
		// 			addTaskRow = itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task;
		// 			addTaskRow.push(addTaskPlusRow);
		// 			itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task = addTaskRow;
		// 		}

		// 		oModel.setProperty("/iwoTabTravel", itemTaskRow);
		// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 		this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 		var sRowCount = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems().length;
		// 		var sSeqNum = 1;
		// 		for (var i = 0; i < sRowCount; i++) {
		// 			itemTaskRow[this.getView().byId("idTravel").getSelectedIndex()].task[i].SqNum = String(sSeqNum);
		// 			sSeqNum = sSeqNum + 1;
		// 			oModel.setProperty("/iwoTabTravel", itemTaskRow);
		// 			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 		}
		// 	} else if (sInternalTable === true) {
		// 		var oViewModel = this.getView().getModel("appView");
		// 		var addTaskRow = [];
		// 		var oModel = this.getView().getModel("localModel");
		// 		var oBegda = this.dateFormatter(lineItemData.Vbegdat);
		// 		var oEndda = this.dateFormatter(lineItemData.Venddat);
		// 		var addTaskPlusRow = {
		// 			"Kschl": "ZHAP",
		// 			"Begda": oBegda,
		// 			"Endda": oEndda,
		// 			"Zentry_tsk": ""
		// 		};

		// 		var AppType = oViewModel.getData().oAppType;
		// 		var itemTaskRow = oModel.getProperty("/iwoTabTravel");
		// 		if (itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task === undefined) {
		// 			addTaskRow.push(addTaskPlusRow);
		// 			itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task = addTaskRow;
		// 		} else {
		// 			addTaskRow = itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task;
		// 			addTaskRow.push(addTaskPlusRow);
		// 			itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task = addTaskRow;
		// 		}

		// 		oModel.setProperty("/iwoTabTravel", itemTaskRow);
		// 		var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 		this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 		var sRowCount = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems().length;
		// 		var sSeqNum = 1;
		// 		for (var i = 0; i < sRowCount; i++) {
		// 			itemTaskRow[this.getView().byId("idInternal").getSelectedIndex()].task[i].SqNum = String(sSeqNum);
		// 			sSeqNum = sSeqNum + 1;
		// 			oModel.setProperty("/iwoTabTravel", itemTaskRow);
		// 			var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 			this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// 		}

		// 	}
		// },
		// onDeleteTaskRow: function (evt) {
		// 	var oModel = this.getView().getModel("localModel");
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var AppType = oViewModel.getData().oAppType;
		// 	var sTaskTablePath = this.oItemContext.getPath().split("/")[2];
		// 	if (AppType && AppType !== "ChangeProject") {
		// 		this.getView().getModel("localModel").getData().iwoTabTravel[sTaskTablePath].task = this.oiwotabtravelT[sTaskTablePath].task;
		// 	}
		// 	var data = this.getView().getModel("localModel").getData().iwoTabTravel[sTaskTablePath].task;
		// 	var deleteRecord = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getSelectedItem().getBindingContext(
		// 		"taskFragmodel").getPath();
		// 	deleteRecord = Number(deleteRecord.split("/")[2]) + 1;

		// 	var oTableRecords = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getSelectedItems();
		// 	var itemRow = oModel.getProperty("/iwoTabTravel");
		// 	for (var i = 0; i < oTableRecords.length; i++) {
		// 		var sDeletRecord = oTableRecords[i].getCells()[1].getValue();
		// 		for (var s = 0; s < data.length; s++) {
		// 			if (sDeletRecord === data[s].SqNum) {
		// 				data.splice(s, 1);
		// 				this.getView().getModel().refresh();
		// 			}
		// 		}
		// 	}

		// 	var sSeqNum = 1;
		// 	for (var i = 0; i < itemRow[sTaskTablePath].task.length; i++) {
		// 		itemRow[sTaskTablePath].task[i].SqNum = String(sSeqNum);
		// 		sSeqNum = sSeqNum + 1;
		// 	}

		// 	oModel.setProperty("/iwoTabTravel", itemRow);
		// 	var oTaskFragmodel = new JSONModel(this.oItemContext.getObject());
		// 	this._oTaskLabor.setModel(oTaskFragmodel, "taskFragmodel");
		// },

		onAddItemLaborRow: function (evt) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var addRow = [];
			var Year = "9999";
			var day = "31";
			var month = "11";
			var sEnddate = new Date(Year, month, day);
			var sDatbi = this.dateFormatter(sEnddate);
			var oModel = this.getView().getModel("localModel");
			var lineItemData = JSON.parse(JSON.stringify(this.oItemContext.getObject()));
			var sItemStrtDateRev = lineItemData.Vbegdat;
			var sDatb = this.dateFormatter(sItemStrtDateRev);
			if (AppType === "ChangeProject" || this.changeRequestType === "ChangeProject") {
				var addPlusRow = {
					Kschl: "ZIAP",
					Datab: sDatb,
					Datbi: sDatbi,
					Zentry_lab: "N"
				};
			} else {
				var addPlusRow = {
					Kschl: "ZIAP",
					Datab: sDatb,
					Datbi: sDatbi,
					Zentry_lab: ""
				};
			}

			var AppType = oViewModel.getData().oAppType;
			var itemRow = oModel.getProperty("/iwoTabTravel");
			if (itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor === undefined) {
				addRow.push(addPlusRow);
				itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor = addRow;
			} else {
				addRow = itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor;
				addRow.push(addPlusRow);
				itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor = addRow;
			}

			oModel.setProperty("/iwoTabTravel", itemRow);
			var oItemFragmodel = new JSONModel(this.oItemContext.getObject());
			this._oItemLabor.setModel(oItemFragmodel, "itemFragmodel");
			var sRowCount = sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborTable").getItems().length;
			var sSeqNum = 1;
			for (var i = 0; i < sRowCount; i++) {
				itemRow[this.getView().byId("idTravel").getSelectedIndex()].labor[i].SqNum = String(sSeqNum);
				sSeqNum = sSeqNum + 1;
				oModel.setProperty("/iwoTabTravel", itemRow);
				var oItemFragmodel = new JSONModel(this.oItemContext.getObject());
				this._oItemLabor.setModel(oItemFragmodel, "itemFragmodel");
			}
		},

		onItemLabSelect: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oselectedTask = oEvent.getSource().getSelectedContexts();
			var bFlag;
			if (AppType === "BILLRej" || AppType === "CSIReview") {
				bFlag = false;
			} else {
				bFlag = true;
			}

			if (oselectedTask.length > 0) {
				if (AppType === "ChangeRequest" || AppType === "ChangeProject" || !AppType) {
					for (var i = 0; i < oselectedTask.length; i++) {
						if (oselectedTask[i].getObject().Zentry_lab === 'N' || oselectedTask[i].getObject().Zentry_lab === '') {
							continue;
						} else {
							bFlag = false;
							break;
						}
					}
				}
			} else {
				bFlag = false;
			}
			sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "iditemDele").setEnabled(bFlag);
		},

		onDeleteItemLaborRow: function (evt) {
			var sRevenueTable = this.getView().byId("idTravel").getVisible();
			var sInternalTable = this.getView().byId("idInternal").getVisible();
			var oModel = this.getView().getModel("localModel");
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sItemTablePath = this.oItemContext.getPath().split("/")[2];
			if (AppType && AppType !== "ChangeProject") {
				this.getView().getModel("localModel").getData().iwoTabTravel[sItemTablePath].labor = this.oiwotabtravel[sItemTablePath].labor;
			}
			var data = this.getView().getModel("localModel").getData().iwoTabTravel[sItemTablePath].labor;
			var deleteRecord = sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborTable").getSelectedItem().getBindingContext(
				"itemFragmodel").getPath();
			deleteRecord = Number(deleteRecord.split("/")[2]) + 1;
			var oTableRecords = sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborTable").getSelectedItems();
			var itemRow = oModel.getProperty("/iwoTabTravel");
			if (sRevenueTable === true) {
				for (var i = 0; i < oTableRecords.length; i++) {
					var sDeletRecord = oTableRecords[i].getCells()[1].getValue();
					for (var s = 0; s < data.length; s++) {
						if (sDeletRecord === data[s].SqNum) {
							data.splice(s, 1);
							this.getView().getModel().refresh();

						}
					}

				}

				var sSeqNum = 1;
				for (var i = 0; i < itemRow[sItemTablePath].labor.length; i++) {
					itemRow[sItemTablePath].labor[i].SqNum = String(sSeqNum);
					sSeqNum = sSeqNum + 1;
				}

				oModel.setProperty("/iwoTabTravel", itemRow);
				var oItemFragmodel = new JSONModel(this.oItemContext.getObject());
				this._oItemLabor.setModel(oItemFragmodel, "itemFragmodel");
			} else if (sInternalTable === true) {
				for (var i = 0; i < oTableRecords.length; i++) {
					var sDeletRecord = oTableRecords[i].getCells()[1].getValue();
					for (var s = 0; s < data.length; s++) {
						if (sDeletRecord === data[s].SqNum) {
							data.splice(s, 1);
							this.getView().getModel().refresh();

						}
					}

				}
				oModel.setProperty("/iwoTabTravel", itemRow);
				var oItemFragmodel = new JSONModel(this.oItemContext.getObject());
				this._oItemLabor.setModel(oItemFragmodel, "itemFragmodel");
			}
		},

		onAddLaborRow: function (evt) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var oModel = this.getView().getModel();
			this.HeaderLabourRowClick = "Click";
			var sRevenueForm = this.getView().byId("SimpleFormChangewbs").getVisible();
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();
			var Year = "9999";
			var day = "31";
			var month = "11";
			var sDefaultEnd = new Date(Year, month, day);
			var sDatbi = this.dateFormatter(sDefaultEnd);

			if (sRevenueForm === true) {
				var sHeaderDate = this.getView().byId("dateCtrlStr").getDateValue();
				var sDatb = this.dateFormatter(sHeaderDate);
			} else if (sInternalForm === true) {
				var sHeaderEnd = this.getView().byId("idStarInt").getDateValue();
				var sDatb = this.dateFormatter(sHeaderEnd);
			}
			if (AppType === "ChangeProject" || this.changeRequestType === "ChangeProject") {
				var addRow = {
					Kschl: "ZHAP",
					Datab: sDatb,
					Datbi: sDatbi,
					HRowType: "",
					Zentry_lab: "N"
				};
			} else {
				var addRow = {
					Kschl: "ZHAP",
					Datab: sDatb,
					Datbi: sDatbi,
					HRowType: "",
					Zentry_lab: ""
				};
			}

			var itemRow = oModel.getProperty("/laborData");
			itemRow.push(addRow);
			oModel.setProperty("/laborData", itemRow);
		},

		onSelectLabor: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var bFlag;
			var oselectedTask = oEvent.getSource().getSelectedContexts();
			if (AppType === "BILLRej" || AppType === "CSIReview") {
				bFlag = false;
			} else {
				bFlag = true;
			}
			if (oselectedTask.length > 0) {
				if (AppType === "ChangeRequest" || AppType === "ChangeProject" || !AppType) {
					for (var i = 0; i < oselectedTask.length; i++) {
						if (oselectedTask[i].getObject().Zentry_lab === 'N' || oselectedTask[i].getObject().Zentry_lab === '') {
							continue;
						} else {
							bFlag = false;
							break;
						}
					}
				}
			} else {
				bFlag = false;
			}

			sap.ui.core.Fragment.byId(this.createId("idLabourType"), "idLaborDelete1").setEnabled(bFlag);

		},

		onDeleteLaborRow: function (evt) {
			var data = this.getView().getModel().getData().laborData;
			var deleteRecord = evt.getSource().getParent().getParent().getSelectedItem().getBindingContext().getObject();
			for (var i = 0; i < data.length; i++) {
				if (data[i] === deleteRecord) {
					data.splice(i, 1); //removing 1 record from i th index.
					this.getView().getModel().refresh();
					break; //quit the loop
				}
			}
		},

		onAddLineItem: function () {
			var that = this;
			sap.ui.core.BusyIndicator.show(0);
			var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
			if (sPrjTyp === "ZCGC") {
				that.getView().byId("Headerlabor").setEnabled(false);
			} else {
				that.getView().byId("Headerlabor").setEnabled(true);
			}
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if (AppType === "ChangeProject" || AppType === "ChangeRequest") {
				that.aAgm = "";
				that.aWbsowner1 = "";
				that.aWbsowner2 = "";
				that.aFinApp = "";
				that.aPrjAc = "";
				that.aDraftIa = "";
				that.aBds = "";
				that.aInvRec = "";
				that.aVbegdat = "";
				that.aVenddat = "";
			}
			that.StatusFlag = "StatusVisibleFalse";
			this.onPopUpCompleteRevDisableFlag = true;
			// if (AppType === "that.StatusFlag") {
			// 	var aID = ["idFSystatusline"];
			// 	that._fnSetVisibleFalse(aID);
			// }
			this.onCreateIwoTravel();
			this.getView().byId("addrecord11").setEnabled(false);
			this.getView().getModel("appView").setProperty("/count", this.getView().getModel("localModel").getProperty("/iwoTabTravel").length);
		},

		onPlannedRevenueChange: function (evt) {
			var sValue = evt.getParameter("value");
			var sCostValue = Number(sValue);

			var fieldid = evt.getParameter("id");
			if (sCostValue === 0) {
				sap.ui.getCore().byId(fieldid).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(fieldid).setValueStateText("Planned Revenue cannot be 0.");
			} else if (sCostValue > 2500000) {
				sap.ui.getCore().byId(fieldid).setValueState("Warning"); //this is for Error
				sap.ui.getCore().byId(fieldid).setValueStateText(
					"Revenue contracts over $ 2.5 million require Revenue Recognition Checklist (RRCL) attached, in order to remove NORA. The request will be processed At Risk if the document is not attached "
				);
			} else if (sCostValue) {
				sap.ui.getCore().byId(fieldid).setValueState("None"); //this is for Error \
				sap.ui.getCore().byId(fieldid).setValueStateText("None");
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("Error"); //this is for Error \
				sap.ui.getCore().byId(fieldid).setValueStateText("Planned Revenue cannot be empty.");
			}
		},

		onAutopopulateOther: function (oEvent) {
			var aID;
			var oViewModel = this.getView().getModel("appView");
			var oRow = oEvent.getParameter("row");
			var oContext = oRow.getBindingContext("localModel");
			this.getView().getModel().getData().HeaderData.addiFildRowCont = oContext;
			var oData = JSON.parse(JSON.stringify(oContext.getObject()));
			oData.Bstdk = this.dateFormatter(oData.Bstdk);
			var oModel1 = new sap.ui.model.json.JSONModel(oData);
			var oView = this.getView();
			var oDialog = oView.byId("idDialogLineItem");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.LineItemPopup", this);
				oView.addDependent(oDialog);
			}
			oDialog.setModel(oModel1, "oFragmentModel");
			var oPayer = this.getView().byId(sap.ui.core.Fragment.createId(this.getView().getId(), "idPayer"));
			oPayer.setSuggestionRowValidator(this.suggestionRowValidator);

			var oShip = this.getView().byId(sap.ui.core.Fragment.createId(this.getView().getId(), "idship"));
			oShip.setSuggestionRowValidator(this.suggestionRowValidator);

			var oBill = this.getView().byId(sap.ui.core.Fragment.createId(this.getView().getId(), "idbill"));
			oBill.setSuggestionRowValidator(this.suggestionRowValidator);
			oDialog.open();

			// var oLineitemEndDate = oData.Venddat;
			var AppType = oViewModel.getData().oAppType;
			var oRejectType = oViewModel.getData().RejectType;
			// var oEntrytype = oData.Zentry_tp;
			if (AppType === "CSIReview") {
				aID = ["idFRLegacy", "idFRcheckbox", "idLineAGM", "idOwner1", "idOwner2", "idFinanceApp", "idDraftInv", "idStartDate", "idEndDate"];
				this._fnSetEditableFalse(aID);
				this._fnSetEditableTrue(["idProjAcc", "idBillingData", "idInvoice"]);
			}

			if (AppType === "BILLRej" || AppType === "View" || AppType === "BILLReview") {
				aID = ["idPoNum", "datePo", "idFResCost", "idFResCost", "idPCS", "idIFS", "idWBSCoCodeL31", "idFRLegacy", "idFRcheckbox",
					"idLineAGM", "idOwner1", "idOwner2", "idFinanceApp", "idDraftInv", "idBillingData",
					"idPayerPopup", "idshipPopup", "idbillPopup", "idStartDate", "idEndDate", "idInvoice"
				];
				this._fnSetEditableFalse(aID);
			}

			if (AppType === "ChangeProject" || AppType === "ChangeRequest" || AppType === "View" || (AppType === "CSIRej" && oData.Zentry_tp !==
					"N") || (AppType ===
					"BILLRej" && oData.Zentry_tp !== "N") || (AppType === "CSIReview" && oData.Zentry_tp !== "N") || (AppType === "BILLReview" &&
					oData.Zentry_tp !== "N")) {
				if (oData.Zentry_tp === "N" || oData.Zentry_tp === "") {
					var aID = ["idFSystatusline"];
					this._fnSetVisibleFalse(aID);
				} else {
					aID = ["idFSystatusline"];
					this._fnSetVisibleTrue(aID);
				}
			}
			if (AppType === "BILLRej" || AppType === "View" || AppType === "BILLReview") {
				this._fnSetEditableFalse("idSaveLineItem");
			}

			var oViewModel = this.getView().getModel("appView");
			var oCurrentDateLItem = new Date();
			var oCurrentDateEndYear = oCurrentDateLItem.getFullYear();
			if (oCurrentDateLItem.getMonth() < 10) {
				var oCurrentDateMonth = ("0" + (oCurrentDateLItem.getMonth() + 1));
			} else {
				var oCurrentDateMonth = oCurrentDateLItem.getMonth() + 1;
			}

			//var oCurrentDateMonth = ("0" + (oCurrentDateLItem.getMonth() + 1));//oCurrentDateLItem.getMonth() + 1;
			//oCurrentDateLItem.getDate();
			if (oCurrentDateLItem.getDate() < 10) {
				var oCurrentDateDay = ("0" + (oCurrentDateLItem.getDate()));
			} else {
				var oCurrentDateDay = oCurrentDateLItem.getDate();
			}

			var oCurrentDate = oCurrentDateEndYear.toString() + oCurrentDateMonth.toString() + oCurrentDateDay.toString();
			// that.oCurrentDateLineItem = oCurrentDateLineItem;
			var oEndDateLItem1 = oData.Venddat;
			var oEndDateLItem = new Date(oEndDateLItem1);
			var oLineItemEndYear = oEndDateLItem.getFullYear();

			//var oLineItemEndMonth = ("0" + (oEndDateLItem.getMonth() + 1));
			if (oEndDateLItem.getMonth() < 10) {
				var oLineItemEndMonth = ("0" + (oEndDateLItem.getMonth() + 1));
			} else {
				var oLineItemEndMonth = oEndDateLItem.getMonth() + 1;
			}

			//oEndDateLItem.getMonth() + 1;
			//var oLineItemEndDay = ("0" + (oEndDateLItem.getDate()));
			if (oEndDateLItem.getDate() < 10) {
				var oLineItemEndDay = ("0" + (oEndDateLItem.getDate()));
			} else {
				var oLineItemEndDay = oEndDateLItem.getDate();
			}

			//oEndDateLItem.getDate();
			var oEndDateLineItem = oLineItemEndYear.toString() + oLineItemEndMonth.toString() + oLineItemEndDay.toString();
			// that.oEndDateLineItem = oEndDateLineItem;
			// if (this.oCurrentDateLineItem > this.oEndDateLineItem) {
			if (oEndDateLineItem > oCurrentDate) {
				oViewModel.getData().StatusCLSD = "oStatusDisable";
				this.getView().getModel("appView").refresh(true);
			} else {
				oViewModel.getData().StatusCLSD = "oStatusEnable";
				this.getView().getModel("appView").refresh(true);
			}
			sap.ui.core.BusyIndicator.hide();
		},

		onPopUpCancel: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if (AppType === "CSIReview") {
				this.getView().byId("idSaveBtn").setEnabled(true);
			}
			if (!AppType || AppType === "ChangeProject" || AppType === "ChangeRequest" || AppType === "CSIRej") {
				this.getView().byId("addrecord11").setEnabled(true);
			}
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			oDailog.destroy();
		},

		/*This method for upate the Additional data popup*/

		onPlannedCost: function (evt) {
			var sValue = evt.getParameter("value");
			var sCostValue = Number(sValue);
			var fieldid = evt.getParameter("id");
			if (sCostValue === 0) {
				sap.ui.getCore().byId(fieldid).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(fieldid).setValueStateText("Planned Revenue cannot be 0.");
			} else if (sCostValue) {
				sap.ui.getCore().byId(fieldid).setValueState("None"); //this is for Error 
				sap.ui.getCore().byId(fieldid).setValueStateText("None");

			} else {
				sap.ui.getCore().byId(fieldid).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(fieldid).setValueStateText("Planned Revenue cannot be empty.");
			}
		},

		onAGMChange: function (evt) {
			var that = this;
			that.aAgm = "X";
			var newID = evt.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
			}
		},

		onOwner1Change: function (evt) {
			var that = this;
			that.aWbsowner1 = "X";
			var newID = evt.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
			}
		},

		onWbsOwnerEqual: function () {
			var oWBS1 = this.getView().byId("idOwner1").getSelectedKey();
			var oWBS2 = this.getView().byId("idOwner2").getValue();
			if (oWBS1 === oWBS2) {
				sap.m.MessageToast.show("WBS Owner1 and WBS Owner2 should not be same", {
					duration: 6000
				});
				this.getView().byId("idOwner2").setValueState("Error");
			} else {
				this.getView().byId("idOwner1").setValueState("None");
				this.getView().byId("idOwner2").setValueState("None");
			}
		},

		onIntPopEualWoner: function () {
			var oWBS1 = this.getView().byId("idOwner1Int").getSelectedKey();
			var oWBS2 = this.getView().byId("idOwner2Int").getValue();
			if (oWBS1 === oWBS2) {
				sap.m.MessageToast.show("WBS Owner1 and WBS Owner2 should not be same", {
					duration: 6000
				});
				this.getView().byId("idOwner2Int").setValueState("Error");
			} else {
				this.getView().byId("idOwner1Int").setValueState("None");
				this.getView().byId("idOwner2Int").setValueState("None");
			}
		},

		onOwner2Change: function (evt) {
			this.aWbsowner2 = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},
		onProjAccChange: function (evt) {
			this.aPrjAc = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},
		onDraftInvChange: function (evt) {
			this.aDraftIa = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},
		onBillChange: function (evt) {
			this.aBds = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},

		onEndDateChange: function () {
			var that = this;
			that.aVenddat = "X";
		},

		onInvoiceChange: function (evt) {
			this.aInvRec = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},
		onFinanceApprChange: function (evt) {
			this.aFinApp = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},

		//Internal
		onIntAGMChange: function (evt) {
			this.aAgm = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},

		onIntOwner1Change: function (evt) {
			this.aWbsowner1 = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},
		onIntOwner2Change: function (evt) {
			this.aWbsowner2 = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},
		onIntFinanceApprChange: function (evt) {
			this.aFinApp = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},

		onIntProjAccChange: function (evt) {
			this.aPrjAc = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},

		onIntDraftInvChange: function (evt) {
			this.aDraftIa = "X";
			var oSrc = evt.getSource();
			this._fnCheckValidKey(oSrc);
		},

		_fnCheckValidKey: function (oSrc) {
			var sKey = oSrc.getSelectedKey();
			if (!sKey) {
				sKey.setValue("");
			}
		},

		onWBSStartDateChange: function (oEvent) {
			var that = this,
				oSrc = oEvent.getSource(),
				Year = oSrc.getDateValue().getFullYear(),
				day = oSrc.getDateValue().getDate(),
				month = oSrc.getDateValue().getMonth();
			this.getView().getModel("localModel").setProperty(oSrc.getBindingContext("localModel").getPath() + "/minEndDate", new Date(Year,
				month, day));
			that.aVbegdat = "X";
			that.aVenddat = "X";
		},

		onWBSEndDateNavigate: function (oEvent) {
			var oSrc = oEvent.getSource();
			var oStartDate = oSrc.getBindingContext("localModel").getObject().Vbegdat;
			oSrc.setMinDate(this.dateFormatter(oStartDate));
		},

		onInputChangePO: function (oEvent) {
			var oPONumber = oEvent.getSource().getValue();
			var oLocalModel = this.getView().getModel("localModel");
			var oData = oLocalModel.getProperty("/iwoTabTravel");
			if (oPONumber) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].Zentry_tp !== "E" && oData[i].Zentry_tp !== "C") {
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/Bstnk", oPONumber);
					}
				}
			}
		},

		onManCheck: function (evt) {
			var str = evt.getParameter("value");
			var endDateID = evt.getParameter("id");
			if (str) {
				sap.ui.getCore().byId(endDateID).setValueState("None");
			} else {
				sap.ui.getCore().byId(endDateID).setValueState("Error");
			}
		},

		onSpecialCharsCheck: function (evt) {
			var str = evt.getParameter("value");
			var sControlId = evt.getParameter("id");
			var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
			for (var i = 0; i < str.length; i++) {
				if (s.indexOf(str.charAt(i)) !== -1) {
					sap.ui.getCore().byId(sControlId).setValueState("Error");
					sap.ui.getCore().byId(sControlId).setValueStateText("Special characters are not allowed");
				}
			}
		},

		onSpecialChar: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var fieldid = oEvent.getParameter("id");
			var regex = new RegExp("\\t");
			for (var i = 0; i < newValue.length; i++) {
				if (newValue.match(regex)) {
					this.getView().byId(fieldid).setValueState("Error");
					this.getView().byId(fieldid).setValueStateText("Unprintable characters are not allowed");
				} else {
					this.getView().byId(fieldid).setValueState("None");
					this.getView().byId(fieldid).setValueStateText("None");
				}
			}
		},

		onSpecialCharIntTable: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var oSrc = oEvent.getSource();
			var regex = new RegExp("\\t");
			if (newValue.match(regex)) {
				oSrc.setValueState("Error");
				oSrc.setValueStateText("Unprintable characters are not allowed");
			} else {
				oSrc.setValueState("None");
				oSrc.setValueStateText("None");
			}
		},

		checkSpecialChars: function (evt) {
			var str = evt.getParameter("value");
			var oSrc = evt.getSource();
			var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
			for (var i = 0; i < str.length; i++) {
				if (s.indexOf(str.charAt(i)) !== -1) {
					oSrc.setValueState("Error");
					oSrc.setValueStateText("Special characters are not allowed");
				} else {
					oSrc.setValueState("None");
					oSrc.setValueStateText("None");
				}
			}
		},

		onAddLineItemInternal: function () {
			var that = this;
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;

			if (AppType === "ChangeProject" || AppType === "ChangeRequest") {
				that.aAgm = "";
				that.aWbsowner1 = "";
				that.aWbsowner2 = "";
				that.aFinApp = "";
				that.aPrjAc = "";
				that.aDraftIa = "";
				that.aVbegdat = "";
				that.aVenddat = "";

			}
			this.onCreateIwoTravel();
			this.getView().getModel("appView").setProperty("/count", this.getView().getModel("localModel").getProperty("/iwoTabTravel").length);
			this.getView().byId("addInternal").setEnabled(false);
		},

		onAutopopulateInternal: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var oRow = oEvent.getParameter("row");
			var oContext = oRow.getBindingContext("localModel");
			this.getView().getModel().getData().HeaderData.addiFildRowCont = oContext;
			var oData = JSON.parse(JSON.stringify(oContext.getObject()));

			var oView = this.getView();
			var oDialog = oView.byId("idLineItemInternal");

			// var oViewModel = oView.getModel("appView").getData();
			var oModel1 = new sap.ui.model.json.JSONModel(oData);
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.C1.WbsC1Request.fragments.LineItemPopupInternal", this);
				oView.addDependent(oDialog);
			}
			oDialog.setModel(oModel1, "oInternalFragmentModel");
			oDialog.open();
			var AppType = oViewModel.getData().oAppType;
			// var oViewModel = oView.getModel("appView").getData();
			if (oData.Zentry_tp === "E" || AppType === "CSIReview") {
				this.getView().byId("addInternal").setEnabled(false);

				this.onPopUpCompleteIntDisable();
			}

			if (AppType === "ChangeProject" || AppType === "ChangeRequest" || (AppType === "CSIRej" && oData.Zentry_tp !== "N") || (AppType ===
					"BILLRej" && oData.Zentry_tp !== "N") || (AppType === "CSIReview" && oData.Zentry_tp !== "N") || (AppType === "BILLReview" &&
					oData.Zentry_tp !== "N") || (AppType === "View" && this.oStatus === "APPROVED") || (AppType === "View" && this.oStatus ===
					"AUTOAPPRVD")) {
				if (oData.Zentry_tp === "N" || oData.Zentry_tp === "") {
					var aID = ["idIFSystatusline"];
					this._fnSetVisibleFalse(aID);
				} else {
					aID = ["idIFSystatusline"];
					this._fnSetVisibleTrue(aID);
				}
			}
			var oViewModel = this.getView().getModel("appView");
			var oCurrentDateS = new Date();
			var oCurrentDateEndYear = oCurrentDateS.getFullYear();
			//var oCurrentDateMonth = ("0" + (oCurrentDateS.getMonth() + 1));
			if (oCurrentDateS.getMonth() < 10) {
				var oCurrentDateMonth = ("0" + (oCurrentDateS.getMonth() + 1));
			} else {
				var oCurrentDateMonth = oCurrentDateS.getMonth() + 1;
			} //oCurrentDateS.getMonth() + 1;
			if (oCurrentDateS.getDate() < 10) {
				var oCurrentDateDay = ("0" + (oCurrentDateS.getDate()));
			} else {
				var oCurrentDateDay = oCurrentDateS.getDate();
			}

			//var oCurrentDateDay = ("0" + (oCurrentDateS.getDate()));//oCurrentDateS.getDate();
			var oCurrentDate = oCurrentDateEndYear.toString() + oCurrentDateMonth.toString() + oCurrentDateDay.toString();
			// that.oCurrentDateLineItem = oCurrentDateLineItem;
			var oEndDateLItem1 = oData.Venddat;
			var oEndDateLItem = new Date(oEndDateLItem1);
			var oLineItemEndYear = oEndDateLItem.getFullYear();
			if (oEndDateLItem.getMonth() < 10) {
				var oLineItemEndMonth = ("0" + (oEndDateLItem.getMonth() + 1));
			} else {
				var oLineItemEndMonth = oEndDateLItem.getMonth() + 1;
			}
			//oEndDateLItem.getMonth() + 1;
			if (oEndDateLItem.getDate() < 10) {
				var oLineItemEndDay = ("0" + (oEndDateLItem.getDate()));
			} else {
				var oLineItemEndDay = oEndDateLItem.getDate();
			}
			//oEndDateLItem.getDate();
			var oEndDateLineItem = oLineItemEndYear.toString() + oLineItemEndMonth.toString() + oLineItemEndDay.toString();
			// that.oEndDateLineItem = oEndDateLineItem;
			// if (this.oCurrentDateLineItem > this.oEndDateLineItem) {

			if (oEndDateLineItem > oCurrentDate) {
				oViewModel.getData().StatusCLSD = "oStatusDisable";
				this.getView().getModel("appView").refresh(true);
			} else {
				oViewModel.getData().StatusCLSD = "oStatusEnable";
				this.getView().getModel("appView").refresh(true);
			}
		},

		onCloseInternalPopup: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			oDailog.destroy();
			var AppType = oViewModel.getData().oAppType;
			if (!AppType || AppType === "ChangeProject" || AppType === "ChangeRequest" || AppType === "CSIRej") {
				this.getView().byId("addInternal").setEnabled(true);
			}
			if (AppType === "CSIReview") {
				this.getView().byId("idSaveBtn").setEnabled(true);
			}
		},

		onGarbageTabDip: function (oEvent) {
			var oDip = oEvent.getSource().getSelectedKey();
			var oContext = oEvent.getSource().getBindingContext("localModel").getPath();
			if (!oDip) {
				//this.getView().getModel("localModel").setProperty(oContext + "/RaKey", "");
			}
		},

		check19carInt: function (evt) {
			var str = evt.getParameter("value");
			if (str === "") {
				evt.getSource().setValue("");
				evt.getSource().setValueState("Error");
				evt.getSource().setValueStateText("Planned Revenue cannot be empty.");
			} else {
				var sControlId = evt.getParameter("id");
				var regex = /^[0-9.,-]+$/;
				if (regex.test(str)) {
					//
				} else {
					this.getView().byId(sControlId).setValue(str.slice(0, -1));
				}
			}
		},

		onAddComaDecilal: function (evt) {
			var str = evt.getParameter("value");
			var sControlId = evt.getParameter("id");
			var nStr = str.replace(/,/g, '');
			var oDeciml = parseFloat(nStr).toFixed(2);
			var oSplit = oDeciml.split(".");
			var oValue = Math.sign(oSplit[0]);
			if (oValue === -1) {
				if (oSplit[0].length <= 14) {
					var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					this.getView().byId(sControlId).setValue(nValue);
					this.getView().byId(sControlId).setValueState("None");
				} else {
					this.getView().byId(sControlId).setValueState("Error");
					sap.m.MessageToast.show('please enter only 13 digit before the decimal');
				}
			} else {
				if (oSplit[0].length <= 13) {
					var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					this.getView().byId(sControlId).setValue(nValue);
					this.getView().byId(sControlId).setValueState("None");
				} else {
					this.getView().byId(sControlId).setValueState("Error");
					sap.m.MessageToast.show('please enter only 13 digit before the decimal');
				}
			}

			if (str === 0) {
				sap.ui.getCore().byId(sControlId).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText("Planned Revenue cannot be 0.");
			} else if (str > 2500000) {
				sap.ui.getCore().byId(sControlId).setValueState("Warning"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText(
					"Revenue contracts over $ 2.5 million require Revenue Recognition Checklist (RRCL) attached, in order to remove NORA. The request will be processed At Risk if the document is not attached "
				);
			} else if (parseInt(str) < -2500000) {
				sap.ui.getCore().byId(sControlId).setValueState("Warning"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText(
					"Revenue contracts over $ 2.5 million require Revenue Recognition Checklist (RRCL) attached, in order to remove NORA. The request will be processed At Risk if the document is not attached "
				);
			} else if (str) {
				sap.ui.getCore().byId(sControlId).setValueState("None"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText("None");
			} else {
				sap.ui.getCore().byId(sControlId).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText("Planned Revenue cannot be empty.");
			}

		},
		onAddComaDecilalCost: function (evt) {
			var str = evt.getParameter("value");
			var sControlId = evt.getParameter("id");
			var nStr = str.replace(/,/g, '');
			var oDeciml = parseFloat(nStr).toFixed(2);
			var oSplit = oDeciml.split(".");
			var oValue = Math.sign(oSplit[0]);
			if (oValue === -1) {
				if (oSplit[0].length <= 14) {
					var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					this.getView().byId(sControlId).setValue(nValue);
					this.getView().byId(sControlId).setValueState("None");
				} else {
					this.getView().byId(sControlId).setValueState("Error");
					sap.m.MessageToast.show('please enter only 13 digit before the decimal');
				}
			} else {
				if (oSplit[0].length <= 13) {
					var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					this.getView().byId(sControlId).setValue(nValue);
					this.getView().byId(sControlId).setValueState("None");
				} else {
					this.getView().byId(sControlId).setValueState("Error");
					sap.m.MessageToast.show('please enter only 13 digit before the decimal');
				}
			}

			if (str === 0) {
				sap.ui.getCore().byId(sControlId).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText("Planned Revenue cannot be 0.");
			} else if (str) {
				sap.ui.getCore().byId(sControlId).setValueState("None"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText("None");

			} else {
				sap.ui.getCore().byId(sControlId).setValueState("Error"); //this is for Error 
				sap.ui.getCore().byId(sControlId).setValueStateText("Planned Revenue cannot be empty.");
			}
		},

		check19carIntCost: function (evt) {
			var str = evt.getParameter("value");
			if (str === "") {
				evt.getSource().setValue("");
				evt.getSource().setValueState("Error");
				evt.getSource().setValueStateText("Planned Cost cannot be empty.");
			} else {
				var regex = /^[0-9.,-]+$/;
				if (!regex.test(str)) {
					evt.getSource().setValue(str.slice(0, -1));
				}
			}
		},

		onAddComaDecilalCostInternal: function (evt) {
			var str = evt.getParameter("value");
			var nStr = str.replace(/,/g, '');
			var oDeciml = parseFloat(nStr).toFixed(2);
			var oSplit = oDeciml.split(".");
			var oValue = Math.sign(oSplit[0]);
			if (oValue === -1) {
				if (oSplit[0].length <= 14) {
					var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					evt.getSource().setValue(nValue);
					evt.getSource().setValueState("None");
				} else {
					evt.getSource().setValueState("Error");
					sap.m.MessageToast.show('please enter only 13 digit before the decimal');
				}
			} else {
				if (oSplit[0].length <= 13) {
					var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
					evt.getSource().setValue(nValue);
					evt.getSource().setValueState("None");
				} else {
					evt.getSource().setValueState("Error");
					sap.m.MessageToast.show('please enter only 13 digit before the decimal');
				}
			}
			if (str === 0) {
				evt.getSource().setValueState("Error"); //this is for Error 
				evt.getSource().setValueStateText("Planned Revenue cannot be 0.");
			} else if (str) {
				evt.getSource().setValueState("None"); //this is for Error 
				evt.getSource().setValueStateText("None");

			} else {
				evt.getSource().setValueState("Error"); //this is for Error 
				evt.getSource().setValueStateText("Planned Revenue cannot be empty.");
			}
		},

		check19carIntCostInternal: function (evt) {
			var str = evt.getParameter("value");
			if (str === "") {
				evt.getSource().setValue("");
				evt.getSource().setValueState("Error");
				evt.getSource().setValueStateText("Planned Cost cannot be empty.");
			} else {
				var regex = /^[0-9.,-]+$/;
				if (!regex.test(str)) {
					evt.getSource().setValue(str.slice(0, -1));
				}
			}
		},

		onInputValidationOppId: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var sRow = oEvent.getSource().getBindingContext("localModel").getPath();
			var oSrc = oEvent.getSource();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var SZentrytp = oEvent.getSource().getBindingContext("localModel").getObject().Zentry_tp; //RCR

			if (SZentrytp === "N" || SZentrytp === "") {
				if (newValue === "") {
					oSrc.setValueState("Error");
					oSrc.setValueStateText("Please enter the value."); // Add record button disable
				} else {
					oSrc.setValueState("None");
				}
			} else {
				if (newValue === "") {
					oSrc.setValueState("None");
					// sap.m.MessageToast.show("Optional field for Existing and changed line item", {
					// 	duration: 50000
					// });
					// oSrc.setValueStateText("Optional field for Existing Line item");
				}
			}
			var oLocalModel = this.getView().getModel("localModel");
			var oppIdClear = oLocalModel.getProperty(sRow + "/ZsfdcOppid");

			if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && SZentrytp === "C") || (AppType === "")) {
				if (oppIdClear !== newValue) {
					oLocalModel.setProperty(sRow + "/CaseSafeId", "");
					oLocalModel.setProperty(sRow + "/SolTyp", "");
					oLocalModel.setProperty(sRow + "/ContModl", "");
					oLocalModel.setProperty(sRow + "/oCaseSafeModel", null);
					if ((AppType === "ChangeProject" && SZentrytp === "N") || (AppType === "")) {
						if (oppIdClear !== newValue) {
							oLocalModel.setProperty(sRow + "/Matnr", "");
							oLocalModel.setProperty(sRow + "/Maktx", "");
							oLocalModel.setProperty(sRow + "/majOffDesc", "");
							oLocalModel.setProperty(sRow + "/Prodh", "");
							oLocalModel.setProperty(sRow + "/Prctr", "");
							oLocalModel.setProperty(sRow + "/Pstyv", "");
							oLocalModel.setProperty(sRow + "/Ffprf", "");
							oLocalModel.setProperty(sRow + "/CaseSafeId", "");
							oLocalModel.setProperty(sRow + "/SolTyp", "");
							oLocalModel.setProperty(sRow + "/ContModl", "");
							oLocalModel.setProperty(sRow + "/oCaseSafeModel", null);

						}
					}
				}
			} else if ((AppType === "ChangeRequest" && SZentrytp === "N") || (AppType === "ChangeProject" && SZentrytp === "N") || (AppType ===
					"")) {
				if (oppIdClear !== newValue) {
					oLocalModel.setProperty(sRow + "/Matnr", "");
					oLocalModel.setProperty(sRow + "/Maktx", "");
					oLocalModel.setProperty(sRow + "/majOffDesc", "");
					oLocalModel.setProperty(sRow + "/Prodh", "");
					oLocalModel.setProperty(sRow + "/Prctr", "");
					oLocalModel.setProperty(sRow + "/Pstyv", "");
					oLocalModel.setProperty(sRow + "/Ffprf", "");
					oLocalModel.setProperty(sRow + "/CaseSafeId", "");
					oLocalModel.setProperty(sRow + "/SolTyp", "");
					oLocalModel.setProperty(sRow + "/ContModl", "");
					oLocalModel.setProperty(sRow + "/oCaseSafeModel", null);

				}
			}
		},

		onInterInputValidationOppId: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var obj = oEvent.getSource().getBindingContext("localModel").getObject();
			if (newValue === "") {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText("Please enter the value."); // Add record button disable
			} else {
				oEvent.getSource().setValueState("None");
			}
			var oppIdClear = obj.ZsfdcOppid;
			if (oppIdClear !== newValue) {
				obj.CaseSafeId = "";
				obj.SolTyp = "";
				obj.ContModl = "";
			}
		},

		onChangeOppId: function (evt) {
			var sValue = evt.getParameter("value");
			var sRow = evt.getSource().getBindingContext("localModel").getPath();
			var aFilters = [];
			var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var SZentrytp = evt.getSource().getBindingContext("localModel").getObject().Zentry_tp;

			if (SZentrytp === "N" || SZentrytp === "") {
				this.getView().getModel("localModel").setProperty(sRow + "/SolTyp", "");
				this.getView().getModel("localModel").setProperty(sRow + "/ContModl", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Matnr", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Maktx", "");
				this.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Prodh", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Prctr", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "");
				this.getView().getModel("localModel").setProperty(sRow + "/RaKey", "");
				this.getView().getModel("localModel").setProperty(sRow + "/CaseSafeId", "");
			}

			if (sValue.length === 0) {
				this.getView().getModel("localModel").setProperty(sRow + "/isRevenueMatEditable", false);
				if (SZentrytp === "N" || SZentrytp === "") {
					evt.getSource().setValueState("Error");
				} else {
					evt.getSource().setValueState("None");
				}
			} else {
				// var SZentrytp = evt.getSource().getBindingContext("localModel").getObject().Zentry_tp;
				if ((AppType === "ChangeProject" && SZentrytp !== "E") || (AppType === "CSIRej") || (AppType === "BILLRej") || (AppType ===
						"ChangeRequest" && SZentrytp === "N") || (AppType === "")) {
					this.getView().getModel("localModel").setProperty(sRow + "/isRevenueMatEditable", true);
				} else if (AppType === "ChangeRequest" && SZentrytp === "C") {
					this.getView().getModel("localModel").setProperty(sRow + "/isRevenueMatEditable", false);
				} else if (AppType === "ChangeRequest" && SZentrytp === "") {
					this.getView().getModel("localModel").setProperty(sRow + "/isRevenueMatEditable", true);
				}
				evt.getSource().setValueState("None");

				var oModel = this.getView().getModel("oDataModel");
				var that = this;
				oModel.read("/SearchCaseSafeIdSet", {
					urlParameters: {
						"$filter": "(Optid eq '" + sValue + "')"
					},
					success: function (oData) {
						that.getView().getModel("localModel").setProperty(sRow + "/oCaseSafeModel", oData.results);
					},
					error: function (oError) {}
				});
				var aFilters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Auart", sap.ui.model.FilterOperator.EQ, sPrjTyp),
					],
					and: false
				});
				oModel.read("/SearchItemCatSet", {
					filters: [aFilters],
					success: function (oData) {
						that.getView().getModel("localModel").setProperty(sRow + "/oBillModel", oData.results);
					},
					error: function (oError) {}
				});
			}
		},

		onCaseSafeChange: function (evt) {
			var oSrc = evt.getSource(),
				sValue = oSrc.getSelectedKey(),
				sRow = evt.getSource().getBindingContext("localModel").getPath();

			var modelLength = this.getView().getModel("localModel").getProperty(sRow + "/oCaseSafeModel");
			if (sValue === "") {
				this.getView().getModel("localModel").setProperty(sRow + "/CaseSafeId", "");
				this.getView().getModel("localModel").setProperty(sRow + "/SolTyp", "");
				this.getView().getModel("localModel").setProperty(sRow + "/ContModl", "");
			} else {
				this.getView().getModel("localModel").setProperty(sRow + "/SolTyp", modelLength[0].SolTyp);
				this.getView().getModel("localModel").setProperty(sRow + "/ContModl", modelLength[0].ContMdl);
			}
		},

		onPayMentTermChange: function (evt) {
			this.gPayTerm = "G";
			var sValue = evt.getParameter("value");
			if (!sValue) {
				evt.getSource().setValueState("Error");
			} else {
				evt.getSource().setValueState("None");
			}
		},

		// onSuggestMaterialNo: function (oEvent) {
		// 	var sRow = oEvent.getSource().getBindingContext("localModel").getPath();
		// 	var sOppId = this.getView().getModel("localModel").getProperty(sRow + "/ZsfdcOppid");
		// 	var sZBUKRSMat = this.getView().byId("comCode").getValue();
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("OppId", sap.ui.model.FilterOperator.EQ, sOppId),
		// 			new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sZBUKRSMat)
		// 		],
		// 		and: true
		// 	});
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	var oSource = oEvent.getSource();
		// 	var that = this;
		// 	oModel.read("/SearchMatMastSet", {
		// 		filters: [aFilters],
		// 		urlParameters: {
		// 			"$top": 100
		// 		},
		// 		success: function (oResponse) {
		// 			that.getView().getModel("localModel").getProperty(sRow + "/sug");
		// 			oSource._refreshItemsDelayed();
		// 		},
		// 		error: function (oError) {}
		// 	});
		// },
		onSuggestMaterialNo: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSrc = oEvent.getSource();
			var sRow = oEvent.getSource().getBindingContext("localModel").getPath();
			var sOppId = this.getView().getModel("localModel").getProperty(sRow + "/ZsfdcOppid");
			var sCaseSafeId = this.getView().getModel("localModel").getProperty(sRow + "/CaseSafeId");
			var sZBUKRSMat = this.getView().byId("comCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("OppId", sap.ui.model.FilterOperator.EQ, sOppId),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sZBUKRSMat),
					new sap.ui.model.Filter("caseId", sap.ui.model.FilterOperator.EQ, sCaseSafeId),
					new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: true
			});
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/SearchMatMastSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var mResponse = oResponse.results.length;
					// that.getView().getModel("localModel").getProperty(sRow + "/sug");
					that.getView().getModel("localModel").setProperty(sRow + "/sug", oResponse.results);
					oSrc._refreshItemsDelayed();
					if (mResponse === 0) {
						sap.m.MessageToast.show("No material for the offering. Contact OMT team", {
							duration: 50000
						});
						oSrc.setValueState("Error");
						oSrc.setValue("");
						that.getView().getModel("localModel").setProperty(sRow + "/Maktx", "");
						that.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", "");
						that.getView().getModel("localModel").setProperty(sRow + "/Prodh", "");
						that.getView().getModel("localModel").setProperty(sRow + "/Prctr", "");
						that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "");
						that.getView().getModel("localModel").setProperty(sRow + "/RaKey", "");
					}
				},
				error: function (oError) {}
			});
		},

		onofferingMiss: function (oEvent) {
			var mValue = oEvent.getParameter("value");
			var sRow = oEvent.getSource().getBindingContext("localModel").getPath();
			var sOppId = this.getView().getModel("localModel").getProperty(sRow + "/ZsfdcOppid");
			var sZBUKRSMat = this.getView().byId("comCode").getValue();
			var that = this;
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, mValue),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sZBUKRSMat),
					new sap.ui.model.Filter("OppId", sap.ui.model.FilterOperator.EQ, sOppId)
				],
				and: true
			});
			if (mValue) {
				oModel.read("/SearchMatMastSet", {
					filters: [aFilters],
					success: function (oData) {
						var mResponse = oData.results.length;
						if (mResponse === 0) {
							sap.m.MessageToast.show("No material for the offering. Contact OMT team", {
								duration: 50000
							});
						} else {
							that.getView().getModel("localModel").setProperty(sRow + "/sug", oData.results);
						}
					},
					error: function (oError) {}
				});
			}
		},

		// onRevMatChange: function (oEvent) {
		// 	var oSrc = oEvent.getSource();
		// 	var sSelected = oEvent.getParameter("value");
		// 	var sRow = oSrc.getBindingContext("localModel").getPath();
		// 	var sOppId = this.getView().getModel("localModel").getProperty(sRow + "/ZsfdcOppid");
		// 	var sZBUKRSMat = this.getView().byId("comCode").getValue();
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, sSelected),
		// 			new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sZBUKRSMat),
		// 			new sap.ui.model.Filter("OppId", sap.ui.model.FilterOperator.EQ, sOppId)
		// 		],
		// 		and: true
		// 	});
		// 	var that = this;
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
		// 	oModel.read("/SearchMatMastSet", {
		// 		filters: [aFilters],
		// 		success: function (oData) {
		// 			if (!sSelected) {
		// 				oSrc.setValueState("Error");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Maktx", "");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", "");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Prodh", "");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Prctr", "");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "");
		// 			} else {
		// 				if (oData.results.length === 0) {
		// 					sap.m.MessageToast.show("No material for the offering. Contact OMT team", {
		// 						duration: 5000
		// 					});
		// 				} else {
		// 					oSrc.setValueState("None");
		// 					var sItemBill = oData.results[0].Mtpos;
		// 					that.getView().getModel("localModel").setProperty(sRow + "/Maktx", oData.results[0].Maktx);
		// 					that.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", oData.results[0].majOffDesc);
		// 					that.getView().getModel("localModel").setProperty(sRow + "/Prodh", oData.results[0].Prdha);
		// 					that.getView().getModel("localModel").setProperty(sRow + "/Prctr", oData.results[0].Prctr);
		// 					that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", sItemBill);
		// 				}
		// 			}
		// 			if (sItemBill === "ZFIX") {
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "ZPER");
		// 			} else if (sItemBill === "ZTME") {
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Ffprf", "ZRRB0001");
		// 			}
		// 			if (sPrjTyp === 'ZCGC') {
		// 				sItemBill = sPrjTyp;
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "ZCGC");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/RaKey", "ZRA01");
		// 				that.getView().getModel("localModel").getProperty(sRow + "/RaKey");
		// 				var sStateRA = oSrc.getValue() === "" ? "Error" : "None";
		// 				that.getView().getModel("localModel").setProperty(sRow + "/revRAKeyValueState", sStateRA);
		// 				that.getView().getModel("localModel").setProperty(sRow + "/Ffprf", "");
		// 				that.getView().getModel("localModel").setProperty(sRow + "/isRevRAKeyEditable", true);
		// 			}
		// 			var oItem = that.getView().getModel("localModel").getProperty(sRow + "/Pstyv");
		// 			var sState = oItem === "" ? "Error" : "None";
		// 			that.getView().getModel("localModel").setProperty(sRow + "/revItmBillCatValueState", sState);
		// 		},
		// 		error: function (oError) {}
		// 	});
		// },
		//warrenty 10/7
		onRevMatChange: function (oEvent) {
			var oSrc = oEvent.getSource();
			var sSelected = oEvent.getParameter("value");
			var sRow = oSrc.getBindingContext("localModel").getPath();
			var sVal = oSrc.getValue();
			if (sVal.length < 10) {
				oSrc.setValueState("Error");
				oSrc.setValue("");
				this.getView().getModel("localModel").setProperty(sRow + "/Maktx", "");
				this.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Prodh", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Prctr", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "");
				this.getView().getModel("localModel").setProperty(sRow + "/RaKey", "");
			} else {
				oSrc.setValueState("None");
				var sOppId = this.getView().getModel("localModel").getProperty(sRow + "/ZsfdcOppid");
				var sCaseSafeId = this.getView().getModel("localModel").getProperty(sRow + "/CaseSafeId");
				var sZBUKRSMat = this.getView().byId("comCode").getValue();
				var aFilters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Matnr", sap.ui.model.FilterOperator.Contains, sSelected),
						new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sZBUKRSMat),
						new sap.ui.model.Filter("OppId", sap.ui.model.FilterOperator.EQ, sOppId),
						new sap.ui.model.Filter("caseId", sap.ui.model.FilterOperator.EQ, sCaseSafeId)
					],
					and: true
				});
				var that = this;
				var oModel = this.getView().getModel("oDataModel");
				var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
				oModel.read("/SearchMatMastSet", {
					filters: [aFilters],
					success: function (oData) {
						if (!sSelected) {
							oSrc.setValueState("Error");
							that.getView().getModel("localModel").setProperty(sRow + "/Maktx", "");
							that.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", "");
							that.getView().getModel("localModel").setProperty(sRow + "/Prodh", "");
							that.getView().getModel("localModel").setProperty(sRow + "/Prctr", "");
							that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "");
						} else {
							if (oData.results.length === 0) {
								sap.m.MessageToast.show("No material for the offering. Contact OMT team", {
									duration: 5000
								});
							} else {
								oSrc.setValueState("None");
								var sItemBill = oData.results[0].Mtpos;
								that.getView().getModel("localModel").setProperty(sRow + "/Maktx", oData.results[0].Maktx);
								that.getView().getModel("localModel").setProperty(sRow + "/majOffDesc", oData.results[0].majOffDesc);
								that.getView().getModel("localModel").setProperty(sRow + "/Prodh", oData.results[0].Prdha);
								that.getView().getModel("localModel").setProperty(sRow + "/Prctr", oData.results[0].Prctr);
								that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", sItemBill);
							}
						}
						if (sItemBill === "ZFIX") {
							that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "ZPER");
						} else if (sItemBill === "ZTME") {
							that.getView().getModel("localModel").setProperty(sRow + "/Ffprf", "ZRRB0001");
						}
						if (sPrjTyp === 'ZCGC') {
							sItemBill = sPrjTyp;
							that.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "ZCGC");
							that.getView().getModel("localModel").setProperty(sRow + "/RaKey", "ZRA01");
							that.getView().getModel("localModel").getProperty(sRow + "/RaKey");
							var sStateRA = oSrc.getValue() === "" ? "Error" : "None";
							that.getView().getModel("localModel").setProperty(sRow + "/revRAKeyValueState", sStateRA);
							that.getView().getModel("localModel").setProperty(sRow + "/Ffprf", "");
							that.getView().getModel("localModel").setProperty(sRow + "/isRevRAKeyEditable", true);

						}
						var oItem = that.getView().getModel("localModel").getProperty(sRow + "/Pstyv");
						var sState = oItem === "" ? "Error" : "None";
						that.getView().getModel("localModel").setProperty(sRow + "/revItmBillCatValueState", sState);

					},
					error: function (oError) {}
				});
			}
		},

		onItemBillChange: function (evt) {
			var sValue = evt.getSource("value").getSelectedKey();
			if (!sValue) {
				evt.getSource("value").setValueState("Error");
				evt.getSource("value").setValue("");
			} else {
				evt.getSource("value").setValueState("None");
			}
		},

		onIntOppidClear: function (oEvent) {
			var sRow = oEvent.getSource().getBindingContext("localModel").getPath();
			var skey = oEvent.getSource().getValue();
			if (skey === "") {
				this.getView().getModel("localModel").setProperty(sRow + "/Matnr", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Maktx", "");
				this.getView().getModel("localModel").setProperty(sRow + "/Pstyv", "");
			}
		},

		onIntChangeOppId: function (evt) {
			var sValue = evt.getParameter("value");
			var sPrjSubTyp = this.getView().byId("idSubTyp").getSelectedKey();
			var sRow = evt.getSource().getBindingContext("localModel").getPath();
			var obj = this.getView().getModel("localModel").getObject(sRow);
			var oKeyOpId = obj.ZsfdcOppid;

			if (sValue === "") {
				obj.ZsfdcOppid = ""
				if (sPrjSubTyp === "BP") {
					obj.CaseSafeId = "";
					obj.SolTyp = "";
					obj.ContModl = "";
				}
			} else if (!oKeyOpId) {
				obj.ZsfdcOppid = "";
			} else {
				var oModel = this.getView().getModel("oDataModel");
				var that = this;
				var sZBUKRS = this.getView().byId("comCode").getValue(); //New
				oModel.read("/SearchCaseSafeIdSet", {
					urlParameters: {
						"$filter": "(Optid eq '" + sValue + "')"
					},
					success: function (oData) {
						that.getView().getModel("localModel").setProperty(sRow + "/oIntCaseSafeModel", oData.results);
					},
					error: function (oError) {}
				});
			}
		},

		onIntCaseSafeChange: function (evt) {
			var sValue = evt.getSource().getSelectedKey();
			var oSource = evt.getSource();
			var obj = oSource.getBindingContext("localModel").getObject();
			if (!sValue) {
				obj.SolTyp = "";
				obj.ContModl = "";
			}
			var modelLength = obj.oIntCaseSafeModel;
			for (var i = 0; i < modelLength.length; i++) {
				if (modelLength[i].CaseSafeId === sValue) {
					obj.SolTyp = modelLength[i].SolTyp;
					obj.ContModl = modelLength[i].ContMdl;
				}
			}
		},

		onRAChange: function (evt) {
			var sValue = evt.getSource("value").getSelectedKey();
			if (!sValue) {
				evt.getSource("value").setValueState("Error");
				evt.getSource("value").setValue("");
			} else {
				evt.getSource("value").setValueState("None");
			}
		},

		onInputChangeDeS: function (oEvent) {
			var str = oEvent.getParameter("value");
			var sVal = str ? "None" : "Error";
			oEvent.getSource().setValueState(sVal);
		},
		onInputAppro: function (oEvent) {
			var str = oEvent.getParameter("value");
			var sVal = str ? "None" : "Error";
			oEvent.getSource().setValueState(sVal);
		},
		// onSubEnable: function (evt) {
		// 	// var that = this;
		// 	var oLocalModel = this.getView().getModel("localModel");
		// 	var oModel = this.getView().getModel("localModel").getData().iwoTabTravel;
		// 	var sRevenueTable = this.getView().byId("idTravel").getVisible();
		// 	var sInternalTable = this.getView().byId("idInternal").getVisible();
		// 	var sBtn = "Yes";
		// 	if (sRevenueTable === true) {
		// 		for (var i = 0; i < oModel.length; i++) {
		// 			var oEntry = oModel[i].Zentry_tp;
		// 			if (oEntry === "N" || oEntry === "") {
		// 				var sLineWBSDesc = oModel[i].Arktx;
		// 				var sVal = sLineWBSDesc ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revWbsDescValueState", sVal);

		// 				var sOppId = oModel[i].ZsfdcOppid;
		// 				sVal = sOppId ? "None" : "Error";
		// 				oModel[i].revOppIdValueState = sVal;

		// 				var sLineItemPayTerms = oModel[i].Zterm;
		// 				sVal = sLineItemPayTerms ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPayTermValueState", sVal);

		// 				var sMatNum = oModel[i].Matnr;
		// 				sVal = sMatNum ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revMatnrValueState", sVal);

		// 				var sItemBillCat = oModel[i].Pstyv;
		// 				sVal = sItemBillCat ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revItmBillCatValueState", sVal);

		// 				var sRAKey = oModel[i].RaKey;
		// 				sVal = sRAKey ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revRAKeyValueState", sVal);

		// 				var sPlanReve = oModel[i].Zplnrev;
		// 				sVal = sPlanReve ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPlanRevValueState", sVal);

		// 				// var sPlanCost =  = oModel[i].uu;
		// 				var sPlanCost = oModel[i].Zplncst;
		// 				sVal = sPlanCost ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPlanCostValueState", sVal);
		// 				//if (oModel[i].Zentry_tp !== "E") {
		// 				if (!sLineWBSDesc || !sOppId || !sLineItemPayTerms || !sMatNum || !sItemBillCat || !sRAKey || !sPlanReve || !sPlanCost || !
		// 					oModel[i].Agm ||
		// 					!oModel[i].DraftIa || !oModel[i].FinApp || !oModel[i].Wbsowner2 || !oModel[i].Wbsowner1) {
		// 					sBtn = "No";
		// 				}
		// 			}
		// 			// }
		// 		}
		// 		return sBtn;
		// 	} else if (sInternalTable === true) {
		// 		var key = this.getView().byId("idSubTyp").getSelectedKey();
		// 		for (var i = 0; i < oModel.length; i++) {
		// 			var oEntry = oModel[i].Zentry_tp;
		// 			if (oEntry === "N" || oEntry === "") {
		// 				var sRespCost = oModel[i].Fkstl;
		// 				sVal = sRespCost ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/intResCostValueState", sVal);

		// 				var sLineWBSDesc = oModel[i].Arktx;
		// 				sVal = sLineWBSDesc ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/intWbsDescValueState", sVal);

		// 				var sItemBillCat = oModel[i].Pstyv;
		// 				sVal = sItemBillCat ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/intItmBillCatValueState", sVal);

		// 				var sPlanCost = oModel[i].Zplncst;
		// 				sVal = sPlanCost ? "None" : "Error";
		// 				oLocalModel.setProperty("/iwoTabTravel/" + i + "/intPlanCostValueState", sVal);
		// 				if (oModel[i].Zentry_tp !== "E") {
		// 					if (!sRespCost || !sLineWBSDesc || !sItemBillCat || !sPlanCost || !oModel[i].FinApp || !oModel[i].Wbsowner2 || !oModel[i].Wbsowner1) {
		// 						sBtn = "No";
		// 					}
		// 				}
		// 			}
		// 		}
		// 		return sBtn;
		// 	}
		// }, //RCR
		onSubEnable: function (evt) {
			// var that = this;
			var oLocalModel = this.getView().getModel("localModel");
			var oModel = this.getView().getModel("localModel").getData().iwoTabTravel;
			var sRevenueTable = this.getView().byId("idTravel").getVisible();
			var sInternalTable = this.getView().byId("idInternal").getVisible();
			var sBtn = "Yes";
			if (sRevenueTable === true) {
				for (var i = 0; i < oModel.length; i++) {
					var oEntry = oModel[i].Zentry_tp;
					if (oEntry === "N" || oEntry === "") {
						var sLineWBSDesc = oModel[i].Arktx;
						var sVal = sLineWBSDesc ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revWbsDescValueState", sVal);

						var sOppId = oModel[i].ZsfdcOppid;
						sVal = sOppId ? "None" : "Error";
						oModel[i].revOppIdValueState = sVal;

						var sLineItemPayTerms = oModel[i].Zterm;
						sVal = sLineItemPayTerms ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPayTermValueState", sVal);

						var sMatNum = oModel[i].Matnr;
						sVal = sMatNum ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revMatnrValueState", sVal);

						var sItemBillCat = oModel[i].Pstyv;
						sVal = sItemBillCat ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revItmBillCatValueState", sVal);

						var sRAKey = oModel[i].RaKey;
						sVal = sRAKey ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revRAKeyValueState", sVal);

						var sPlanReve = oModel[i].Zplnrev;
						sVal = sPlanReve ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPlanRevValueState", sVal);

						var sPlanCost = oModel[i].Zplncst;
						sVal = sPlanCost ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPlanCostValueState", sVal);
						//if (oModel[i].Zentry_tp !== "E") {
						if (!sLineWBSDesc || !sOppId || !sLineItemPayTerms || !sMatNum || !sItemBillCat || !sRAKey || !sPlanReve || !sPlanCost || !
							oModel[i].Agm ||
							!oModel[i].DraftIa || !oModel[i].FinApp || !oModel[i].Wbsowner2 || !oModel[i].Wbsowner1) {
							sBtn = "No";
						}
					} else {
						// var oSource = evt.getSource();
						// var obj = oSource.getBindingContext("localModel").getObject();
						var sLineWBSDesc = oModel[i].Arktx;
						var sVal = sLineWBSDesc ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revWbsDescValueState", sVal);

						var sOppId = oModel[i].ZsfdcOppid;
						sVal = sOppId ? "None" : "None";
						oModel[i].revOppIdValueState = sVal;

						var sLineItemPayTerms = oModel[i].Zterm;
						sVal = sLineItemPayTerms ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPayTermValueState", sVal);

						var sMatNum = oModel[i].Matnr;
						sVal = sMatNum ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revMatnrValueState", sVal);

						var sItemBillCat = oModel[i].Pstyv;
						sVal = sItemBillCat ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revItmBillCatValueState", sVal);

						var sRAKey = oModel[i].RaKey;
						sVal = sRAKey ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revRAKeyValueState", sVal);

						var sPlanReve = oModel[i].Zplnrev;
						sVal = sPlanReve ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPlanRevValueState", sVal);

						var sPlanCost = oModel[i].Zplncst;
						sVal = sPlanCost ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/revPlanCostValueState", sVal);

						if (!sPlanReve || !sPlanCost || !oModel[i].Agm || !oModel[i].DraftIa || !oModel[i].FinApp || !oModel[i].Wbsowner2 ||
							!oModel[i].Wbsowner1) {
							sBtn = "No";
						}

					}
					// }
				}
				return sBtn;
			} else if (sInternalTable === true) {
				var key = this.getView().byId("idSubTyp").getSelectedKey();
				for (var i = 0; i < oModel.length; i++) {
					var oEntry = oModel[i].Zentry_tp;
					if (oEntry === "N" || oEntry === "") {
						var sRespCost = oModel[i].Fkstl;
						sVal = sRespCost ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intResCostValueState", sVal);

						var sLineWBSDesc = oModel[i].Arktx;
						sVal = sLineWBSDesc ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intWbsDescValueState", sVal);

						var sItemBillCat = oModel[i].Pstyv;
						sVal = sItemBillCat ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intItmBillCatValueState", sVal);

						var sPlanCost = oModel[i].Zplncst;
						sVal = sPlanCost ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intPlanCostValueState", sVal);
						// if (oModel[i].Zentry_tp !== "E") {
						if (!sRespCost || !sLineWBSDesc || !sItemBillCat || !sPlanCost || !oModel[i].FinApp || !oModel[i].Wbsowner2 || !oModel[i].Wbsowner1) {
							sBtn = "No";
						}
						// }
					} else {
						var sRespCost = oModel[i].Fkstl;
						sVal = sRespCost ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intResCostValueState", sVal);

						var sLineWBSDesc = oModel[i].Arktx;
						sVal = sLineWBSDesc ? "None" : "None";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intWbsDescValueState", sVal);

						var sItemBillCat = oModel[i].Pstyv;
						sVal = sItemBillCat ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intItmBillCatValueState", sVal);

						var sPlanCost = oModel[i].Zplncst;
						sVal = sPlanCost ? "None" : "Error";
						oLocalModel.setProperty("/iwoTabTravel/" + i + "/intPlanCostValueState", sVal);

						if (!sItemBillCat || !sPlanCost || !oModel[i].FinApp || !oModel[i].Wbsowner2 || !oModel[i].Wbsowner1) {
							sBtn = "No";
						}
					}
				}
				return sBtn;
			}
		},

		onSavePopUpItems: function (evt) {
			sap.ui.core.BusyIndicator.show(0);
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if (AppType === "CSIReview") {
				this.getView().byId("idSaveBtn").setEnabled(true);
			}

			if (!AppType || AppType === "ChangeProject" || AppType === "ChangeRequest" || AppType === "CSIRej") {
				this.getView().byId("addrecord11").setEnabled(true);
			}
			var oContext = this.getView().getModel().getData().HeaderData.addiFildRowCont;
			var popUpData = this.getView().byId("idDialogLineItem").getModel("oFragmentModel").getData();

			var checkbox = this.getView().byId("idFRcheckbox").getSelected();
			popUpData.Inind = checkbox ? 'X' : '';
			popUpData.SavePopup = 'X';
			popUpData.Vbegdat = this.dateFormatter(popUpData.Vbegdat);
			popUpData.Venddat = this.dateFormatter(popUpData.Venddat);
			popUpData.minEndDate = this.dateFormatter(popUpData.minEndDate);
			var sPayerKey = popUpData.payerName;
			popUpData.PayerKey = sPayerKey ? sPayerKey.substring(0, 10).split(" ")[0] : sPayerKey;
			var sShipToKey = popUpData.shipToName;
			popUpData.ShipToKey = sShipToKey ? sShipToKey.substring(0, 10).split(" ")[0] : sShipToKey;
			var sBillToKey = popUpData.billToName;
			popUpData.BillToKey = sBillToKey ? sBillToKey.substring(0, 10).split(" ")[0] : sBillToKey;
			this.getView().getModel("localModel").setProperty(oContext.getPath(), popUpData);
			sap.ui.core.BusyIndicator.hide();
			MessageToast.show("WBS Element details saved successfully.");
			this.onPopUpCancel(evt);
		},

		onSavePopUpInternalItems: function (evt) {
			sap.ui.core.BusyIndicator.show(0);
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if (AppType === "CSIReview") {
				this.getView().byId("idSaveBtn").setEnabled(true);
			}
			// if (oViewModel.getData().EstatTxt !== "INPROGRESS") {
			if (AppType !== "View") {
				this.getView().byId("addInternal").setEnabled(true);
			}
			var oContext = this.getView().getModel().getData().HeaderData.addiFildRowCont;
			var popUpData = this.getView().byId("idLineItemInternal").getModel("oInternalFragmentModel").getData();
			var sIndiaIndiactor = this.getView().byId("idIFcheck").getSelected();
			if (sIndiaIndiactor === true) {
				popUpData.Inind = "X";
			}
			popUpData.Vbegdat = this.dateFormatter(popUpData.Vbegdat);
			popUpData.Venddat = this.dateFormatter(popUpData.Venddat);
			popUpData.minEndDate = this.dateFormatter(popUpData.minEndDate);
			popUpData.SavePopup = 'X';
			this.getView().getModel("localModel").setProperty(oContext.getPath(), popUpData);
			sap.ui.core.BusyIndicator.hide();
			MessageToast.show("WBS Element details saved successfully.");
			this.onCloseInternalPopup(evt);
		},

		// onValidBtnPress: function () {
		// 	var that = this;
		// 	var draftData;
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var sMandatory = this.onSubEnable();
		// 	// sMandatory = "";
		// 	if (sMandatory === "No") {
		// 		sap.ui.core.BusyIndicator.hide();
		// 		MessageToast.show("Please fill all the mandatory fields!!!");
		// 	} else {
		// 		if (oViewModel.getData().oAppType === "ChangeProject") {
		// 			draftData = this.onGetData("VALIDATE", oViewModel.getData().Requestid);
		// 		} else {
		// 			draftData = this.onGetData("VALIDATE");
		// 		}
		// 		draftData.d.WBSRequestItemSet.results = this._fnRemoveFields(draftData.d.WBSRequestItemSet.results);
		// 		var oModel = this.getView().getModel("oDataModel");
		// 		oModel.create("/WBSRequestHeaderSet", draftData, {
		// 			success: function (oResponse) {
		// 				sap.ui.core.BusyIndicator.hide();
		// 				var sErrorLog = oResponse.WBSErrorSet.results.length;
		// 				if (sErrorLog === 0) {
		// 					sap.m.MessageToast.show("WBS request Validated Successfully.", {
		// 						duration: 5000
		// 					});
		// 					that.getView().byId("messBtn").setVisible(false);
		// 					oViewModel.getData().ReqID = oResponse.ReqNo;
		// 				} else {
		// 					sap.ui.core.BusyIndicator.hide();
		// 					sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
		// 						duration: 5000
		// 					});
		// 					that.getView().byId("messBtn").setVisible(true);
		// 					that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
		// 					oViewModel.getData().ReqID = oResponse.ReqNo;
		// 				}
		// 			},
		// 			error: function (oError, oResponse) {
		// 				sap.ui.core.BusyIndicator.hide();
		// 				sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
		// 					duration: 5000
		// 				});

		// 			}
		// 		});
		// 	}
		// },

		onValidBtnPress: function () {
			var that = this;
			var draftData;
			var oViewModel = this.getView().getModel("appView");
			var sMandatory = this.onSubEnable();
			// sMandatory = "";
			if (sMandatory === "No") {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please fill all the mandatory fields!!!");
			} else {
				if (oViewModel.getData().oAppType === "ChangeProject") {
					draftData = this.onGetData("VALIDATE", oViewModel.getData().Requestid);
				} else {
					draftData = this.onGetData("VALIDATE");
				}
				draftData.d.WBSRequestItemSet.results = this._fnRemoveFields(draftData.d.WBSRequestItemSet.results);
				var oModel = this.getView().getModel("oDataModel");
				oModel.create("/WBSRequestHeaderSet", draftData, {
					success: function (oResponse) {
						sap.ui.core.BusyIndicator.hide();
						var sErrorLog = oResponse.WBSErrorSet.results.length;

						if (sErrorLog === 0) {
							sap.m.MessageToast.show("WBS request Validated Successfully.", {
								duration: 5000
							});
							that.getView().byId("messBtn").setVisible(false);
							oViewModel.getData().ReqID = oResponse.ReqNo;
							// that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
							var wbsElement = that.getView().getModel("localModel").getProperty("/iwoTabTravel");
							// var oTable1 = this.getView().byId("idTable");
							for (var i = 0; i < wbsElement.length; i++) {
								wbsElement[i].IconColor = "S";
							}
							var oLocalModel = that.getView().getModel("localModel");
							that.getView().getModel().getData().errorResults = [];
							oLocalModel.refresh(true);

						} else {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageToast.show("WBS request Validated Successfully with Errors. Please check the error Logs.", {
								duration: 5000
							});
							that.getView().byId("messBtn").setVisible(true);
							that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
							oViewModel.getData().ReqID = oResponse.ReqNo;
							var wbsElement = that.getView().getModel("localModel").getProperty("/iwoTabTravel");
							// var oTable1 = this.getView().byId("idTable");
							for (var i = 0; i < wbsElement.length; i++) {
								var oWbsIcon = oResponse.WBSErrorSet.results.filter(function (a) {
									return Number(a.MsgN0) === Number(wbsElement[i].Posnr);
								});
								if (oWbsIcon.length > 0) {
									wbsElement[i].IconColor = "E"; // for phase2 table  Adding color  dynamically 
								} else {
									wbsElement[i].IconColor = "S";

									// for phase2 table  Adding color  dynamically 	
								}
							}
							that.getView().getModel("localModel").setProperty("/iwoTabTravel", wbsElement);
						}
					},
					error: function (oError, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
							duration: 5000
						});

					}
				});
			}
		},

		onSaveDraftBtnPress: function () {
			var that = this;
			this.getView().getModel("appView").setProperty("/isBusy", true);
			var oViewModel = this.getView().getModel("appView");
			var oCompanyCode = that.getView().byId("comCode").getValue();
			var oComCode1 = that.getView().getModel("oDataModel").getData("/SearchCompCodeSet(SysId='C1',Bukrs='" + oCompanyCode + "')");
			// if(oCompanyCode ===""){
			// 	var oComCode = that.getView().byId("comCode").getValue();
			// }

			if (!oComCode1) {
				sap.m.MessageToast.show("Please Enter a CompanyCode", {
					duration: 5000
				});
			} else {
				var sReqId = oViewModel.getData().Requestid;
				var draftData = this.onGetData("DRAFT", sReqId);
				var oModel = this.getView().getModel("oDataModel");
				oModel.create("/WBSRequestHeaderSet", draftData, {
					success: function (oResponse) {
						that.getView().getModel("appView").setProperty("/isBusy", false);
						var sErrorLog = oResponse.WBSErrorSet.results.length;
						if (sErrorLog === 0) {
							sap.m.MessageToast.show("WBS request Drafted Successfully. Request # " + oResponse.ReqNo, {
								duration: 5000
							});
							var oViewModel = that.getView().getModel("appView");
							that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
							oViewModel.getData().Requestid = oResponse.ReqNo;
							that.getView().getModel("appView").refresh(true);

							var attach = oResponse.WBSAttachSet.results.length;
							if (attach !== 0) {
								that.getView().getModel().setProperty("/WBSAttachSet", oResponse.WBSAttachSet.results);
							}
							oViewModel.getData().Requestid = "";
							that.onClearWBSData();
						} else {
							sap.m.MessageToast.show("Check the error log(s)", {
								duration: 5000
							});
							that.getView().byId("messBtn").setVisible(true);
							that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
						}
					},
					error: function (oError, oResponse) {
						that.getView().getModel("appView").setProperty("/isBusy", false);
						sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
							duration: 5000
						});
					}
				});

			}
		},

		onSubmitBtnPress: function () {
			var that = this;
			var sMandatory = this.onSubEnable();
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;

			var reqID = oViewModel.getData().Requestid;
			if (sMandatory === "No") {
				that.getView().getModel("appView").setProperty("/isBusy", false);
				MessageToast.show("Please fill all the mandatory fields!!!");
			} else {
				if (AppType === "ChangeProject") {
					var draftData = this.onGetData("C1CHGPROJ", reqID);
				} else {
					var draftData = this.onGetData("SUBMIT", reqID);
				}
				// var draftData = this.onGetData("SUBMIT", reqID);
				var oModel = this.getView().getModel("oDataModel");
				oModel.create("/WBSRequestHeaderSet", draftData, {
					success: function (oResponse) {
						that.getView().getModel("appView").setProperty("/isBusy", false);
						var oViewModel = that.getView().getModel("appView");
						var sErrorLog = oResponse.WBSErrorSet.results.length;
						if (sErrorLog === 0) {
							sap.m.MessageToast.show("WBS request Submited Successfully. Request # " + oResponse.ReqNo, {
								duration: 5000
							});
							that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
							oViewModel.getData().ReqID = oResponse.ReqNo;
							that.onClearWBSData();
						} else {
							that.getView().getModel("appView").setProperty("/isBusy", false);
							sap.m.MessageToast.show("Please check the error Log(s).", {
								duration: 5000
							});
							that.getView().byId("messBtn").setVisible(true);
							that.getView().getModel().getData().errorResults = oResponse.WBSErrorSet.results;
							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().ReqID = oResponse.ReqNo;
						}
					},
					error: function (oError, oResponse) {
						that.getView().getModel("appView").setProperty("/isBusy", false);
						sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
							duration: 5000
						});
					}
				});
			}
		},

		onGetData: function (action, sReqId) {
			var that = this;
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var sRevenueForm = this.getView().byId("SimpleFormChangewbs").getVisible();
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();

			var sPrjTyp = this.getView().byId("idProjTyp").getSelectedKey();
			var Comment = this.getView().byId("TypeHere").getValue();
			// Get array of Tokens
			var aTokens = this.getView().byId("wbsEmail").getTokens();
			// Get an array of the keys of the tokens and join them together with a "," inbetween
			var Email = aTokens.map(function (oToken) {
				return oToken.getKey();
			}).join(",");

			if (sRevenueForm === true) {
				var oType = oViewModel.getData().type;

				var oLength = window.location.href.split("#")[1].split("?").length;
				if (oLength > 1) {
					var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
					if (oLength1 === 1) {
						var oNav = window.location.href.split("#")[1].split("?")[1].split("=")[0];
					}
				}
				if (oType === "OpprAppC1" && oNav === "navAryy") {
					var sZBUKRS = this.getView().byId("idComCo2").getValue();
					var PayerK = this.getView().byId("idPayer").getValue();
					var sPayer = PayerK.split(" ")[0];
					var ShipK = this.getView().byId("idship").getValue();
					var sship = ShipK.split(" ")[0];
					var BillK = this.getView().byId("idbill").getValue();
					var sBill = BillK.split(" ")[0];
					var Sold = this.getView().byId("idSoldTo").getValue();
					var sSold = Sold.split(" ")[0];
					var sAGM = this.getView().byId("idAccMan").getSelectedKey();
					if (sAGM === "") {
						var AGM = this.getView().byId("idAccMan").getValue();
						if (AGM.length > 8) {
							sAGM = AGM.split("(")[1].split(")")[0];
						}

					}
					var sWBSOwner1 = this.getView().byId("idWBS1").getSelectedKey();
					if (sWBSOwner1 === "") {
						var WBSOwner1 = this.getView().byId("idWBS1").getValue();
						if (WBSOwner1.length > 8) {
							sWBSOwner1 = WBSOwner1.split("(")[1].split(")")[0];
						}

					}

					var sFinapp = this.getView().byId("idFinApp").getSelectedKey();
					if (sFinapp === "") {
						var Finapp = this.getView().byId("idFinApp").getValue();
						if (Finapp.length > 8) {
							sFinapp = Finapp.split("(")[1].split(")")[0];
						}

					}

				} else {
					var sAGM = this.getView().byId("idAccMan").getSelectedKey();
					var sWBSOwner1 = this.getView().byId("idWBS1").getSelectedKey();
					var sFinapp = this.getView().byId("idFinApp").getSelectedKey();
					var sPayerK = this.getView().byId("idPayer").getSelectedKey();
					var sShipK = this.getView().byId("idship").getSelectedKey();
					var sBillK = this.getView().byId("idbill").getSelectedKey();
					var sSold = this.getView().byId("idSoldTo").getSelectedKey();

					var sship = this.getView().byId("idship").getSelectedKey();
					if (sShipK) {
						var sship = this.getView().byId("idship").getSelectedKey();
					} else {
						var sship = this.getView().byId("idSoldTo").getSelectedKey();
					}

					var sZBUKRS = this.getView().byId("idComCo2").getValue();
					var sPayer = this.getView().byId("idPayer").getSelectedKey();
					if (sPayerK) {
						var sPayer = this.getView().byId("idPayer").getSelectedKey();
					} else {
						var sPayer = this.getView().byId("idSoldTo").getSelectedKey();
					}
					if (sBillK) {
						var sBill = this.getView().byId("idbill").getSelectedKey();
					} else {
						var sBill = this.getView().byId("idSoldTo").getSelectedKey();
					}
				}
				if (sSold === "") {
					sSold = this.getView().byId("idSoldTo").getValue();
					if (AppType) {
						if (sSold && sSold !== "00000000") {
							sSold = sSold.split(",")[0];
						}
					}
				}
				if (sship === "") {
					sship = this.getView().byId("idship").getValue();
					if (AppType) {
						if (sship && sship !== "00000000") {
							sship = sship.split(",")[0];
						}
					}
				}
				if (sPayer === "") {
					sPayer = this.getView().byId("idPayer").getValue();
					if (AppType) {
						if (sPayer && sPayer !== "00000000") {
							sPayer = sPayer.split(",")[0];
						}
					}
				}
				if (sBill === "") {
					sBill = this.getView().byId("idbill").getValue();
					if (AppType) {
						if (sBill && sBill !== "00000000") {
							sBill = sBill.split(",")[0];
						}
					}
				}
				var s1CheckSign = this.getView().byId("ch2").getSelected();
				if (s1CheckSign === true) {
					var sCheckSign;
					sCheckSign = "X";
				}
				var sSig = this.getView().byId("idSign").getValue();
				var sProjCu = this.getView().byId("idUSD").getValue();
				var sPONum = this.getView().byId("idpo").getValue();;
				var sPODate = this.getView().byId("dateCtrlPo").getDateValue();
				if (!sPODate) {

				} else {
					var sPodate = this.dateFormatter(sPODate);
				}

				var szterm = this.getView().byId("idPaymt").getValue();
				var sReason = this.getView().byId("idReason").getValue();;
				var sInvL = this.getView().byId("idInvLay").getSelectedKey();
				var sBilCal = this.getView().byId("idBillCal").getSelectedKey();
				var sDate = this.getView().byId("dateCtrlStr").getDateValue();
				var sContractStart = this.dateFormatter(sDate);
				var eDate = this.getView().byId("dateCtrlEnd").getDateValue();
				var sContractend = this.dateFormatter(eDate);
				var sWbsOwner2 = this.getView().byId("idWBS2").getSelectedKey();
				var sDraft = this.getView().byId("idDrftInv").getSelectedKey();
				// var sFinapp = this.getView().byId("idFinApp").getSelectedKey();
				var sPrjAc = this.getView().byId("idProAc").getSelectedKey();
				var sBds = this.getView().byId("idBillStw").getSelectedKey();
				var sinvRc = this.getView().byId("idInv").getSelectedKey();
				if (sPrjAc === "") {
					var sPrjAc = this.getView().byId("idProAc").getValue();
					if (sPrjAc.length > 8) {
						var sPrjAc = sPrjAc.split("(")[1].split(")")[0];
					}
				}
				if (sBds === "") {
					var gBds = this.getView().byId("idBillStw").getValue();
					if (gBds.length > 8) {
						var sBds = gBds.split("(")[1].split(")")[0];
					}
				}

				if (sinvRc === "") {
					var gInvc = this.getView().byId("idInv").getValue();
					if (gInvc.length > 8) {
						var sinvRc = gInvc.split("(")[1].split(")")[0];
					}
				}
				var sKtxt = this.getView().byId("idProjDes").getValue();

				if (AppType) {
					var sInvL = this.getView().byId("idInvLay").getValue();
					if (sInvL && sInvL !== "00000000") {
						sInvL = sInvL.slice(0, 2);
					}
				}

				if (AppType) {
					var sBilCal = this.getView().byId("idBillCal").getValue();
					if (sBilCal && sBilCal !== "00000000") {
						sBilCal = sBilCal.slice(0, 2);
					}
				}

				if (sAGM === "") {
					sAGM = this.getView().byId("idAccMan").getValue();
					if (AppType) {
						if (sAGM.length > 8 && sAGM !== "00000000") {
							sAGM = sAGM.split("(")[1].split(")")[0];
						}
					}
				}
				if (sWBSOwner1 === "") {
					sWBSOwner1 = this.getView().byId("idWBS1").getValue();
					if (AppType) {
						if (sWBSOwner1.length > 8 && sWBSOwner1 !== "00000000") {
							sWBSOwner1 = sWBSOwner1.split("(")[1].split(")")[0];
						}
					}
				}
				if (sWbsOwner2 === "") {
					sWbsOwner2 = this.getView().byId("idWBS2").getValue();
					if (AppType) {
						if (sWbsOwner2.length > 8 && sWbsOwner2 !== "00000000") {
							sWbsOwner2 = sWbsOwner2.split("(")[1].split(")")[0];
						}
					}
				}
				if (sDraft === "") {
					sDraft = this.getView().byId("idDrftInv").getValue();
					if (AppType) {
						if (sDraft.length > 8 && sDraft !== "00000000") {
							sDraft = sDraft.split("(")[1].split(")")[0];
						}
					}
				}
				if (sFinapp === "") {
					sFinapp = this.getView().byId("idFinApp").getValue();
					if (AppType) {
						if (sFinapp.length > 8 && sFinapp !== "00000000") {
							sFinapp = sFinapp.split("(")[1].split(")")[0];
						}
					}
				}
				if (sPrjAc === "") {
					sPrjAc = this.getView().byId("idProAc").getValue();
					if (AppType) {
						if (sPrjAc.length > 8 && sPrjAc !== "00000000") {
							sPrjAc = sPrjAc.split("(")[1].split(")")[0];
						}
					}
				}
				if (sBds === "") {
					sBds = this.getView().byId("idBillStw").getValue();
					if (AppType) {
						if (sBds.length > 8 && sBds !== "00000000") {
							sBds = sBds.split("(")[1].split(")")[0];
						}
					}
				}
				if (sinvRc === "") {
					sinvRc = this.getView().byId("idInv").getValue();
					if (AppType) {
						if (sinvRc.length > 8 && sinvRc !== "00000000") {
							sinvRc = sinvRc.split("(")[1].split(")")[0];
						}
					}
				}
			} else if (sInternalForm === true) {
				var sPrjSub = this.getView().byId("idSubTyp").getSelectedKey();
				var oType = oViewModel.getData().type;
				var oLength = window.location.href.split("#")[1].split("?").length;
				if (oLength > 1) {
					var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
					if (oLength1 === 1) {
						var oNav = window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy";
					}
				}
				if (oType === "OpprAppC1" && oNav === "navAryy") {
					var Sold = this.getView().byId("idIntSold").getValue();
					var sSold = Sold.split(" ")[0];
					var sAGM = this.getView().byId("idAccManInt").getSelectedKey();
					if (sAGM === "") {
						var AGM = this.getView().byId("idAccManInt").getValue();
						if (AGM.length > 8) {
							sAGM = AGM.split("(")[1].split("(")[1].split(")")[0];
						}

					}
					var sWBSOwner1 = this.getView().byId("idWBS1Int").getSelectedKey();
					if (sWBSOwner1 === "") {
						var WBSOwner1 = this.getView().byId("idWBS1Int").getValue();
						if (WBSOwner1.length > 8) {
							sWBSOwner1 = WBSOwner1.split("(")[1].split(")")[0];
						}

					}
					var sFinapp = this.getView().byId("idFinAppInt").getSelectedKey();
					if (sFinapp === "") {
						var Finapp = this.getView().byId("idFinAppInt").getValue();
						if (Finapp.length > 8) {
							sFinapp = Finapp.split("(")[1].split(")")[0];
						}

					}
				} else {
					var sAGM = this.getView().byId("idAccManInt").getSelectedKey();
					var sWBSOwner1 = this.getView().byId("idWBS1Int").getSelectedKey();
					var sFinapp = this.getView().byId("idFinAppInt").getSelectedKey();

					var sSold = this.getView().byId("idIntSold").getSelectedKey();
					if (!AppType) {
						if (sSold === "") {
							var sSold = this.getView().byId("idIntSold").getValue();
						}
					}

				}

				if (sSold === "") {
					sSold = this.getView().byId("idIntSold").getValue();
					if (AppType) {
						sSold = sSold.split(",")[0];
					}
				}

				var sKtxt = this.getView().byId("idProIntDs").getValue();
				var sZBUKRS = this.getView().byId("idComFormInt").getValue();
				var sProjCu = this.getView().byId("idUSDInt").getValue();
				// var szterm = this.getView().byId("idPaymtInt").getValue();
				var sDateInt = this.getView().byId("idStarInt").getDateValue();
				var sContractStart = this.dateFormatter(sDateInt);
				var eDateInt = this.getView().byId("idEndInt").getDateValue();
				var sContractend = this.dateFormatter(eDateInt);
				var sWbsOwner2 = this.getView().byId("idWBS2Int").getSelectedKey();
				var sDraft = this.getView().byId("idDr").getSelectedKey();
				// var sFinapp = this.getView().byId("idFinAppInt").getSelectedKey();
				var sPrjAc = this.getView().byId("idProAcInt").getSelectedKey();
				if (sPrjAc === "") {
					var sPrjAc = this.getView().byId("idProAcInt").getValue();
					if (sPrjAc.length > 8) {
						var sPrjAc = sPrjAc.split("(")[1].split(")")[0];
					}
				}

				if (sAGM === "") {
					sAGM = this.getView().byId("idAccManInt").getValue();
					if (AppType) {
						if (sAGM.length > 8 && sAGM !== "00000000") {
							sAGM = sAGM.split("(")[1].split(")")[0];
						}
					}
				}
				if (sWBSOwner1 === "") {
					sWBSOwner1 = this.getView().byId("idWBS1Int").getValue();
					if (AppType) {
						if (sWBSOwner1.length > 8) {
							sWBSOwner1 = sWBSOwner1.split("(")[1].split(")")[0];
						}
					}
				}
				if (sWbsOwner2 === "") {
					sWbsOwner2 = this.getView().byId("idWBS2Int").getValue();
					if (AppType) {
						if (sWbsOwner2.length > 8) {
							sWbsOwner2 = sWbsOwner2.split("(")[1].split(")")[0];
						}
					}
				}
				if (sDraft === "") {
					sDraft = this.getView().byId("idDr").getValue();
					if (AppType) {
						if (sDraft.length > 8 && sDraft !== "00000000" && sDraft !== "") {
							sDraft = sDraft.split("(")[1].split(")")[0];
						}
					}
				}
				if (sFinapp === "") {
					sFinapp = this.getView().byId("idFinAppInt").getValue();
					if (AppType) {
						sFinapp = sFinapp.split("(")[1].split(")")[0];
					}
				}
				if (sPrjAc === "") {
					sPrjAc = this.getView().byId("idProAcInt").getValue();
					if (AppType) {
						sPrjAc = sPrjAc.split("(")[1].split(")")[0];
					}
				}

			}
			var oViewModel = this.getView().getModel("appView");
			var oProjectIDChangeReq = that.oZpspid;
			if ((AppType === "ChangeRequest" || AppType === "BILLRej" || AppType === "CSIRej") && oProjectIDChangeReq !== "") {
				var projid = that.oZpspid;
				var oContractID = that.oZvbeln;
				var oZentry_tp = that.Zentry_tp;
			}
			//warranty 27/01/22 AppType === "OpprAppC1Mng"
			if (AppType === "ChangeProject" || AppType === "OpprAppC1Mng") {
				var projid = oViewModel.getData().ZProjectID;
				var oContractID = that.oContractID;
				sReqId = "";
			}

			var draftData = {
				"d": {
					"ReqNo": sReqId,
					"Zbukrs": sZBUKRS,
					"Zpspid": projid,
					"Zvbeln": oContractID,
					"Soldto": sSold,
					"Payer": sPayer,
					"ShipTo": sship,
					"BillTo": sBill,
					"Ktext": sKtxt,
					"PrjTyp": sPrjTyp,
					"PrjStp": sPrjSub,
					"ZriskInd": sCheckSign,
					"ZzCasId": sSig,
					"Waers": sProjCu,
					"Bstnk": sPONum,
					"Bstdk": sPodate,
					"Zterm": szterm,
					"ZPtReason": sReason,
					"Vtweg": "10",
					"Spart": "10",
					"Kvgr1": sInvL,
					"Perfk": sBilCal,
					"Guebg": sContractStart,
					"Gueen": sContractend,
					"Agm": sAGM,
					"Wbsowner1": sWBSOwner1,
					"Wbsowner2": sWbsOwner2,
					"DraftIa": sDraft,
					"FinApp": sFinapp,
					"PrjAc": sPrjAc,
					"Bds": sBds,
					"InvRec": sinvRc,
					"Zentry_tp": oZentry_tp,
					"Action": action,
					"WBSRequestItemSet": {
						"results": [{

						}]
					},
					"WBSRequestDetails": {
						"results": [{
							"ReqNum": "",
							"Zbukrs": sZBUKRS,
							"ProjTyp": sPrjTyp,
							"Email": Email,
							"ReqCom": Comment,
							"Zflag": ""
						}]
					},
					"WBSReqStatusDetSet": {
						"results": []
					},
					"WBSLaborTypeSet": {
						"results": []
					},
					"WBSTaskSet": {
						"results": []
					},
					"WBSErrorSet": {
						"results": []
					},
					"WBSAttachSet": {
						"results": []
					},
					"WBSLaborTypeItemSet": {
						"results": []
					}
				}
			};
			//Download and Upload
			var tab1toAttach = this.getView().getModel().getData().WBSAttachSet;
			draftData.d.WBSAttachSet.results = tab1toAttach;
			//Begin of Changes Srini vallepu  Scenario2 -  UnComment after commit
			var type = oViewModel.getData().type;
			var oLength = window.location.href.split("#")[1].split("?").length;
			if (oLength > 1) {
				var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
				if (oLength1 === 1) {
					var oNav = window.location.href.split("#")[1].split("?")[1].split("=")[0];
				}
			}
			if (type === "OpprAppC1" || oNav === "navAryyManage") {
				draftData.d.WBSRequestDetails.results[0].Zflag = "X";
			}

			var L3 = this.getView().getModel().getData().taskData;

			var sTableData = this.getView().getModel("localModel").getData().iwoTabTravel;
			var L1 = this.getTableData(sTableData);

			if (AppType === "ChangeProject") {
				//delete  L1.Prart;
				for (var i = 0; i < L1.length; i++) {
					delete L1[i].Prart;
					delete L1[i].__metadata;
					delete L1[i].SysId;
					delete L1[i].toC1Labor;
					delete L1[i].toC1LaborItems;
					delete L1[i].toC1Tasks;
				}
			}

			L1 = this._fnRemoveFields(L1);
			var sHeaderLaborData = this.getView().getModel().getData().laborData;
			var L2 = this.getLaborData(sTableData, sHeaderLaborData);

			var L3 = this.getTaskData(sTableData);

			draftData.d.WBSRequestItemSet.results = L1;
			draftData.d.WBSLaborTypeSet.results = L2;
			draftData.d.WBSTaskSet.results = L3;
			return draftData;
		},

		getTableData: function (sData) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var tableData = jQuery.extend(true, [], sData);

			for (var i = 0; i < tableData.length; i++) {
				if (!AppType) {
					if (tableData[i].Zentry_tp === "N") {
						var sZentry_tp = "";
						tableData[i].Zentry_tp = sZentry_tp;
					}
				}

				if (!tableData[i].PayerKey && tableData[i].payerName !== "" && tableData[i].payerName !== undefined && tableData[i].payerName.length >
					8) {
					tableData[i].Payer = tableData[i].payerName.substring(0, 10).split(" ")[0];
				} else {
					tableData[i].Payer = tableData[i].PayerKey;
				}

				if (tableData[i].ShipToKey !== "" && tableData[i].shipToName !== undefined && tableData[i].shipToName.length > 8) {
					tableData[i].ShipTo = tableData[i].shipToName.substring(0, 10).split(" ")[0];
				} else {
					tableData[i].ShipTo = tableData[i].ShipToKey;
				}

				if (tableData[i].BillToKey !== "" && tableData[i].billToName !== undefined && tableData[i].billToName.length > 8) {
					tableData[i].BillTo = tableData[i].billToName.substring(0, 10).split(" ")[0];
				} else {
					tableData[i].BillTo = tableData[i].BillToKey;
				}

				if (tableData[i].Agm !== "" && tableData[i].Agm !== undefined && tableData[i].Agm.length > 8) {
					tableData[i].Agm = tableData[i].Agm.split("(")[1].split(")")[0];
				}
				if (tableData[i].Wbsowner1 !== "" && tableData[i].Wbsowner1 !== undefined && tableData[i].Wbsowner1.length > 8) {
					tableData[i].Wbsowner1 = tableData[i].Wbsowner1.split("(")[1].split(")")[0];
				}
				if (tableData[i].Wbsowner2 !== "" && tableData[i].Wbsowner2 !== undefined && tableData[i].Wbsowner2.length > 8) {
					tableData[i].Wbsowner2 = tableData[i].Wbsowner2.split("(")[1].split(")")[0];
				}
				if (tableData[i].FinApp !== "" && tableData[i].FinApp !== undefined && tableData[i].FinApp.length > 8) {
					tableData[i].FinApp = tableData[i].FinApp.split("(")[1].split(")")[0];
				}
				if (tableData[i].DraftIa !== "" && tableData[i].DraftIa !== undefined && tableData[i].DraftIa.length > 8) {
					tableData[i].DraftIa = tableData[i].DraftIa.split("(")[1].split(")")[0];
				}
				if (tableData[i].PrjAc !== "" && tableData[i].PrjAc !== undefined && tableData[i].PrjAc.length > 8) {
					tableData[i].PrjAc = tableData[i].PrjAc.split("(")[1].split(")")[0];
				}
				if (tableData[i].Bds !== "" && tableData[i].Bds !== undefined && tableData[i].Bds.length > 8) {
					tableData[i].Bds = tableData[i].Bds.split("(")[1].split(")")[0];
				}
				if (tableData[i].InvRec !== "" && tableData[i].InvRec !== undefined && tableData[i].InvRec.length > 8) {
					tableData[i].InvRec = tableData[i].InvRec.split("(")[1].split(")")[0];
				}
				if (tableData[i].task && tableData[i].task.length > 0) {
					tableData[i].taskFlg = "X";
				}

				if (tableData[i].labor && tableData[i].labor.length > 0) {
					tableData[i].laborFlg = "X";
				}
				if (tableData[i].labor) {
					delete tableData[i].labor;
				}
				if (tableData[i].task) {
					delete tableData[i].task;
				}

				tableData[i].Vbegdat = tableData[i].Vbegdat ? this.dateFormatter(tableData[i].Vbegdat) : null;
				tableData[i].Venddat = tableData[i].Venddat ? this.dateFormatter(tableData[i].Venddat) : null;
				tableData[i].Bstdk = tableData[i].Bstdk ? this.dateFormatter(tableData[i].Bstdk) : null;
				tableData[i].CaseSafeId = tableData[i].CaseSafeId;
			}
			return tableData;
		},

		getLaborData: function (sTableData, sHeaderLaborData) {
			var itemlabor = jQuery.extend(true, [], sTableData);
			var s = [];
			for (var i = 0; i < itemlabor.length; i++) {
				if (itemlabor[i].labor) {
					var sLaborLength = itemlabor[i].labor.length;
					for (var a = 0; a < sLaborLength; a++) {
						var data = {
							"Reqno": itemlabor[i].Requestnumber,
							"Posnr": itemlabor[i].Posnr,
							"Kschl": "ZIAP",
							"Zmatnr": itemlabor[i].labor[a].Zmatnr,
							"Datab": this.dateFormatter(itemlabor[i].labor[a].Datab),
							"Datbi": this.dateFormatter(itemlabor[i].labor[a].Datbi),
							"Zentry_lab": itemlabor[i].labor[a].Zentry_lab
						};
						s.push(data);
					}
				}
			}

			var headerlabor = jQuery.extend(true, [], sHeaderLaborData);
			for (var i = 0; i < headerlabor.length; i++) {
				var data = {
					"Reqno": headerlabor[i].Requestnumber,
					"Kschl": "ZHAP",
					"Zmatnr": headerlabor[i].Zmatnr,
					"Datab": this.dateFormatter(headerlabor[i].Datab),
					"Datbi": this.dateFormatter(headerlabor[i].Datbi),
					"Zentry_lab": headerlabor[i].Zentry_lab
				};
				s.push(data);
			}
			return s;
		},

		getTaskData: function (sTableData) {
			var taskData = jQuery.extend(true, [], sTableData);
			var sTask = [];
			for (var i = 0; i < taskData.length; i++) {
				if (taskData[i].task) {
					var sTaskLength = taskData[i].task.length;
					for (var a = 0; a < sTaskLength; a++) {
						var data = {
							"Reqno": taskData[i].Requestnumber,
							"Posnr": taskData[i].Posnr,
							"Task": taskData[i].task[a].Task,
							"Begda": this.dateFormatter(taskData[i].task[a].Begda),
							"Endda": this.dateFormatter(taskData[i].task[a].Endda),
							"Tasktext": taskData[i].task[a].Tasktext,
							"Pspri": taskData[i].task[a].Pspri,
							"Zentry_tsk": taskData[i].task[a].Zentry_tsk
						};
						sTask.push(data);
					}
				}
			}
			return sTask;
		},

		onHeaderLaborPress: function (oEvent) {
			var that = this;
			var oModel = that.getView().getModel();
			var oView = that.getView();
			if (!that._oDialogHLB) {
				// create dialog via fragment factory
				that._oDialogHLB = sap.ui.xmlfragment(that.createId("idLabourType"), "WBS.C1.WbsC1Request.fragments.LabourType", that);
				oView.addDependent(that._oDialogHLB);
			}
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			if (AppType) {
				that._oDialogHLB.setModel(oModel);
			}
			that._oDialogHLB.open();

			if ((AppType === "ChangeProject") || (AppType === "ChangeRequest" && this.oHeaderType === true)) {
				oViewModel.getData().FrasDateDis = "oDateEdit";
				oViewModel.getData().FrasDis = "oDisplay";
				oViewModel.getData().FrasBtn = "oEdit";
				that.getView().getModel("appView").refresh(true);
			}

			var slaborData;
			if (this.HeaderLabourRowClick === "Click") {
				slaborData = this.HeaderAddRowData;
			} else {
				slaborData = this.getView().getModel().getData().laborData;
			}

			for (var i = 0; i < slaborData.length; i++) {
				slaborData[i].Datab = this.dateFormatter(slaborData[i].Datab);
				slaborData[i].Datbi = this.dateFormatter(slaborData[i].Datbi);
				if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View") {
					sap.ui.core.Fragment.byId(this.createId("idLabourType"), "idLaborTable").getItems()[i].getCells()[1].setEditable(false);
					sap.ui.core.Fragment.byId(this.createId("idLabourType"), "idLaborTable").getItems()[i].getCells()[2].setEditable(false);
					sap.ui.core.Fragment.byId(this.createId("idLabourType"), "idLaborTable").getItems()[i].getCells()[3].setEditable(false);
				}
			}
			if (AppType === "CSIReview" || AppType === "BILLReview" || AppType === "View" || AppType === "BILLRej") {
				oViewModel.getData().FrasDis = "oDisplay";
				oViewModel.getData().FrasBtn = "oDisplay";
				that.getView().getModel("appView").refresh(true);
			}
		},

		onHeaderLaborChange: function (evt) {
			var sLaborTypeKey = evt.getSource().getSelectedKey();
			if (!sLaborTypeKey) {
				evt.getSource().setValue("");
			}
		},

		onHeaderLaberSave: function (evt) {
			this.onCancel(evt);
		},

		onItemLaborSave: function (evt) {
			sap.ui.core.Fragment.byId(this.createId("idItemLaborType"), "idItemLaborSave").setEnabled(false);
			this.onItemLaborCancel();
		},

		// onTaskChange: function (evt) {
		// 	var aRows = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems().length;
		// 	var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>? ";
		// 	for (var i = 0; i < aRows; i++) {
		// 		var sTaskId = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].getValue();
		// 		var sTaskDesc = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[3].getValue();

		// 		for (var a = 0; a < sTaskDesc.length; a++) {
		// 			if (s.indexOf(sTaskDesc.charAt(a)) !== -1) {
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[3].setValueState("Error");
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[3].setValueStateText(
		// 					"Special characters are not allowed");
		// 			} else {
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[3].setValueState("None");
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[3].setValueStateText("None");
		// 			}
		// 		}

		// 		for (var b = 0; b < sTaskId.length; b++) {
		// 			if (s.indexOf(sTaskId.charAt(b)) !== -1) {
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].setValueState("Error");
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].setValueStateText(
		// 					"Special characters are not allowed");
		// 			} else {
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].setValueState("None");
		// 				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].setValueStateText("None");

		// 			}
		// 		}
		// 	}
		// },
		toUpperCase: function (oEvent) {
			var aRows = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getModel("taskFragmodel").getData().task.length;
			for (var i = 0; i < aRows; i++) {
				var str = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getContextByIndex(i).getObject().Task.toUpperCase();
				sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getContextByIndex(i).getObject().Task = str;
			}
		},
		onSettoUppercase: function () {
			var oFormTaskData = this._oAddTaskLabor.getModel("AddtaskFragmodel").getData();
			var oFormTaskId = oFormTaskData.Task.toUpperCase();
			this._oAddTaskLabor.getModel("AddtaskFragmodel").getData().Task = oFormTaskId;

		},
		// toUpperCase: function (oEvent) {
		// 	var aRows = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems().length;
		// 	for (var i = 0; i < aRows; i++) {
		// 		var str = sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].getValue().toUpperCase();
		// 		sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskTable").getItems()[i].getCells()[2].setValue(str);
		// 	}
		// },
		onTaskIdChange: function (evt) {
			var str = evt.getParameter("value").toUpperCase();
			var sControlId = evt.getParameter("id");
			// str.toUpperCase();
			var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
			for (var i = 0; i < str.length; i++) {
				if (s.indexOf(str.charAt(i)) != -1) {
					sap.ui.getCore().byId(sControlId).setValueState("Error");
					sap.ui.getCore().byId(sControlId).setValueStateText("Special characters are not allowed");
				} else {
					sap.ui.getCore().byId(sControlId).setValueState("None");
					sap.ui.getCore().byId(sControlId).setValueStateText("None");
				}
			}
		},
		// onTaskIdChange: function (evt) {
		// 	var str = evt.getParameter("value").toUpperCase();
		// 	var sControlId = evt.getParameter("id");
		// 	// str.toUpperCase();
		// 	var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
		// 	for (var i = 0; i < str.length; i++) {
		// 		if (s.indexOf(str.charAt(i)) != -1) {
		// 			sap.ui.getCore().byId(sControlId).setValueState("Error");
		// 			sap.ui.getCore().byId(sControlId).setValueStateText("Special characters are not allowed");
		// 		}
		// 	}
		// },
		onTaskDescChange: function (evt) {
			var str = evt.getParameter("value");
			var sControlId = evt.getParameter("id");
			var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
			for (var i = 0; i < str.length; i++) {
				if (s.indexOf(str.charAt(i)) != -1) {
					sap.ui.getCore().byId(sControlId).setValueState("Error");
					sap.ui.getCore().byId(sControlId).setValueStateText("Special characters are not allowed");
				} else {
					sap.ui.getCore().byId(sControlId).setValueState("None");
					sap.ui.getCore().byId(sControlId).setValueStateText("None");
				}
			}
		},
		// onTaskDescChange: function (evt) {
		// 	var str = evt.getParameter("value");
		// 	var sControlId = evt.getParameter("id");
		// 	var s = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
		// 	for (var i = 0; i < str.length; i++) {
		// 		if (s.indexOf(str.charAt(i)) != -1) {
		// 			sap.ui.getCore().byId(sControlId).setValueState("Error");
		// 			sap.ui.getCore().byId(sControlId).setValueStateText("Special characters are not allowed");
		// 		}
		// 	}
		// },
		onTaskSelect: function (oEvent) {
			var oViewModel = this.getView().getModel("appView");
			var AppType = oViewModel.getData().oAppType;
			var bFlag;
			var oselectedTask = oEvent.getSource().getSelectedIndices();
			if (AppType === "BILLRej" || AppType === "CSIReview" || AppType === "View" || AppType === "BILLReview") {
				bFlag = false;
			} else {
				bFlag = true;
			}

			if (oselectedTask.length > 0) {
				if (AppType === "ChangeRequest" || AppType === "ChangeProject" || !AppType) {
					for (var i = 0; i < oselectedTask.length; i++) {
						// if (!oselectedTask[i].getObject().Zentry_tsk || oselectedTask[i].getObject().Zentry_tsk === 'N' || oselectedTask[i].getObject().Zentry_tsk ===
						// 	'') {
						// 	continue;
						// } else {
						// 	bFlag = false;
						// 	break;
						// }
						//this.oItemContext.getObject().task[oEvent.getSource().getSelectedIndices()[0]].Zentry_tsk
						if (!this.oItemContext.getObject().task[oEvent.getSource().getSelectedIndices()[i]].Zentry_tsk || this.oItemContext.getObject().task[
								oEvent.getSource().getSelectedIndices()[i]].Zentry_tsk === "N" || this.oItemContext.getObject().task[oEvent.getSource().getSelectedIndices()[
								i]].Zentry_tsk === "") {
							continue;
						} else {
							bFlag = false;
							break;
						}
					}
				}
			} else {
				bFlag = false;
			}

			sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskDelte").setEnabled(bFlag);

		},
		// onTaskSelect: function (oEvent) {
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var AppType = oViewModel.getData().oAppType;
		// 	var bFlag;
		// 	var oselectedTask = oEvent.getSource().getSelectedContexts();
		// 	if (AppType === "BILLRej" || AppType === "CSIReview") {
		// 		bFlag = false;
		// 	} else {
		// 		bFlag = true;
		// 	}

		// 	if (oselectedTask.length > 0) {
		// 		if (AppType === "ChangeRequest" || AppType === "ChangeProject" || !AppType) {
		// 			for (var i = 0; i < oselectedTask.length; i++) {
		// 				if (!oselectedTask[i].getObject().Zentry_tsk || oselectedTask[i].getObject().Zentry_tsk === 'N' || oselectedTask[i].getObject().Zentry_tsk ===
		// 					'') {
		// 					continue;
		// 				} else {
		// 					bFlag = false;
		// 					break;
		// 				}
		// 			}
		// 		}
		// 	} else {
		// 		bFlag = false;
		// 	}

		// 	sap.ui.core.Fragment.byId(this.createId("idTask"), "idTaskDelte").setEnabled(bFlag);

		// },
		onTaskSave: function (evt) {
			this.onTaskLaborCancel();
		},

		dateFormatter: function (sDate) {
			try {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
				});
				if (sDate) {
					sDate = new Date(sDate);
					var n = sDate.getTimezoneOffset() / 60;
					if (Math.sign(n) === -1) {
						var oDate1 = dateFormat.format(new Date(sDate));
						var startDateObject = new Date(oDate1);
						var sFormatDate = startDateObject;
						return sFormatDate;
					} else {
						return sDate;
					}
				} else {
					return null;
				}
			} catch (exception) {
				return sDate;
			}

		},
		onDeleteInternalTravel: function () {
			var oTable = this.getView().byId("idInternal");
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().statusCode;
			if (type === "E0001") {
				var that = this;
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Are you sure you want to delete ?"
					}),
					beginButton: new sap.m.Button({
						text: "Ok",
						press: function () {
							var aContexts = oTable.getSelectedIndices();
							if (aContexts.length < 1) {
								MessageToast.show("Please Select Atleast One Row!!!");
							} else {
								//--> loop backward from the selected Rows
								for (var i = aContexts.length - 1; i >= 0; i--) {
									var idx = aContexts[i];
									var oModel = that.getView().getModel("localModel");
									var itab = oModel.getProperty("/iwoTabTravel");
									itab.splice(idx, 1);
									oModel.setProperty("/iwoTabTravel", itab);
								}
								oTable.clearSelection();

								MessageToast.show("Successfully Deleted the Record.");

							}
							dialog.close();

							var sRowCount = that.getView().byId("idInternal").getBinding("rows").getLength();
							var oPrvalue = 0;
							for (var i = 0; i < sRowCount; i++) {
								var oEnType = that.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Zentry_tp;
								if (oEnType === "E") {
									oPrvalue = that.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Posnr;

								} else {
									oPrvalue = parseInt(oPrvalue, 10) + 1;
									var sSeqNum = String(oPrvalue).padStart(6, '0');
									that.getView().byId("idInternal").getModel("localModel").getData().iwoTabTravel[i].Posnr = sSeqNum;
								}
							}
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
						that.getView().getModel("appView").setProperty("/count", that.getView().getModel("localModel").getProperty("/iwoTabTravel").length);
					}
				});
				dialog.open();
			} else {
				if (oTable.getSelectedIndices().length <= 1) {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: new sap.m.Text({
							text: "Are you sure you want to delete ?"
						}),
						beginButton: new sap.m.Button({
							text: "Ok",
							press: function () {
								var aContexts = oTable.getSelectedIndices();
								if (aContexts.length < 1) {
									MessageToast.show("Please Select Atleast One Row!!!");
								} else {
									var idx = oTable.getSelectedIndices()[0];
									var oModel1 = that.getView().byId("idTravel").getModel("localModel");
									var IwoguidItem = oModel1.getData().iwoTabTravel[idx].IwoguidItem;
									var Iwo = oModel1.getData().iwoTabTravel[idx].Iwo;
									var Requestid = oModel1.getData().iwoTabTravel[idx].Requestid;
									if (IwoguidItem) {
										var oModel = that.getView().getModel("oDataModel");
										var sPath1 = "/IWOOtherSet(Requestid='" + Requestid + "',Iwo='" + Iwo + "',IwoguidItem='" + IwoguidItem + "')";
										oModel.remove(sPath1, {
											success: function (oResponse) {
												sap.ui.core.BusyIndicator.hide();
												sap.m.MessageToast.show("Successfully Deleted IWO Record.", {
													duration: 5000
												});
												for (var i = aContexts.length - 1; i >= 0; i--) {
													var idx = aContexts[i];
													var oModel = that.getView().getModel();
													var itab = oModel.getProperty("/iwoTabTravel");
													itab.splice(idx, 1)
														// itab.push(itemRow);
													oModel.setProperty("/iwoTabTravel", itab);
												}
												oTable.clearSelection();
											},
											error: function (oError) {
												sap.ui.core.BusyIndicator.hide();
												var msg = oError.responseText.split('"value":"')[1].split('"},')[0];
												sap.m.MessageToast.show(msg, {
													duration: 5000
												});
											}
										});
										dialog.close();
									} else {
										for (var i = aContexts.length - 1; i >= 0; i--) {
											var idx = aContexts[i];
											var oModel = that.getView().getModel();
											var itab = oModel.getProperty("/iwoTabTravel");
											itab.splice(idx, 1);
											oModel.setProperty("/iwoTabTravel", itab);

										}
										oTable.clearSelection();
										MessageToast.show("Successfully Deleted IWO Record.");
									}
								}
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
				} else {
					MessageToast.show("Please Select Only One Row!!!");
				}
			}
		},

		removeText: function (sValue) {
			if (sValue === undefined) {
				var sField = "";
			} else {
				sField = sValue.split("(")[0];
			}
			return sField;
		},

		onClearWBSData: function () {
			var oModel = this.getView().getModel().getData();
			this.getView().byId("idIconTabBar").setSelectedKey("1");
			oModel.HeaderData = [];

			var sRevenueForm = this.getView().byId("SimpleFormChangewbs").getVisible();
			var sInternalForm = this.getView().byId("SimpleFormInternal").getVisible();

			this.getView().byId("idProjTyp").setSelectedKey();
			this.getView().byId("idSubTyp").setSelectedKey();
			this.getView().byId("TypeHere").setValue();
			this.getView().byId("wbsEmail").setTokens([]);
			this.getView().byId("fileUploader").setValue();
			oModel.WBSAttachSet = [];

			if (sRevenueForm === true) {
				this.getView().byId("idSoldTo").setSelectedKey();
				this.getView().byId("idship").setSelectedKey();
				this.getView().byId("idbill").setSelectedKey();
				this.getView().byId("idPayer").setSelectedKey();
				this.getView().byId("idSign").setValue();
				this.getView().byId("idpo").setValue();
				this.getView().byId("dateCtrlPo").setValue();
				this.getView().byId("idPaymt").setValue();
				this.getView().byId("idReason").getValue();
				this.getView().byId("idInvLay").setValue();
				this.getView().byId("idBillCal").setSelectedKey();
				this.getView().byId("dateCtrlStr").setValue();
				this.getView().byId("dateCtrlEnd").setValue();
				this.getView().byId("idAccMan").setSelectedKey();
				this.getView().byId("idWBS1").setSelectedKey();
				this.getView().byId("idWBS2").setSelectedKey();
				this.getView().byId("idDrftInv").setSelectedKey();
				this.getView().byId("idFinApp").setSelectedKey();
				this.getView().byId("idProAc").setSelectedKey();
				this.getView().byId("idBillStw").setSelectedKey();
				this.getView().byId("idInv").setSelectedKey();
				this.getView().byId("idProjDes").setValue();

			} else if (sInternalForm === true) {
				this.getView().byId("idIntSold").setSelectedKey();
				this.getView().byId("idProIntDs").setValue();
				this.getView().byId("idComFormInt").setValue();
				this.getView().byId("idUSDInt").setValue();
				this.getView().byId("idStarInt").setValue();
				this.getView().byId("idEndInt").setValue();
				this.getView().byId("idAccManInt").setSelectedKey();
				this.getView().byId("idWBS1Int").setSelectedKey();
				this.getView().byId("idWBS2Int").setSelectedKey();
				this.getView().byId("idDr").setSelectedKey();
				this.getView().byId("idFinAppInt").setSelectedKey();
				this.getView().byId("idProAcInt").setSelectedKey();
			}
			oModel.iwoTabTravel = [];
			oModel.laborData = [];
			oModel.itemLaborData = [];
			oModel.wbsRevenue = [];
			oModel.wbsInternal = [];
		},

		onBrowse: function (oEvent) {
			var oFileUploader = this.getView().byId("fileUploader");
			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first");
				return;
			} else {
				sap.ui.core.BusyIndicator.show(0);
				var file = [];
				this.browsePayload = [];
				var name = [];
				var type = [];
				var domRef = oFileUploader.getFocusDomRef();

				for (var i = 0; i < domRef.files.length; i++) {
					file[i] = domRef.files[i];
					name[i] = file[i].name;
					type[i] = file[i].type;
					var reader = new FileReader();
					reader.readAsDataURL(file[i]);
				}

				var oModel = this.getView().getModel("appView");
				var Owner = oModel.getData().Owner;
				var projType = this.getView().byId("idProjTyp").getSelectedKey();
				var timeStamp = new Date();

				var attachment = this.getView().getModel().getData().WBSAttachSet;
				reader.onload = function (event) {

					for (var i = 0; i < domRef.files.length; i++) {
						// get an access to the content to the file
						var vContent = event.currentTarget.result;
						//  phase1 production  bug  for  msg.
						if (type[i] === "") {
							var fileData = vContent.split(";base64,")[1];
						} else {
							var dataRemove = "data:" + type[i] + ";base64,";
							var fileData = vContent.replace(dataRemove, "");
						}
						// var dataRemove = "data:" + type[i] + ";base64,";
						// var fileData = vContent.replace(dataRemove, "");
						//end  of changes for  pridction bug ,sg file 
						var length = attachment.length;

						for (var j = 0; j < length; j++) {
							if (name[i] === attachment[j].Filename) {
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show("You have selected the same file again  " + name[i]);
								this.flag = true;
								return;
							} else {
								if (j === attachment.length - 1 && this.flag !== true) {
									attachment.push({
										"Reqid": "",
										"Projty": projType,
										"Filename": name[i],
										"Mimetype": type[i],
										"Data": fileData,
										"Ernam": Owner,
										"Timestamp": timeStamp
									});
								}
							}
						}
						if (i === 0 && attachment.length === 0) {
							attachment.push({
								"Reqid": "",
								"Projty": projType,
								"Filename": name[i],
								"Mimetype": type[i],
								"Data": fileData,
								"Ernam": Owner,
								"Timestamp": timeStamp
							});
						}
					}
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("File successfully uploaded. Please see the attachment section for the uploaded files.");
				};
			}
		},

		onPressAttachment: function (oEvent) {
			this.getView().byId("fileUploader").setValue("");
			var oView = this.getView();
			var oDialog = oView.byId("idAttachment");
			if (!oDialog) {
				var oModel = this.getView().getModel();
				this.getView().setModel(oModel);
				oDialog = sap.ui.xmlfragment("idAttachment", "WBS.C1.WbsC1Request.fragments.downloadAttac", this);
				oView.addDependent(oDialog);
			}
			oDialog.open();
		},

		onDeleteAttach: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext().sPath;
			var index = sPath.slice(sPath.length - 1);
			var attachment = this.getView().getModel().getData().WBSAttachSet;
			var reqNumber = attachment[index].Reqid;
			//var fileName = attachment[index].Filename; 
			var Attachid = attachment[index].Attachid;
			if (attachment[index].Reqid) {
				var oDataModel = this.getView().getModel("oDataModel");
				var sPath1 = "/WBSAttachSet(Reqid='" + reqNumber + "',Attachid='" + Attachid + "')";
				var that = this;
				oDataModel.remove(sPath1, {
					success: function (oResponse) {
						sap.ui.core.BusyIndicator.hide();
						attachment.splice(index, 1);
						var oModel = that.getView().getModel();
						oModel.refresh();
						sap.m.MessageToast.show("Attachment Deleted sucessfully.", {
							duration: 5000
						});
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
							duration: 5000
						});
					}
				});
			} else {
				attachment.splice(index, 1);
				var oModel = this.getView().getModel();
				oModel.refresh();
			}
		},

		onDownladAttach: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext().sPath;
			var index = sPath.slice(sPath.length - 1);
			var attachment = this.getView().getModel().getData().WBSAttachSet;
			var reqNumber = attachment[index].Reqid;
			//var fileName = attachment[index].Filename;
			var Attachid = attachment[index].Attachid;

			var sUrl = "/sap/opu/odata/sap/ZODATA_WBS_REQ_C1_PH2_SRV/WBSAttachSet(Reqid='" + reqNumber + "',Attachid='" + Attachid +
				"')/$value";
			var httpUrl = window.location.href.split("/sap/")[0];
			var strUrl = httpUrl + sUrl;
			window.open(strUrl);
		},

		// Scenario2 :  Begin of changes by Srinivas vallepu
		onLoadOppData: function (obj) {
			this.getView().getModel().setProperty("/toOpprData", obj);
			var comCode = obj[0].Zbukrs;
			var oppID = obj[0].OptId;
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Opp_HeaderSet(Optid='" + oppID + "',Bukrs='" + comCode + "')", {
				success: function (oData, oResponse) {
					that.getView().getModel().setProperty("/wbsRevenue/Wbsowner1", oData.Perresp);
					that.getView().getModel().setProperty("/wbsInternal/Wbsowner1", oData.Perresp);
					that.getView().getModel().setProperty("/wbsRevenue/Agm", oData.Actgm);
					that.getView().getModel().setProperty("/wbsInternal/Agm", oData.Actgm);
					that.getView().getModel().setProperty("/wbsInternal/FinApp", oData.FinAnl);
					that.getView().getModel().setProperty("/wbsRevenue/FinApp", oData.FinAnl);
					that.getView().getModel().setProperty("/wbsRevenue/Guebg", new Date(oData.Guebg));
					that.getView().getModel().setProperty("/wbsInternal/Guebg", new Date(oData.Guebg));
					that.getView().getModel().setProperty("/wbsInternal/Gueen", new Date(oData.Gueen));
					that.getView().getModel().setProperty("/wbsRevenue/Gueen", new Date(oData.Gueen));
					that.byId("idEndInt").setMinDate(oData.Guebg);
					that.byId("dateCtrlEnd").setMinDate(oData.Guebg);
					that.getView().getModel().setProperty("/wbsRevenue/Ktext", oData.Zpspid);
					that.getView().getModel().setProperty("/wbsInternal/Ktext", oData.Zpspid);
					that.getView().getModel().setProperty("/wbsRevenue/Soldto", oData.CustName);
					that.getView().getModel().setProperty("/wbsRevenue/Payer", oData.CustName);
					that.getView().getModel().setProperty("/wbsRevenue/ShipTo", oData.CustName);
					that.getView().getModel().setProperty("/wbsRevenue/BillTo", oData.CustName);
					that.getView().getModel().setProperty("/wbsInternal/Soldto", oData.CustName);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		onSelectSafecaseID: function (obj) {
			var oModel = this.getView().getModel("oDataModel");
			var oppID = obj[0].OptId;
			var aFilters = [];
			for (var i = 0; i < obj.length; i++) {
				aFilters.push(new sap.ui.model.Filter("CaseSafeId", sap.ui.model.FilterOperator.Contains, obj[i].CasesafeId));

			}
			aFilters.push(new sap.ui.model.Filter([
				new sap.ui.model.Filter("Optid", sap.ui.model.FilterOperator.Contains, oppID)
			], false));
			var that = this;
			oModel.read("/SearchCaseSafeIdSet", {
				filters: aFilters,
				success: function (oResponse) {
					var oSafecase = new JSONModel(oResponse);
					that.getView().setModel(oSafecase, "oIntCaseSafeModel");
					that.getView().setModel(oSafecase, "oCaseSafeModel");

				},
				error: function (oError) {}
			});
		},
		onLoadChangeProjectOppdata: function (Zpspid, TYPE, obj) {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			that.aAgm = "X";
			that.aWbsowner1 = "X";
			that.aWbsowner2 = "X";
			that.aFinApp = "X";
			that.aPrjAc = "X";
			that.aDraftIa = "X";
			that.aBds = "X";
			that.aInvRec = "X";
			that.aVbegdat = "X";
			that.aVenddat = "X";

			var oViewModel = this.getView().getModel("appView");
			this.getView().getModel("appView").refresh(true);

			this.oManageRequestModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
			var oModel = this.getView().getModel("oDataModel");
			this.oManageRequestModel.read("/ManageProjectC1Set('" + Zpspid + "')", {
				urlParameters: {
					'$expand': "toManageItemC1"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
					}
					var Zvbeln = oData.Zvbeln;
					var Zpspid = oData.Zpspid;
					that.onLoadItemLabourProject(Zpspid, Zvbeln);
					var Zposid = oData.toManageItemC1.results[0].Zposid;
					that.onLoadTaskProject(Zpspid, Zposid);
					that.getView().byId("idContractNo").setVisible(true);
					oViewModel.getData().OriginatorName = "";
					that.oContractID = oData.Zvbeln;
					oViewModel.getData().Contractid = that.oContractID;

					oViewModel.getData().RequestorEmail = "";
					if (!oData.ChangedOn) {
						oViewModel.getData().ReqDate = "";
					} else {
						oViewModel.getData().ReqDate = oData.ChangedOn.toDateString();
					}
					that.getView().getModel("appView").refresh(true);
					var sCode = oData.Zbukrs;
					var sTerm = oData.Zterm;
					that.getView().byId("comCode").setValue(sCode);
					that.getView().byId("idComCo2").setValue(sCode);
					that.getView().byId("idPaymt").setValue(sTerm);
					if (oData.Email) {
						var oEmail = oData.Email;
						var aLen = oEmail.length;
						if (aLen != 0) {
							var data = oEmail.split(",");
							var tokenValue = [];
							for (var i = 0; i < data.length; i++) {
								tokenValue.push(new Token({
									text: data[i],
									key: data[i]
								}));
							}
							var oMultiInput1 = that.getView().byId("wbsEmail");
							oMultiInput1.setTokens(tokenValue);
						}
					}
					var prjType = oData.toManageItemC1.results[0].Prart;
					var oProjectBox = that.getView().byId("idProjTyp");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.EQ, sCode)
						],
						and: true
					});
					oBindingBox.filter(aFilters);

					if (prjType === "RV") {
						prjType = "ZBC";
					} else if (prjType === "GB") {
						prjType = "ZCGC";
					} else if (prjType === "LT" || prjType === "OH" || prjType === "ST" || prjType === "BP" || prjType ===
						"SU" || prjType === "SB" || prjType === "BS" || prjType === "BN") {
						prjType = "ZPRJ";
					}
					that.getView().byId("idProjTyp").setSelectedKey(prjType);
					var key = that.getView().byId("idProjTyp").getSelectedKey();
					//item  cat code 

					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Auart", sap.ui.model.FilterOperator.EQ, key)
						],
						and: false
					});
					oModel.read("/SearchItemCatSet", {
						filters: [aFilters],
						success: function (oData) {
							var oBillModel = new sap.ui.model.json.JSONModel(oData);
							that.getView().setModel(oBillModel, "oBillModel");
						},
						error: function (oError) {}
					});

					//item cat code
					// //Tab 2

					if (key === "ZPRJ") {
						sap.m.MessageToast.show("Internal Project Selected", {
							duration: 5000
						});
						that.getView().byId("SimpleFormInternal").setVisible(true);
						that.getView().byId("SimpleFormChangewbs").setVisible(false);
						that.getView().byId("subTyp").setVisible(true);
						that.getView().byId("idSubTyp").setVisible(true);
						if (TYPE === "CSIReview" || TYPE === "BILLReview" || TYPE === "View" || TYPE === "ChangeProject") {
							that.getView().byId("idSubTyp").setEditable(false);
						}

						that.getView().byId("idInternal").setVisible(true);
						that.getView().byId("idTravel").setVisible(false);

						//Tab 1	
						var sSubType = oData.PrjStp;
						that.getView().byId("idSubTyp").setSelectedKey(sSubType);
						//================ Internal Form =====================
						that.getView().getModel().getData().wbsInternal.Ktext = oData.Ktext;
						that.getView().byId("idComFormInt").setValue(sCode);
						that.getView().getModel().getData().wbsInternal.Waers = oData.Waers;
						var sPrjCur = oData.Waers;
						that.getView().byId("idUSDInt").setValue(sPrjCur);
						that.getView().getModel().getData().wbsInternal.Zterm = oData.Zterm;
						that.getView().getModel().getData().wbsInternal.Guebg = oData.Guebg;
						that.getView().getModel().getData().wbsInternal.Gueen = oData.Gueen;

					} else {
						sap.m.MessageToast.show("Revenue Project Selected", {
							duration: 5000
						});
						if (key === "ZBC" || key === "ZCGC") {
							that.getView().byId("SimpleFormInternal").setVisible(false);
							that.getView().byId("SimpleFormChangewbs").setVisible(true);
							that.getView().byId("subTyp").setVisible(false);
							that.getView().byId("idSubTyp").setVisible(false);
							that.getView().byId("idInternal").setVisible(false);
							that.getView().byId("idTravel").setVisible(true);

							that.getView().getModel().getData().wbsRevenue.Ktext = oData.Ktext;
							if (oData.ZriskInd === "X") {
								oData.ZriskInd = true;
								that.getView().byId("ch2").setSelected(oData.ZriskInd);
								that.getView().byId("idSign").setRequired(false);

							}
							that.getView().getModel().getData().wbsRevenue.ZriskInd = oData.ZriskInd;
							that.getView().getModel().getData().wbsRevenue.ZzCasId = oData.ZzCasId;
							that.getView().getModel().getData().wbsRevenue.Bstnk = oData.Bstnk;
							var sProCur = oData.Waers;
							that.getView().byId("idUSD").setValue(sProCur);
							that.getView().getModel().getData().wbsRevenue.Bstdk = oData.Bstdk;

							var sPymntTerm = oData.Zterm;
							that.getView().byId("idPaymt").setValue(sPymntTerm);
							that.getView().getModel().getData().wbsRevenue.ZPtReason = oData.ZPtReason;
							that.getView().getModel().getData().wbsRevenue.Agm = oData.Agm;
							that.getView().getModel().getData().wbsRevenue.Guebg = oData.Guebg;
							that.getView().getModel().getData().wbsRevenue.Gueen = oData.Gueen;
						}

					}
					//OppID Disable warranty 1/25/22
					var oModelE = that.getView().getModel("oDataModel");
					if (prjType === "ZBC" || prjType === "ZCGC") {
						oModelE.read("/WBSHeaderChngFlgSet('" + prjType + "')", {
							success: function (oData, oResponse) {
								var eAgm = oData.Agm;
								if (eAgm === 'X') {
									that.getView().byId("idAccMan").setEditable(true);
								} else {
									that.getView().byId("idAccMan").setEditable(false);
								}

								// var eBds = oData.Bds;
								// if (eBds === 'X') {
								// 	that.getView().byId("idBillStw").setEditable(true);
								// } else {
								// 	that.getView().byId("idBillStw").setEditable(false);
								// }

								var eBillTo = oData.BillTo;
								if (eBillTo === 'X') {
									that.getView().byId("idbill").setEditable(true);
								} else {
									that.getView().byId("idbill").setEditable(false);
								}
								var eBstdk = oData.Bstdk; //PO Date
								if (eBstdk === 'X') {
									that.getView().byId("dateCtrlPo").setEditable(true);
								} else {
									that.getView().byId("dateCtrlPo").setEditable(false);
								}
								var eBstnk = oData.Bstnk; //PO Number
								if (eBstnk) {
									that.getView().byId("idpo").setEditable(true);
								} else {
									that.getView().byId("idpo").setEditable(false);
								}
								var eDraftIa = oData.DraftIa;
								if (eDraftIa === 'X') {
									that.getView().byId("idDrftInv").setEditable(true);
								} else {
									that.getView().byId("idDrftInv").setEditable(false);
								}
								var eFinApp = oData.FinApp;
								if (eFinApp === 'X') {
									that.getView().byId("idFinApp").setEditable(true);
								} else {
									that.getView().byId("idFinApp").setEditable(false);
								}
								var eGuebg = oData.Guebg;
								if (eGuebg === 'X') {
									that.getView().byId("dateCtrlStr").setEditable(true);
								} else {
									that.getView().byId("dateCtrlStr").setEditable(false);
								}
								var eGueen = oData.Gueen;
								if (eGueen === 'X') {
									that.getView().byId("dateCtrlEnd").setEditable(true);
								} else {
									that.getView().byId("dateCtrlEnd").setEditable(false);
								}
								// var eInvRec = oData.InvRec;
								// if (eInvRec === 'X') {
								// 	that.getView().byId("idInv").setEditable(true);
								// } else {
								// 	that.getView().byId("idInv").setEditable(false);
								// }
								var eKtext = oData.Ktext; //Project Description
								if (eKtext === 'X') {
									that.getView().byId("idProjDes").setEditable(true);
								} else {
									that.getView().byId("idProjDes").setEditable(false);
								}
								var eKvgr1 = oData.Kvgr1;
								if (eKvgr1 === 'X') {
									that.getView().byId("idInvLay").setEditable(true);
								} else {
									that.getView().byId("idInvLay").setEditable(false);
								}
								var ePayer = oData.Payer;
								if (ePayer === 'X') {
									that.getView().byId("idPayer").setEditable(true);
								} else {
									that.getView().byId("idPayer").setEditable(false);
								}
								var ePerfk = oData.Perfk;
								if (ePerfk === 'X') {
									that.getView().byId("idBillCal").setEditable(true);
								} else {
									that.getView().byId("idBillCal").setEditable(false);
								}
								// var ePrjAc = oData.PrjAc;
								// if (ePrjAc === 'X') {
								// 	that.getView().byId("idProAc").setEditable(true);
								// } else {
								// 	that.getView().byId("idProAc").setEditable(false);
								// }
								var eShipTo = oData.ShipTo;
								if (eShipTo === 'X') {
									that.getView().byId("idship").setEditable(true);
								} else {
									that.getView().byId("idship").setEditable(false);
								}
								// var eSoldto = oData.Soldto;
								// if (eSoldto === 'X') {
								// 	that.getView().byId("idSoldTo").setEditable(true);
								// } else {
								// 	that.getView().byId("idSoldTo").setEditable(false);
								// }
								// var eWaers = oData.Waers;
								// if (eWaers === 'X') {
								// 	that.getView().byId("idUSD").setEditable(true);
								// } else {
								// 	that.getView().byId("idUSD").setEditable(false);
								// }
								var eWbsowner1 = oData.Wbsowner1;
								if (eWbsowner1 === 'X') {
									that.getView().byId("idWBS1").setEditable(true);
								} else {
									that.getView().byId("idWBS1").setEditable(false);
								}
								var eWbsowner2 = oData.Wbsowner2;
								if (eWbsowner2 === 'X') {
									that.getView().byId("idWBS2").setEditable(true);
								} else {
									that.getView().byId("idWBS2").setEditable(false);
								}
								var eZPtReason = oData.ZPtReason;
								if (eZPtReason === 'X') {
									that.getView().byId("idReason").setEditable(true);
								} else {
									that.getView().byId("idReason").setEditable(false);
								}
								var eZterm = oData.Zterm;
								if (eZterm === 'X') {
									that.getView().byId("idPaymt").setEditable(true);
								} else {
									that.getView().byId("idPaymt").setEditable(false);
								}
								var eZzCasId = oData.ZzCasId;
								if (eZzCasId === 'X') {
									that.getView().byId("idSign").setEditable(true);
								} else {
									that.getView().byId("idSign").setEditable(false);
								}

							},
							error: function (oError, oResponse) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
									duration: 5000
								});
							}
						}); //Header Group A&B
						oModelE.read("/WBSItemChngFlgSet('" + prjType + "')", {

							success: function (oResponse) {
								// delete oResponse.__metadata;
								// delete oResponse.toItmChngFlg.__metadata;
								var EnableDesable = new JSONModel(oResponse);
								that.getView().setModel(EnableDesable, "EnableDesable");

								// var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
								// that.getView().setModel(toItmChngFlg, "toItmChngFlg");

								sap.ui.core.BusyIndicator.hide();
							},
							error: function (oError, oResponse) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
									duration: 5000
								});
							}
						}); //Item Group A&B
					}

					if (TYPE === "ChangeProject") {
						oData.toManageItemC1.results.forEach(function (oItem) {
							oItem.Zentry_tp = "E";
						});
						that.getView().getModel("localModel").setProperty("/iwoTabTravel", oData.toManageItemC1.results);
						var oRevRowIndex = that.getView().getModel().getData().iwoTabTravel.length;
						for (var i = 0; i < oRevRowIndex; i++) {
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Agm = oData.toManageItemC1.results[i].agmName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Bds = oData.toManageItemC1.results[i].bdsName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Wbsowner1 = oData.toManageItemC1.results[i].wbsowner1Name;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].Wbsowner2 = oData.toManageItemC1.results[i].wbsowner2Name;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].PrjAc = oData.toManageItemC1.results[i].prjAcName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].InvRec = oData.toManageItemC1.results[i].invRecName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].FinApp = oData.toManageItemC1.results[i].finAppName;
							that.getView().getModel("localModel").getData().iwoTabTravel[i].DraftIa = oData.toManageItemC1.results[i].draftIAName;
						}

						var oLoadProjRec = that.getView().getModel("localModel").getData().iwoTabTravel.length;
						for (var i = 0; i < oLoadProjRec; i++) {
							var oExistingRec = oData.toManageItemC1.results[i].Zentry_tp;
							if (oExistingRec === "E") {
								oViewModel.getData().FrasDis = "oEdit";
								oViewModel.getData().FrasBtn = "oEdit";
							}
						}
						var oRevRowIndex = that.getView().getModel("localModel").getData().iwoTabTravel.length;
						for (var i = 0; i < oRevRowIndex; i++) {
							var sPlannedRevenue = that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplnrev;
							// var sPlannedRevenue = that.getView().getModel().getProperty("/iwoTabTravel")[0].Zplnrev;
							var nRevStr = sPlannedRevenue.replace(/,/g, '');
							var oSplit = nRevStr.split(".");
							var sRevenueValue = nRevStr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
							that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplnrev = sRevenueValue;

						}
						//PlannedCost

						for (var i = 0; i < oRevRowIndex; i++) {
							var sPlannedCost = that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplncst;
							var nCostStr = sPlannedCost.replace(/,/g, '');
							var oSplit = nCostStr.split(".");
							var sCostValue = nCostStr.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
							that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].Zplncst = sCostValue;
							// var ItemLaborIconToolTip = oData.toManageItemC1.results[i].laborFlg;
							// var TaskIconToolTip = oData.toManageItemC1.results[i].taskFlg;
							// if (!ItemLaborIconToolTip && !TaskIconToolTip) {} else {
							// 	var LaborTooltipText = ItemLaborIconToolTip === "X" ? "ItemLabour Present ," : "";
							// 	that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].laborFlg = LaborTooltipText;

							// 	var TaskTooltipText = TaskIconToolTip === "X" ? "Task Present" : "";
							// 	that.getView().getModel("localModel").getProperty("/iwoTabTravel")[i].taskFlg = TaskTooltipText;
							// }
						}
						var iwotab = that.getView().getModel("localModel").getData().iwoTabTravel;
						for (var i = 0; i < iwotab.length; i++) {
							if (that.getView().getModel("localModel").getData().iwoTabTravel[i].Zentry_tp === "E") {
								that.getView().byId("Headerlabor").setEnabled(false);
								that.getView().byId("Itemlabor").setEnabled(false);
								that.getView().byId("tasks").setEnabled(false);
							}
						}
						var oAppType1 = "ChangeProject";
						that.onDisplayData(oAppType1);
					}
					var oModelExt = that.getView().getModel("localModel").getData().iwoTabTravel;
					var oExtline1 = oModelExt[0].Zentry_tp;
					if (oExtline1 === "E" || TYPE === "ChangeProject") {
						//To Change app  title 
						var oView1 = that.getView().getParent();
						oView1.getService("ShellUIService").then(
							function (oService) {
								oService.setTitle("Manage Project Request"); //warranty (Description Change)
							}
						);
						that.byId("HeaderID").setObjectTitle("Manage Project Request"); //warranty

						//
					} else {
						//To Change app  title 
						var oView1 = that.getView().getParent();
						oView1.getService("ShellUIService").then(
							function (oService) {
								oService.setTitle("New Project Request");
							}
						);
						that.byId("HeaderID").setObjectTitle("New Project Request");
						//
					}
					// if (oExtline1 === "E") {
					// 	//To Change app  title 
					// 	var oView1 = that.getView().getParent();
					// 	oView1.getService("ShellUIService").then(
					// 		function (oService) {
					// 			oService.setTitle("Manage Project Request");
					// 		}
					// 	);
					// 	that.byId("HeaderID").setObjectTitle("Manage Project Request");

					// 	//
					// } else {
					// 	//To Change app  title 
					// 	var oView1 = that.getView().getParent();
					// 	oView1.getService("ShellUIService").then(
					// 		function (oService) {
					// 			oService.setTitle("New Project Request");
					// 		}
					// 	);
					// 	that.byId("HeaderID").setObjectTitle("New Project Request");
					// 	//
					// }
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});

			var ReqNo = "";
			this.oManageRequestModel.read("/Customer_NameSet(ReqNo='" + ReqNo + "',Zpspid='" + Zpspid + "')", {
				success: function (oData1, oResponse1) {
					oViewModel.getData().Originator = oData1.Changedby;
					that.getView().getModel("appView").refresh(true);

					that.getView().getModel().getData().wbsInternal.Soldto = oData1.SoldTo;
					that.getView().getModel().getData().wbsInternal.Agm = oData1.AccGenMan;
					that.getView().getModel().getData().wbsInternal.Wbsowner1 = oData1.WbsOwnr1;
					that.getView().getModel().getData().wbsInternal.Wbsowner2 = oData1.WbsOwnr2;
					that.getView().getModel().getData().wbsInternal.FinApp = oData1.FinApp;
					that.getView().getModel().getData().wbsInternal.DraftIa = oData1.DraftInvApp;
					that.getView().getModel().getData().wbsInternal.PrjAc = oData1.ProAcc;
					// } else {
					that.getView().getModel().getData().wbsRevenue.Soldto = oData1.SoldTo;
					that.getView().getModel().getData().wbsRevenue.Payer = oData1.Payer;
					that.getView().getModel().getData().wbsRevenue.ShipTo = oData1.ShipTo;
					that.getView().getModel().getData().wbsRevenue.BillTo = oData1.BillTo;
					that.getView().getModel().getData().wbsRevenue.Kvgr1 = oData1.InvLay;
					that.getView().getModel().getData().wbsRevenue.Perfk = oData1.BillCal;
					that.getView().getModel().getData().wbsRevenue.Agm = oData1.AccGenMan;
					that.getView().getModel().getData().wbsRevenue.Wbsowner1 = oData1.WbsOwnr1;
					that.getView().getModel().getData().wbsRevenue.Wbsowner2 = oData1.WbsOwnr2;
					that.getView().getModel().getData().wbsRevenue.FinApp = oData1.FinApp;
					that.getView().getModel().getData().wbsRevenue.DraftIa = oData1.DraftInvApp;
					that.getView().getModel().getData().wbsRevenue.PrjAc = oData1.ProAcc;
					that.getView().getModel().getData().wbsRevenue.Bds = oData1.BillDataSte;
					that.getView().getModel().getData().wbsRevenue.InvRec = oData1.InvRec;

					sap.ui.core.BusyIndicator.hide();
					// }
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},
		onSelectcaseSafeID: function (oEvent) {
			var oRow = oEvent.getSource().getParent(); //Get Row
			var keyID = oEvent.getSource().getSelectedKey();
			// keyID.toString();
			var oTable = oRow.getParent(); // Get Table
			var iRowIndex = oTable.indexOfRow(oRow);
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().type;
			var oIwoTabTravel = this.getView().getModel("localModel").getProperty("/iwoTabTravel");
			var oLength = window.location.href.split("#")[1].split("?").length;
			if (oLength > 1) {
				var oLength1 = window.location.href.split("#")[1].split("?")[1].split("&").length;
				if (oLength1 === 1) {
					var oNav = window.location.href.split("#")[1].split("?")[1].split("=")[0];
					if (oNav === "navAryyManage") {
						jQuery.sap.require("jquery.sap.storage");
						var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
						var obj = oStorage.get("oppData") ? oStorage.get("oppData") : null;
						this.getView().getModel().setProperty("/toOpprData", obj);
					}
				}
			}
			if (type === "OpprAppC1" || oNav === "navAryyManage") {
				var oppData = this.getView().getModel().getProperty("/toOpprData");
				var oDataUp = oppData.filter(function (value) {
					return value.CasesafeId === keyID;

				});
				if (oDataUp.length !== 0) {
					var uniqID = oDataUp[0].UniqId;
					oIwoTabTravel[iRowIndex].UniqueId = uniqID;
				}

			}
		},
		_fnSetVisibleTrue: function (aFieldID) {
			for (var i = 0; i < aFieldID.length; i++) {
				if (this.getView().byId(aFieldID[i])) {
					this.getView().byId(aFieldID[i]).setVisible(true);
				}
			}
		},
		_fnSetVisibleFalse: function (aFieldID) {
			for (var i = 0; i < aFieldID.length; i++) {
				if (this.getView().byId(aFieldID[i])) {
					this.getView().byId(aFieldID[i]).setVisible(false);
				}
			}
		},

		_fnSetEditableFalse: function (aFieldID) {
			for (var i = 0; i < aFieldID.length; i++) {
				if (this.getView().byId(aFieldID[i])) {
					this.getView().byId(aFieldID[i]).setEditable(false);
				}
			}
		},

		_fnSetEditableTrue: function (aFieldID) {
			for (var i = 0; i < aFieldID.length; i++) {
				if (this.getView().byId(aFieldID[i])) {
					this.getView().byId(aFieldID[i]).setEditable(true);
				}
			}
		},
		//warrenty issue in ph2
		onfilenameLengthExceed: function () {
			MessageBox.show("Length of the file name should not be more than 100 characters ", sap.m.MessageBox.Icon.ERROR, "Error");
		},
		// Sceanario2 :  End of changes by Srinivas vallepu

		_fnRemoveFields: function (oData) {
			for (var i = 0; i < oData.length; i++) {
				delete oData[i].revItmBillCatValueState;
				delete oData[i].revMatnrValueState;
				delete oData[i].revOppIdValueState;
				delete oData[i].revPayTermValueState;
				delete oData[i].revPlanCostValueState;
				delete oData[i].revPlanRevValueState;
				delete oData[i].revRAKeyValueState;
				delete oData[i].revWbsDescValueState;
				delete oData[i].isRevenueMatEditable;
				delete oData[i].isRevRAKeyEditable;
				delete oData[i].oCaseSafeModel;
				delete oData[i].oIntCaseSafeModel;
				delete oData[i].oBillModel;
				delete oData[i].sug;
				delete oData[i].intItmBillCatValueState;
				delete oData[i].intPlanCostValueState;
				delete oData[i].intResCostValueState;
				delete oData[i].intWbsDescValueState;
				delete oData[i].SavePopup;
				delete oData[i].minEndDate;
				delete oData[i].PayerKey;
				delete oData[i].ShipToKey;
				delete oData[i].BillToKey;
				delete oData[i].IconColor;
				delete oData[i].oCount; // Ratnakumar added phase 3
				// delete oData[i].CaseSafeId;
			}
			return oData;
		}

	});
});