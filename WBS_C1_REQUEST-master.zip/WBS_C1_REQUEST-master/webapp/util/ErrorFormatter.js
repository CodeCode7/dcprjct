sap.ui.define(function () {
    "use strict";
    return {
        getIcon: function (sStatus) {
           switch (sStatus) {
			case "E":
				this.getParent().addStyleClass("errorIcon");
				return  'sap-icon://message-error' ;
			case "S":
				this.getParent().removeStyleClass("errorIcon");
				return 'sap-icon://message-error';
			default:
				this.getParent().removeStyleClass("errorIcon");
				return 'sap-icon://message-error';
			}
        }
    };
}, true);