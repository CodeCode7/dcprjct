sap.ui.define(["sap/m/Token"], function (Token) {
	"use strict";

	return {
		getNewRowColor: function (sStatus) {
			switch (sStatus) {
			case "N":
				return 'Success';
			case "C":
				return 'Warning';
			case "E":
				return 'Information';
			default:
			}
		},
		//Phase 2 Enable Disable
		ChanProjEditEnableTaskDes: function (sValue1) {
			// if (sValue1 === "DLFL") {
			// 	return false;
			// } else if (sValue1 !== "DLFL" && sValue2 === "X") {
			// 	return true;
			// } else if (sValue2 !== "X") {
			// 	return false;
			// } else {
			// 	return true;
			// }
			if (sValue1 === "X") {
				return true;
			} else {
				return false;
			}
		},
		ChanProjEditEnableTakDesc: function (sValue1, sValue2) {
			if (sValue1 === "DLFL") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},

		ChanProjEditEnableTaskSD: function (sValue1, sValue2) {
			if (sValue1 === "DLFL") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditEnableTaskED: function (sValue1, sValue2) {
			if (sValue1 === "DLFL") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditEnableTaskPryty: function (sValue1, sValue2) {
			if (sValue1 === "DLFL") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditEnableLaborSD: function (sValue1, sValue2) {
			if (sValue1 === "DLFL") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return false;
			}
		},
		//(vinodh) return chnged true to false
		ChanProjEditEnableLaborED: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else if (sValue3 === "oDateEdit") {
				return true;
			} else {
				return false;
			}
		},
		//(vinodh) return chnged true to false
		ChanProjEditEnableArtx: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditZsfdcOppid: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditItem: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditSDate: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD" || sValue1 === "TECO") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditEDate: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD" || sValue1 === "TECO") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditPlndRev: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditPlndCst: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		// ChanProjEditCaseID: function (sValue1) {
		// 	if (sValue1 === "DLFL" || sValue1 === "CLSD") {
		// 		return false;
		// 	} else {
		// 		return true;
		// 	}
		// },
		ChanProjEditCaseID: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditDIP: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditZterm: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditEnableItemBillCat: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N" && sValue2 === "") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}

		},
		ChanProjEditEnableRAKey: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N" && sValue2 === "") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}

		},

		ChanProjEditEnableMat: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}

		},
		ChanProjEditWBS: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditIndia: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditPo: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditPoDate: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditCost: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditPCS: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditIFSC: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditIFSCDes: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditStatusLine: function (sValue1) {
			if (sValue1 === "DLFL") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditPayer: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditShip: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditBill: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditAgm: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditWBS1: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditWBS2: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditFinapp: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEditDraftInv: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjStatusLineInt: function (sValue) {
			if (sValue === "DLFL") {
				return false;
			} else {
				return true;
			}
		},
		// ChanProjStatusLineInt: function (sValue1, sValue2) {
		// 	if (sValue1 === "DLFL" || sValue1 === "CLSD") {
		// 		return false;
		// 	} else if (sValue1 !== "DLFL" && sValue2 === "X") {
		// 		return true;
		// 	} else if (sValue2 !== "X") {
		// 		return false;
		// 	} else {
		// 		return true;
		// 	}
		// },
		//Internal
		ChanProjEnIntFkstl: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjEnIntArtx: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjStartInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD" || sValue1 === "TECO") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjEndInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD" || sValue1 === "TECO") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjPland: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjOppIdInt: function (sValue1, sValue2) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjPCSInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjIFCSInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjIFCSDInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjLegacyInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjIndInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjAgmInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjWBS1Int: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjWBS2Int: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjDrafVInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChangeProjPrAcInt: function (sValue1, sValue2, sValue3, sValue4) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD" && sValue4 !== "CSIReview") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue4 === "CSIReview") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}

		},
		ChangeProjFinAppInt: function (sValue1, sValue2, sValue3) {
			if (sValue1 === "DLFL" || sValue1 === "CLSD") {
				return false;
			} else if (sValue1 !== "DLFL" && sValue2 === "X") {
				return true;
			} else if (sValue3 === "N") {
				return true;
			} else if (sValue2 !== "X") {
				return false;
			} else {
				return true;
			}
		},
		ChanProjStatusCLSD: function (sValue) {
			if (sValue === "oStatusDisable") {
				return false;
			} else {
				return true;
			}
		},
		//End
		ProjectAdmin: function (sValue) {
			/*below code for Input fields*/
			if (sValue) {
				var m = this.getView().byId("idSoldTo").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},

		getMessageType: function (sStatus) {
			switch (sStatus) {
			case "S":
				return 'Success';
			case "E":
				return 'Error';
			case "W":
				return 'Warning';
			case "I":
				return 'Information';
			default:
				return 'Error';
			}
		},

		RowIconVisible: function (sValue1, sValue2, sValue3) {
			if ((sValue1 && sValue1.length > 0) || (sValue2 && sValue2.length > 0)) {
				return true;
			} else if (sValue3 === "E") {
				return true;
			} else {
				return false;
			}
		},
		itemDateDisable: function (sValue) {
			switch (sValue) {
			case "oDateDisplay":
				return false;
			case "oDateEdit":
				return false;
			default:
				return false;
			}
		},
		// (vinodh) case:oDateEdit changed false to true
		columnDisabled: function (sValue) {
			switch (sValue) {
			case "oDisplay":
				return false;
			case "oEdit":
				return true;
			default:
				return true;
			}
		},

		PopColumnDisabled: function (sValue) {
			switch (sValue) {
			case "E":
				return false;
			case "N":
				return false;
			default:
				return true;
			}
		},

		getMessageTypeRow: function (sStatus) {
			switch (sStatus) {
			case "S":
				return 'Success';
			case "E":
				return 'Error';
			case "W":
				return 'Warning';
			case "I":
				return 'Information';
			default:
				return 'Information';
			}
		},
		ChanProjEdit: function (sValue) {
			switch (sValue) {
			case "E":
				return false;
			case "N":
				return true;
			default:
				return true;
			}
		},
		ChanOppIDEdit: function (sValue) {
			switch (sValue) {
			case "E":
				return false;
			case "N":
				return true;
			case "S":
				return false;
			default:
				return true;
			}
		},
		EnabledField: function (sValue) {
			var oViewModel = this.getView().getModel("appView");
			if (oViewModel !== undefined) {
				var AType = oViewModel.getData().editableType;
				if (AType === "V") {
					return false;
				} else {
					return true;
				}
			}
		},
		getmasterWBSCombo: function (sStatus) {
			var condi2 = window.location.href.split("#")[1].split("?")[1].split("&")[2].split("=")[1];
			// if (condi2 === "AdditionOfRes") {
			// 	return true;
			// }else{
			// 	return false;
			// }
		},
		twoDecimalValue: function (sValue) {
			var oValue;
			if (sValue === null) {
				oValue = "";
			} else {
				var num = parseFloat(sValue);;
				oValue = num.toFixed(2);
			}
			return oValue;
		},
		// removeDecimalValue: function (sValue) {
		// 	var nValue;
		// 	if (sValue) {
		// 		nValue = Math.round(sValue);
		// 		// return nValue;
		// 	} else {
		// 		nValue;

		// 	}
		// 		return nValue;
		// },
		AttachBtnEnabled: function (sValue) {
			if (sValue) {
				return true;
			} else {
				return false;
			}
		},
		getSowText: function (sStatus) {
			if (sStatus != null && sStatus != "") {
				var getData = this.getView().getModel("oSowAppView").oData;
				var json = getData.filter(function (a) {
					return a.Jobsubcat === sStatus;
				});
				return json[0].Jobsubcattext;
			}
		},
		multiInputFormat: function (args) {
			if (args != null) {
				// 				var text = args;
				// 				var n = args.split(",").length;
				// // 				var m = "00";
				// 				var m = new Token({key: args.split(",")[0], text: args.split(",")[0]});
				var appData = {
					tokens: [{
						text: "Deskjet Printer",
						key: "DP"
					}, {
						text: "LCD Display",
						key: "LCD"
					}]
				};

				var dataModel = new sap.ui.model.json.JSONModel(appData);

				return dataModel;

			}
		},
		dateFormat: function (sValue) {
			var str;
			if (sValue === null) {
				str = "";
			} else {
				str = sValue.substring(0, sValue.length - 1);
				str = str.substring(1);

				str = str.replace(/\D/g, "");
				var dt = new Date(eval(str));
				var oDateFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					format: "yMMMd"
				});
				str = oDateFormat.format(dt);
			}
			//sValue = sValue.replace("/", "");
			return str;

		},
		breakLineName: function (sStatus) {
			var m = sStatus;
			var name = "";
			if (sStatus === null || sStatus === undefined) {
				var name = "";
			} else {
				var n = m.split(",");
				for (var i = 0; i < n.length; i++) {
					var nameCount = i + 1;
					name = name + nameCount + ") " + n[i] + "\n"
				}
			}
			return name;
		},
		Soldto: function (sValue) {

			var m = this.getView().byId("idSoldTo").getSuggestionItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},

		CheckBoxClick: function (sValue) {
			if (sValue === "X") {
				return true;
			} else {
				return false;
			}
		},

		rowIconToolTip: function (labor, task) {
			var sText = "";
			if (labor && labor.length > 0) {
				sText = sText.concat("Item Labour present");
			}
			if (task && task.length > 0) {
				var sTooltip = sText.length > 0 ? ", Item Task Present" : "Item Task Present";
				sText = sText.concat(sTooltip);
			}
			return sText;
		},

		DateFormatTask: function (sDate) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			// var sDate = sValue;
			if (sDate) {
				var n = sDate.getTimezoneOffset() / 60;
				if (Math.sign(n) === 1) {
					var oDate1 = dateFormat.format(new Date(sDate));
					if (oDate1 === "9999-12-31") {
						return new Date(oDate1);
					}
					oDate1 = oDate1 + "T24:00:00";
					return new Date(oDate1);
				} else {
					var oDate1 = dateFormat.format(new Date(sDate));
					oDate1 = oDate1 + "T14:00:00";
					return new Date(oDate1);
				}
			}

		}
	};
});