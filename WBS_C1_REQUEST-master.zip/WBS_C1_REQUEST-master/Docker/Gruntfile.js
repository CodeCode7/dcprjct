module.exports = function (grunt) {
	"use strict";
	grunt.loadNpmTasks("@sap/grunt-sapui5-bestpractice-build");
	grunt.config.merge({
		compatVersion: "1.38"
	});
	grunt.registerTask("default", [
		"clean",
		"lint",
		"build"
	]);
	grunt.loadNpmTasks("@sap/grunt-sapui5-bestpractice-test");
	grunt.registerTask("unit_and_integration_tests", ["test"]);
	grunt.config.merge({
		coverage_threshold: {
			statements: 0,
			branches: 0,
			functions: 0,
			lines: 0
		}
	});
	grunt.config.merge({
		karma:{
			ci: {
			    browsers: ['ChromeHeadlessNoSandbox'],
			    customLaunchers: {
			      ChromeHeadlessNoSandbox: {
			        base: 'ChromeHeadless',
			        flags: ['--no-sandbox']
			      }
    },
			}
		}
	});
	var tmpDir = process.env.WORKSPACE + "/dist";
	var zipFileSuffix = "-abap.zip";
	grunt.loadNpmTasks("grunt-zip");
	grunt.registerTask("createZip", ["zip"]);
	grunt.config.merge({
		zip: {
			build: {
				cwd: tmpDir,
				src: tmpDir + "/**/*",
				dest: process.env.WORKSPACE + "/<%= pkg.name %>" + zipFileSuffix
			}
		}
	});
};