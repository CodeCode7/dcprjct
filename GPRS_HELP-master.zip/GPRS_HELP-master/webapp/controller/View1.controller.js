sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Text",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/ui/core/Item",
	"sap/ushell/services/UserInfo",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, Text, Fragment, JSONModel, Dialog, Item, UserInfo, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("gprsHelp.GPRS_HELP.controller.View1", {
		onInit: function () {

		},
		onBeforeRendering: function () {

			var tableModel = new JSONModel([]); //create and instatiate table json Model 
			this.getView().setModel(tableModel, "tableModel");
			this.fetchDataforTable();

		},

		fetchDataforTable: function () {

			var oModel = this.getView().getModel("ZODATA_WBS_HELP_SRV");
			var that = this;

			oModel.read("/WBS_HelpSet", {
				success: function (oData, oResponse) {

					var tableModel = that.getView().getModel("tableModel");
					var finalStack = [];
					for (var i = 0; i < oData.results.length; i++) { // change the seq num to display properly
						oData.results[i].dummySeq = i + 1; // instantiate a new dummy property just for sequence purposes
						finalStack.push(oData.results[i]);
					}

					tableModel.setData(finalStack);
					that.getAdministrator(); // get adminstrator data

				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					// that.getView().byId("idTable").setVisibleRowCount("10");
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}

			});

		},

		getAdministrator: function () { // fetch administrator

			var oModel = this.getView().getModel("ZODATA_WBS_HELP_SRV");
			var that = this;
			var oUser = new UserInfo();
			var ouserId = oUser.getId();
			// var ouserId = "11596835";

			oModel.read("/AdminCheckSet(" + "'" + ouserId + "'" + ")", {
				success: function (oResponse) {

					if (oResponse.Flag === "X") {
						that.getView().byId("buttadd").setVisible(true);
						that.getView().byId("buttedit").setVisible(true);
						that.getView().byId("buttdel").setVisible(true);

					} else {

						that.getView().byId("buttadd").setVisible(false);
						that.getView().byId("buttedit").setVisible(false);
						that.getView().byId("buttdel").setVisible(false);

					}

				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					// that.getView().byId("idTable").setVisibleRowCount("10");
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}

			});

		},

		openLink: function (oEvent) {
			window.location.replace(
				"https://dxcportal.sharepoint.com/sites/FinanceTransformationFPA/SitePages/Global-Project-WBS.aspx?OR=Teams-HL&CT=1629297557284&Mode=Edit"
			);
		},

		onCheckitem: function (oEvent) {

		},
		onAdd: function (oEvent) {

			var oView = this.getView();
			var oDialog = oView.byId("idDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "gprsHelp.GPRS_HELP.fragments.addrecord", this);
				oView.addDependent(oDialog);
			}
			oDialog.open();

		},
		onSaveAdd: function (oEvent) {

			var oModel = this.getView().getModel("ZODATA_WBS_HELP_SRV");
			var currlen = this.getView().byId("idHelpTable").getItems().length;

			if (currlen !== undefined || currlen > 0) {
				currlen = currlen + 1;
			}

			var gprstext = this.byId("iddesc").getValue();
			var reqpayload = {
				// "Seq_num": currlen.toString(),
				"Seq_num": "",
				"Text": gprstext
			};
			var that = this;
			oModel.create("/WBS_HelpSet", reqpayload, {
				success: function (oResponse) {
					debugger;
					that.getView().getModel("tableModel").refresh();
					var tabarr = that.getView().getModel("tableModel").getData();
					tabarr = tabarr.sort((a, b) => (a.dummySeq > b.dummySeq ? 1 : -1));
					var reqpayload = {
						"dummySeq": tabarr.length + 1,
						"Seq_num": oResponse.Seq_num,
						"Text": that.byId("iddesc").getValue()
					};

					tabarr.push(reqpayload);
					that.getView().getModel("tableModel").refresh();

					var oDialog = that.getView().byId("idadddialog");
					oDialog.close();
					oDialog.destroy();
					// that.onCancel(oEvt);
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					// that.getView().byId("idTable").setVisibleRowCount("10");
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
					// sap.m.MessageToast.show(oError.message +"\n" + oError.statusText + "\n" +oError.responseText, {
					// 	duration: 5000,
					// 	width: "35em"
					// });
				}
			});

		},

		onEdit: function (oEvent) {
			debugger;
			var selitem = this.getView().byId("idHelpTable").getSelectedItem();

			if (selitem !== null) {
				var seldata = selitem.getBindingContext("tableModel").getObject();
				var autoPop = new JSONModel({
					Seq_num: seldata.Seq_num,
					Text: seldata.Text,
				});
				this.getView().setModel(autoPop, "editItemModel");

				var oView = this.getView();
				var oDialog = oView.byId("idDialog");
				// create dialog lazily
				if (!oDialog) {
					// create dialog via fragment factory
					oDialog = sap.ui.xmlfragment(oView.getId(), "gprsHelp.GPRS_HELP.fragments.editrecord", this);
					oView.addDependent(oDialog);
				}
				oDialog.open();
			} else {

				sap.m.MessageToast.show("Please select a record to Edit", {
					duration: 5000
				});
			}

		},
		onDelete: function (oEvent) {
			var that = this;
			MessageBox.warning("Do you want to Delete this Record?", {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
					// MessageToast.show("Action selected: " + sAction);
					if (sAction !== "CANCEL") {
						that.onDeleteConfirm(oEvent);
					}
				}
			});
		},

		onDeleteConfirm: function (oEvent) {
			debugger;
			var oModel = this.getView().getModel("ZODATA_WBS_HELP_SRV");
			var selitem = this.getView().byId("idHelpTable").getSelectedItem();

			if (selitem !== null) {
				var seldata = selitem.getBindingContext("tableModel").getObject();
				var seqnum = seldata.Seq_num;
				var relpath = "/WBS_HelpSet(" + "Seq_num=" + "'" + seqnum + "'" + ")";
				var that = this;
				oModel.remove(relpath, {
					method: "DELETE",
					success: function (oData, oResponse) {
						debugger;
						that.fetchDataforTable();
					},
					error: function (e) {

					}
				});

			} else {
				sap.m.MessageToast.show("Please select a record to Delete!", {
					duration: 5000
				});
			}

		},
		onSaveRecord: function (oEvent) {
			var oModel = this.getView().getModel("ZODATA_WBS_HELP_SRV");

			var getSeqnum = this.getView().getModel("editItemModel").getData().Seq_num;
			var gprstext = this.getView().getModel("editItemModel").getData().Text;
			var reqpayload = {
				"Seq_num": getSeqnum,
				"Text": gprstext
			};
			var arr = this.getView().getModel("tableModel").getData();
			for (var i = 0; i < arr.length; i++) {
				if (arr[i].Seq_num === getSeqnum) {
					arr[i].Text = gprstext;
					break;
				}
			} // update tableModel
			var relpath = "/WBS_HelpSet(" + "Seq_num=" + "'" + getSeqnum + "'" + ")";
			var that = this;
			oModel.update(relpath, reqpayload, {
				method: "PUT",
				success: function (data) {

					that.getView().getModel("tableModel").refresh(true);
					that.getView().byId("idHelpTable").rerender();
					var oDialog = that.getView().byId("idEditDialog");
					oDialog.close();
					oDialog.destroy();
				},
				error: function (e) {

				}
			});

			oModel.refresh();

		},
		onCancel: function (oEvent) {
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			sap.ui.core.BusyIndicator.hide(); //UAT NCR - 341763
			oDailog.destroy();
		}

	});
});