sap.ui.define([
	"gprsHelp/GPRS_HELP/test/unit/controller/View1.controller"
], function () {
	"use strict";
});