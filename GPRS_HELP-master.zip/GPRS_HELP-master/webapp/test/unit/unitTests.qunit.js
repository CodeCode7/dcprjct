/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"gprsHelp/GPRS_HELP/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});