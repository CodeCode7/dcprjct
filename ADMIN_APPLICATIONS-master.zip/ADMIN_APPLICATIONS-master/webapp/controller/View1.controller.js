sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ushell/services/CrossApplicationNavigation"
], function (Controller, CrossApplicationNavigation) {
	"use strict";

	return Controller.extend("homepage.controller.View1", {
		pressICP: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "Initiate"
					}
				});

		},
		onApproverGroup: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "ApproverGroup"
					}
				});
		},
		onApprove: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OpenApprover"
					}
				});

		},
		onDelegation: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OpenDelegation"
					}
				});

			// OpenDelegation
		},
		onProjAcc: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OpenPA"
					}
				});

		},
		onInvRec: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OpenInvoice"
					}
				});

		},
		onBDS: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OpenBDS"
					}
				});

		},
		onWBSDefault: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "WBSDefault"
					}
				});

		},
		onWBSchAgent: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "chAgent"
					}
				});

		},
		onWorkflowAdmin: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "WFAdmin"
					}
				});

		},

		onOppidDefualt: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OppIdDefault"
					}
				});

		},
		onUploadVersion: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "upldVersn"
					}
				});

		},
		onGeneralSettings: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "gnrlSetgs"
					}
				});

		}

	});

});