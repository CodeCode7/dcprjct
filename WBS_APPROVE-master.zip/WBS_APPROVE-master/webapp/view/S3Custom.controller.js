jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("sap.m.MessageToast");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("cross.fnd.fiori.inbox.CA_FIORI_INBOXExtensionWBS.util.CustomConfirmationDialogManager");
jQuery.sap.require("cross.fnd.fiori.inbox.util.ConfirmationDialogManager");
sap.ui.controller("cross.fnd.fiori.inbox.CA_FIORI_INBOXExtensionWBS.view.S3Custom", {
	CustomoConfirmationDialogManager: cross.fnd.fiori.inbox.CA_FIORI_INBOXExtensionWBS.util.CustomConfirmationDialogManager,
	oConfirmationDialogManager: cross.fnd.fiori.inbox.util.ConfirmationDialogManager,

	extHookChangeFooterButtons: function (oButtonList) {
		// var aMenuButtons = oButtonList.aButtonList;
		// 	aMenuButtons.splice(2,2);
		// 	aMenuButtons.splice(0,1);
		// 	aMenuButtons.splice(2,1);
		var that = this;
		oButtonList.oPositiveAction = {
			Id: "EXT_BUTTON",
			sI18nBtnTxt: "Approve",
			bEnabled: true,
			onBtnPressed: function (oEvent) {
				this.finalFilters = [];
				that.billcheckFlag = false;
			
				var oModel = that.getView().getModel("oDataRequest");
				var instanceID = window.location.href.split("InstanceID='")[1].split("'")[0];
				this.finalFilters.push(new sap.ui.model.Filter("Instanceid", sap.ui.model.FilterOperator.EQ, instanceID));
				oModel.read("/check_billSet", {
					filters: this.finalFilters,

					success: function (oData, oResponse) {
						var dialogState = sap.ui.core.ValueState;
						if (oData.results[0].Billstatus === "X") {
							that.billcheckFlag = true;
						} else {
							that.billcheckFlag = false;
						}
					

						sap.ui.core.BusyIndicator.show(0);
						if (sap.ui.getCore().byId('idTextArea')) {
							sap.ui.getCore().byId('idTextArea').destroy();
						}
						if (!that.oDialog) {
							that.oDialog = new sap.m.Dialog({
								title: "Error Information",
								state: "Error",
								type: 'Message',
								content: [
									new sap.m.Table(that.createId("idTable"), {
										columns: [
											new sap.m.Column({
												width: "80%",
												header: [
													new sap.m.Label({
														text: "Description"
													})
												]
											}),
											new sap.m.Column({
												width: "20%",
												header: [
													new sap.m.Label({
														text: "Message Type"
													})
												]
											})
										],
										items: {
											path: '/',
											template: new sap.m.ColumnListItem({
												cells: [
													new sap.m.Text({
														text: "{Mesage}"
													}),
													new sap.m.Text({
														text: "{Error}"
													})
												]
											})
										}
									})

								],
								endButton: new sap.m.Button({
									icon: "sap-icon://accept",
									press: function () {

										that.oDialog.close();
										//that.cDialog.close();
										sap.ui.core.BusyIndicator.hide();

										// oDialog.destroy();
									}
								}),
								afterClose: function () {
									that.oDialog.close();
								}
							});
						}
						if (!that.sDialog) {
							that.sDialog = new sap.m.Dialog({
								title: "Success",
								state: "Success",
								type: 'Message',
								content: [
									new sap.m.Table(that.createId("sdTable"), {
										columns: [
											new sap.m.Column({
												width: "80%",
												header: [
													new sap.m.Label({
														text: "Description"
													})
												]
											}),
											new sap.m.Column({
												width: "20%",
												header: [
													new sap.m.Label({
														text: "Message Type"
													})
												]
											})
										],
										items: {
											path: '/',
											template: new sap.m.ColumnListItem({
												cells: [
													new sap.m.Text({
														text: "{Mesage}"
													}),
													new sap.m.Text({
														text: "{Error}"
													})
												]
											})
										}
									})

								],
								endButton: new sap.m.Button({
									icon: "sap-icon://accept",
									press: function () {
										that.sDialog.close();
										window.location.reload();
										sap.ui.core.BusyIndicator.hide();
										// sDialog.destroy();

									}
								}),
								afterClose: function () {
									that.sDialog.close();
									// sDialog.destroy();
									// sDialog = null;
								}
							});
						}
						if (!that.cDialog) {
						

							that.cDialog = new sap.m.Dialog({
								title: "Submit Decision",
								type: 'Message',
								contentWidth: "400px",
								contentHeight: "250px",
								resizable: true,
								state: dialogState.Success,
								content: [
									new sap.m.Text({
										text: "You selected \"Approve\"."

									}),
									new sap.m.TextArea({
										id: "idTextArea",
										width: '100%',
										height: "140px",
										maxLength: 500,
										showExceededText: true,
										valueStateText: 'Max. 500 characters are allowed',
										liveChange: function (e) {
											var f = e.getParameter('value');
											var o = e.getSource().getParent();
											o.data("note", f);
											if (f.length > 500) {
												o.getBeginButton().setEnabled(false);
											} else {
												o.getBeginButton().setEnabled(f.length > 0);
											}
											var oTextArea = e.getSource(),
												iValueLength = oTextArea.getValue().length,
												iMaxLength = oTextArea.getMaxLength(),
												sState = iValueLength > iMaxLength ? "Error" : "None";

											oTextArea.setValueState(sState);

										},
										placeholder: 'Add Note (Mandatory) Max. 500 characters will be saved.'
									}),
								
									new sap.m.CheckBox({
										id: "idBillCheck",
										selected: "",
										text: "\n",
										visible: that.billcheckFlag
									}),
										new sap.m.Text({
										text: "Billing Approval Required",
										visible: that.billcheckFlag
									}),
								],
								beginButton: new sap.m.Button({
									text: "Submit",
									enabled: false,
									press: function (oEvent) {
										sap.ui.core.BusyIndicator.show(0);
										var textArea = sap.ui.getCore().byId("idTextArea").getValue();
										var BillCheck = sap.ui.getCore().byId("idBillCheck").getSelected();
										var instanceID = window.location.href.split("InstanceID='")[1].split("'")[0];
										var oModel = that.getView().getModel("oDataRequest");
										var BillstatusFlag;
										if (BillCheck) {
											BillstatusFlag = "X";
										} else {
											BillstatusFlag = "";
										}
										var cData = {
											"d": {
												"Instanceid": instanceID,
												"Workitem": textArea,
												"Billstatus": BillstatusFlag,
												"toMssg": {
													"results": [{
														"Instanceid": "",
														"Error": "",
														"Mesage": ""
													}]
												}

											}

										};
										if (textArea === "") {
											sap.ui.core.BusyIndicator.hide();
											//that.cDialog.close();
											sap.m.MessageToast.show("Please enter the comment", {
												duration: 5000
											});
										} else {
											sap.ui.core.BusyIndicator.show(0);
											that.cDialog.close();
											oModel.create("/RFC_checkSet", cData, {
												success: function (oResponse) {
													var oLength = oResponse.toMssg.results.length;
													if (oLength === 0) {
														sap.m.MessageToast.show("No workItem", {
															duration: 5000
														});
													} else {
														var oError = oResponse.toMssg.results[0].Error;
													}
													if (oError !== "S") {
														sap.ui.core.BusyIndicator.show(0);
														var oData1 = oResponse.toMssg.results;
														var sModel = new sap.ui.model.json.JSONModel(oData1);
														var oTable = sap.ui.getCore().byId(that.createId("idTable"));
														oTable.setModel(sModel);
														//that.cDialog.close();
														that.oDialog.open();
													}
													if (oError === "S") {
														sap.ui.core.BusyIndicator.show(0);
														var sData = oResponse.toMssg.results;
														var nModel = new sap.ui.model.json.JSONModel(sData);
														var sTable = sap.ui.getCore().byId(that.createId("sdTable"));
														sTable.setModel(nModel);
														//that.cDialog.close();
														that.sDialog.open();
													}

												},
												error: function (oError) {
													sap.ui.core.BusyIndicator.hide();
													that.oDialog.close();
													that.sDialog.close();
													sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
														duration: 5000
													});
												}
											});
										}
									}
								}),
								endButton: new sap.m.Button({
									text: "Cancel",
									press: function (oEvent) {
										that.cDialog.close();
										sap.ui.core.BusyIndicator.hide();
									}
								}),
								afterClose: function (e) {
									that.cDialog.destroy();
									that.cDialog = null;
									// sap.ui.getCore().byId("idTextArea").setValue("");
									// e.getSource().getBeginButton().setEnabled(false);
									// that.cDialog.close();
								}
							});
						}
						that.cDialog.open();
					},
					error: function (err) {

					
					}
				});

			}
		};

		return oButtonList;
	},
	createDecisionButtons: function (d, u, o) {
		var p = null;
		var n = null;
		var b = [];
		var t = this;
		var I = this.oModel2.getData(),
			a = t._getActionHelper();
		if (!t.bNavToFullScreenFromLog && (I.TaskSupports.ProcessingLogs || I.TaskSupports.WorkflowLog) && t.oDataManager.getShowLogEnabled()) {
			// b.push({
			// 	sI18nBtnTxt: t.bShowLogs ? "XBUT_HIDELOG" : "XBUT_SHOWLOG",
			// 	onBtnPressed: jQuery.proxy(this.onLogBtnPress, this)
			// });
		}
		if (!this.switchToOutbox()) {
			if (!this._isTaskConfirmable(I)) {
				for (var i = 0; i < d.length; i++) {
					var D = d[i];
					D.InstanceID = I.InstanceID;
					D.SAP__Origin = o;
					if (D.Nature === "POSITIVE") {
						p = {
							sBtnTxt: D.DecisionText,
							onBtnPressed: function (g) {
								return function () {
									t.showDecisionDialog(t.oDataManager.FUNCTION_IMPORT_DECISION, g, true);
								};
							}(D)
						};
					} else if (D.Nature === "NEGATIVE") {
						n = {
							sBtnTxt: D.DecisionText,
							onBtnPressed: function (g) {
								return function () {
									t.showDecisionDialog(t.oDataManager.FUNCTION_IMPORT_DECISION, g, true);
								};
							}(D)
						};
					} else {
						// b.push({
						// 	sBtnTxt: D.DecisionText,
						// 	onBtnPressed: function (g) {
						// 		return function () {
						// 			t.showDecisionDialog(t.oDataManager.FUNCTION_IMPORT_DECISION, g, true);
						// 		};
						// 	}(D)
						// });
					}
				}
			}
			// if (this._isTaskConfirmable(I)) {
			// 	p = {
			// 		sI18nBtnTxt: "XBUT_CONFIRM",
			// 		onBtnPressed: function (g) {
			// 			return function () {
			// 				t.showConfirmationDialog(t.oDataManager.FUNCTION_IMPORT_CONFIRM, I);
			// 			};
			// 		}(I)
			// 	};
			// }
			// if (t.fnFormatterSupportsProperty(I.TaskSupports.Claim, I.SupportsClaim)) {
			// 	b.push({
			// 		sI18nBtnTxt: "XBUT_CLAIM",
			// 		onBtnPressed: function (E) {
			// 			if (sap.ui.Device.system.phone) {
			// 				t.stayOnDetailScreen = true;
			// 			}
			// 			t.sendAction("Claim", I, null);
			// 		}
			// 	});
			// }
			// if (t.fnFormatterSupportsProperty(I.TaskSupports.Release, I.SupportsRelease)) {
			// 	b.push({
			// 		sI18nBtnTxt: "XBUT_RELEASE",
			// 		onBtnPressed: function (E) {
			// 			if (sap.ui.Device.system.phone) {
			// 				t.stayOnDetailScreen = true;
			// 			}
			// 			t.sendAction("Release", I, null);
			// 		}
			// 	});
			// }
			// if (t.fnFormatterSupportsProperty(I.TaskSupports.Forward, I.SupportsForward)) {
			// 	b.push({
			// 		sI18nBtnTxt: "XBUT_REASSIGN",
			// 		sType: sap.m.ButtonType.Emphasized,
			// 		onBtnPressed: jQuery.proxy(this.onForwardPopUp, this)
			// 	});
			// }
			// if (I.TaskSupports) {
			// 	if (I.TaskSupports.Resubmit) {
			// 		b.push({
			// 			sI18nBtnTxt: "XBUT_RESUBMIT",
			// 			onBtnPressed: jQuery.proxy(this.showResubmitPopUp, this)
			// 		});
			// 	}
			// }
			var P = this._getParsedParamsForIntent(u.GUI_Link);
			if (P) {
				this.xNavService = this.xNavService || sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container
					.getService("CrossApplicationNavigation");
				this.isSupported = false;
				this.isOpenModeEmpty = false;
				if (this.xNavService) {
					var c = this._getIntentParam(P);
					this.xNavService.isNavigationSupported(c).done(function (r) {
						t.isSupported = t._isOpenModeSupported(r);
						t.isOpenModeEmpty = t._isOpenModeEmpty(r);
						if ((t.isSupported || t.isOpenModeEmpty) && a.isOpenTaskEnabled(I, t.bEmbedIntoDetail)) {
							b.push({
								sI18nBtnTxt: "XBUT_OPENWBS",
								onBtnPressed: function (E) {
									t.checkStatusAndOpenTaskUI();
								}
							});
							t.refreshHeaderFooterOptions();
						} else if (!t.isSupported && !t.isOpenModeEmpty) {
							jQuery.sap.log.error("Error in creating open task button. Check the intent configuration");
						}
					}).fail(function () {
						jQuery.sap.log.error("Error while creating open task buttons");
					});
				}
			} else {
				if (!t.oDataManager.isUIExecnLinkNavProp() && I.GUI_Link && a.isOpenTaskEnabled(I, t.bEmbedIntoDetail)) {
					b.push({
						sI18nBtnTxt: "XBUT_OPENWBS",
						onBtnPressed: function (E) {
							t.checkStatusAndOpenTaskUI();
						}
					});
				} else {
					if (I.TaskSupports.UIExecutionLink && I.UIExecutionLink && I.UIExecutionLink.GUI_Link && a.isOpenTaskEnabled(I, t.bEmbedIntoDetail)) {
						b.push({
							sI18nBtnTxt: "XBUT_OPENWBS",
							onBtnPressed: function (E) {
								t.checkStatusAndOpenTaskUI();
							}
						});
					}
				}
			}
			// if (window.plugins && window.plugins.calendar) {
			// 	var e = this.oModel2.getData();
			// 	var f = e.CompletionDeadLine;
			// 	if (f) {
			// 		var A = function (g) {
			// 			if (g < new Date()) {
			// 				this.oConfirmationDialogManager.showDecisionDialog({
			// 					question: this.i18nBundle.getText("dialog.warning.mq.CalendarEventInThePast"),
			// 					title: this.i18nBundle.getText("dialog.warning.mq.CalendarEventInThePast.title"),
			// 					confirmButtonLabel: this.i18nBundle.getText("XBUT_OK"),
			// 					noteMandatory: false,
			// 					confirmActionHandler: jQuery.proxy(this.createCalendarEvent, this)
			// 				});
			// 			} else {
			// 				this.createCalendarEvent();
			// 			}
			// 		};
			// 		b.push({
			// 			sI18nBtnTxt: "XBUT_CALENDAR",
			// 			onBtnPressed: jQuery.proxy(A, this, f)
			// 		});
			// 	}
			// }
		}
		// if (this.switchToOutbox() && I.TaskSupports.CancelResubmission) {
		// 	b.push({
		// 		sI18nBtnTxt: "XBUT_RESUME",
		// 		onBtnPressed: function (E) {
		// 			t.sendAction("CancelResubmission", I, null);
		// 		}
		// 	});
		// }
		var B = {};
		B.oPositiveAction = p;
		B.oNegativeAction = n;
		B.aButtonList = b;
		this.addShareOnJamAndEmail(B);
		if (this.extHookChangeFooterButtons) {
			this.extHookChangeFooterButtons(B);
			p = B.oPositiveAction;
			n = B.oNegativeAction;
			b = B.aButtonList;
		}
		this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
			oPositiveAction: p,
			oNegativeAction: n,
			buttonList: b,
			oJamOptions: B.oJamOptions,
			oEmailSettings: B.oEmailSettings,
			bSuppressBookmarkButton: true
		});
		this.refreshHeaderFooterOptions();
	},
	_updateHeaderTitle: function (d) {
		if (d) {
			var c = this.getOwnerComponent().getComponentData();
			this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
				sDetailTitle: d.TaskDefinitionName ? d.TaskDefinitionName : this.i18nBundle.getText("ITEM_DETAIL_DISPLAY_NAME")
			});
			this.refreshHeaderFooterOptions();
		}
		var o = this.getOwnerComponent();
		this.getOwnerComponent().getService("ShellUIService").then(jQuery.proxy(function (s) {
			var S = "";
			var D = (c && c.startupParameters && c.startupParameters.expertMode && c.startupParameters.expertMode[0]) ? this.i18nBundle.getText(
				"SHELL_TITLE_MYTASK") : this.i18nBundle.getText("SHELL_TITLEIWO");
			if (D) {
				S = D;
			}
			s.setTitle(S);
			if (this.bNavToFullScreenFromLog) {
				s.setBackNavigation(jQuery.proxy(this.fnOnNavBackFromLogDescription, this));
			} else {
				s.setBackNavigation(jQuery.proxy(o.onHeaderBack, o));
			}
		}, this), function (e) {
			jQuery.sap.log.error("Cannot get ShellUIService", e, "cross.fnd.fiori.inbox.Component");
		});
	},
	showDecisionDialog: function (f, d, s) {

		if (d.DecisionKey == "0002") {
			this.CustomoConfirmationDialogManager.showDecisionDialog({
				question: this.i18nBundle.getText("XMSG_DECISION_QUESTION", d.DecisionText),
				showNote: s,
				title: this.i18nBundle.getText("XTIT_SUBMIT_DECISION"),
				confirmButtonLabel: this.i18nBundle.getText("XBUT_SUBMIT"),
				noteMandatory: d.CommentMandatory,
				confirmActionHandler: jQuery.proxy(function (d, n) {
					this.sendAction(f, d, n);
				}, this, d)
			});

		} else {
			this.oConfirmationDialogManager.showDecisionDialog({
				question: this.i18nBundle.getText("XMSG_DECISION_QUESTION", d.DecisionText),
				showNote: s,
				title: this.i18nBundle.getText("XTIT_SUBMIT_DECISION"),
				confirmButtonLabel: this.i18nBundle.getText("XBUT_SUBMIT"),
				noteMandatory: d.CommentMandatory,
				confirmActionHandler: jQuery.proxy(function (d, n) {
					this.sendAction(f, d, n);
				}, this, d)
			});

		}

	},

});