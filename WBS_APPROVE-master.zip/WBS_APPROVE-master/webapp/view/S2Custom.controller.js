sap.ui.controller("cross.fnd.fiori.inbox.CA_FIORI_INBOXExtensionWBS.view.S2Custom", {

	extHookChangeMassApprovalButtons: function (oButtonList) {
		// Place your hook implementation code here 
			var aMenuButtons = oButtonList.aButtonList;
			aMenuButtons.splice(1,1);
			aMenuButtons.splice(2,1);
	},
		showDecisionButtons: function () {
		this.clearDecisionButtons();
		var t = this,
			T = this.aMultiSelectDecisionOptions ? this.aMultiSelectDecisionOptions.length : 0;
		if (T > 0) {
			for (var i = 0; i < T; i++) {
				var d = this.aMultiSelectDecisionOptions[i];
				var D = d.DecisionText;
				var b = {
					sBtnTxt: D,
					onBtnPressed: (function (d) {
						return function () {
							t.showDecisionDialog(d);
						};
					})(d)
				};
				switch (d.Nature) {
				case "POSITIVE":
					this.oMultiSelectActions.positiveAction = b;
					break;
				case "NEGATIVE":
					this.oMultiSelectActions.negativeAction = b;
					break;
				default:
					this.oMultiSelectActions.additionalActions.push(b);
				}
			}
		}
		var s = this.getList().getSelectedItems();
		var o = {
			Forward: true,
			Resubmit: true
		};
		var a = this.checkDecisionSupport(s, o);
		if (a.Forward === true) {
			var f = {
				sI18nBtnTxt: "XBUT_REASSIGN",
				onBtnPressed: jQuery.proxy(this.onForwardPopUp, this)
			};
			this.oMultiSelectActions.additionalActions.push(f);
		}
		// if (a.Resubmit === true) {
		// 	var r = {
		// 		sI18nBtnTxt: "XBUT_RESUBMIT",
		// 		onBtnPressed: jQuery.proxy(this.showResubmitPopUp, this)
		// 	};
		// 	this.oMultiSelectActions.additionalActions.push(r);
		// }
		var B = {};
		B.oPositiveAction = this.oMultiSelectActions.positiveAction;
		B.oNegativeAction = this.oMultiSelectActions.negativeAction;
		B.aButtonList = this.oMultiSelectActions.additionalActions;
		if (this.extHookChangeMassApprovalButtons) {
			this.extHookChangeMassApprovalButtons(B);
			this.oMultiSelectActions.positiveAction = B.oPositiveAction;
			this.oMultiSelectActions.negativeAction = B.oNegativeAction;
			this.oMultiSelectActions.additionalActions = B.aButtonList;
		}
		this._oApplicationImplementation.oMHFHelper.defineMasterHeaderFooter(this);
	}

});