/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/ui/base/Object", "sap/m/Button", "sap/m/Dialog", "sap/m/Text", "sap/m/TextArea"], function (O, B, D, T, a) {
	"use strict";
	return {
		getI18nBundle: function () {
			return sap.ca.scfld.md.app.Application.getImpl().AppI18nModel.getResourceBundle();
		},
		showDecisionDialog: function (d) {
			d = this._initializeDialogSettings(d);
			if (sap.ui.getCore().byId('confirmDialogTextarea')) {
				sap.ui.getCore().byId('confirmDialogTextarea').destroy();
			}
			var o = this._createConfirmationDialog(d.noteMandatory, d.question, d.title, d.confirmButtonLabel, d.showNote);
			o.getBeginButton().attachPress(jQuery.proxy(function (e) {
				var n;
				if (d.showNote) {
					n = sap.ui.getCore().byId('confirmDialogTextarea').getValue();
				}
				if (!n) {
					n = "";
				}
				d.confirmActionHandler(n);
				e.getSource().getParent().close();
			}, this));
			o.open();
		},
		
		_initializeDialogSettings: function (d) {
			return jQuery.extend({
				noteMandatory: false,
				question: "",
				title: "",
				confirmButtonLabel: "",
				showNote: false,
				confirmActionHandler: function () {
					return;
				}
			}, d);
		},
		_createConfirmationDialog: function (n, q, t, b, s) {
			var c;
			var dialogState = sap.ui.core.ValueState;
			if (s) {
				c = [new T({
					text: q
				}), new a("confirmDialogTextarea", {
					liveChange: function (e) {
						var f = e.getParameter('value');
						var o = e.getSource().getParent();
						o.data("note", f);
						if (n) {
							if (f.length > 500) {
								o.getBeginButton().setEnabled(false);
							} else {
								o.getBeginButton().setEnabled(f.length > 0);
							}
							var oTextArea = e.getSource(),
								iValueLength = oTextArea.getValue().length,
								iMaxLength = oTextArea.getMaxLength(),
								sState = iValueLength > iMaxLength ? "Error" : "None";

							oTextArea.setValueState(sState);

						}
					},
					maxLength: 500,
					width: '100%',
					height: "140px",
					showExceededText: true,
					valueStateText: 'Max. 500 characters are allowed',
					placeholder: this.getI18nBundle().getText(n ? "XMSG_COMMENT_MANDATORY" : "XMSG_COMMENT_OPTIONAL")
				})];
			} else {
				c = [new T({
					text: q
				})];
			}
		
			var d = new D({
				title: t,
				type: 'Message',
				content: c,
				contentWidth: "400px",
				contentHeight: "250px",
				state:dialogState.Error,
				beginButton: new B({
					text: b,
					tooltip: this.getI18nBundle().getText("submit.request"),
					enabled: !n
				}),
				endButton: new B({
					text: this.getI18nBundle().getText("XBUT_CANCEL"),
					tooltip: this.getI18nBundle().getText("cancel.request"),
					press: function (e) {
						d.close();
					}
				}),
				afterClose: function () {
					d.destroy();
				}
			});
			return d;
		}
	};
}, true);