sap.ui.define([
	"sap/ui/core/mvc/Controller", "sap/ushell/services/CrossApplicationNavigation"
], function (Controller, CrossApplicationNavigation) {
	"use strict";

	return Controller.extend("homepagereport.controller.View1", {
		onOppidReport: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OppID"
					}
				});

		},
		onReqReport: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "ReqRepo"
					}
				});

		},

		onOppDtlReport: function () {

			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "OppDtl"
					}
				});

		},

		onOppDtlntfyReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "dealNfy"
					}
				});
		},

		onSubDtlReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "subDtl"
					}
				});
		},
		onCycleTimeReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "cycleTime"
					}
				});
		},
		onReassignReport: function () {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "wbsReassgn"
					}
				});
		},

	});

});