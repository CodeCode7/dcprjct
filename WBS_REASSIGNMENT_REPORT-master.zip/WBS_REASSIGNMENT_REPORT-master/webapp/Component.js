sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("wbsReassgn.wbs_reassign_report.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});