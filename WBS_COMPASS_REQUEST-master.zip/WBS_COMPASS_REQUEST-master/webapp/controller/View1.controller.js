sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/Token",
	"sap/m/Dialog",
	"sap/ui/table/RowAction",
	"sap/ui/table/RowActionItem",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/table/library",
	"sap/ushell/services/UserInfo",
	"WBS/Compass/WbsCompassRequest/util/Formatter",
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/ui/generic/app/navigation/service/NavigationHandler",
	"sap/ui/generic/app/navigation/service/NavType",
	"sap/ushell/services/CrossApplicationNavigation",
	"sap/m/MessageBox",
	"WBS/Compass/WbsCompassRequest/util/ErrorFormatter",
], function (Controller, MessageToast, Fragment, JSONModel, Token, Dialog, RowAction, RowActionItem, Filter, FilterOperator, library,
	UserInfo, Formatter, Label, TextArea, NavigationHandler, NavType, CrossApplicationNavigation, MessageBox) {
	"use strict";
	var oFormatter = Formatter;
	var SortOrder = library.SortOrder;
	return Controller.extend("WBS.Compass.WbsCompassRequest.controller.View1", {
		formatter: Formatter,
		onInit: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var oView = this.getOwnerComponent();
			var autoPop = new JSONModel({
				Requestid: "",
				IwoGuidItem: "",
			});
			oView.setModel(autoPop, "autoPopData");

			var oError = new JSONModel();
			oView.setModel(oError, "oErrorAppView");

			var summ = new JSONModel();
			oView.setModel(summ, "summary");
			// var oModel = this.getView().getModel("oDataModel");
			var oModel = this.getView().getModel("oDataModel").setSizeLimit(500); // Changes done for phase-1 in phase-2 code.
			// this.onSelectFinanceAnalyst();
			var oUser = new UserInfo();
			var ouserId = oUser.getId();
			if (ouserId != "DEFAULT_USER") {
				var olastName = oUser.getUser().getLastName().toUpperCase();
				var ofirstName = oUser.getUser().getFirstName().toUpperCase();
				var ofullName = oUser.getUser().getFullName().toUpperCase();
				var oemail = oUser.getUser().getEmail();
				var oViewModel = new JSONModel({
					Owner: ouserId,
					Requestor: ouserId,
					ReqDate: new Date().toDateString(),
					toDate: new Date(),
					fixedWBSEle: "",
					Admin: false,
					oppAdmin: false,
					oSpanProj: "NO", //for spanish project
					sys_orign: "",
					comCode: "",
					type: "",
					indicator: "",
					projType: "",
					projTypeid: "",
					projTypeName: "",
					Submitter: "",
					RequestorEmail: oemail,
					iwoNo: "",
					Requestid: "",
					IWOAdmin: "",
					ReqID: "",
					oErrorCount: 0,
					EstatTxt: "Create",
					RequestorName: ofullName,
					OwnerName: ofullName,
					AdminName: "",
					oppSafeCaseid: true,
					oUserStatus: "",
					uploadFlag: ""
				});
				oView.setModel(oViewModel, "appView");
			} else {
				var oViewModel;
				oViewModel = new JSONModel({
					Owner: "11500386",
					Requestor: "11500386",
					ReqDate: new Date().toDateString(),
					toDate: new Date(),
					fixedWBSEle: "",
					Admin: false,
					oppAdmin: false,
					oSpanProj: "NO", //for spanish project
					RequestorEmail: "kim.john@dxc.com",
					sys_orign: "",
					comCode: "",
					projType: "",
					projTypeid: "",
					projTypeName: "",
					Submitter: "",
					iwoNo: "",
					Requestid: "",
					IWOAdmin: "",
					ReqID: "",
					totalCount: 0,
					tableBusyDelay: 0,
					oErrorCount: 0,
					EstatTxt: "Create",
					RequestorName: "John, Kim",
					OwnerName: "John, Kim",
					AdminName: "",
					type: "",
					indicator: "",
					actionType: "",
					oppSafeCaseid: true,
					statusCode: "E0001",
					oUserStatus: "",
					uploadFlag: ""
				});
				oView.setModel(oViewModel, "appView");
			}
			this.onSelectRAKey();

			// rohit - new table model changes
			var emptyMod = new JSONModel({
				wbsElementStr: []
			});
			oView.setModel(emptyMod, "pageModel");
			oView.getModel("pageModel").setSizeLimit(500); // UAT NCR Drop  down  values  for service offering
			// rohit - end new table model changes
			this.onSelectSystemStatus();
			// this.onSelectUserStatus();

			var oModel1 = this.getView().getModel("oDataModel");
			var that = this;
			oModel1.read("/OMTReqAuthSet", {
				success: function (oResponse) {
					var oViewModel = that.getView().getModel("appView");
					if (oResponse.results[0].ApprFlg === "Y") {
						oViewModel.getData().Admin = true;
					} else {
						oViewModel.getData().Admin = false;
					}

					var condi1 = window.location.href.split("#")[1].split("?").length;
					if (condi1 > 1) {
						if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {
							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().type = "OpprApp";
							that.getView().getModel("appView").refresh(true);
							// var m = decodeURIComponent(decodeURIComponent(window.location.href))
							// var m1 = m.split("navAryy=")[1];
							// var obj = JSON.parse(m1);
							// var len = obj.length;
							jQuery.sap.require("jquery.sap.storage");
							var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
							if (oStorage.get("oppData")) {
								var obj = oStorage.get("oppData");
								// oStorage.clear();
							}
							// that.getView().setBusy(true);
							that.onLoadOppData(obj);
							// that.getView().setBusy(false);
							that.getView().byId("idT1ComCode").setEnabled(false);
							// that.getView().byId("idProjType").setSelectedKey(PRJ_TYP1);
							that.getView().byId("idProjType").setEnabled(false);
							// var oModel = that.getView().getModel();
							// var toOpprData = oModel.getProperty("/toOpprData");
							// wbsElement.push(wbsElementRow);

						} else if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryyManage") {
							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().type = "OpprApp";
							that.getView().getModel("appView").refresh(true);
							// var m = decodeURIComponent(decodeURIComponent(window.location.href))
							// var m1 = m.split("navAryyManage=")[1];
							// var obj = JSON.parse(m1);
							// var len = obj.length;
							jQuery.sap.require("jquery.sap.storage");
							var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
							if (oStorage.get("oppData")) {
								var obj = oStorage.get("oppData");
								// oStorage.clear();
							}
							var ReqNo = obj[0].Projectid;
							var TYPE = "OpprApp";
							that.getView().byId("idT1ComCode").setEnabled(false);
							that.getView().byId("downBtn").setVisible(true);
							that.getView().getModel().setProperty("/toOpprData", obj);
							that.onLoadOppManageData(ReqNo, TYPE, obj);
						} else {
							var ReqNo = window.location.href.split("#")[1].split("?")[1].split("&")[0].split("=")[1];

							// C1 to Compass Nav issue - Phase 3
							var Comcode = window.location.href.split("#")[1].split("?")[1].split("&")[0].split("=")[0];
							if (Comcode == "ComCode") {
								sap.ui.core.BusyIndicator.hide();
								// that.getView().byId("idT1ComCode").setValue(Comcode);

							} else {
								var TYPE = window.location.href.split("#")[1].split("?")[1].split("&")[1].split("=")[1];
								if (TYPE === "ChangeRequest") {
									//To Change app  title 
									// oView.getService("ShellUIService").then(
									// 	function (oService) {
									// 		oService.setTitle("WBS Change Request");
									// 	}
									// );

									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().type = "ChangeRequest";
									that.getView().getModel("appView").refresh(true);
									that.getView().byId("downBtn").setVisible(true);
									// that.getView().byId("uploBtn").setVisible(false);
									that.onLoadData(ReqNo, TYPE);
								} else if (TYPE === "ReViewReq") {
									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().type = "View";
									that.getView().getModel("appView").refresh(true);
									// that.getView().byId("downBtn").setVisible(true);
									that.onLoadDataReviwReq(ReqNo, TYPE);
									// that.getView().byId("downBtn").setVisible(true);
									// that.getView().byId("settBtn").setEnabled(true);

								} else if (TYPE === "View") {
									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().type = "View";
									that.getView().getModel("appView").refresh(true);
									that.onLoadDataReviwReq(ReqNo, TYPE);
								} else if (TYPE === "ChangeProject" || ReqNo === "ChangeProject") {
									var temp = ReqNo;
									ReqNo = TYPE;
									TYPE = temp;
									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().type = "ChangeProject";
									that.getView().byId("downBtn").setVisible(true);
									that.getView().getModel("appView").refresh(true);
									// that.onEnableDesableFields();
									that.onLoadChnageProject(ReqNo, TYPE);
								} else if (TYPE === "DuplicateExisting" || ReqNo === "DuplicateExisting") {
									var temp = ReqNo;
									ReqNo = TYPE;
									TYPE = temp;
									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().type = "DuplicateExisting";
									that.getView().getModel("appView").refresh(true);
									// that.onEnableDesableFields();
									that.onLoadChnageProject(ReqNo, TYPE);
									that.onSelectUserStatus();

								} else if (TYPE === "Upload" || ReqNo === "Upload") {
									// oView.setModel(oViewModel, "appView");
									var oViewModel = that.getView().getModel("appView");
									oViewModel.getData().uploadFlag = "X";
									that.getView().getModel("appView").refresh(true);
									that._uploadFileDialog();

								}
							}

						}
					} else {
						sap.ui.core.BusyIndicator.show(0);
						// that.onSelectUserStatus();
						that.onSelectUserStatusaLL();
						var oModel1 = that.getView().getModel("oDataModel");
						// var oModel = that.getView().getModel("oDataModel").setSizeLimit(300);
						var that1 = that;
						oModel1.read("/UserProfileSet('ZGPRS_ERP')", {
							success: function (oResponse) {
								// var oSow = new JSONModel(oResponse.results);
								// oView.setModel(oSow, "oSowAppView");
								if (oResponse.Parva === "C1") {
									sap.ui.core.BusyIndicator.hide();
									sap.ushell.Container
										.getService("CrossApplicationNavigation")
										.toExternal({
											target: {
												semanticObject: "DXCGPRS",
												action: "createC1"
											},
											params: {
												"ComCode": ""
											},
											// appStateKey: oAppState.getKey()
										});
								} else {
									sap.ui.core.BusyIndicator.hide();
								}

							},
							error: function (oError) {
								sap.ui.core.BusyIndicator.hide();
							}
						});
					}

				},
				error: function (oError) {
					// sap.ui.core.BusyIndicator.hide();
				}
			});

			// 0000001964 0000001946
			// this.onLoadData("0000003170", "ChangeRequest");
			// this.onLoadChnageProject("ES1-V0008", "ChangeonLoadDataProject");
			// this.onLoadData("0000000724", "ChangeRequest");
			// this.onLoadData("0000003639", "ChangeRequest");
			// this.onLoadDataReviwReq("0000002916", "ReViewReq");
			// this.onLoadDataReviwReq("0000003247", "ReViewReq");
			//var oViewModel = this.getView().getModel("appView");
			//oViewModel.getData().type = "ChangeRequest";
			//this.getView().getModel("appView").refresh(true);
			// this.onLoadDataReviwReq("0000003211", "ReViewReq");
			//this.onLoadChnageProject("SE1-PON03", "ChangeProject");
			 //this.onLoadData("0000003736", "ChangeRequest");
			//this.onLoadData("0000003736", "ChangeRequest"); //Spanish Project record
			// this.onLoadDataReviwReq("0000002916", "ReViewReq");
			// GB9-RR017 //  GB9-V0139 -> Trade
			// GB9-V0125 //  ->  internal Id
			// var oViewModel = that.getView().getModel("appView");
			// oViewModel.getData().type = "ChangeRequest";
			// this.onLoadData("0000002974", "ChangeRequest");
			// this.onLoadChnageProject("GB9-RP238", "ChangeProject");
			// ES9-7P202

			// this.onLoadChnageProject("GB9-RP237", "DuplicateExisting");
			// this.onLoadChnageProject("GB9-V0125", "ChangeProject");
			// var oViewModel = this.getView().getModel("appView");
			// oViewModel.getData().type = "ChangeProject";
			// this.getView().getModel("appView").refresh(true);
			// this.onLoadChnageProject("GB9-MDD09", "DuplicateExisting

			// var obj1 = [{
			// 		CasesafeId: "00k5000000jFVUVAA4",
			// 		OptId: "OPX-0020519837",
			// 		UniqId: "OPX-0020519837-9",
			// 		Zbukrs: "GBA5"
			// 	}]
			// 	this.onLoadOppData(obj1);

			// var flagUpload = window.location.href.split("#")[1].split("?")[1].split("=")[1];
			// var flagUpload = true;
			// if(flagUpload === true){

			// }

			// var emptyMod = new JSONModel([]);
			// this.getView().setModel(emptyMod, "pageModel"); // rohit - instantiate simple page model for table
			// this.onLoadData("0000002468", "ChangeRequest"); // rohit - change
		},
		onLoadOppData: function (obj) {
			sap.ui.core.BusyIndicator.show(0);
			this.getView().byId("idWbsGuided").setEnabled(false);
			this.getView().getModel().setProperty("/toOpprData", obj);
			var comCode = obj[0].Zbukrs;
			var oppID = obj[0].OptId;
			// var comCode = "GBA5";
			// var oppID = "OPX-0020833596";
			// this.onSelectOppAppDataTab4();
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Opp_HeaderSet('" + oppID + "')", {
				success: function (oData, oResponse) {
					// var m = decodeURIComponent(decodeURIComponent(window.location.href))
					// var m1 = m.split("navAryy=")[1];
					// var obj = JSON.parse(m1);
					jQuery.sap.require("jquery.sap.storage");
					var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
					if (oStorage.get("oppData")) {
						var obj = oStorage.get("oppData");
						oStorage.clear();
					}
					that.getView().getModel().setProperty("/toOpprData", obj);
					// var obj = that.getView().getModel().getProperty("/toOpprData");
					var oppID = obj[0].OptId;
					var comCode = obj[0].Zbukrs;
					that.getView().getModel().setProperty("/toDetails/Zbukrs", comCode);
					that.getView().getModel().setProperty("/draftData/d/Zbukrs", comCode);
					// that.getView().byId("idT2OpporId").setSelectedKey(oppID);
					that.getView().getModel().setProperty("/draftData/d/Zzsiebelid", oppID);
					that.getView().byId("idT2OpporId").setEnabled(false);
					if (oData.Actgm) {
						oData.Actgm = oData.Actgm.split("(")[1].split(")")[0];
					}
					if (oData.Perresp) {
						oData.Perresp = oData.Perresp.split("(")[1].split(")")[0];
					}
					if (oData.FinAnl) {
						oData.FinAnl = oData.FinAnl.split("(")[1].split(")")[0];
					}

					// that.getView().getModel().setProperty("/draftData/d/Agm", oData.Actgm);
					// that.getView().getModel().setProperty("/draftData/d/Vernr", oData.Perresp);

					// that.getView().getModel().setProperty("/draftData/d/Zzsiebelid", new Date(oData.Cadate));
					// that.getView().getModel().setProperty("/draftData/d/Zzsiebelid", oData.Optmanag);
					// that.getView().getModel().setProperty("/draftData/d/Zzsiebelid", oData.Zpspid);
					that.getView().getModel().setProperty("/draftData/d/Zzldpcid", oData.Zzldpcid);
					that.getView().getModel().setProperty("/draftData/d/Zpgid", oData.Zzpgid);
					that.getView().getModel().setProperty("/draftData/d/Guebg", new Date(oData.Guebg));
					that.getView().getModel().setProperty("/draftData/d/Gueen", new Date(oData.Gueen));
					that.byId("idEnddate").setMinDate(new Date(oData.Guebg));
					that.getView().getModel().setProperty("/draftData/d/Ktext", oData.Zpspid);
					// that.getView().getModel().setProperty("/toDetails/FinApp", oData.FinAnl);
					// that.getView().getModel().setProperty("/draftData/d/FinApp", oData.FinAnl);
					that.getView().getModel().setProperty("/draftData/d/Zkunnr", oData.ClientID);
					that.getView().getModel().setProperty("/draftData/d/Zzsoarincd", oData.IndustryCode);

					that.getView().byId("idProjType").setSelectedKey("PRJ_TYP1");
					that.getView().byId("idT2ProjCategory").setValue("ES-NOSOAR");
					that.getView().byId("idT2ProjCategory").setEditable(false);
					that.getView().byId("idT2PrjSts").setSelectedKey("I");
					that.getView().byId("idT2PrjSts").setValue("I");
					that.getView().byId("idT2OpporId").setRequired(true);
					that.getView().byId("idT2RevMthd").setRequired(true);
					that.getView().byId("idT2LdPracSet").setRequired(true);
					var oProjectBox = that.getView().byId("idT2ContractType");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
							new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
							new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
						],
						and: true
					});
					// aFilters.push(oFilters);
					oBindingBox.filter(aFilters);

					var oBindingBoxT2 = that.getView().byId("idT2LdPracSet").getBinding("items");
					var aFiltersT2 = [];
					var oFiltersT2 = new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.NE, "BLANK");
					aFiltersT2.push(oFiltersT2);
					oBindingBoxT2.filter(aFiltersT2);

					var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
					var aFiltersT3 = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
							new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
						],
						and: false
					});
					oBindingBoxT3.filter(aFiltersT3);

					var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
					var aFiltersT4 = new sap.ui.model.Filter({
						// filters: [
						// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ4"),
						// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ5"),
						// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ2"),
						// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ3"),
						// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ7")
						// ],
						// and: true
						filters: [
							new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
							new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ")
						],
						and: false
					});
					oBindingBoxT4.filter(aFiltersT4);

					var oViewModel = that.getView().getModel("appView");
					oViewModel.getData().projType = "Trade";
					that.getView().getModel("appView").refresh(true);
					//that.onSelectUserStatusaLL();
					//Promise call
					Promise.all([
						that._fnReadCompanyCode(comCode),
						that._fnReadEmpIDName(oData.Actgm, oData.Perresp, oData.FinAnl),
						that._fnonSelectUserStatus(),
						// that._fnReadSelectOppAppDataTab4(),
					]).then(that._fnSuccessHandler.bind(that));
					// sap.ui.core.BusyIndicator.hide();
				},
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		// _fnReadSelectOppAppDataTab4: function (oEvent) {
		// 	var that = this;
		// 	return new Promise(
		// 		function (resolve, reject) {
		// 			var oModel = that.getView().getModel("oDataModel");
		// 			// var sRow = oEvent.getSource().getBindingContext("pageModel").getPath(); // rohit - change
		// 			var oppData = that.getView().getModel().getProperty("/toOpprData");
		// 			var oppID = oppData[0].OptId;
		// 			var aFilters = [];
		// 			for (var i = 0; i < oppData.length; i++) {
		// 				aFilters.push(new sap.ui.model.Filter("Uniq_id", sap.ui.model.FilterOperator.Contains, oppData[i].CasesafeId));
		// 			}
		// 			aFilters.push(new sap.ui.model.Filter([
		// 				new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, oppID),
		// 			], false));
		// 			// aFilters.push(new Filter("Opt_id", sap.ui.model.FilterOperator.EQ, keyID));
		// 			// var that = this;
		// 			oModel.read("/Search_Safecase_IDSet", {
		// 				filters: aFilters,
		// 				success: function (oResponse) {
		// 					var oSafecase = new JSONModel(oResponse.results);
		// 					// that.getView().byId(id).setModel(oSafecase, "oSafecase");
		// 					// that.getView().setModel(oSafecase, "oSafecase");
		// 					that.getView().getModel("pageModel").setProperty("/oCaseSafeModel", oResponse.results);
		// 					resolve(oResponse);
		// 				},
		// 				error: function (oError) {
		// 					reject(oError);
		// 				}
		// 			});
		// 		});
		// },
		_fnonSelectUserStatus: function (prjType) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					var oModel = that.getView().getModel("oDataModel");
					var aFilters = [];
					if (prjType === "PRJ_TYP2") {
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
					} else if (prjType === "PRJ_TYP1") {
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CSSP "));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "INTG "));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKAC "));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKCO"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "AMRT"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CCLS"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
					} else {
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
						aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
					}
					// var that = this;
					oModel.read("/Search_User_StatusSet", {
						filters: aFilters,
						success: function (oResponse) {
							// var oUserStatus = new JSONModel(oResponse.results);
							// that.getView().setModel(oUserStatus, "oUserStatusModel");
							var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
							for (var m = 0; m < tableData.length; m++) { // rohit - change
								var contextid = "/wbsElementStr/" + m.toString();
								that.getView().getModel("pageModel").setProperty(contextid + "/oUserStatusModel", oResponse.results);

							}
							resolve(oResponse);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
		},
		_fnReadCompanyCode: function (comCode) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					var oModel1 = that.getView().getModel("oDataModel");
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("Compcode", sap.ui.model.FilterOperator.Contains, comCode));
					oModel1.read("/Search_Company_CodeSet", {
						filters: aFilters,
						success: function (oResponse) {
							var Proid = oResponse.results[0].Proid;
							var Des_sys = oResponse.results[0].Des_sys;
							var m = Proid + "@-#####";
							that.getView().byId("idProjDefi").setMask(m);

							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().sys_orign = Des_sys;
							that.getView().getModel("appView").refresh(true);
							resolve(oResponse);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
		},
		_fnReadEmpIDName: function (Actgm, Perresp, FinAnl) {
			var that = this;
			that.sTerm1 = Actgm;
			that.sTerm2 = Perresp;
			that.sTerm3 = FinAnl;
			return new Promise(
				function (resolve, reject) {
					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter([
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3)
					// ], false));
					if (that.sTerm1) {
						aFilters.push(new sap.ui.model.Filter([
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
							// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
							// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3)
						], false));
					}

					if (that.sTerm2) {
						aFilters.push(new sap.ui.model.Filter([
							// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
							// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3)
						], false));
					}
					if (that.sTerm3) {
						aFilters.push(new sap.ui.model.Filter([
							// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
							// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3)
						], false));
					}
					var oModel = that.getView().getModel("oDataModel");
					oModel.read("/Search_Finan_AnalystSet", {
						filters: aFilters,
						success: function (oResponse) {
							// new sap.ui.model.json.JSONModel(oResponse.results);
							// return oModel;
							var term1 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm1;
							});

							if (term1.length !== 0) {
								var oViewModel = that.getView().getModel("appView");
								var firstName1 = term1[0].FirstName;
								var lastName1 = term1[0].LastName;
								var EmpID1 = term1[0].Pernr;
								var oID = term1[0].FirstName + "," + term1[0].LastName + "(" + term1[0].Pernr + ")";
								// oViewModel.getData().Requestor = oID;
								// that.getView().getModel("appView").refresh(true);
								that.getView().byId("idT2ActMngr").setValue(oID);

							} else {
								// that.getView().byId("idT2ActMngr").setValue(that.sTerm1);
								that.getView().getModel().setProperty("/draftData/d/Agm", that.sTerm1);
							}
							var term2 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm2;
							});
							if (term2.length !== 0) {
								var firstName1 = term2[0].FirstName;
								var lastName1 = term2[0].LastName;
								var EmpID1 = term2[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().getModel().setProperty("/draftData/d/Vernr", that.sTerm2);
									that.getView().byId("idT2PersResp").setValue(oID);
								}
							} else {
								// that.getView().byId("idT2ActMngr").setValue(that.sTerm2);
								that.getView().getModel().setProperty("/draftData/d/Vernr", that.sTerm2);
							}
							var term3 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm3;
							});
							if (term3.length !== 0) {
								var firstName1 = term3[0].FirstName;
								var lastName1 = term3[0].LastName;
								var EmpID1 = term3[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().getModel().setProperty("/toDetails/FinApp", that.sTerm3);
									that.getView().getModel().setProperty("/draftData/d/FinApp", that.sTerm3);
									that.getView().byId("idT1FinAnyst").setValue(oID);
									that.getView().byId("idT2FinAnyst").setValue(oID);
								}
							} else {
								// that.getView().byId("idT2ActMngr").setValue(that.sTerm3);
								that.getView().getModel().setProperty("/toDetails/FinApp", that.sTerm3);
								that.getView().getModel().setProperty("/draftData/d/FinApp", that.sTerm3);
							}
							resolve(oResponse);
						},
						error: function (oError) {
							reject(oError);
						}

					});
				});
		},
		_fnSuccessHandler: function () {
			sap.ui.core.BusyIndicator.hide();
		},
		onLoadOppManageData: function (Zpspid, sTYPE, obj) {
			sap.ui.core.BusyIndicator.show(0);
			this.navvyArryManType = sTYPE;
			this.getView().byId("idWbsGuided").setEnabled(false);
			var oModel = this.getView().getModel("oDataModelMng");
			var that = this;
			// this.oManageModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZODATA_WBS_MANAGE_SRV");
			// urlParameters: {
			// 	"$orderby": "Systemdate desc, Systemtime desc"
			// },
			oModel.read("/ZPROJHEADERSet(SysId='COMPASS',Zpspid='" + Zpspid + "')", {
				urlParameters: {
					'$expand': "toItem"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					jQuery.sap.require("jquery.sap.storage");
					var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
					if (oStorage.get("oppData")) {
						var obj = oStorage.get("oppData");
						// oStorage.clear();
					}
					that.getView().getModel().setProperty("/toOpprData", obj);
					var oppID = obj[0].OptId;
					var oViewModel = that.getView().getModel("appView");
					//Begin of commeted by Srinivas vallepu Phase2  Production issue
					// if (oData.Changed_by !== "BKGRND_USER" && that.navvyArryManType !== "OpprApp") {
					// 	oViewModel.getData().Requestor = oData.Changed_by;
					// 	oViewModel.getData().RequestorName = "";
					// } else if (oData.Changed_by === "BKGRND_USER") {
					// 	var oUser = new UserInfo();
					// 	var ouserId = oUser.getId();
					// 	var ofirstName = oUser.getUser().getFirstName().toUpperCase();
					// 	var olastName = oUser.getUser().getLastName().toUpperCase();
					// 	var ofullID = ofirstName + "," + olastName + " " + ouserId;
					// 	oViewModel.getData().Requestor = ofullID;
					// 	oViewModel.getData().RequestorName = "";
					// }

					var oNumber = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
					var oLuser = oData.Changed_by.split("", 1);
					var oDataReturn = oNumber.filter(function (a) {
						return a === oLuser[0];
					});
					if (oDataReturn.length > 0) {
						oViewModel.getData().Requestor = oData.Changed_by;
						oViewModel.getData().RequestorName = "";
					} else {
						var oUser = new UserInfo();
						var ouserId = oUser.getId();
						var ofirstName = oUser.getUser().getFirstName().toUpperCase();
						var olastName = oUser.getUser().getLastName().toUpperCase();
						var ofullID = ofirstName + "," + olastName + " " + ouserId;
						oViewModel.getData().Requestor = ofullID;
						oViewModel.getData().RequestorName = "";
					}

					//End of commeted by Srinivas vallepu Phase2  Production issue
					if (that.navvyArryManType !== "OpprApp") {
						oViewModel.getData().RequestorName = "";
						oViewModel.getData().ReqDate = oData.Changed_on.toDateString();
					}
					oViewModel.getData().EstatTxt = "";
					oViewModel.getData().sys_orign = oData.Des_sys;
					that.getView().getModel("appView").refresh(true);
					/*Load the data to local model for binding*/
					var prjType = "";
					if (oData.toItem.results && oData.toItem.results.length > 0) {
						prjType = oData.toItem.results[0].Prart;
					}
					if (prjType === "C" || prjType === "L") {
						prjType = "PRJ_TYP1";
						that.onSelectUserStatus(prjType);
						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Trade";
						that.getView().getModel("appView").refresh(true);
						that.getView().byId("idT2OpporId").setRequired(true);
						that.getView().byId("idLblOpp").setRequired(true);
						that.getView().byId("idT2LdPracSet").setEditable(true);
						that.getView().byId("idT2LdPracSet").setRequired(true);
						that.getView().byId("idT2RevMthd").setRequired(true);

						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
						var aFiltersT4 = new sap.ui.model.Filter({
							// filters: [
							// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ4"),
							// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ5"),
							// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ6"),
							// 	new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ7")
							// 	// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ2"),
							// 	// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ3")
							// ],
							// and: true
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ3"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ2")
							],
							and: false
						});
						oBindingBoxT4.filter(aFiltersT4);

					} else {
						prjType = "PRJ_TYP2";
						that.onSelectUserStatus(prjType);
						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Internal";
						that.getView().getModel("appView").refresh(true);
						that.getView().byId("idT2OpporId").setRequired(false);
						that.getView().byId("idT2OpporId").setEditable(false);
						that.getView().byId("idT2LdPracSet").setEditable(false);
						// that.getView().byId("idT2RevMthd").setRequired(false);
						that.getView().byId("idT2RevMthd").setValue("TE");

						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "C"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "L"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
							],
							and: true
						});
						oBindingBoxT3.filter(aFiltersT3);

						oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
						var aFiltersT4 = new sap.ui.model.Filter({
							filters: [
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ4"),
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ5"),
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ2"),
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ3")
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5")
							],
							and: false
						});
						oBindingBoxT4.filter(aFiltersT4);
					}

					var toStatus = {
						"results": [{
							ReqNum: "",
							StCount: "",
							ActType: "SUBMITTER",
							ActId: "",
							TimeStp: "0",
							ActCom: "",
							Status: ""
						}]
					};
					var toDetails = {
						"results": [{
							ReqNum: "",
							Zbukrs: oData.Zbukrs,
							Zpspid: oData.Zpspid,
							Zvbeln: "",
							ProjTyp: prjType,
							ReasReq: "",
							Req_com: oData.Req_com,
							ReqDet: "",
							Priority: "",
							ReqFun: "",
							TypeReq: "",
							FinApp: oData.FinApp,
							Email: []
						}]
					};
					var toError = {
						"results": []
					};
					var toAttach = {
						"results": []
					};
					oData.toDetails = toDetails;
					oData.toStatus = toStatus;
					oData.toError = toError;
					oData.toAttach = toAttach;
					var oNoToItem = oData.toItem.results.length;
					for (var i = 0; i < oNoToItem; i++) {
						delete oData.toItem.results[i].__metadata;
						delete oData.toItem.results[i].SysId;
					}
					delete oData.__metadata;
					delete oData.SysId;
					delete oData.ChangedAt;
					that.getView().getModel().setProperty("/draftData/d", oData);
					that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
					if (oData.toItem.results && oData.toItem.results.length > 0) {
						that.getView().getModel().setProperty("/draftData/d/Wbs_type", oData.toItem.results[0].Prart);
					}
					// that.getView().getModel().setProperty("/draftData/d/Zzsiebelid", oppID);    // this code to display opp id which is selected in opp App.

					var oEmail = oData.toDetails.results[0].Email;
					var aLen = oEmail.length;
					if (aLen != 0) {
						var data = oEmail.split(",");
						var tokenValue = [];
						for (var i = 0; i < data.length; i++) {
							tokenValue.push(new Token({
								text: data[i],
								key: data[i]
							}));
						}
						var oMultiInput1 = that.getView().byId("idT1Email");
						oMultiInput1.setTokens(tokenValue);
					}
					that.getView().byId("idProjDefi").setValue(oData.Zpspid);
					that.getView().byId("idT2ContractType").setSelectedKey(oData.ZzContracttype);
					that.getView().byId("idProjType").setSelectedKey(prjType);
					that.getView().byId("idWBSTypeT1").setEnabled(false);
					if (oData.ZzGlblProj === "X") {
						that.getView().byId("idGlobProj").setEditable(false);
					}
					if (that.navvyArryManType === "OpprApp") {
						oData.toItem.results.forEach(function (oItem) {
							oItem.Zentry_tp = "E";
						});
						// that.getView().getModel().setProperty("/wbsElementStr", oData.toItem.results);
						that.getView().getModel("pageModel").setProperty("/wbsElementStr", oData.toItem.results); // rohit - change
					}
					// that.getView().byId("idT1ComCode").setSelectedKey(oData.Zbukrs);
					var optID = [...new Map(oData.toItem.results.map(item => [item["ZsfdcOppid"], item])).values()];
					//Promise call
					Promise.all([
						// that._fnReadSelectServiceOff(oData.Vgsbr),
						// that._fnReadSelectProjPhase(oData.Vgsbr),
						that._fnReadSelectServiceOff(), // Added Production Phase2 issue srini vallepu
						that._fnReadSelectProjPhase(), /// Added Production Phase2 issue srini vallepu
						that._fnReadEmpIDNameManOppApp(oData.Changed_by, oData.FinApp, oData.Vernr, oData.PrjAd, oData.Agm),
						that._fnReadSelectOppAppDataTab4(optID),
						//	that._fnonSelectUserStatus(),		//Mayank: Added condition, if required same as onloadoppData.
						that._fnReadEnableDesableFields("C")
					]).then(that._fnSuccessHandler.bind(that));

					// that.onSelectServiceOff(oData.Vgsbr);
					// that.onSelectProjPhase(oData.Vgsbr);
					// that.onSelectWbsType(oData.Zpgid);
					// that.sTerm1 = oData.Changed_by;
					// that.sTerm2 = oData.FinApp;
					// that.sTerm3 = oData.Vernr;
					// that.sTerm4 = oData.PrjAd;
					// that.sTerm5 = oData.FinApp;
					// that.sTerm6 = oData.Agm;

					// var aFilters = [];
					// // aFilters.push(new sap.ui.model.Filter("Sysnam", sap.ui.model.FilterOperator.Contains, "COM"));
					// aFilters.push(new sap.ui.model.Filter([
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm5),
					// 	new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6),
					// ], false));
					// var oModel1 = that.getView().getModel("oDataModel");
					// oModel1.read("/Search_Finan_AnalystSet", {
					// 	filters: aFilters,
					// 	success: function (oResponse) {
					// 		// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					// 		// return oModel;
					// 		var term1 = oResponse.results.filter(function (a) {
					// 			return a.Pernr === that.sTerm1;
					// 		});
					// 		if (term1.length !== 0 && that.navvyArryManType !== "OpprApp") {
					// 			var oViewModel = that.getView().getModel("appView");
					// 			var firstName1 = term1[0].FirstName;
					// 			var lastName1 = term1[0].LastName;
					// 			var EmpID1 = term1[0].Pernr;
					// 			var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
					// 			// oViewModel.getData().Requestor = oID;
					// 			oViewModel.getData().Requestor = EmpID1;
					// 			oViewModel.getData().RequestorName = firstName1 + "," + lastName1;
					// 			that.getView().getModel("appView").refresh(true);
					// 		}

					// 		var term2 = oResponse.results.filter(function (a) {
					// 			return a.Pernr === that.sTerm2;
					// 		});
					// 		if (term2.length !== 0) {
					// 			var firstName1 = term2[0].FirstName;
					// 			var lastName1 = term2[0].LastName;
					// 			var EmpID1 = term2[0].Pernr;
					// 			if (EmpID1 !== "00000000") {
					// 				var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
					// 				that.getView().byId("idT1FinAnyst").setValue(oID);
					// 			}
					// 		}

					// 		var term3 = oResponse.results.filter(function (a) {
					// 			return a.Pernr === that.sTerm3;
					// 		});
					// 		if (term3.length !== 0) {
					// 			var firstName1 = term3[0].FirstName;
					// 			var lastName1 = term3[0].LastName;
					// 			var EmpID1 = term3[0].Pernr;
					// 			if (EmpID1 !== "00000000") {
					// 				var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
					// 				that.getView().byId("idT2PersResp").setValue(oID);
					// 			}
					// 		}

					// 		var term4 = oResponse.results.filter(function (a) {
					// 			return a.Pernr === that.sTerm4;
					// 		});
					// 		if (term4.length !== 0) {
					// 			var firstName1 = term4[0].FirstName;
					// 			var lastName1 = term4[0].LastName;
					// 			var EmpID1 = term4[0].Pernr;
					// 			if (EmpID1 !== "00000000") {
					// 				var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
					// 				that.getView().byId("idT2ProjAdmin").setValue(oID);
					// 			}
					// 		}

					// 		var term5 = oResponse.results.filter(function (a) {
					// 			return a.Pernr === that.sTerm5;
					// 		});
					// 		if (term5.length !== 0) {
					// 			var firstName1 = term5[0].FirstName;
					// 			var lastName1 = term5[0].LastName;
					// 			var EmpID1 = term5[0].Pernr;
					// 			if (EmpID1 !== "00000000") {
					// 				var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
					// 				that.getView().byId("idT2FinAnyst").setValue(oID);
					// 			}
					// 		}

					// 		var term6 = oResponse.results.filter(function (a) {
					// 			return a.Pernr === that.sTerm6;
					// 		});
					// 		if (term6.length !== 0) {
					// 			var firstName1 = term6[0].FirstName;
					// 			var lastName1 = term6[0].LastName;
					// 			var EmpID1 = term6[0].Pernr;
					// 			if (EmpID1 !== "00000000") {
					// 				var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
					// 				that.getView().byId("idT2ActMngr").setValue(oID);
					// 			}
					// 		}
					// 		//To Change app  title 
					// 		var oView1 = that.getView().getParent();
					// 		oView1.getService("ShellUIService").then(
					// 			function (oService) {
					// 				oService.setTitle("Manage Project Request");
					// 			}
					// 		);
					// 		that.byId("HeaderID").setObjectTitle("Manage Project Request");

					// 		//
					// 	},
					// 	error: function (oError) {}
					// });
					// that.onSelectOppAppDataTab4();
					// that.onRequestTypeTab1();
					//Commented 10-01-2022
					if (that.navvyArryManType === "OpprApp") {
						that.getView().byId("idProjType").setEnabled(false);
						that.getView().byId("idProjDefi").setEnabled(false);
						// 	that.getView().byId("idT4ProjDefDesc").setEditable(false);
						// 	that.getView().byId("idStartDate").setEnabled(false);
						// 	that.getView().byId("idEnddate").setEnabled(false);
						// 	that.getView().byId("idT2PersResp").setEditable(false);
						// 	that.getView().byId("idT2ProjRespCC").setEditable(false);
						// 	that.getView().byId("idT2ProjCategory").setEditable(false);
						// 	that.getView().byId("idT2ContractId").setEditable(false);
						// 	that.getView().byId("idT2ContractType").setEditable(false);
						// 	that.getView().byId("idT2CustId").setEditable(false);
						// 	that.getView().byId("idT2LdPracSet").setEditable(false);
						// 	that.getView().byId("idT2ProjAdmin").setEditable(false);
						// 	that.getView().byId("idT2FinAnyst").setEditable(false);
						// 	that.getView().byId("idT2ActMngr").setEditable(false);
						// 	that.getView().byId("idT2PrjSts").setEditable(false);
						// 	that.getView().byId("idT2RevMthd").setEditable(false);
						// 	that.getView().byId("idT2ContractTrm").setEditable(false);
						// 	that.getView().byId("idT2OpporId").setEditable(false);
						// 	that.getView().byId("idT2Program").setEditable(false);
						// 	that.getView().byId("idGlobProj").setEditable(false);
						// 	that.getView().byId("idEvExtract").setEditable(false);
						// 	that.getView().byId("idWBSTypeT1").setEnabled(false);
					}

					// sap.ui.core.BusyIndicator.hide();
				},
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		_fnReadSelectServiceOff: function (Gsber) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					var oModel = that.getView().getModel("oDataModel");
					var aFilters = [];
					aFilters.push(new Filter("VGSBR", sap.ui.model.FilterOperator.EQ, Gsber));
					// var that = this;
					// oModel.read("/Search_Service_OfferingSet", {
					// 	success: function (oResponse) {

					// 		//rohit - change
					// 		// var oSerOff = new JSONModel(oResponse.results);
					// 		// that.getView().setModel(oSerOff, "oServiOffer");

					// 		var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
					// 		for (var m = 0; m < tableData.length; m++) { // rohit - change

					// 			// 	var targetElement = oResponse.results.find(function (element) { // rohit - change
					// 			// 		if (element.VGSBR === tableData[m].Pgsbr) {
					// 			// 			return element;
					// 			// 		}

					// 			// 	});
					// 			var contextid = "/wbsElementStr/" + m.toString();

					// 			// tableData[m].Zzsolseid = targetElement.Solseid; // rohit - change
					// 			that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);

					// 		}
					// 		resolve(oResponse);
					// 	},
					// 	error: function (oError) {
					// 		reject(oError);
					// 	}
					// });

					if (Gsber) {
						oModel.read("/Search_Service_OfferingSet", {
							filters: aFilters,
							success: function (oResponse) {
								//rohit - change
								var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");

								for (var m = 0; m < tableData.length; m++) { // Mayank - change
									var contextid = "/wbsElementStr/" + m.toString();
									var oCurrServiOff = tableData[m].Zzsolseid;
									var oNewResult = oResponse.results.filter(function (a) {
										return a.Solseid === oCurrServiOff;
									});
									if (oNewResult.length >= 1) {
										that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);
									} else {
										var oNewSerOff = {
											PCSGID: "",
											Solseds: "",
											Solseid: oCurrServiOff,
											VGSBR: "",
											ZZ_TOC: ""
										};
										var OCopyData = oResponse.results;
										OCopyData.push(oNewSerOff);
										that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", OCopyData);
									}
								}
								resolve(oResponse);

							},
							error: function (oError) {
								reject(oError);
							}
						});
					} else {
						oModel.read("/Search_Service_OfferingSet", {
							success: function (oResponse) {
								//rohit - change
								var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
								//341844 - 
								oResponse.results = [...new Map(oResponse.results.map(item => [item["Solseid"], item])).values()];

								for (var m = 0; m < tableData.length; m++) { // Mayank - change
									var contextid = "/wbsElementStr/" + m.toString();
									var oCurrServiOff = tableData[m].Zzsolseid;
									var oNewResult = oResponse.results.filter(function (a) {
										return a.Solseid === oCurrServiOff;
									});
									if (oNewResult.length >= 1) {
										that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);
									} else {
										var oNewSerOff = {
											PCSGID: "",
											Solseds: "",
											Solseid: oCurrServiOff,
											VGSBR: "",
											ZZ_TOC: ""
										};
										var OCopyData = oResponse.results;
										OCopyData.push(oNewSerOff);
										that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", OCopyData);
									}
									// that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);
								}
								resolve(oResponse);
							},
							error: function (oError) {
								reject(oError);
							}
						});
					}

				});
		},
		_fnReadSelectProjPhase: function (Pgsbr) {
			// var that = this;
			var that = this;
			return new Promise(
				function (resolve, reject) {
					var oModel = that.getView().getModel("oDataModel");
					var PrartTyp = that.getView().byId("idWBSTypeT1").getValue();
					var projType = that.getView().byId("idProjType").getSelectedKey();
					var PrartTyp;

					var aFilters = [];
					aFilters.push(new Filter("Pgsbr", sap.ui.model.FilterOperator.EQ, Pgsbr));
					aFilters.push(new Filter("Prart", sap.ui.model.FilterOperator.EQ, PrartTyp));
					// var that = this;
					oModel.read("/Search_proj_Phase_CodeSet", {

						urlParameters: {
							"$orderby": "ZzprojPhaseCd asc"
						},
						success: function (oResponse) {
							// var oProjPhase = new JSONModel(oResponse.results);
							// that.getView().setModel(oProjPhase, "oProjPhase");

							var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
							oResponse.results = [...new Map(oResponse.results.map(item => [item["ZzprojPhaseCd"], item])).values()]; // Phase2 Production  Issue 
							for (var m = 0; m < tableData.length; m++) {
								var contextid = "/wbsElementStr/" + m.toString();
								that.getView().getModel("pageModel").setProperty(contextid + "/oProjPhaseTempModl", oResponse.results);
							}
							resolve(oResponse);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
		},
		_fnReadSelectOppAppDataTab4: function (oppID) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					var oModel = that.getView().getModel("oDataModel");
					//Commented by  Srinivas Vallepu 12/01/22
					// var oppData = that.getView().getModel().getProperty("/toOpprData");
					// var oppID = oppData[0].OptId;
					// var aFilters = [];
					// for (var i = 0; i < oppData.length; i++) {
					// 	aFilters.push(new sap.ui.model.Filter("Uniq_id", sap.ui.model.FilterOperator.Contains, oppData[i].CasesafeId));
					// }
					// aFilters.push(new sap.ui.model.Filter([
					// 	new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, oppID),
					// ], false));
					// End of Commented by  Srinivas Vallepu 12/01/22
					var aFilters = [];
					for (var i = 0; i < oppID.length; i++) {
						if (oppID[i].ZsfdcOppid) {
							aFilters.push(new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.EQ, oppID[i].ZsfdcOppid));
						}
					}
					if (aFilters.length !== 0) {
						oModel.read("/Search_Safecase_IDSet", {
							filters: aFilters,
							success: function (oResponse) {
								var oSafecase = new JSONModel(oResponse.results);
								var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
								for (var m = 0; m < tableData.length; m++) { // rohit - change
									var contextid = "/wbsElementStr/" + m.toString();
									//that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oResponse.results);

									// CR ID 341819
									var oCurrOptIF = that.getView().getModel("pageModel").getProperty(contextid + "/ZsfdcOppid");
									var oCurrCaseSafeID = tableData[m].Safecase_id;
									var oNewResult = oResponse.results.filter(function (a) {
										return a.Opt_id === oCurrOptIF;
									});
									//that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult); // rohit - change
									if (oCurrCaseSafeID) {
										var oNewCaseSafe = {
											Opt_id: "",
											Uniq_id: oCurrCaseSafeID,
											Zzsolseid: "",
											Cnt_typ: "",
											Sol_typ: "",
											Zz_toc: ""
										};
										var OCopyData = oResponse.results;
										OCopyData.push(oNewCaseSafe);
										that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", OCopyData);
										// }

									} else {
										that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult);
									}

								}
								resolve(oResponse);
							},
							error: function (oError) {
								reject(oError);
							}
						});
					}
				});
		},
		_fnReadEmpIDNameManOppApp: function (Changed_by, FinApp, Vernr, PrjAd, Agm) {
			var that = this;
			that.sTerm1 = Changed_by;
			that.sTerm2 = FinApp;
			that.sTerm3 = Vernr;
			that.sTerm4 = PrjAd;
			that.sTerm5 = FinApp;
			that.sTerm6 = Agm;
			return new Promise(
				function (resolve, reject) {
					var aFilters = [];
					if (that.sTerm1) {
						aFilters.push(new sap.ui.model.Filter([
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1)
						], false));
					}
					if (that.sTerm2) {
						aFilters.push(new sap.ui.model.Filter([
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2)
						], false));
					}
					if (that.sTerm3) {
						aFilters.push(new sap.ui.model.Filter([
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3)
						], false));
					}
					if (that.sTerm4) {
						aFilters.push(new sap.ui.model.Filter([
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4)
						], false));
					}
					if (that.sTerm6) {
						aFilters.push(new sap.ui.model.Filter([
							new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6)
						], false));
					}
					var oModel1 = that.getView().getModel("oDataModel");
					oModel1.read("/Search_Finan_AnalystSet", {
						filters: aFilters,
						success: function (oResponse) {
							// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
							// return oModel;
							var term1 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm1;
							});
							if (term1.length !== 0 && that.navvyArryManType !== "OpprApp") {
								var oViewModel = that.getView().getModel("appView");
								var firstName1 = term1[0].FirstName;
								var lastName1 = term1[0].LastName;
								var EmpID1 = term1[0].Pernr;
								var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
								// oViewModel.getData().Requestor = oID;
								oViewModel.getData().Requestor = EmpID1;
								oViewModel.getData().RequestorName = firstName1 + "," + lastName1;
								that.getView().getModel("appView").refresh(true);
							}

							var term2 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm2;
							});
							if (term2.length !== 0) {
								var firstName1 = term2[0].FirstName;
								var lastName1 = term2[0].LastName;
								var EmpID1 = term2[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT1FinAnyst").setValue(oID);
								}
							}

							var term3 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm3;
							});
							if (term3.length !== 0) {
								var firstName1 = term3[0].FirstName;
								var lastName1 = term3[0].LastName;
								var EmpID1 = term3[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2PersResp").setValue(oID);
								}
							}

							var term4 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm4;
							});
							if (term4.length !== 0) {
								var firstName1 = term4[0].FirstName;
								var lastName1 = term4[0].LastName;
								var EmpID1 = term4[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ProjAdmin").setValue(oID);
								}
							}

							var term5 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm5;
							});
							if (term5.length !== 0) {
								var firstName1 = term5[0].FirstName;
								var lastName1 = term5[0].LastName;
								var EmpID1 = term5[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2FinAnyst").setValue(oID);
								}
							}

							var term6 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm6;
							});
							if (term6.length !== 0) {
								var firstName1 = term6[0].FirstName;
								var lastName1 = term6[0].LastName;
								var EmpID1 = term6[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ActMngr").setValue(oID);
								}
							}
							//To Change app  title 
							var oView1 = that.getView().getParent();
							oView1.getService("ShellUIService").then(
								function (oService) {
									oService.setTitle("Manage Project Request");
								}
							);
							that.byId("HeaderID").setObjectTitle("Manage Project Request");
							resolve(oResponse);
							//
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
		},
		onLoadChnageProject: function (Zpspid, TYPE) {
			sap.ui.core.BusyIndicator.show(0);
			this.getView().byId("idWbsGuided").setEnabled(false);
			var oModel = this.getView().getModel("oDataModelMng");
			var that = this;
			// this.oManageModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZODATA_WBS_MANAGE_SRV");
			// urlParameters: {
			// 	"$orderby": "Systemdate desc, Systemtime desc"
			// },
			// "/ZPROJHEADERSet(SysId='COMPASS',Zpspid='" + Zpspid + "')"
			oModel.read("/ZPROJHEADERSet(SysId='COMPASS',Zpspid='" + Zpspid + "')", {
				urlParameters: {
					'$expand': "toItem"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					var oViewModel = that.getView().getModel("appView");
					// Phase2  Production issue - Added by  srini vallepu
					var oNumber = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
					var oLuser = oData.Changed_by.split("", 1);
					var oDataReturn = oNumber.filter(function (a) {
						return a === oLuser[0];
					});
					if (oViewModel.getData().type === "DuplicateExisting") {
						var oUser = new UserInfo();
						var ouserId = oUser.getId();
						var ofirstName = oUser.getUser().getFirstName().toUpperCase();
						var olastName = oUser.getUser().getLastName().toUpperCase();
						var ofullID = ofirstName + "," + olastName + " " + ouserId;
						oViewModel.getData().Requestor = ofullID;
						oViewModel.getData().RequestorName = "";

					} else {
						if (oDataReturn.length > 0) {
							oViewModel.getData().Requestor = oData.Changed_by;
							oViewModel.getData().RequestorName = "";
						} else {
							var oUser = new UserInfo();
							var ouserId = oUser.getId();
							var ofirstName = oUser.getUser().getFirstName().toUpperCase();
							var olastName = oUser.getUser().getLastName().toUpperCase();
							var ofullID = ofirstName + "," + olastName + " " + ouserId;
							oViewModel.getData().Requestor = ofullID;
							oViewModel.getData().RequestorName = "";
						}
					}
					// if (oData.Changed_by !== "BKGRND_USER" && oViewModel.getData().type !== "ChangeProject") {
					// 	oViewModel.getData().Requestor = oData.Changed_by;
					// 	oViewModel.getData().RequestorName = "";
					// } else if (oData.Changed_by === "BKGRND_USER") {
					// 	var oUser = new UserInfo();
					// 	var ouserId = oUser.getId();
					// 	var ofirstName = oUser.getUser().getFirstName().toUpperCase();
					// 	var olastName = oUser.getUser().getLastName().toUpperCase();
					// 	var ofullID = ofirstName + "," + olastName + " " + ouserId;
					// 	oViewModel.getData().Requestor = ofullID;
					// 	oViewModel.getData().RequestorName = "";
					// }
					// if (oViewModel.getData().type !== "ChangeProject") {
					// 	oViewModel.getData().RequestorName = "";
					// 	oViewModel.getData().ReqDate = oData.Changed_on.toDateString();

					// }
					// Phase2  -  Production issue - End of comment by Srini vallepu
					oViewModel.getData().EstatTxt = "";
					if (oViewModel.getData().type === "DuplicateExisting") {
						oViewModel.getData().EstatTxt = "Create";
					}
					oViewModel.getData().sys_orign = oData.Des_sys;
					oViewModel.getData().fixedWBSEle = oData.Zpspid;
					oViewModel.getData().comCode = oData.Zbukrs;
					that.getView().getModel("appView").refresh(true);

					var Proid = oData.Zpspid.slice(0, 2);
					var m = Proid + "@-#####";
					that.getView().byId("idProjDefi").setMask(m);

					/*Load the data to local model for binding*/
					var prjType = "";
					if (oData.toItem.results && oData.toItem.results.length > 0) {
						prjType = oData.toItem.results[0].Prart;
					}
					if (prjType === "C" || prjType === "L") {
						prjType = "PRJ_TYP1";
						that.onSelectUserStatus(prjType);
						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Trade";
						that.getView().getModel("appView").refresh(true);
						that.getView().byId("idT2OpporId").setRequired(true);
						that.getView().byId("idLblOpp").setRequired(true);
						that.getView().byId("idT2LdPracSet").setEditable(true);
						that.getView().byId("idT2LdPracSet").setRequired(true);
						// that.getView().byId("idT2RevMthd").setRequired(true);

						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oProjectBox = that.getView().byId("idT2ContractType");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
							],
							and: true
						});
						// aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

						var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
						if (TYPE === "DuplicateExisting") {
							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1")
								],
								and: false
							});
						} else {
							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ3"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ2")
								],
								and: false
							});
						}

						oBindingBoxT4.filter(aFiltersT4);

					} else {
						prjType = "PRJ_TYP2";
						that.onSelectUserStatus(prjType);
						var oViewModel = that.getView().getModel("appView");
						var oAdmin = oViewModel.getData().Admin;
						if (oData.toItem.results[2].Zz_gtmwbs) {
							oViewModel.getData().projType = "Trade";
						} else {
							oViewModel.getData().projType = "Internal";
						}
						that.getView().getModel("appView").refresh(true);
						// that.getView().byId("idT2OpporId").setRequired(false);
						// that.getView().byId("idT2OpporId").setEditable(false);
						// that.getView().byId("idT2LdPracSet").setEditable(false);
						// that.getView().byId("idT2RevMthd").setRequired(false);
						that.getView().byId("idT2RevMthd").setValue("TE");

						var oProjectBox = that.getView().byId("idT2ContractType");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);
						if (TYPE === "ChangeProject") {
							if (oAdmin === true && oData.toItem.results[0].Prart === "B") {
								that.getView().byId("idT2OpporId").setRequired(true);
								that.getView().byId("idT2OpporId").setEditable(true);
								that.getView().byId("idT2LdPracSet").setEditable(true);
								that.getView().byId("idT2LdPracSet").setRequired(true);
								if (oData.Zzldpcid === "") {
									that.getView().byId("idT2LdPracSet").setValue("HQCEX");
									that.getView().byId("idT2LdPracSet").setSelectedKey("HQCEX");
								}

								that.getView().byId("idReqType").setValue("Business & Development Project");
								that.getView().byId("idReqType").setSelectedKey("Business & Development Project");
								that.getView().byId("idReqType").setEditable(false);

								oViewModel.getData().oppAdmin = true;

								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								var aFiltersT3 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
									],
									and: true
								});
								oBindingBoxT3.filter(aFiltersT3);

								var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");

								if (oData.Zbukrs === "ES87" || oData.Zbukrs === "ES88" || oData.Zbukrs === "ES89") {
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
										],
										and: false
									});
								} else {
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
										],
										and: false
									});
								}
								oBindingBoxT4.filter(aFiltersT4);

								var oProjectBox = that.getView().byId("idReqTypeDtls");
								var oBindingBox = oProjectBox.getBinding("items");
								// var aFilters5 = [];
								// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Business & Development Project");Field
								var aFilters5 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET27")
										// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET28"),
										// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
									],
									and: false
								});
								// aFilters5.push(oFilters);
								oBindingBox.filter(aFilters5);

								// } else if (oData.toItem.results[2].Zz_gtmwbs) { // Logic for Spanish project
							} else if (oData.Zzsiebelid !== "" && oData.toItem.results[0].Prart === "J") {
								var oSpanishChange = "YES";
								that.getView().byId("idT2OpporId").setRequired(true);
								that.getView().byId("idLblOpp").setRequired(true);
								that.getView().byId("idT2LdPracSet").setEditable(true);
								that.getView().byId("idT2LdPracSet").setRequired(true);
								that.getView().byId("idT2RevMthd").setEditable(true);
								// that.getView().byId("idT2RevMthd").setRequired(true);

								var oProjectBox = that.getView().byId("idT2ContractType");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
									],
									and: true
								});
								// aFilters.push(oFilters);
								oBindingBox.filter(aFilters);
								that.getView().byId("idReqType").setValue("Spanish Delivery Project");
								that.getView().byId("idReqType").setSelectedKey("Spanish Delivery Project");
								that.getView().byId("idReqType").setEditable(false);

								var oProjectBox = that.getView().byId("idReqTypeDtls");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = [];
								var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET30");
								aFilters.push(oFilters);
								oBindingBox.filter(aFilters);
								// var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
								// var aFiltersT4 = new sap.ui.model.Filter({
								// 	filters: [
								// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
								// 	],
								// 	and: false
								// });

								// oBindingBoxT4.filter(aFiltersT4);
								oViewModel.getData().projType = "Trade";
								oViewModel.getData().oSpanProj = "YES";
								that.getView().getModel("appView").refresh(true);

							} else {
								if (oData.toItem.results[0].Prart === "J" || oData.toItem.results[0].Prart === "R" || oData.toItem.results[0].Prart === "V") {

									that.getView().byId("idReqType").setValue("Standard Internal Project(Funded)");
									that.getView().byId("idReqType").setSelectedKey("Standard Internal Project(Funded)");
									that.getView().byId("idReqType").setEditable(false);
									var oProjectBox = that.getView().byId("idReqTypeDtls");
									var oBindingBox = oProjectBox.getBinding("items");
									var aFilters = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET23")
										],
										and: false
									});
									oBindingBox.filter(aFilters);

								} else if (oData.toItem.results[0].Prart === "E" || oData.toItem.results[0].Prart === "M" ||
									oData.toItem.results[0].Prart === "O" || oData.toItem.results[0].Prart === "W") {

									that.getView().byId("idReqType").setValue("Standard Internal Project(Non-Funded)");
									that.getView().byId("idReqType").setSelectedKey("Standard Internal Project(Non-Funded)");
									that.getView().byId("idReqType").setEditable(false);
									var oProjectBox = that.getView().byId("idReqTypeDtls");
									var oBindingBox = oProjectBox.getBinding("items");
									var aFilters = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20")
										],
										and: false
									});
									oBindingBox.filter(aFilters);

								}
								oViewModel.getData().oppAdmin = false;

								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								var aFiltersT3 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "C"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "L"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
									],
									and: true
								});
								oBindingBoxT3.filter(aFiltersT3);

								var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
								// if (oData.Zbukrs === "ES87" || oData.Zbukrs === "ES88" || oData.Zbukrs === "ES89") {
								// 	that.getView().byId("idT2OpporId").setRequired(true);
								// 	that.getView().byId("idT2OpporId").setEditable(true);
								// 	that.getView().byId("idT2LdPracSet").setEditable(true);
								// 	that.getView().byId("idT2LdPracSet").setRequired(true);
								// 	that.getView().byId("idT2RevMthd").setEditable(true);
								// 	var aFiltersT4 = new sap.ui.model.Filter({
								// 		filters: [
								// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
								// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
								// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
								// 		],
								// 		and: false
								// 	});
								// } else {
								that.getView().byId("idT2OpporId").setRequired(false);
								that.getView().byId("idT2OpporId").setEditable(false);
								that.getView().byId("idT2LdPracSet").setEditable(false);
								that.getView().byId("idT2LdPracSet").setRequired(false);
								var aFiltersT4 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5")
									],
									and: false
								});
								// }
								oBindingBoxT4.filter(aFiltersT4);
							}
						} else if (TYPE === "DuplicateExisting") {
							var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
							if (oAdmin === true && oData.toItem.results[0].Prart === "B") {
								var aFiltersDup = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")

									],
									and: false
								});

							} else {
								var aFiltersDup = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5")
									],
									and: false
								});
							}

							oBindingBoxT4.filter(aFiltersDup);

						}

						that.getView().getModel("appView").refresh(true);
					}

					var toStatus = {
						"results": [{
							ReqNum: "",
							StCount: "",
							ActType: "SUBMITTER",
							ActId: "",
							TimeStp: "0",
							ActCom: "",
							Status: ""
						}]
					};
					var toDetails = {
						"results": [{
							ReqNum: "",
							Zbukrs: oData.Zbukrs,
							Zpspid: oData.Zpspid,
							Zvbeln: "",
							ProjTyp: prjType,
							ReasReq: "",
							Req_com: oData.Req_com,
							ReqDet: "",
							Priority: "",
							ReqFun: "",
							TypeReq: "",
							FinApp: oData.FinApp,
							Email: []
						}]
					};
					var toError = {
						"results": []
					};
					var toAttach = {
						"results": []
					};
					oData.toDetails = toDetails;
					oData.toStatus = toStatus;
					oData.toError = toError;
					oData.toAttach = toAttach;
					var oNoToItem = oData.toItem.results.length;
					for (var i = 0; i < oNoToItem; i++) {
						delete oData.toItem.results[i].__metadata;
						delete oData.toItem.results[i].SysId;
					}
					delete oData.__metadata;
					delete oData.SysId;
					delete oData.ChangedAt;
					/*Below code for load case safe id*/
					var optID = [...new Map(oData.toItem.results.map(item => [item["ZsfdcOppid"], item])).values()];
					if (optID.length > 0) {
						that.onLoadCaseSafeChangeProjTab4(optID);
					}

					that.getView().getModel().setProperty("/draftData/d", oData);
					that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
					that.getView().getModel().setProperty("/draftData/d/Wbs_type", oData.toItem.results[0].Prart);
					var oEmail = oData.toDetails.results[0].Email;
					var aLen = oEmail.length;
					if (aLen != 0) {
						var data = oEmail.split(",");
						var tokenValue = [];
						for (var i = 0; i < data.length; i++) {
							tokenValue.push(new Token({
								text: data[i],
								key: data[i]
							}));
						}
						var oMultiInput1 = that.getView().byId("idT1Email");
						oMultiInput1.setTokens(tokenValue);
					}

					that.getView().byId("idProjDefi").setValue(oData.Zpspid);
					that.getView().byId("idT2ContractType").setSelectedKey(oData.ZzContracttype);
					that.getView().byId("idProjType").setSelectedKey(prjType);
					if (TYPE === "ChangeProject") {
						oData.toItem.results.forEach(function (oItem) {
							oItem.Zentry_tp = "E";
						});
						// that.getView().getModel().setProperty("/wbsElementStr", oData.toItem.results);
						that.getView().getModel("pageModel").setProperty("/wbsElementStr", oData.toItem.results); // rohit - change
					}
					if (TYPE === "DuplicateExisting") {
						oData.toItem.results.forEach(function (oItem) {
							// oItem.Zentry_tp = "E";
							oItem.Zentry_tp = "";
							oItem.Systatusline = "REL";
						});
						for (var i = 0; i < oData.toItem.results.length; i++) {
							oData.toItem.results[i].oldZposid = oData.toItem.results[i].Zposid; // for phase2 table
							if (oData.toItem.results[i].Stufe === 1 || oData.toItem.results[i].Stufe === 2) {
								oData.toItem.results[i].Ustatusline = "CRTD";
							}
						}
						that.getView().getModel("pageModel").setProperty("/wbsElementStr", oData.toItem.results); // rohit - change

					}
					if (TYPE === "DuplicateExisting") {
						// that.onSelectServiceOff(oData.Vgsbr);
						// that.onSelectProjPhase(oData.Vgsbr);
						that.onSelectServiceOff(); // Enabled due to Service Off not displaying 
						that.onSelectProjPhase(); // Enabled due to Service Off not displaying 
					} else {
						if (oAdmin === true && oData.toItem.results[0].Prart === "B") {
							that.onSelectServiceOff();
							that.onSelectProjPhase(oData.Vgsbr);
						} else {
							that.onSelectServiceOff();
							that.onSelectProjPhase();
						}

					}

					that.sTerm1 = oData.Changed_by;
					that.sTerm2 = oData.FinApp;
					that.sTerm3 = oData.Vernr;
					that.sTerm4 = oData.PrjAd;
					that.sTerm5 = oData.FinApp;
					that.sTerm6 = oData.Agm;

					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter("Sysnam", sap.ui.model.FilterOperator.Contains, "COM"));
					aFilters.push(new sap.ui.model.Filter([
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm5),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6),
					], false));
					var oModel1 = that.getView().getModel("oDataModel");
					oModel1.read("/Search_Finan_AnalystSet", {
						filters: aFilters,
						success: function (oResponse) {
							// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
							// return oModel;
							var term1 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm1;
							});
							var oViewModel = that.getView().getModel("appView");
							if (term1.length !== 0 && oViewModel.getData().type !== "ChangeProject") {
								var firstName1 = term1[0].FirstName;
								var lastName1 = term1[0].LastName;
								var EmpID1 = term1[0].Pernr;
								var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
								oViewModel.getData().Requestor = oID;
								that.getView().getModel("appView").refresh(true);
							}

							var term2 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm2;
							});
							if (term2.length !== 0) {
								var firstName1 = term2[0].FirstName;
								var lastName1 = term2[0].LastName;
								var EmpID1 = term2[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT1FinAnyst").setValue(oID);
								}
							}

							var term3 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm3;
							});
							if (term3.length !== 0) {
								var firstName1 = term3[0].FirstName;
								var lastName1 = term3[0].LastName;
								var EmpID1 = term3[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2PersResp").setValue(oID);
								}
							}

							var term4 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm4;
							});
							if (term4.length !== 0) {
								var firstName1 = term4[0].FirstName;
								var lastName1 = term4[0].LastName;
								var EmpID1 = term4[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ProjAdmin").setValue(oID);
								}
							}

							var term5 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm5;
							});
							if (term5.length !== 0) {
								var firstName1 = term5[0].FirstName;
								var lastName1 = term5[0].LastName;
								var EmpID1 = term5[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2FinAnyst").setValue(oID);
								}
							}

							var term6 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm6;
							});
							if (term6.length !== 0) {
								var firstName1 = term6[0].FirstName;
								var lastName1 = term6[0].LastName;
								var EmpID1 = term6[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ActMngr").setValue(oID);
								}
							}
							//To Change app  title 
							var oView1 = that.getView().getParent();
							if (TYPE === "DuplicateExisting") {
								oView1.getService("ShellUIService").then(
									function (oService) {
										oService.setTitle("New Project Request");
									}
								);
								that.byId("HeaderID").setObjectTitle("New Project Request");

							} else {
								oView1.getService("ShellUIService").then(
									function (oService) {
										oService.setTitle("Manage Project Request");
									}
								);
								that.byId("HeaderID").setObjectTitle("Manage Project Request");

							}

							//
						},

						error: function (oError) {}
					});

					if (TYPE === "ChangeProject" || TYPE === "DuplicateExisting") {
						that.getView().byId("idWbsGuided").setEnabled(false);
						// that.getView().byId("idT1FinAnyst").setEnabled(false);
						// that.getView().byId("idT1ComCode").setEnabled(false);
						that.getView().byId("idProjType").setEnabled(false);

						if (TYPE === "DuplicateExisting") {
							that.getView().byId("idProjDefi").setEnabled(true);
							that.getView().byId("idT1ComCode").setEnabled(true);
							that.getView().byId("idWBSTypeT1").setEnabled(true);
							that.getView().byId("idReqType").setEnabled(true);
							that.getView().byId("idWbsGuided").setEnabled(true);
						} else {
							that.getView().byId("idProjDefi").setEnabled(false);
							that.getView().byId("idT1ComCode").setEnabled(false);
							that.getView().byId("idWBSTypeT1").setEnabled(false);
							if (oData.ZzGlblProj === "X") {
								that.getView().byId("idGlobProj").setEditable(false);
							}
							that.getView().byId("uploBtn").setVisible(false);
						}
						// that.getView().byId("idT4ProjDefDesc").setEditable(false);
						// that.getView().byId("idStartDate").setEnabled(false);
						// that.getView().byId("idEnddate").setEnabled(false);
						// that.getView().byId("idT2PersResp").setEditable(false);
						// that.getView().byId("idT2ProjRespCC").setEditable(false);
						// that.getView().byId("idT2ProjCategory").setEditable(false);
						// that.getView().byId("idT2ContractId").setEditable(false);
						// that.getView().byId("idT2ContractType").setEditable(false);
						// that.getView().byId("idT2CustId").setEditable(false);
						// that.getView().byId("idT2LdPracSet").setEditable(false);
						// that.getView().byId("idT2ProjAdmin").setEditable(false);
						// that.getView().byId("idT2FinAnyst").setEditable(false);
						// that.getView().byId("idT2ActMngr").setEditable(false);
						// that.getView().byId("idT2PrjSts").setEditable(false);
						// that.getView().byId("idT2RevMthd").setEditable(false);
						// that.getView().byId("idT2ContractTrm").setEditable(false);
						// that.getView().byId("idT2OpporId").setEditable(false);
						// that.getView().byId("idT2Program").setEditable(false);
						// that.getView().byId("idEvExtract").setEditable(false);

					}

					// if (prjType === "C" || prjType === "L") { "PRJ_TYP1"
					if (prjType === "PRJ_TYP1" || oSpanishChange === "YES") {
						that.onEnableDesableFields("C");
					} else {
						that.onEnableDesableFields("J");
					}

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		onLoadCaseSafeChangeProjTab4: function (oppID) {
			var oModel = this.getView().getModel("oDataModel");
			// var oppData = this.getView().getModel().getProperty("/toOpprData");
			// var oppID = oppData[0].OptId;
			var aFilters = [];
			for (var i = 0; i < oppID.length; i++) {
				if (oppID[i].ZsfdcOppid) {
					aFilters.push(new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.EQ, oppID[i].ZsfdcOppid));
				}
				// aFilters.push(new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, "OPX-0020445867"));
				// aFilters.push(new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, "OPX-0020802547"));
			}
			if (aFilters.length !== 0) {
				var that = this;
				oModel.read("/Search_Safecase_IDSet", {
					filters: aFilters,
					success: function (oResponse) {
						var oSafecase = new JSONModel(oResponse.results);
						var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
						for (var m = 0; m < tableData.length; m++) { // rohit - change
							var contextid = "/wbsElementStr/" + m.toString();
							var oCurrOptIF = that.getView().getModel("pageModel").getProperty(contextid + "/ZsfdcOppid");
							var oCurrCaseSafeID = tableData[m].Safecase_id;
							var oNewResult = oResponse.results.filter(function (a) {
								return a.Opt_id === oCurrOptIF;
								// return a.Uniq_id === oCurrCaseSafeID
							});
							//that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult); // rohit - change

							// CR ID 341819
							if (oCurrCaseSafeID) {
								// if (oNewResult.length >= 1) {
								// 	that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult);
								// } else {
								var oNewCaseSafe = {
									Opt_id: "",
									Uniq_id: oCurrCaseSafeID,
									Zzsolseid: "",
									Cnt_typ: "",
									Sol_typ: "",
									Zz_toc: ""
								};
								var OCopyData = oResponse.results;
								OCopyData.push(oNewCaseSafe);
								that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", OCopyData);
								// }

							} else {
								that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult);
							}

						}
					},
					error: function (oError) {}
				});

			}

		},
		onEnableDesableFields: function (projType) {
			sap.ui.core.BusyIndicator.show(0);
			var oModel1 = this.getView().getModel("oDataModel");
			// var oModel = this.getView().getModel("oDataModel").setSizeLimit(300);
			var that = this;
			oModel1.read("/WBSHeaderChngFlgSet('" + projType + "')", {
				urlParameters: {
					'$expand': "toItmChngFlg"
				},
				success: function (oResponse) {
					delete oResponse.__metadata;
					delete oResponse.toItmChngFlg.__metadata;
					var oViewModel = that.getView().getModel("appView");
					var wbsType = that.getView().byId("idWBSTypeT1").getValue();
					if (oViewModel.getData().Admin === true && wbsType === "B") {
						oResponse.Zzldpcid = "X";
						oResponse.Zzsiebelid = "X";
						oResponse.toItmChngFlg.ZzTaskOrderCat = "X";
					}

					var EnableDesable = new JSONModel(oResponse);
					that.getView().setModel(EnableDesable, "EnableDesable");

					var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
					that.getView().setModel(toItmChngFlg, "toItmChngFlg");

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		onLoadChnageSpanishProject: function (Zpspid, Zbukrs, TYPE) {
			sap.ui.core.BusyIndicator.show(0);
			this.getView().byId("idWbsGuided").setEnabled(false);
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			// this.oManageModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZODATA_WBS_MANAGE_SRV");
			// urlParameters: {
			// 	"$orderby": "Systemdate desc, Systemtime desc"
			// },
			// "/ZPROJHEADERSet(SysId='COMPASS',Zpspid='" + Zpspid + "')"
			oModel.read("/SpanishProjectHeadSet(Zpspid='" + Zpspid + "',Zbukrs='" + Zbukrs + "')", {
				urlParameters: {
					'$expand': "toItem"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					var oViewModel = that.getView().getModel("appView");
					//Begin of Commeted  below  Code for Phase2 production issue
					// if (oData.ChangedBy !== "BKGRND_USER" && oViewModel.getData().type !== "ChangeProject") {
					// 	oViewModel.getData().Requestor = oData.ChangedBy;
					// 	oViewModel.getData().RequestorName = "";
					// } else if (oData.ChangedBy === "BKGRND_USER") {
					var oUser = new UserInfo();
					var ouserId = oUser.getId();
					var ofirstName = oUser.getUser().getFirstName().toUpperCase();
					var olastName = oUser.getUser().getLastName().toUpperCase();
					var ofullID = ofirstName + "," + olastName + " " + ouserId;
					oViewModel.getData().Requestor = ofullID;
					oViewModel.getData().RequestorName = "";
					// }
					// if (oViewModel.getData().type !== "ChangeProject") {
					// 	oViewModel.getData().RequestorName = "";
					// 	oViewModel.getData().ReqDate = oData.ChangedOn.toDateString();
					// }
					//End  of Commeted  below  Code for Phase2 production issue
					oViewModel.getData().EstatTxt = "";
					oViewModel.getData().oSpanProj = "YES";
					// oViewModel.getData().sys_orign = oData.Des_sys;        //P-2
					that.getView().getModel("appView").refresh(true);
					/*Load the data to local model for binding*/
					var prjType = "";
					if (oData.toItem.results && oData.toItem.results.length > 0) {
						prjType = oData.toItem.results[0].Prart;
					}
					// if (prjType === "C" || prjType === "L") {  //P-2
					if (prjType) {
						prjType = "PRJ_TYP2";
						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Trade";
						that.getView().getModel("appView").refresh(true);
						that.getView().byId("idT2OpporId").setRequired(true);
						that.getView().byId("idLblOpp").setRequired(true);
						that.getView().byId("idT2LdPracSet").setEditable(true);
						// that.getView().byId("idT2RevMthd").setRequired(true);

						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "C"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "L"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
							],
							and: true
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
						var aFiltersT4 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")  // Production  BUg
							],
							and: false
						});
						oBindingBoxT4.filter(aFiltersT4);

						var oProjectBox = that.getView().byId("idT2ContractType");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
							],
							and: true
						});
						oBindingBox.filter(aFilters);

					}

					var toStatus = {
						"results": [{
							ReqNum: "",
							StCount: "",
							ActType: "SUBMITTER",
							ActId: "",
							TimeStp: "0",
							ActCom: "",
							Status: ""
						}]
					};
					var toDetails = {
						"results": [{
							ReqNum: "",
							Zbukrs: oData.Zbukrs,
							Zpspid: oData.Zpspid,
							Zvbeln: "",
							ProjTyp: prjType,
							ReasReq: "",
							Req_com: "",
							ReqDet: "",
							Priority: "",
							ReqFun: "",
							TypeReq: "",
							FinApp: oData.FinApp,
							Email: []
						}]
					};
					var toError = {
						"results": []
					};
					var toAttach = {
						"results": []
					};
					oData.Kostl = "";
					oData.Vgsbr = "";
					oData.Prctr = "";
					oData.toDetails = toDetails;
					oData.toStatus = toStatus;
					oData.toError = toError;
					oData.toAttach = toAttach;
					oData.Changed_by = oData.ChangedBy;
					oData.Changed_on = oData.ChangedOn;
					oData.Des_sys = oViewModel.getData().sys_orign;
					var oNoToItem = oData.toItem.results.length;
					for (var i = 0; i < oNoToItem; i++) {
						// oData.toItem.results[i].Zproj_Subp_Cat_C = oData.toItem.results[i].ZprojSubpCatC;
						// oData.toItem.results[i].Zzproj_Phase_Cd = oData.toItem.results[i].ZzprojPhaseCd;
						// oData.toItem.results[i].Zz_focode = oData.toItem.results[i].ZzFocode;
						// oData.toItem.results[i].Zz_vrcode = oData.toItem.results[i].ZzVrcode;
						// oData.toItem.results[i].Zz_gtmwbs = oData.toItem.results[i].ZzGtmwbs;
						// oData.toItem.results[i].Zz_bpa = oData.toItem.results[i].ZzBpa;
						// oData.toItem.results[i].Cont_modl = oData.toItem.results[i].ContModl;
						// oData.toItem.results[i].Sol_typ = oData.toItem.results[i].SolTyp;
						// oData.toItem.results[i].Safecase_id = oData.toItem.results[i].SafecaseId;
						delete oData.toItem.results[i].__metadata;
						delete oData.toItem.results[i].SysId;
						delete oData.toItem.results[i].Mandt;
						delete oData.toItem.results[i].ZzBillclass;
						delete oData.toItem.results[i].ZzOpServer;
						delete oData.toItem.results[i].ZzOpClient;
						delete oData.toItem.results[i].Zapprqst;
						delete oData.toItem.results[i].Payer;
						delete oData.toItem.results[i].ShipTo;
						delete oData.toItem.results[i].BillTo;
						delete oData.toItem.results[i].ChangedBy;
						delete oData.toItem.results[i].ChangedOn;
						delete oData.toItem.results[i].ChangedAt;
						// begin of Commented by Srinivas Vallepu
						// oData.toItem.results[i].Zzsolseid = "";
						// oData.toItem.results[i].Zzproj_Phase_Cd = "";

						if (oData.toItem.results[i].Stufe === 2 || oData.toItem.results[i].Stufe === 1) {
							oData.toItem.results[i].Zzsolseid = "BLANK";
						}
						// End of Commented by Srinivas vallepu
						// delete oData.toItem.results[i].ZprojSubpCatC;
						// delete oData.toItem.results[i].ZzprojPhaseCd;
						// delete oData.toItem.results[i].ZzFocode;
						// delete oData.toItem.results[i].ZzVrcode;
						// delete oData.toItem.results[i].ZzGtmwbs;
						// delete oData.toItem.results[i].ZzBpa;
						// delete oData.toItem.results[i].ContModl;
						// delete oData.toItem.results[i].SolTyp;
						// delete oData.toItem.results[i].SafecaseId;
					}
					delete oData.__metadata;
					delete oData.SysId;
					delete oData.ChangedAt;
					delete oData.Mandt;
					delete oData.WbsType;
					delete oData.ChangedBy;
					delete oData.ChangedOn;
					delete oData.Billstatus;
					delete oData.ZentryTp;
					that.getView().byId("idWBSTypeT1").setSelectedKey("");
					that.getView().byId("idWBSTypeT1").setValue("");
					that.getView().getModel().setProperty("/draftData/d", oData);
					that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
					that.getView().getModel().setProperty("/draftData/d/Wbs_type", oData.toItem.results[0].Prart);
					var oEmail = oData.toDetails.results[0].Email;
					var aLen = oEmail.length;
					if (aLen != 0) {
						var data = oEmail.split(",");
						var tokenValue = [];
						for (var i = 0; i < data.length; i++) {
							tokenValue.push(new Token({
								text: data[i],
								key: data[i]
							}));
						}
						var oMultiInput1 = that.getView().byId("idT1Email");
						oMultiInput1.setTokens(tokenValue);
					}

					that.getView().byId("idProjDefi").setValue(oData.Zpspid);

					// that.getView().byId("idT2ContractId").setSelectedKey(oData.Zpgid);
					that.getView().byId("idT2ContractType").setSelectedKey(oData.ZzContracttype);
					that.getView().byId("idProjType").setSelectedKey(prjType);

					oData.toItem.results.forEach(function (oItem) {
						oItem.Zentry_tp = "";
					});
					that.getView().getModel("pageModel").setProperty("/wbsElementStr", oData.toItem.results); // rohit - change

					// that.onSelectServiceOff(oData.Vgsbr); commented by Srinivas Vallepu
					// that.onSelectProjPhase(oData.Vgsbr);  commented by Srinivas Vallepu
					that.onSelectServiceOff();
					that.onSelectProjPhase();
					that.onSelectUserStatus(prjType);

					that.sTerm1 = oData.ChangedBy;
					that.sTerm2 = oData.FinApp;
					that.sTerm3 = oData.Vernr;
					that.sTerm4 = oData.PrjAd;
					that.sTerm5 = oData.FinApp;
					that.sTerm6 = oData.Agm;

					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter("Sysnam", sap.ui.model.FilterOperator.Contains, "COM"));
					aFilters.push(new sap.ui.model.Filter([
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm5),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6),
					], false));
					var oModel1 = that.getView().getModel("oDataModel");
					oModel1.read("/Search_Finan_AnalystSet", {
						filters: aFilters,
						success: function (oResponse) {
							// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
							// return oModel;
							var term1 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm1;
							});
							var oViewModel = that.getView().getModel("appView");
							if (term1.length !== 0 && oViewModel.getData().type !== "ChangeProject") {
								var firstName1 = term1[0].FirstName;
								var lastName1 = term1[0].LastName;
								var EmpID1 = term1[0].Pernr;
								var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
								oViewModel.getData().Requestor = oID;
								that.getView().getModel("appView").refresh(true);
							}

							var term2 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm2;
							});
							if (term2.length !== 0) {
								var firstName1 = term2[0].FirstName;
								var lastName1 = term2[0].LastName;
								var EmpID1 = term2[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT1FinAnyst").setValue(oID);
								}
							}

							var term3 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm3;
							});
							if (term3.length !== 0) {
								var firstName1 = term3[0].FirstName;
								var lastName1 = term3[0].LastName;
								var EmpID1 = term3[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2PersResp").setValue(oID);
								}
							}

							var term4 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm4;
							});
							if (term4.length !== 0) {
								var firstName1 = term4[0].FirstName;
								var lastName1 = term4[0].LastName;
								var EmpID1 = term4[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ProjAdmin").setValue(oID);
								}
							}

							var term5 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm5;
							});
							if (term5.length !== 0) {
								var firstName1 = term5[0].FirstName;
								var lastName1 = term5[0].LastName;
								var EmpID1 = term5[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2FinAnyst").setValue(oID);
								}
							}

							var term6 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm6;
							});
							if (term6.length !== 0) {
								var firstName1 = term6[0].FirstName;
								var lastName1 = term6[0].LastName;
								var EmpID1 = term6[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ActMngr").setValue(oID);
								}
							}
						},
						error: function (oError) {}
					});
					that.getView().byId("idProjDefi").setEnabled(false);
					// that.getView().byId("idDeleWbsEle").setEnabled(false);
					// that.getView().byId("idSiblingWBS").setEnabled(false);
					// that.getView().byId("idChildWBS").setEnabled(false);

					that.getView().byId("idWBSTypeT1").setEnabled(false);
					that.getView().byId("idT2ProjCategory").setValue("ES-NOSOAR");

					if (TYPE === "ChangeProject" || TYPE === "DuplicateExisting") {
						that.getView().byId("idWbsGuided").setEnabled(false);
						// that.getView().byId("idT1FinAnyst").setEnabled(false);
						that.getView().byId("idT1ComCode").setEnabled(false);
						that.getView().byId("idWBSTypeT1").setEnabled(false);
						that.getView().byId("idProjType").setEnabled(false);

						if (TYPE === "DuplicateExisting") {
							that.getView().byId("idProjDefi").setEnabled(true);
							that.getView().byId("idT1ComCode").setEnabled(true);
						} else {
							that.getView().byId("idProjDefi").setEnabled(false);
							that.getView().byId("idT1ComCode").setEnabled(false);
						}
					}

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		onDisplayPriority: function (sReqType) {
			var date = new Date();
			if (date.getDay() == 0) {
				date.setDate(date.getDate() - 2);
			} else if (date.getDay() == 6) {
				date.setDate(date.getDate() - 1);
			}
			var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
			var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
			var d = new Date(date.getFullYear(), date.getMonth() + 1, 0)
			var days = d.getDate();
			var weekdays = 0;
			var year = date.getYear() + 1900;
			var month = date.getMonth();
			var workday = "";
			var workday1 = "";
			var iterator = 0;

			while (workday1 != "WD-6") {
				var t1 = new Date(year, month, days);
				days = days - 1;
				if (t1.getDay() == 0 || t1.getDay() == 6) continue; // no weekday
				workday1 = "WD-" + iterator;
				if (date.setHours(0, 0, 0, 0) === t1.setHours(0, 0, 0, 0)) {
					workday = "WD-" + iterator;
					break;
				}
				iterator = iterator + 1;

			}
			iterator = 1;
			for (var day = 1; day <= days; day++) {
				var t = new Date(year, month, day);
				if (t.getDay() == 0 || t.getDay() == 6) continue; // no weekday
				if (date.setHours(0, 0, 0, 0) === t.setHours(0, 0, 0, 0)) {
					workday = "WD" + iterator;
					break;
				}
				iterator = iterator + 1;
			}
			var logo = "LOGO";
			var outlook = "OUTLOOK";
			var other = "OTHER";
			var new_logo_high = ["WD-2", "WD-1", "WD-0", "WD1", "WD2", "WD3", "WD4"];
			var new_logo_med = ["WD5", "WD6", "WD7", "WD8", "WD9", "WD10", "WD11", "WD12", "WD13", "WD14", "WD15", "WD16", "WD17", "WD18",
				"WD19", "WD20", "WD-3", "WD-4", "WD-5", "WD-6"
			];
			var out_look_med = ["WD-0", "WD1", "WD2", "WD3", "WD4", "WD5"];
			var out_look_high = ["WD17", "WD18", "WD19", "WD20", "WD-6", "WD-5", "WD-4", "WD-3", "WD-2", "WD-1"];
			// var out_look_low = ["WD6", "WD7", "WD8", "WD9", "WD10", "WD11", "WD12", "WD13", "WD14", "WD15", "WD16", "WD17", "WD18", "WD19",
			// 	"WD20"
			// ];
			var out_look_low = ["WD6", "WD7", "WD8", "WD9", "WD10", "WD11", "WD12", "WD13", "WD14", "WD15", "WD16", "WD17"];

			var other_high = ["WD-2", "WD-1", "WD-0", "WD1", "WD2", "WD3", "WD4"];
			var other_med = ["WD5", "WD6", "WD7", "WD8", "WD9", "WD10", "WD11", "WD12", "WD13", "WD14", "WD15", "WD16", "WD17", "WD18",
				"WD19", "WD20", "WD-3", "WD-4", "WD-5", "WD-6"
			];

			var else_high = ["WD-4", "WD-3", "WD-2", "WD-1", "WD-0", "WD1"];
			var else_med = ["WD1", "WD2", "WD3", "WD4", "WD5"];
			var else_low = ["WD6", "WD7", "WD8", "WD9", "WD10", "WD11", "WD12", "WD13", "WD14", "WD15", "WD16", "WD17", "WD18",
				"WD19", "WD20", "WD-6", "WD-5",
			];
			var sReqType1 = this.getView().byId("idReqType").getValue();
			if (sReqType1 = "WBS Add/Change without CAN") {
				if (sReqType === "Other") {
					this.getView().byId("idT1Priority").setValue("LOW")
					this.getView().byId("idT1Priority").setEnabled(false);
					this.getView().byId("idT1Priority").setValueState("None");
				} else {
					if (else_high.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE HIGH");
						this.getView().byId("idT1Priority").setValue("HIGH");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_med.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE MEDIUM");
						this.getView().byId("idT1Priority").setValue("MEDIUM");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_low.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE LOW");
						this.getView().byId("idT1Priority").setValue("LOW");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					}
				}
			} else if (sReqType1 = "WBS Add/Change including CAN") {
				if (sReqType === "Other") {
					this.getView().byId("idT1Priority").setValue("LOW")
					this.getView().byId("idT1Priority").setEnabled(false);
					this.getView().byId("idT1Priority").setValueState("None");
				} else {
					if (else_high.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE HIGH");
						this.getView().byId("idT1Priority").setValue("HIGH");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_med.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE MEDIUM");
						this.getView().byId("idT1Priority").setValue("MEDIUM");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_low.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE LOW");
						this.getView().byId("idT1Priority").setValue("LOW");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					}
				}
			} else {
				if (sReqType === "New Logo") {
					if (new_logo_high.includes(workday)) {
						// sap.m.MessageToast.show(workday+"NEW LOGO HIGH");
						this.getView().byId("idT1Priority").setValue("HIGH")
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (new_logo_med.includes(workday)) {
						// sap.m.MessageToast.show(workday+"NEW LOGO MEDIUM");
						this.getView().byId("idT1Priority").setValue("MEDIUM");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					}
				} else if (sReqType === "Outlook ID Separation – Business Need") {
					if (out_look_high.includes(workday)) {
						// sap.m.MessageToast.show(workday+"OUTLOOK HIGH");
						this.getView().byId("idT1Priority").setValue("HIGH")
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (out_look_med.includes(workday)) {
						// sap.m.MessageToast.show(workday+"OUTLOOK MEDIUM");
						this.getView().byId("idT1Priority").setValue("MEDIUM");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (out_look_low.includes(workday)) {
						// sap.m.MessageToast.show(workday+"OUTLOOK LOW");
						this.getView().byId("idT1Priority").setValue("LOW");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					}
				} else if (sReqType === "Other") {
					// if (other_high.includes(workday)) {
					// 	// sap.m.MessageToast.show(workday+"OTHER HIGH");
					// 	this.getView().byId("idT1Priority").setValue("HIGH")
					// 	this.getView().byId("idT1Priority").setEnabled(false);
					// } else if (other_med.includes(workday)) {
					// 	// sap.m.MessageToast.show(workday+"OTHER MEDIUM");
					// 	this.getView().byId("idT1Priority").setValue("MEDIUM");
					// 	this.getView().byId("idT1Priority").setEnabled(false);
					// }
					// sap.m.MessageToast.show(workday+"OTHER LOW");
					this.getView().byId("idT1Priority").setValue("LOW")
					this.getView().byId("idT1Priority").setEnabled(false);
					this.getView().byId("idT1Priority").setValueState("None");
				} else if (sReqType === "Change Existing WBS") {
					if (else_high.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE HIGH");
						this.getView().byId("idT1Priority").setValue("HIGH");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_med.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE MEDIUM");
						this.getView().byId("idT1Priority").setValue("MEDIUM");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_low.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE LOW");
						this.getView().byId("idT1Priority").setValue("LOW");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					}
				} else {
					if (else_high.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE HIGH");
						this.getView().byId("idT1Priority").setValue("HIGH");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_med.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE MEDIUM");
						this.getView().byId("idT1Priority").setValue("MEDIUM");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					} else if (else_low.includes(workday)) {
						// sap.m.MessageToast.show(workday+"ELSE LOW");
						this.getView().byId("idT1Priority").setValue("LOW");
						this.getView().byId("idT1Priority").setEnabled(false);
						this.getView().byId("idT1Priority").setValueState("None");
					}
				}
			}
		},
		onLoadData: function (ReqNo, TYPE) {
			sap.ui.core.BusyIndicator.show(0);
			var oModel = this.getView().getModel("oDataModel");

			var oViewModel = this.getView().getModel("appView");
			oViewModel.getData().Requestid = ReqNo;
			// oViewModel.getData().type = "View";
			this.getView().getModel("appView").refresh(true);
			var that = this;
			oModel.read("/HeaderRequestManageSet('" + ReqNo + "')", {
				urlParameters: {
					'$expand': "toAttach,toItem,toStatus,toDetails"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						// return;
					}
					// IF we have any existing liens in the Project need to disable all project Defenition  tab fields -  added by  Srini vallepu
					if (oData.toItem.results.length > 0) {
						var oExtline = oData.toItem.results[0].Zentry_tp;
					} else {
						var oExtline = "";
					}
					that.byId("idEnddate").setMinDate(new Date(oData.Guebg));
					that.getView().byId("uploBtn").setVisible(false);
					if (oExtline === 'E' || oExtline === 'C') {
						that.getView().byId("idWbsGuided").setEnabled(false);
						that.getView().byId("idT1ComCode").setEnabled(false);
						that.getView().byId("idWBSTypeT1").setEnabled(false);
						that.getView().byId("idProjType").setEnabled(false);
						that.getView().byId("idProjDefi").setEnabled(false);
						that.getView().byId("idT2ProjCategory").setEnabled(true);
						if (oData.ZzGlblProj === "X") {
							that.getView().byId("idGlobProj").setEditable(false);
						}
					}
					var oViewModel = that.getView().getModel("appView");
					// oViewModel.getData().Requestor = oData.Changed_by;
					// Phase2  Production issue - Added by  srini vallepu
					var oNumber = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
					var oLuser = oData.Changed_by.split("", 1);
					var oDataReturn = oNumber.filter(function (a) {
						return a === oLuser[0];
					});
					if (oDataReturn.length > 0) {
						oViewModel.getData().Requestor = oData.Changed_by;
						oViewModel.getData().RequestorName = "";
					} else {
						var oUser = new UserInfo();
						var ouserId = oUser.getId();
						var ofirstName = oUser.getUser().getFirstName().toUpperCase();
						var olastName = oUser.getUser().getLastName().toUpperCase();
						var ofullID = ofirstName + "," + olastName + " " + ouserId;
						oViewModel.getData().Requestor = ofullID;
						oViewModel.getData().RequestorName = "";
					}
					if (oData.Changed_on && oViewModel.getData().type !== "ChangeRequest") {

						var oDate = oData.Changed_on.toDateString();
						// oViewModel.getData().ReqDate = oDate + " " + oTime;
						oViewModel.getData().ReqDate = oDate;
					}
					if (oViewModel.getData().type !== "ChangeRequest") {
						oViewModel.getData().RequestorName = "";
					}
					oViewModel.getData().RequestorEmail = "";
					oViewModel.getData().sys_orign = oData.Des_sys;
					oViewModel.getData().EstatTxt = oData.toStatus.results[0].Status;
					oViewModel.getData().fixedWBSEle = oData.Zpspid;
					that.getView().getModel("appView").refresh(true);

					var Proid = oData.Zpspid.slice(0, 2);
					var m = Proid + "@-#####";
					that.getView().byId("idProjDefi").setMask(m);
					that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
					if (oData.toDetails.results[0].Zflag === "X") {
						that.getView().byId("idT1ComCode").setEnabled(false);
						that.getView().byId("idProjType").setEnabled(false);
					}
					delete oData.__metadata;
					delete oData.SysId;
					delete oData.toSummary;
					delete oData.toError.__deferred;
					that.getView().getModel().setProperty("/draftData/d", oData);
					that.getView().getModel().setProperty("/wbsElementStr", oData.toItem.results);
					// Phase3 - UAT Issue.
					for (var i = 0; i < oData.toItem.results.length; i++) {
						oData.toItem.results[i].oldZposid = oData.toItem.results[i].Zposid; // for phase2 table
					}
					// End of Phase3 -UAT Issue 
					that.getView().getModel("pageModel").setProperty("/wbsElementStr", oData.toItem.results); // rohit - change
					// that.getView().byId("idTable").setVisibleRowCount(oData.toItem.results.length);
					that.getView().byId("idTable").setVisibleRowCount(8); // rohit -change
					var oEmail = oData.toDetails.results[0].Email;
					var aLen = oEmail.length;
					if (aLen != 0) {
						var data = oEmail.split(",");
						var tokenValue = [];
						for (var i = 0; i < data.length; i++) {
							tokenValue.push(new Token({
								text: data[i],
								key: data[i]
							}));
						}
						var oMultiInput1 = that.getView().byId("idT1Email");
						oMultiInput1.setTokens(tokenValue);
					}

					var attach = oData.toAttach.results.length;
					if (attach !== 0) {
						// var fName = oData.toAttach.results[0].Filename;
						// that.getView().byId("fileUploader").setValue(fName);
						that.getView().byId("idIWOUpload").setEnabled(true);
						// that.getView().byId("idDeleWbsAttch").setEnabled(true);

					}
					that.getView().getModel().setProperty("/toAttach", oData.toAttach.results);
					// var TypeAppReq = "ReViewReq";
					if (TYPE === "ReViewReq") {
						that.onTabDisplay();
					} else if (TYPE === "View") {
						that.onTabDisplay();
					} else if (TYPE === "ChangeProject") {
						that.getView().byId("idWbsGuided").setEnabled(false);
						that.onProjectChange(TYPE);
					} else if (TYPE === "ChangeRequest") {
						var sSelect = oData.toDetails.results[0].ReqDet;
						that.onDisplayPriority(sSelect);
					}
					that.getView().byId("idProjDefi").setValue(oData.Zpspid);
					// that.getView().byId("idT1ComCode").setSelectedKey(oData.Zbukrs);
					var oAdmin = oViewModel.getData().Admin;
					if (oData.toDetails.results[0].ProjTyp === "C" || oData.toDetails.results[0].ProjTyp === "L") {
						oViewModel.getData().oSpanProj = "NO";
						that.getView().getModel("appView").refresh(true);
						if (oExtline !== 'E' || oExtline !== "C") {
							that.onSelectUserStatus("PRJ_TYP1");
						} else {
							that.getView().byId("idT2ProjCategory").setEditable(false);
							// that.onSelectUserStatus();
							that.onSelectUserStatusaLL();
						}
						that.getView().byId("idProjType").setSelectedKey("PRJ_TYP1");

						that.getView().byId("idT2OpporId").setRequired(true);
						if (oExtline !== "E" || oExtline !== "C") {
							that.getView().byId("idT2LdPracSet").setEditable(true);
						}
						that.getView().byId("idT2RevMthd").setRequired(true);
						// that.getView().byId("idT2ContractType").setEditable(true);

						that.getView().byId("idT2LdPracSet").setRequired(true);
						// that.getView().byId("idT2LdPracSet").setSelectedKey("");
						if (oExtline !== "E" || oExtline !== "C") {
							that.getView().byId("idT2RevMthd").setEditable(true);
						}
						// that.getView().byId("idT2ContractTrm").setRequired(true);
						// that.getView().byId("idT2PrjSts").setRequired(true);
						var oProjectBox = that.getView().byId("idT2ContractType");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
								new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
							],
							and: true
						});
						// aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

						var oBindingBoxT2 = that.getView().byId("idT2LdPracSet").getBinding("items");
						var aFiltersT2 = [];
						var oFiltersT2 = new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.NE, "BLANK");
						aFiltersT2.push(oFiltersT2);
						oBindingBoxT2.filter(aFiltersT2);

						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
						//  Phase3 changes added  by Srini Vallepu.
						if (oExtline === "E" || oExtline === "C") {

							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ2"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ3")
								],
								and: false
							});

						} else {

							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1")
								],
								and: false
							});

							// var aFiltersT4 = new sap.ui.model.Filter({
							// 	filters: [
							// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ4"),
							// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ5"),
							// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ6"),
							// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ7")
							// 	],
							// 	and: true
							// });

						}
						oBindingBoxT4.filter(aFiltersT4);

						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Trade";
						that.getView().getModel("appView").refresh(true);

					} else {
						oViewModel.getData().oSpanProj = "NO";
						that.getView().getModel("appView").refresh(true);
						if (oExtline === 'E' || oExtline === 'C') {
							that.onSelectUserStatus("PRJ_TYP2");
						} else {
							that.getView().byId("idT2ProjCategory").setEditable(false);
							that.onSelectUserStatus();
							that.onSelectUserStatusaLL();
						}
						that.getView().byId("idProjType").setSelectedKey("PRJ_TYP2");

						that.getView().byId("idT2ContractType").setEditable(false);
						// that.getView().byId("idT2LdPracSet").setEditable(false);
						// that.getView().byId("idT2LdPracSet").setValue("");
						// that.getView().byId("idT2LdPracSet").setSelectedKey("");
						// that.getView().byId("idT2LdPracSet").setRequired(false);

						// that.getView().byId("idT2OpporId").setRequired(false);
						// that.getView().byId("idT2OpporId").setEditable(false);
						// that.getView().byId("idT2ContractTrm").setRequired(false);
						// that.getView().byId("idT2PrjSts").setRequired(false);
						var sSelect1 = oData.toDetails.results[0].ReasReq;
						if (sSelect1 === "Business & Development Project" && oAdmin) {
							oViewModel.getData().oppAdmin = true;
							that.getView().byId("idT2LdPracSet").setEditable(true);
							if (oData.Zzldpcid === "") {
								that.getView().byId("idT2LdPracSet").setValue("HQCEX");
								that.getView().byId("idT2LdPracSet").setSelectedKey("HQCEX");
							}
							that.getView().byId("idT2LdPracSet").setRequired(true);
							that.getView().byId("idT2OpporId").setRequired(true);
							that.getView().byId("idT2OpporId").setEditable(true);
							that.getView().byId("idGlobProj").setEditable(false);
							that.getView().byId("idT2RevMthd").setEditable(false);
						} else if (sSelect === "Spanish Delivery Project") {
							that.getView().byId("idT2LdPracSet").setRequired(true);
							that.getView().byId("idT2LdPracSet").setEditable(true);
							that.getView().byId("idT2OpporId").setRequired(true);
							that.getView().byId("idT2OpporId").setEditable(true);
							that.getView().byId("idT2ContractType").setEditable(true);
							that.getView().byId("idWbsGuided").setEnabled(false);
							that.getView().byId("idProjDefi").setEditable(false);
							// that.getView().byId("idDeleWbsEle").setEnabled(false);
							// that.getView().byId("idSiblingWBS").setEnabled(false);
							// that.getView().byId("idChildWBS").setEnabled(false);
							// that.getView().byId("idWBSTypeT1").setEnabled(false);
							that.getView().byId("idT2ProjCategory").setValue("ES-NOSOAR");
							that.getView().byId("idT2RevMthd").setEditable(true);
							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().projType = "Trade";
							oViewModel.getData().oSpanProj = "YES";
							that.getView().getModel("appView").refresh(true);

							var oProjectBox = that.getView().byId("idT2ContractType");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
									new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
									new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
								],
								and: true
							});
							// aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						} else {
							that.getView().byId("idT2LdPracSet").setEditable(false);
							that.getView().byId("idT2LdPracSet").setValue("");
							that.getView().byId("idT2LdPracSet").setSelectedKey("");
							that.getView().byId("idT2LdPracSet").setRequired(false);
							that.getView().byId("idT2OpporId").setRequired(false);
							that.getView().byId("idT2OpporId").setEditable(false);
						}

						if (sSelect !== "Spanish Delivery Project") {
							var oProjectBox = that.getView().byId("idT2ContractType");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}

						if (oAdmin) {
							var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");

							if (oData.toDetails.results[0].Zbukrs === "ES87" || oData.toDetails.results[0].Zbukrs === "ES88" || oData.toDetails.results[
									0].Zbukrs === "ES89") {
								var aFiltersT4 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
									],
									and: false
								});
							} else {
								var aFiltersT4 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
									],
									and: false
								});
							}

							oBindingBoxT4.filter(aFiltersT4);
						} else {
							var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");

							if (oData.toDetails.results[0].Zbukrs === "ES87" || oData.toDetails.results[0].Zbukrs === "ES88" || oData.toDetails.results[
									0].Zbukrs === "ES89") {
								var aFiltersT4 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
										// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
									],
									and: false
								});
							} else {
								var aFiltersT4 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
										new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
										// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
									],
									and: false
								});
							}
							oBindingBoxT4.filter(aFiltersT4);
						}

						if (sSelect !== "Spanish Delivery Project") {
							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().projType = "Internal";
							that.getView().getModel("appView").refresh(true);
						}

					}

					var sSelect = oData.toDetails.results[0].ReasReq;
					if (sSelect === "Standard Internal Project(Non-Funded)") {
						if (oExtline === 'E' || oExtline === 'C') {
							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
								],
								and: false
							});
							oBindingBoxT4.filter(aFiltersT4);
							that.getView().byId("idReqType").setValue("Standard Internal Project(Non-Funded)");
							that.getView().byId("idReqType").setSelectedKey("Standard Internal Project(Non-Funded)");
							that.getView().byId("idReqType").setEditable(false);
						}
						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "E"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "M"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "O"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "W")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oProjectBox = that.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						// var aFilters = [];
						// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Standard Internal Project(Non-Funded)");
						// aFilters.push(oFilters);
						if (oExtline === "E" || oExtline === 'C') {
							var oProjectBox = that.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20")
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET21")
								],
								and: false
							});
							oBindingBox.filter(aFilters);
						} else {
							var oProjectBox = that.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET19");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}

					} else if (sSelect === "Standard Internal Project(Funded)") {
						if (oExtline === 'E' || oExtline === 'C') {
							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
								],
								and: false
							});
							oBindingBoxT4.filter(aFiltersT4);
							that.getView().byId("idReqType").setValue("Standard Internal Project(Funded)");
							that.getView().byId("idReqType").setSelectedKey("Standard Internal Project(Funded)");
							that.getView().byId("idReqType").setEditable(false);
						}
						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var oIntrnlComCode = oData.toDetails.results[0].Zbukrs;
						if (oIntrnlComCode == "JP00") {
							var aFiltersT3 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "D"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
								],
								and: false
							});

						} else {
							var aFiltersT3 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
								],
								and: false
							});
						}
						oBindingBoxT3.filter(aFiltersT3);
						var oProjectBox = that.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						// var aFilters = [];
						// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Standard Internal Project(Funded)");
						// aFilters.push(oFilters);
						if (oExtline === "E" || oExtline === "C") {
							var oProjectBox = that.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET23")
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET24")
								],
								and: false
							});
							oBindingBox.filter(aFilters);
						} else {
							var oProjectBox = that.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET22");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}
						oBindingBox.filter(aFilters);

					} else if (sSelect === "Spanish Delivery Project") {
						that.getView().byId("idProjType").setEditable(false);
						that.getView().byId("idReqType").setEditable(false);
						that.getView().byId("idReqTypeDtls").setEditable(false);
						that.getView().byId("idWBSTypeT1").setEditable(false);

						that.getView().byId("idT2LdPracSet").setRequired(true);
						that.getView().byId("idT2LdPracSet").setEditable(true);
						that.getView().byId("idT2OpporId").setRequired(true);
						that.getView().byId("idT2OpporId").setEditable(true);
						that.getView().byId("idT2ContractType").setEditable(true);
						that.getView().byId("idWbsGuided").setEnabled(false);
						that.getView().byId("idProjDefi").setEnabled(false);
						// that.getView().byId("idDeleWbsEle").setEnabled(false);
						// that.getView().byId("idSiblingWBS").setEnabled(false);
						// that.getView().byId("idChildWBS").setEnabled(false);
						// that.getView().byId("idWBSTypeT1").setEnabled(false);
						that.getView().byId("idT2ProjCategory").setValue("ES-NOSOAR");

						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);
						if (oExtline === "E" || oExtline === "C") {
							var oProjectBox = that.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET30")
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET24")
								],
								and: false
							});
							oBindingBox.filter(aFilters);
						} else {
							var oProjectBox = that.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET29");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}

					} else if (sSelect === "Business & Development Project" && oAdmin) {
						that.getView().byId("idReqType").setEditable(false);
						that.getView().byId("idProjType").setEditable(false);
						that.getView().byId("idT1ComCode").setEditable(false);
						var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "B")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oProjectBox = that.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Business & Development Project");
						if (oExtline === 'E' || oExtline === 'C') {
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET27")
						} else {
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET26")
						}

						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

					}

					that.getView().byId("idReqType").setSelectedKey(oData.toDetails.results[0].ReasReq);
					that.getView().byId("idReqTypeDtls").setSelectedKey(oData.toDetails.results[0].ReqDet);
					that.getView().byId("idReqTypeFun").setSelectedKey(oData.toDetails.results[0].ReqFun);
					// that.getView().byId("idT1FinAnyst").setSelectedKey(oData.toDetails.results[0].FinApp);

					// that.getView().byId("idT2PersResp").setSelectedKey(oData.Vernr);
					// that.getView().byId("idT2ProjRespCC").setSelectedKey(oData.Kostl);
					// that.getView().byId("idT2ProjAdmin").setSelectedKey(oData.PrjAd);
					// that.getView().byId("idT2FinAnyst").setSelectedKey(oData.FinApp);
					// that.getView().byId("idT2ActMngr").setSelectedKey(oData.Agm);

					// that.getView().byId("idT2ContractId").setSelectedKey(oData.Zpgid);
					// that.getView().byId("idT2ContractType").setSelectedKey(oData.ZzContracttype);
					// that.getView().byId("idT2ActMngr").setSelectedKey(oData.Agm);
					if (sSelect === "Business & Development Project") {
						that.onSelectServiceOff();
						that.onSelectProjPhase(oData.Vgsbr);
					} else {
						that.onSelectServiceOff();
						that.onSelectProjPhase();
					}
					/*Below code for load case safe id*/
					var optID = [...new Map(oData.toItem.results.map(item => [item["ZsfdcOppid"], item])).values()];
					if (optID.length > 0) {
						that.onLoadCaseSafeChangeProjTab4(optID);
					}
					// that.onSelectWbsType(oData.Zpgid);
					that.onSelectReqTypeCrossApp(oData.toDetails.results[0].ReasReq);

					that.sTerm1 = oData.Changed_by;
					that.sTerm2 = oData.toDetails.results[0].FinApp;
					that.sTerm3 = oData.Vernr;
					that.sTerm4 = oData.PrjAd;
					that.sTerm5 = oData.FinApp;
					that.sTerm6 = oData.Agm;

					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter("Sysnam", sap.ui.model.FilterOperator.Contains, "COM"));
					aFilters.push(new sap.ui.model.Filter([
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm5),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6),
					], false));
					var oModel = that.getView().getModel("oDataModel");
					oModel.read("/Search_Finan_AnalystSet", {
						filters: aFilters,
						success: function (oResponse) {
							// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
							// return oModel;
							var term1 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm1;
							});
							var oViewModel = that.getView().getModel("appView");
							if (term1.length !== 0) {
								var firstName1 = term1[0].FirstName;
								var lastName1 = term1[0].LastName;
								var EmpID1 = term1[0].Pernr;
								var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
								// oViewModel.getData().Requestor = oID;
								oViewModel.getData().Requestor = EmpID1;
								oViewModel.getData().RequestorName = firstName1 + "," + lastName1;
								that.getView().getModel("appView").refresh(true);
							}

							var term2 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm2;
							});
							if (term2.length !== 0) {
								var firstName1 = term2[0].FirstName;
								var lastName1 = term2[0].LastName;
								var EmpID1 = term2[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT1FinAnyst").setValue(oID);
								}
							}

							var term3 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm3;
							});
							if (term3.length !== 0) {
								var firstName1 = term3[0].FirstName;
								var lastName1 = term3[0].LastName;
								var EmpID1 = term3[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2PersResp").setValue(oID);
								}
							}

							var term4 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm4;
							});
							if (term4.length !== 0) {
								var firstName1 = term4[0].FirstName;
								var lastName1 = term4[0].LastName;
								var EmpID1 = term4[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ProjAdmin").setValue(oID);
								}
							}

							var term5 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm5;
							});
							if (term5.length !== 0) {
								var firstName1 = term5[0].FirstName;
								var lastName1 = term5[0].LastName;
								var EmpID1 = term5[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2FinAnyst").setValue(oID);
								}
							}

							var term6 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm6;
							});
							if (term6.length !== 0) {
								var firstName1 = term6[0].FirstName;
								var lastName1 = term6[0].LastName;
								var EmpID1 = term6[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ActMngr").setValue(oID);
								}
							}
							// var oModelExt = that.getView().getModel().getProperty("/wbsElementStr");
							var oModelExt = that.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
							var oSpanishProject = that.getView().getModel().getData().toDetails.ReasReq;
							var oExtline1 = oModelExt[0].Zentry_tp;
							if ((oExtline1 === "E" || oExtline1 === "C") && (oSpanishProject !== "Spanish Delivery Project")) {
								//To Change app  title 
								var oView1 = that.getView().getParent();
								oView1.getService("ShellUIService").then(
									function (oService) {
										oService.setTitle("Manage Project Request");
									}
								);
								that.byId("HeaderID").setObjectTitle("Manage Project Request");

								//
							} else {
								//To Change app  title 
								var oView1 = that.getView().getParent();
								oView1.getService("ShellUIService").then(
									function (oService) {
										oService.setTitle("New Project Request");
									}
								);
								that.byId("HeaderID").setObjectTitle("New Project Request");
								//
							}
						},
						error: function (oError) {}
					});
					//that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
					var prjType1 = that.getView().byId("idProjType").getSelectedKey();
					if (oExtline === 'E' || oExtline === 'C') {
						if (prjType1 === "PRJ_TYP1" || sSelect === "Spanish Delivery Project") {
							that.onEnableDesableFields("C");
						} else {
							that.onEnableDesableFields("J");
						}
					}
					sap.ui.core.BusyIndicator.hide();

				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},
		onLoadDataReviwReq: function (ReqNo, TYPE) {
			sap.ui.core.BusyIndicator.show(0);
			var oModel = this.getView().getModel("oDataModel");

			var oViewModel = this.getView().getModel("appView");
			oViewModel.getData().Requestid = ReqNo;
			// oViewModel.getData().type = "View";
			this.getView().getModel("appView").refresh(true);
			this.getView().byId("idTable").setVisible(false);
			this.getView().byId("idTable2").setVisible(true);
			// if (TYPE === "ReViewReq") {
			// this.getView().byId("idSummaryTab").setVisible(true);     //  Commmented Phase3  change
			// }
			var that = this;
			// oModel.read("/WBSManageApproveHeadSet('" + ReqNo + "')", {
			// 	urlParameters: {
			// 		'$expand': "toAttach,toItem,toStatus,toDetails"
			// 	},
			oModel.read("/HeaderRequestManageSet('" + ReqNo + "')", {
				urlParameters: {
					'$expand': "toAttach,toItem,toStatus,toDetails,toSummary"
				},
				success: function (oData, oResponse) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						// return;
					}
					// Begin of phase3 changes - Srini  Vallepu
					if (oData.toItem.results[0].Zentry_tp === "E" || oData.toItem.results[0].Zentry_tp === "C") {
						that.getView().byId("idSummaryTab").setVisible(true);
					}
					//End of Phase3  changes - Srini  Vallepu 
					var oViewModel = that.getView().getModel("appView");
					oViewModel.getData().Requestor = oData.Changed_by;
					//Commented by  Srinivas Vallepu  Phase2  Production issue
					// if (oData.Changed_by !== "BKGRND_USER" && oViewModel.getData().type !== "ChangeRequest") {
					oViewModel.getData().Requestor = oData.Changed_by;
					oViewModel.getData().RequestorName = "";
					// } else if (oData.Changed_by === "BKGRND_USER") {
					// 	var oUser = new UserInfo();
					// 	var ouserId = oUser.getId();
					// 	var ofirstName = oUser.getUser().getFirstName().toUpperCase();
					// 	var olastName = oUser.getUser().getLastName().toUpperCase();
					// 	var ofullID = ofirstName + "," + olastName + " " + ouserId;
					// 	oViewModel.getData().Requestor = ofullID;
					// 	oViewModel.getData().RequestorName = "";
					// }
					//End of commeted by Srinivas Vallepu Phase2  Production issue.
					if (oData.Changed_on) {
						var milliseconds = oData.ChangedAt.ms;
						//Get hours from milliseconds
						var hours = milliseconds / (1000 * 60 * 60);
						var absoluteHours = Math.floor(hours);
						var h = absoluteHours > 9 ? absoluteHours : '0' + absoluteHours;
						//Get remainder from hours and convert to minutes
						var minutes = (hours - absoluteHours) * 60;
						var absoluteMinutes = Math.floor(minutes);
						var m = absoluteMinutes > 9 ? absoluteMinutes : '0' + absoluteMinutes;
						//Get remainder from minutes and convert to seconds
						var seconds = (minutes - absoluteMinutes) * 60;
						var absoluteSeconds = Math.floor(seconds);
						var s = absoluteSeconds > 9 ? absoluteSeconds : '0' + absoluteSeconds;

						var oTime = h + ':' + m + ':' + s;
						var oDate = oData.Changed_on.toDateString();
						oViewModel.getData().ReqDate = oDate + " " + oTime;
						// oViewModel.getData().ReqDate = oData.ChangedOn.toDateString();
					}
					oViewModel.getData().RequestorName = "";
					// oViewModel.getData().RequestorEmail = "";
					oViewModel.getData().sys_orign = oData.Des_sys;
					var currStatusNo = oData.toStatus.results.length - 1;

					if (oData.toStatus.results[currStatusNo].Status === "INPROGRESS") {
						oViewModel.getData().EstatTxt = "IN-PROGRESS";
					} else {
						oViewModel.getData().EstatTxt = oData.toStatus.results[currStatusNo].Status;
					}
					that.getView().getModel("appView").refresh(true);

					that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
					that.getView().getModel().setProperty("/draftData/d", oData);
					//that.getView().getModel().setProperty("/draftData/d/toStatus/results/0/ActCom", oData);

					// oData.toItem.results.forEach(function (oItem) {
					// 	oItem.Zentry_tp = "E";
					// });
					// that.getView().getModel().setProperty("/wbsElementStr", oData.toItem.results);
					that.getView().getModel().setProperty("/toSummary", oData.toSummary.results);
					that.getView().getModel("pageModel").setProperty("/wbsElementStr", oData.toItem.results); // rohit - change
					// that.getView().byId("idTable").setVisibleRowCount(oData.toItem.results.length);
					that.getView().byId("idTable").setVisibleRowCount(8); // rohit -change
					var oEmail = oData.toDetails.results[0].Email;
					var aLen = oEmail.length;
					if (aLen != 0) {
						var data = oEmail.split(",");
						var tokenValue = [];
						for (var i = 0; i < data.length; i++) {
							tokenValue.push(new Token({
								text: data[i],
								key: data[i]
							}));
						}
						var oMultiInput1 = that.getView().byId("idT1Email");
						oMultiInput1.setTokens(tokenValue);
					}

					var attach = oData.toAttach.results.length;
					if (attach !== 0) {
						// var fName = oData.toAttach.results[0].Filename;
						// that.getView().byId("fileUploader").setValue(fName);
						that.getView().byId("idIWOUpload").setEnabled(true);
						// that.getView().byId("idDeleWbsAttch").setEnabled(true);

					}
					that.getView().getModel().setProperty("/toAttach", oData.toAttach.results);

					that.getView().byId("idProjDefi").setValue(oData.Zpspid);
					// that.getView().byId("idT1ComCode").setSelectedKey(oData.Zbukrs);
					that.getView().byId("idT1ComCode").setValue(oData.Zbukrs);

					if (oData.toDetails.results[0].ProjTyp === "C" || oData.toDetails.results[0].ProjTyp === "L") {
						that.getView().byId("idProjType").setSelectedKey("PRJ_TYP1");
						that.getView().byId("idT2LdPracSet").setRequired(true);
						that.getView().byId("idT2OpporId").setRequired(true);
						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Trade";
						that.getView().getModel("appView").refresh(true);

					} else {
						that.getView().byId("idProjType").setSelectedKey("PRJ_TYP2");
						var oViewModel = that.getView().getModel("appView");
						oViewModel.getData().projType = "Internal";
						that.getView().getModel("appView").refresh(true);
						that.getView().byId("idT2RevMthd").setValue("TE");
						that.getView().byId("idT2LdPracSet").setRequired(false);
						that.getView().byId("idT2OpporId").setRequired(false);
					}

					that.getView().byId("idReqType").setValue(oData.toDetails.results[0].ReasReq);
					that.getView().byId("idReqTypeDtls").setValue(oData.toDetails.results[0].ReqDet);
					that.getView().byId("idReqTypeFun").setSelectedKey(oData.toDetails.results[0].ReqFun);
					that.getView().byId("idT1FinAnyst").setValue(oData.toDetails.results[0].FinApp);

					that.getView().byId("idT2PersResp").setValue(oData.Vernr);
					that.getView().byId("idT2ProjRespCC").setValue(oData.Kostl);
					that.getView().byId("idT2ProjAdmin").setValue(oData.PrjAd);
					that.getView().byId("idT2FinAnyst").setValue(oData.FinApp);
					that.getView().byId("idT2ActMngr").setValue(oData.Agm);

					that.getView().byId("idT2ContractId").setValue(oData.Zpgid);
					that.getView().byId("idT2ContractType").setValue(oData.ZzContracttype);
					// that.getView().byId("idT2ActMngr").setSelectedKey(oData.Agm);
					// that.onSelectServiceOff(oData.Vgsbr);
					// that.onSelectProjPhase(oData.Vgsbr);

					/*Below code for grayout the field*/
					that.getView().byId("idWbsGuided").setEnabled(false);

					that.getView().byId("idT1ComCode").setEditable(false);
					that.getView().byId("idProjType").setEditable(false);
					that.getView().byId("idProjType").aCustomStyleClasses[0] = "";
					that.getView().byId("idReqType").setEditable(false);
					that.getView().byId("idReqType").aCustomStyleClasses[0] = "";
					that.getView().byId("idWBSTypeT1").setEditable(false);
					that.getView().byId("idWBSTypeT1").aCustomStyleClasses[0] = "";
					that.getView().byId("idReqTypeDtls").setEditable(false);
					that.getView().byId("idReqTypeDtls").aCustomStyleClasses[0] = "";
					that.getView().byId("idReqTypeFun").setEditable(false);
					that.getView().byId("idReqTypeFun").aCustomStyleClasses[0] = "";
					that.getView().byId("idT1Priority").setEditable(false);
					that.getView().byId("idT1Priority").aCustomStyleClasses[0] = "";
					that.getView().byId("idT1Email").setEditable(false);
					that.getView().byId("fileUploader").setEnabled(false);
					that.getView().byId("idT2SubbComm").setEditable(false);
					that.getView().byId("idT1FinAnyst").setEditable(false);

					that.getView().byId("idProjDefi").setEditable(false);
					that.getView().byId("idT4ProjDefDesc").setEditable(false);
					// that.getView().byId("idStartDate").setEnabled(false);
					// that.getView().byId("idEnddate").setEnabled(false);
					that.getView().byId("idStartDate").setEditable(false);
					that.getView().byId("idEnddate").setEditable(false);
					that.getView().byId("idT2PersResp").setEditable(false);
					that.getView().byId("idT2ProjRespCC").setEditable(false);
					that.getView().byId("idT2ProjCategory").setEditable(false);
					that.getView().byId("idT2ContractId").setEditable(false);
					that.getView().byId("idT2ContractType").setEditable(false);
					that.getView().byId("idT2CustId").setEditable(false);
					that.getView().byId("idT2CustNme").setEditable(false);
					that.getView().byId("idT2LdPracSet").setEditable(false);
					that.getView().byId("idT2LdPracSet").aCustomStyleClasses[0] = "";
					that.getView().byId("idT2ProjAdmin").setEditable(false);
					that.getView().byId("idT2FinAnyst").setEditable(false);
					that.getView().byId("idT2ActMngr").setEditable(false);
					that.getView().byId("idT2PrjSts").setEditable(false);
					that.getView().byId("idT2PrjSts").aCustomStyleClasses[0] = "";
					that.getView().byId("idT2RevMthd").setEditable(false);
					that.getView().byId("idT2RevMthd").aCustomStyleClasses[0] = "";
					that.getView().byId("idT2ContractTrm").setEditable(false);
					that.getView().byId("idT2ContractTrm").aCustomStyleClasses[0] = "";
					that.getView().byId("idT2OpporId").setEditable(false);
					that.getView().byId("idT2Program").setEditable(false);
					that.getView().byId("idT2Program").aCustomStyleClasses[0] = "";
					that.getView().byId("idGlobProj").setEditable(false);
					that.getView().byId("idEvExtract").setEditable(false);

					that.getView().byId("idErrorBtn").setEnabled(false);
					that.getView().byId("validBtn").setEnabled(false);
					that.getView().byId("SDBtn").setEnabled(false);
					that.getView().byId("SubBtn").setEnabled(false);
					that.getView().byId("settBtn").setEnabled(false);
					// that.getView().byId("downBtn").setEnabled(false);
					//Begin of Phase3 changes 
					// that.getView().byId("downBtn").setVisible(true);
					if (TYPE === "ReViewReq") {
						// var oCuurentSystem = window.location.href.split("//")[1].split("-")[0];
						// if (oCuurentSystem === "sapmdp") {
						// 	that.getView().byId("downBtnRvw").setVisible(false); //  Phase3 -Review download button added 	
						// 	that.getView().byId("downBtn").setVisible(true);
						// } else {
						that.getView().byId("downBtnRvw").setVisible(true); //  Phase3 -Review download button added 	
						that.getView().byId("downBtn").setVisible(false);
						// }

					} else {
						that.getView().byId("downBtn").setVisible(true);
					}
					//End of Phase3 changes 
					that.getView().byId("uploBtn").setEnabled(false);
					that.getView().byId("uploBtn").setVisible(false);
					that.getView().byId("idDeleWbsEle").setEnabled(false);
					that.getView().byId("idSiblingWBS").setEnabled(false);
					that.getView().byId("idChildWBS").setEnabled(false);
					that.getView().byId("idWbsEle").setEditable(false);
					that.getView().byId("idt4Desc").setEditable(false);

					that.sTerm1 = oData.Changed_by;
					that.sTerm2 = oData.toDetails.results[0].FinApp;
					that.sTerm3 = oData.Vernr;
					that.sTerm4 = oData.PrjAd;
					that.sTerm5 = oData.FinApp;
					that.sTerm6 = oData.Agm;

					var aFilters = [];
					// aFilters.push(new sap.ui.model.Filter("Sysnam", sap.ui.model.FilterOperator.Contains, "COM"));
					aFilters.push(new sap.ui.model.Filter([
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm5),
						new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6),
					], false));

					var oModel = that.getView().getModel("oDataModel");
					oModel.read("/Search_Finan_AnalystSet", {
						filters: aFilters,
						success: function (oResponse) {
							// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
							// return oModel;
							var term1 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm1;
							});
							if (term1.length !== 0) {
								var oViewModel = that.getView().getModel("appView");
								var firstName1 = term1[0].FirstName;
								var lastName1 = term1[0].LastName;
								var EmpID1 = term1[0].Pernr;
								var oID = term1[0].FirstName + "," + term1[0].LastName + "(" + term1[0].Pernr + ")";
								// oViewModel.getData().Requestor = oID;
								oViewModel.getData().Requestor = EmpID1;
								oViewModel.getData().RequestorName = firstName1 + "," + lastName1;
								that.getView().getModel("appView").refresh(true);
							}

							var term2 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm2;
							});
							if (term2.length !== 0) {
								var firstName1 = term2[0].FirstName;
								var lastName1 = term2[0].LastName;
								var EmpID1 = term2[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT1FinAnyst").setValue(oID);
								}
							}

							var term3 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm3;
							});
							if (term3.length !== 0) {
								var firstName1 = term3[0].FirstName;
								var lastName1 = term3[0].LastName;
								var EmpID1 = term3[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2PersResp").setValue(oID);
								}
							}

							var term4 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm4;
							});
							if (term4.length !== 0) {
								var firstName1 = term4[0].FirstName;
								var lastName1 = term4[0].LastName;
								var EmpID1 = term4[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ProjAdmin").setValue(oID);
								}
							}

							var term5 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm5;
							});
							if (term5.length !== 0) {
								var firstName1 = term5[0].FirstName;
								var lastName1 = term5[0].LastName;
								var EmpID1 = term5[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2FinAnyst").setValue(oID);
								}
							}

							var term6 = oResponse.results.filter(function (a) {
								return a.Pernr === that.sTerm6;
							});
							if (term6.length !== 0) {
								var firstName1 = term6[0].FirstName;
								var lastName1 = term6[0].LastName;
								var EmpID1 = term6[0].Pernr;
								if (EmpID1 !== "00000000") {
									var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									that.getView().byId("idT2ActMngr").setValue(oID);
								}
							}
							// var oModelExt = that.getView().getModel().getProperty("/wbsElementStr");
							var oModelExt = that.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
							var oExtline1 = oModelExt[0].Zentry_tp;
							if (oExtline1 === "E" || oExtline1 === "C") {
								//To Change app  title 
								var oView1 = that.getView().getParent();
								oView1.getService("ShellUIService").then(
									function (oService) {
										oService.setTitle("Manage Project Request");
									}
								);
								that.byId("HeaderID").setObjectTitle("Manage Project Request");

								//
							} else {
								//To Change app  title 
								var oView1 = that.getView().getParent();
								oView1.getService("ShellUIService").then(
									function (oService) {
										oService.setTitle("New Project Request");
									}
								);
								that.byId("HeaderID").setObjectTitle("New Project Request");
								//
							}
						},
						error: function (oError) {}
					});

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError, oResponse) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
						duration: 5000
					});
				}
			});
		},
		// onLoadDataRequest: function (ReqNo, TYPE) {
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	var oModel = this.getView().getModel("oDataModel");

		// 	var oViewModel = this.getView().getModel("appView");
		// 	oViewModel.getData().Requestid = ReqNo;
		// 	// oViewModel.getData().type = "View";
		// 	this.getView().getModel("appView").refresh(true);
		// 	var that = this;
		// 	oModel.read("/WBSManageApproveHeadSet('" + ReqNo + "')", {
		// 		// urlParameters: {
		// 		// 	'$expand': "toItem,,toError"
		// 		// },
		// 		urlParameters: {
		// 			'$expand': "toAttach,toItem,toStatus,toDetails"
		// 		},
		// 		success: function (oData, oResponse) {
		// 			if (oData === null || oData === undefined) {
		// 				var sMessage = "WARNING. Received a null or undefined response object.";
		// 				sap.m.MessageToast.show(sMessage);
		// 				// return;
		// 			}
		// 			var oViewModel = that.getView().getModel("appView");
		// 			oViewModel.getData().Requestor = oData.ChangedBy;
		// 			oViewModel.getData().ReqDate = oData.ChangedOn.toDateString();
		// 			oViewModel.getData().RequestorName = "";
		// 			// oViewModel.getData().RequestorEmail = "";
		// 			oViewModel.getData().EstatTxt = oData.toStatus.results[0].Status;
		// 			that.getView().getModel("appView").refresh(true);
		// 			that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
		// 			that.getView().getModel().setProperty("/draftData/d", oData);
		// 			//that.getView().getModel().setProperty("/draftData/d/toStatus/results/0/ActCom", oData);
		// 			that.getView().getModel().setProperty("/wbsElementStr", oData.toItem.results);

		// 			var attach = oData.toAttach.results.length;
		// 			if (attach === 1) {
		// 				var fName = oData.toAttach.results[0].Filename;
		// 				that.getView().byId("fileUploader").setValue(fName);
		// 				// that.getView().byId("idFileAttach").setEnabled(true);
		// 				// that.getView().byId("idDeleWbsAttch").setEnabled(true);

		// 			}
		// 			that.getView().getModel().setProperty("/toAttach", oData.toAttach.results);
		// 			// var TypeAppReq = "ReViewReq";
		// 			if (TYPE === "ReViewReq") {
		// 				that.onTabDisplay();
		// 			} else if (TYPE === "View") {
		// 				that.onTabDisplay();
		// 			} else if (TYPE === "ChangeProject") {
		// 				that.getView().byId("idWbsGuided").setEnabled(false);
		// 				that.onProjectChange(TYPE);
		// 			} else if (TYPE === "ChangeRequest") {
		// 				var sSelect = oData.toDetails.results[0].ReqDet;
		// 				that.onDisplayPriority(sSelect);
		// 			}
		// 			that.getView().byId("idProjDefi").setValue(oData.Zpspid);
		// 			that.getView().byId("idT1ComCode").setSelectedKey(oData.Zbukrs);
		// 			if (oData.toDetails.results[0].ProjTyp === "C") {
		// 				that.getView().byId("idProjType").setSelectedKey("PRJ_TYP1");

		// 				that.getView().byId("idT2ProjCategory").setEditable(false);
		// 				that.getView().byId("idT2ContractType").setEditable(true);
		// 				that.getView().byId("idT2LdPracSet").setEditable(true);
		// 				// that.getView().byId("idT2LdPracSet").setValue("");
		// 				// that.getView().byId("idT2LdPracSet").setSelectedKey("");
		// that.getView().byId("idT2RevMthd").setEditable(true);
		// 				that.getView().byId("idT2RevMthd").setRequired(true);
		// 				// that.getView().byId("idT2ContractTrm").setRequired(true);
		// 				// that.getView().byId("idT2PrjSts").setRequired(true);
		// 				var oProjectBox = that.getView().byId("idT2ContractType");
		// 				var oBindingBox = oProjectBox.getBinding("items");
		// 				var aFilters = new sap.ui.model.Filter({
		// 					filters: [
		// 						new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
		// 						new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
		// 						new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
		// 					],
		// 					and: true
		// 				});
		// 				// aFilters.push(oFilters);
		// 				oBindingBox.filter(aFilters);

		// 				var oBindingBoxT2 = that.getView().byId("idT2LdPracSet").getBinding("items");
		// 				var aFiltersT2 = [];
		// 				var oFiltersT2 = new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.NE, "BLANK");
		// 				aFiltersT2.push(oFiltersT2);
		// 				oBindingBoxT2.filter(aFiltersT2);

		// 				var oViewModel = that.getView().getModel("appView");
		// 				oViewModel.getData().projType = "Trade";
		// 				that.getView().getModel("appView").refresh(true);

		// 			} else {
		// 				that.getView().byId("idProjType").setSelectedKey("PRJ_TYP2");

		// 				that.getView().byId("idT2ProjCategory").setEditable(false);
		// 				that.getView().byId("idT2ContractType").setEditable(false);
		// 				that.getView().byId("idT2LdPracSet").setEditable(false);
		// 				// that.getView().byId("idT2LdPracSet").setValue("BLANK");
		// 				// that.getView().byId("idT2LdPracSet").setSelectedKey("BLANK");
		// 				that.getView().byId("idT2LdPracSet").setRequired(false);
		// 				that.getView().byId("idT2RevMthd").setEditable(false);
		// 				that.getView().byId("idT2RevMthd").setRequired(false);
		// 				that.getView().byId("idT2RevMthd").setValue("");
		// 				// that.getView().byId("idT2ContractTrm").setRequired(false);
		// 				// that.getView().byId("idT2PrjSts").setRequired(false);

		// 				var oProjectBox = that.getView().byId("idT2ContractType");
		// 				var oBindingBox = oProjectBox.getBinding("items");
		// 				var aFilters = [];
		// 				var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
		// 				aFilters.push(oFilters);
		// 				oBindingBox.filter(aFilters);

		// 				var oViewModel = that.getView().getModel("appView");
		// 				oViewModel.getData().projType = "Internal";
		// 				that.getView().getModel("appView").refresh(true);
		// 			}

		// 			that.getView().byId("idReqType").setSelectedKey(oData.toDetails.results[0].ReasReq);
		// 			that.getView().byId("idReqTypeDtls").setSelectedKey(oData.toDetails.results[0].ReqDet);
		// 			that.getView().byId("idReqTypeFun").setSelectedKey(oData.toDetails.results[0].ReqFun);
		// 			that.getView().byId("idT1FinAnyst").setSelectedKey(oData.toDetails.results[0].FinApp);

		// 			that.getView().byId("idT2PersResp").setSelectedKey(oData.Vernr);
		// 			that.getView().byId("idT2ProjRespCC").setSelectedKey(oData.Kostl);
		// 			that.getView().byId("idT2ProjAdmin").setSelectedKey(oData.PrjAd);
		// 			that.getView().byId("idT2FinAnyst").setSelectedKey(oData.FinApp);
		// 			that.getView().byId("idT2ActMngr").setSelectedKey(oData.Agm);

		// 			that.getView().byId("idT2ContractId").setSelectedKey(oData.Zpgid);
		// 			that.getView().byId("idT2ContractType").setSelectedKey(oData.ZzContracttype);
		// 			// that.getView().byId("idT2ActMngr").setSelectedKey(oData.Agm);
		// 			that.onSelectServiceOff(oData.Vgsbr);
		// 			that.onSelectProjPhase(oData.Vgsbr);
		// 			//that.getView().getModel().setProperty("/toDetails", oData.toDetails.results[0]);
		// 			sap.ui.core.BusyIndicator.hide();
		// 		},
		// 		error: function (oError, oResponse) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 			sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
		// 				duration: 5000
		// 			});
		// 		}
		// 	});
		// },
		// onDownladAttach: function (oEvent) {
		// 	// var selItem = oEvent.getParameter("item").getBindingContextPath().split("/")[1];
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var ReqID = oViewModel.getData().Requestid;
		// 	var sUrl = "/sap/opu/odata/sap/ZODATA_WBS_REQUEST_PH2_SRV/WBSAttachSet('" + ReqID + "')/$value";
		// 	var httpUrl = window.location.href.split("/sap/")[0];
		// 	var strUrl = httpUrl + sUrl;
		// 	window.open(strUrl);
		// },
		ongetEmpName: function (sTerm1, sTerm2, sTerm3, sTerm4, sTerm5, sTerm6) {
			// var sTerm = oEvent.getParameter("suggestValue");
			// var oSource = oEvent.getSource();
			// this.sTerm1 = sTerm1;
			// this.sTerm2 = sTerm2;
			// this.sTerm3 = sTerm3;
			// this.sTerm4 = sTerm4;
			// this.sTerm5 = sTerm5;
			// this.sTerm6 = sTerm6
			var osterm = sTerm1;
			var that = this;
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm1),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm2),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm3),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm4),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm5),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm6)
				],
				and: false
			});
			var oModel = this.getView().getModel("oDataModel");

			oModel.read("/Search_Finan_AnalystSet", {
				filters: [aFilters],
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					return oModel;

					// oSource.setModel(oModel, 'oportuT4');
					// oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onDownladAttach: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext().sPath;
			// var sPath = oEvent.getSource().getParent().getBindingContextPath();
			var index = sPath.slice(sPath.length - 1);
			var attachment = this.getView().getModel().getData().toAttach;
			var reqNumber = attachment[index].Reqid;
			var attachID = attachment[index].AttachID;

			var sUrl = "/sap/opu/odata/sap/ZODATA_WBS_REQUEST_PH2_SRV/WBSAttachSet(Reqid='" + reqNumber + "',AttachID='" + attachID +
				"')/$value";
			var httpUrl = window.location.href.split("/sap/")[0];
			// var 0Url = "http://sapmdd-dxc.sapnet.dxccorp.net:8443";
			var strUrl = httpUrl + sUrl;
			window.open(strUrl);
		},

		onTabDisplay: function () {
			this.getView().byId("idWbsGuided").setEnabled(false);

			this.getView().byId("idT1ComCode").setEnabled(false);
			this.getView().byId("idProjType").setEnabled(false);
			this.getView().byId("idReqType").setEnabled(false);
			this.getView().byId("idReqTypeDtls").setEnabled(false);
			this.getView().byId("idReqTypeFun").setEnabled(false);
			this.getView().byId("idT1Priority").setEnabled(false);
			this.getView().byId("idT1Email").setEnabled(false);
			this.getView().byId("fileUploader").setEnabled(false);
			this.getView().byId("idT2SubbComm").setEnabled(false);
			this.getView().byId("idT1FinAnyst").setEnabled(false);
			// this.getView().byId("idUploadFile").setEnabled(false);
			this.getView().byId("idProjDefi").setEnabled(false);
			this.getView().byId("idT4ProjDefDesc").setEnabled(false);
			this.getView().byId("idT2CoCode").setEnabled(false);
			this.getView().byId("idStartDate").setEnabled(false);
			this.getView().byId("idEnddate").setEnabled(false);
			this.getView().byId("idT2PersResp").setEnabled(false);
			this.getView().byId("idT2ProjRespCC").setEnabled(false);
			this.getView().byId("idT2BusnsArea").setEnabled(false);
			this.getView().byId("idT2PrftCenter").setEnabled(false);
			this.getView().byId("idT2ProjCategory").setEnabled(false);
			this.getView().byId("idT2ContractId").setEnabled(false);
			this.getView().byId("idT2ClientId").setEnabled(false);
			this.getView().byId("idT2IndusCode").setEnabled(false);
			this.getView().byId("idT2ContractType").setEnabled(false);
			this.getView().byId("idT2CustId").setEnabled(false);
			this.getView().byId("idT2CustNme").setEnabled(false);
			this.getView().byId("idT2LdPracSet").setEnabled(false);
			this.getView().byId("idT2ProjAdmin").setEnabled(false);
			this.getView().byId("idT2FinAnyst").setEnabled(false);
			this.getView().byId("idT2ActMngr").setEnabled(false);
			this.getView().byId("idT2PrjSts").setEnabled(false);
			this.getView().byId("idT2RevMthd").setEnabled(false);
			this.getView().byId("idT2ContractTrm").setEnabled(false);
			this.getView().byId("idT2OpporId").setEnabled(false);
			this.getView().byId("idT2Program").setEnabled(false);
			this.getView().byId("idGlobProj").setEnabled(false);
			this.getView().byId("idEvExtract").setEnabled(false);

			this.getView().byId("idErrorBtn").setEnabled(false);
			this.getView().byId("validBtn").setEnabled(false);
			this.getView().byId("SDBtn").setEnabled(false);
			this.getView().byId("SubBtn").setEnabled(false);
			this.getView().byId("settBtn").setEnabled(false);
			this.getView().byId("massUpload").setEnabled(false);
			this.getView().byId("idDeleWbsEle").setEnabled(false);
			this.getView().byId("idSiblingWBS").setEnabled(false);
			this.getView().byId("idChildWBS").setEnabled(false);
			this.getView().byId("idWbsEle").setEditable(false);
			this.getView().byId("idt4Desc").setEditable(false);
			this.getView().byId("idPlanIndi").setEditable(false);
			this.getView().byId("idAcIndi").setEditable(false);
			this.getView().byId("idBillIndi").setEditable(false);
			this.getView().byId("idT4CoCode").setEditable(false);
			this.getView().byId("idT4CosCtr").setEditable(false);
			this.getView().byId("idT4BusinArea").setEditable(false);
			this.getView().byId("idT4ProfCtr").setEditable(false);
			this.getView().byId("idT4WbsType").setEnabled(false);
			this.getView().byId("idOpporId").setEditable(false);
			this.getView().byId("idT4SerOffri").setEditable(false);
			this.getView().byId("idSystemStatus").setEditable(false);
			this.getView().byId("idusrStatus").setEditable(false);
			this.getView().byId("idRaKey").setEnabled(false);
			this.getView().byId("idProjAdmin").setEditable(false);
			this.getView().byId("idFinAnyst").setEditable(false);
			this.getView().byId("idPersResp").setEditable(false);
			this.getView().byId("idProjMngr").setEditable(false);
			this.getView().byId("idProjPhase").setEnabled(false);
			// var oEditableModel = new JSONModel();
			// var OEditableData = {
			// 	Editable: false
			// };
			// oEditableModel.setData(OEditableData);
			// that.getView().setModel(oEditableModel, "oEditModel");
		},
		onProjectChange: function (TYPE) {
			if (TYPE === "DuplicateExisting") {
				this.getView().byId("idProjDefi").setEnabled(true);
			} else if (TYPE === "ChangeProject") {
				this.getView().byId("idProjDefi").setEnabled(false);
			}

			this.getView().byId("idT4ProjDefDesc").setEnabled(false);
			this.getView().byId("idT2CoCode").setEnabled(false);
			this.getView().byId("idStartDate").setEnabled(false);
			this.getView().byId("idEnddate").setEnabled(false);
			this.getView().byId("idT2PersResp").setEnabled(false);
			this.getView().byId("idT2ProjRespCC").setEnabled(false);
			this.getView().byId("idT2BusnsArea").setEnabled(false);
			this.getView().byId("idT2PrftCenter").setEnabled(false);
			this.getView().byId("idT2ProjCategory").setEnabled(false);
			this.getView().byId("idT2ContractId").setEnabled(false);
			this.getView().byId("idT2ClientId").setEnabled(false);
			this.getView().byId("idT2IndusCode").setEnabled(false);
			this.getView().byId("idT2ContractType").setEnabled(false);
			this.getView().byId("idT2CustId").setEnabled(false);
			this.getView().byId("idT2CustNme").setEnabled(false);
			this.getView().byId("idT2LdPracSet").setEnabled(false);
			this.getView().byId("idT2ProjAdmin").setEnabled(false);
			this.getView().byId("idT2FinAnyst").setEnabled(false);
			this.getView().byId("idT2ActMngr").setEnabled(false);
			this.getView().byId("idT2PrjSts").setEnabled(false);
			this.getView().byId("idT2RevMthd").setEnabled(false);
			this.getView().byId("idT2ContractTrm").setEnabled(false);
			this.getView().byId("idT2OpporId").setEnabled(false);
			this.getView().byId("idT2Program").setEnabled(false);
			this.getView().byId("idGlobProj").setEnabled(false);
			this.getView().byId("idEvExtract").setEnabled(false);

		},
		onPopUpDisplay: function () {
			this.getView().byId("idStartDateAddiField1").setEditable(false);
			this.getView().byId("idEnddateAddiField").setEditable(false);
			this.getView().byId("idRiskInd").setEditable(false);
			this.getView().byId("idTimeTrack").setEditable(false);
			this.getView().byId("idPlnRevCurr").setEditable(false);
			this.getView().byId("idAddUsr01").setEditable(false);
			this.getView().byId("idAddUsr02").setEditable(false);
			this.getView().byId("idAddUsr03").setEditable(false);
			// this.getView().byId("idAddTaskOrd").setEditable(false);
			this.getView().byId("idContType").setEditable(false);
			this.getView().byId("idEmbLease").setEditable(false);
			this.getView().byId("idBasicSDate").setEditable(false);
			this.getView().byId("idBasicEDate").setEditable(false);

			// this.getView().byId("idTaskOrder").setEditable(false);
			this.getView().byId("idBPO").setEditable(false);
			this.getView().byId("idCanType").setEditable(false);
			this.getView().byId("idForCastStr").setEditable(false);
			this.getView().byId("idPriority").setEditable(false);
			this.getView().byId("idCapRat").setEditable(false);
			this.getView().byId("idMarkup").setEditable(false);
			this.getView().byId("idAddPOC").setEditable(false);
			this.getView().byId("idAsstType").setEditable(false);
			this.getView().byId("idFinOpt").setEditable(false);
			this.getView().byId("idVendr").setEditable(false);
			this.getView().byId("idProjSubPhase").setEditable(false);
			this.getView().byId("idSavePopUpBtn").setEnabled(false);
			this.getView().byId("idGTMwbs").setEditable(false);
			sap.ui.core.BusyIndicator.hide();
		},
		onPopUpDisplayTnternal: function () {
			this.getView().byId("idStartDateAddiField1").setEditable(false);
			this.getView().byId("idEnddateAddiField").setEditable(false);
			this.getView().byId("idRiskInd").setEditable(false);
			this.getView().byId("idEmbLease").setEditable(false);
			// this.getView().byId("idAddTaskOrd").setEditable(false);
			this.getView().byId("idBPO").setEditable(false);
			// this.getView().byId("idTaskOrder").setEditable(false);
			this.getView().byId("idCanType").setEditable(false);
			this.getView().byId("idForCastStr").setEditable(false);
			this.getView().byId("idPriority").setEditable(false);
			this.getView().byId("idCapRat").setEditable(false);
			this.getView().byId("idMarkup").setEditable(false);
			this.getView().byId("idAddPOC").setEditable(false);
			this.getView().byId("idAsstType").setEditable(false);
			this.getView().byId("idFinOpt").setEditable(false);
			this.getView().byId("idVendr").setEditable(false);
			// this.getView().byId("idProjPhase").setEditable(false);
			this.getView().byId("idProjSubPhase").setEditable(false);
		},
		onWbsValidation: function () {

			sap.ui.core.BusyIndicator.show(0);
			// var itemDetails = this.getView().getModel().getData().wbsElementStr;
			// var noItem = itemDetails.length;
			// this.getView().byId("idTable").setVisibleRowCount(noItem);
			var oViewModel = this.getView().getModel("appView");
			var reqID = oViewModel.getData().Requestid;
			var allMandt = this.onValidation();
			var newMandt = this.newValidation(); // rohit - change

			if (allMandt && newMandt) {
				var draftData = this.onGetData("VALIDATE", reqID, "");

				// delete draftData.d.toAttach; // rohit - change - remove attachment temporarily

				var oViewModel = this.getView().getModel("appView");
				var oppSafeCaseid = oViewModel.getData().oppSafeCaseid;
				if (oppSafeCaseid) {
					var oModel = this.getView().getModel("oDataModel");
					draftData.d.toItem.results = this._fnRemoveFields(draftData.d.toItem.results);
					var that = this;
					oModel.create("/HeaderRequestSet", draftData, {
						success: function (oResponse) {
							// that.getView().byId("idTable").setVisibleRowCount("10");
							var oErrorCount = oResponse.toError.results.length;
							if (oErrorCount === 0) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("Validation complete, you can submit the request.", {
									duration: 15000
								});
								that.getView().byId("idErrorBtn").setVisible(false);
								// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
								var oViewModel = that.getView().getModel("appView");
								that.getView().getModel().getData().toError = oResponse.toError.results;
								oViewModel.getData().Requestid = oResponse.ReqNo;

								// Performance issue -Start 

								// /*Mayank:Below code for change color Icon */
								var wbsElement = that.getView().getModel("pageModel").getProperty("/wbsElementStr");

								if (wbsElement.length <= 52) {
									for (var i = 0; i < wbsElement.length; i++) {
										wbsElement[i].IconColor = "S"; // for phase2 table  Adding color  dynamically 
										var oPageModel = that.getView().getModel("pageModel");
										oPageModel.refresh(true);
									}
								}
								// clear errors 
								else{
										var oPageModel = that.getView().getModel("pageModel");
										oPageModel.refresh(true);
								}

								//  below  code commented becouse performace issue in  MDP  .
								// that.getView().getModel().setProperty("/wbsElementStr", oResponse.toItem.results);
								// that.getView().getModel("pageModel").setProperty("/wbsElementStr", oResponse.toItem.results);
								// var oPageModel = that.getView().getModel("pageModel");
								// oPageModel.refresh(true);
								// Performance issue -end 
							} else {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("Validation completed with errors. Please check the error log.", {
									duration: 15000
								});
								that.getView().byId("idErrorBtn").setVisible(true);
								that.getView().getModel().getData().toError = oResponse.toError.results;
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().Requestid = oResponse.ReqNo;
								// oViewModel.getData().Requestid = oResponse.ReqNo;

								// Performance issue -Start 
								/*Mayank:Below code for change color Icon */
								var wbsElement = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
								if (wbsElement.length <= 52) {
									for (var i = 0; i < wbsElement.length; i++) {
										var oWbsIcon = oResponse.toError.results.filter(function (a) {
											return a.MSG_WBS === wbsElement[i].Zposid;
										});
										if (oWbsIcon.length > 0) {
											wbsElement[i].IconColor = "E"; // for phase2 table  Adding color  dynamically 
										} else {
											wbsElement[i].IconColor = "S"; // for phase2 table  Adding color  dynamically 	
										}
										var oPageModel = that.getView().getModel("pageModel");
										oPageModel.refresh(true);
									}
								}
									// clear errors 
								else{
										var oPageModel = that.getView().getModel("pageModel");
										oPageModel.refresh(true);
								}

								// that.getView().getModel().setProperty("/wbsElementStr", oResponse.toItem.results);
								// that.getView().getModel("pageModel").setProperty("/wbsElementStr", oResponse.toItem.results);
								// var oPageModel = that.getView().getModel("pageModel");
								// oPageModel.refresh(true);

								// Performance issue -end 	

							}
							// if (oResponse.FinApp) {
							// 	that.getView().byId("idT2FinAnyst").setSelectedKey(oResponse.FinApp);
							// 	// this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
							// }
							// if (oResponse.toDetails.results[0].FinApp) {
							// 	that.getView().byId("idT1FinAnyst").setSelectedKey(oResponse.toDetails.results[0].FinApp);
							// 	// this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
							// }
						},
						error: function (oError, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							// that.getView().byId("idTable").setVisibleRowCount("10");
							sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
								duration: 15000
							});
							// sap.m.MessageToast.show(oError.message +"\n" + oError.statusText + "\n" +oError.responseText, {
							// 	duration: 5000,
							// 	width: "35em"
							// });
						}
					});
				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Please Use all Case Safe ID.");
				}
				// MessageToast.show("Coming Sooooon!!!");
			} else {
				sap.ui.core.BusyIndicator.hide();
				// var oChangePro = oViewModel.getData().type;
				// // oViewModel.getData().type = "ChangeProject";
				// // var oModel = this.getView().getModel();
				// var oModel = this.getView().getModel("pageModel"); // rohit - change
				// var itab = oModel.getProperty("/wbsElementStr");
				// var oItabExt = itab[0].Zentry_tp;
				// if (oChangePro === "ChangeProject" || oItabExt === "E") {
				// 	var allMandt1 = this.onValidationChange();
				// 	if (!allMandt1) {
				// 		// MessageBox.show(
				// 		// 	"Mandatory existing Project Definition fields have not been populated. \r\n Please work with Global Order Management Team to resolve in COMPASS.",
				// 		// 	sap.m.MessageBox.Icon.ERROR, "Error");
				// 		// And for the team to resolve shall not be "WBS Design Team", shall be "Global Order Management Team
				// 	} else {
				// 		MessageToast.show("Please complete all the mandatory fields.");
				// 	}

				// } else {
				MessageToast.show("Please complete all the mandatory fields.");
				// }

			}
		},
		onWbsSaveDraft: function () {

			sap.ui.core.BusyIndicator.show(0);
			// var itemDetails = this.getView().getModel().getData().wbsElementStr;
			// var noItem = itemDetails.length;
			// this.getView().byId("idTable").setVisibleRowCount(noItem);
			var oProjeDef = this.getView().byId("idProjDefi").getValue(); // Production issue Phase2 
			var comCode = this.getView().byId("idT1ComCode").getSelectedKey();
			if (!comCode) {
				var comCode = this.getView().byId("idT1ComCode").getValue();
			}
			var sDate = this.getView().byId("idStartDate").getDateValue();
			var eDate = this.getView().byId("idEnddate").getDateValue();
			var oViewModel = this.getView().getModel("appView");
			var oppSafeCaseid = oViewModel.getData().oppSafeCaseid;
			// if (comCode && sDate && eDate && oProjeDef.length === 9) { // Phase2  Production issue 
			if (comCode && sDate && eDate && oProjeDef.split(" ").length === 1 && oProjeDef.length === 9) {
				var oViewModel = this.getView().getModel("appView");
				var ReqID = oViewModel.getData().Requestid;
				var draftData = this.onGetData("DRAFT", ReqID, "DRAFT");
				// delete draftData.d.toAttach; // rohit - change - remove attachment temporarily
				var oViewModel = this.getView().getModel("appView");
				var oppSafeCaseid = oViewModel.getData().oppSafeCaseid;
				if (oppSafeCaseid) {
					// MessageToast.show("Coming Sooooon!!!");
					draftData.d.toItem.results = this._fnRemoveFields(draftData.d.toItem.results);
					var oModel = this.getView().getModel("oDataModel");
					var that = this;
					oModel.create("/HeaderRequestSet", draftData, {
						success: function (oResponse) {
							sap.ui.core.BusyIndicator.hide();
							// that.getView().byId("idTable").setVisibleRowCount("10");
							var oErrorCount = oResponse.toError.results.length;
							if (oErrorCount === 0) {
								sap.m.MessageToast.show("Request #" + oResponse.ReqNo + " saved as draft", {
									duration: 10000
								});
								// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().Requestid = oResponse.ReqNo;
								that.getView().getModel("appView").refresh(true);

								var attach = oResponse.toAttach.results.length;
								if (attach !== 0) {
									that.getView().getModel().setProperty("/toAttach", oResponse.toAttach.results);
								}
								that.onClearData();
								// if (oResponse.FinApp) {
								// 	that.getView().byId("idT2FinAnyst").setSelectedKey(oResponse.FinApp);
								// 	// this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
								// }
								// if (oResponse.toDetails.results[0].FinApp) {
								// 	that.getView().byId("idT1FinAnyst").setSelectedKey(oResponse.toDetails.results[0].FinApp);
								// 	// this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
								// 
							} else {
								var oErrMsg = oResponse.toError.results[0].MsgDes;
								MessageBox.show(oErrMsg, sap.m.MessageBox.Icon.ERROR, "Error");
							}
						},
						error: function (oError, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							// that.getView().byId("idTable").setVisibleRowCount("10");
							sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
								duration: 15000
							});
							// sap.m.MessageToast.show(oError.message +"\n" + oError.statusText + "\n" +oError.responseText, {
							// 	duration: 5000,
							// 	width: "35em"
							// });
						}
					});
				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Please Use all Case Safe ID.");
				}

				// }
				//End of changes for Error Message//

				// MessageToast.show("Coming Sooooon!!!");
			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please enter value in Company Code, Start Date, Finish Date & Project Definition.");
			}
		},
		onWbsSubmit: function () {

			sap.ui.core.BusyIndicator.show(0);
			// var itemDetails = this.getView().getModel().getData().wbsElementStr;
			// var noItem = itemDetails.length;
			// this.getView().byId("idTable").setVisibleRowCount(noItem);
			var oViewModel = this.getView().getModel("appView");
			var reqID = oViewModel.getData().Requestid;
			var allMandt = this.onValidation();
			var newMandt = this.newValidation(); // rohit - change
			if (allMandt && newMandt) {
				var draftData = this.onGetData("SUBMIT", reqID, "INPROGRESS");
				// delete draftData.d.toAttach; // rohit - change - remove attachment temporarily
				var oViewModel = this.getView().getModel("appView");
				var oppSafeCaseid = oViewModel.getData().oppSafeCaseid;
				if (oppSafeCaseid) {
					var oModel = this.getView().getModel("oDataModel");
					draftData.d.toItem.results = this._fnRemoveFields(draftData.d.toItem.results);
					var that = this;
					oModel.create("/HeaderRequestSet", draftData, {
						success: function (oResponse) {
							// that.getView().byId("idTable").setVisibleRowCount("10");
							var oErrorCount = oResponse.toError.results.length;
							if (oErrorCount === 0) {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("Request submitted successfully with Request # " + oResponse.ReqNo, {
									duration: 15000
								});
								// that.getView().getModel().getData().HeaderData.ReqID = oResponse.ReqNo;
								that.getView().byId("idErrorBtn").setVisible(false);
								that.onClearData();
								// var oViewModel = that.getView().getModel("appView");
								// oViewModel.getData().Requestid = oResponse.ReqNo;
							} else {
								sap.ui.core.BusyIndicator.hide();
								sap.m.MessageToast.show("Please check the error Logs.", {
									duration: 15000
								});
								that.getView().byId("idErrorBtn").setVisible(true);
								that.getView().getModel().getData().toError = oResponse.toError.results;
								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().Requestid = oResponse.ReqNo;

								// Performance issue -Start 

								// /*Mayank:Below code for change color Icon */
								var wbsElement = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
								if (wbsElement.length <= 52) {
									for (var i = 0; i < wbsElement.length; i++) {
										var oWbsIcon = oResponse.toError.results.filter(function (a) {
											return a.MSG_WBS === wbsElement[i].Zposid;
										});
										if (oWbsIcon.length > 0) {
											wbsElement[i].IconColor = "E"; // for phase2 table  Adding color  dynamically 
										} else {
											wbsElement[i].IconColor = "S"; // for phase2 table  Adding color  dynamically 	
										}
										var oPageModel = that.getView().getModel("pageModel");
										oPageModel.refresh(true);
									}
								}
								
									// clear errors 
								else{
										var oPageModel = that.getView().getModel("pageModel");
										oPageModel.refresh(true);
								}

								// that.getView().getModel().setProperty("/wbsElementStr", oResponse.toItem.results);
								// that.getView().getModel("pageModel").setProperty("/wbsElementStr", oResponse.toItem.results);
								// var oPageModel = that.getView().getModel("pageModel");
								// oPageModel.refresh(true);
								// Performance issue -end 
							}
							// if (oResponse.FinApp) {
							// 	that.getView().byId("idT2FinAnyst").setSelectedKey(oResponse.FinApp);
							// 	// this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
							// }
							// if (oResponse.toDetails.results[0].FinApp) {
							// 	that.getView().byId("idT1FinAnyst").setSelectedKey(oResponse.toDetails.results[0].FinApp);
							// 	// this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
							// }

						},
						error: function (oError, oResponse) {
							sap.ui.core.BusyIndicator.hide();
							// that.getView().byId("idTable").setVisibleRowCount("10");
							sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
								duration: 15000
							});
							// sap.m.MessageToast.show(oError.message +"\n" + oError.statusText + "\n" +oError.responseText, {
							// 	duration: 5000,
							// 	width: "35em"
							// });
						}
					});
				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Please Use all Case Safe ID.");
				}
			} else {
				sap.ui.core.BusyIndicator.hide();

				MessageToast.show("Please complete all the mandatory fields.");
				// var oChangePro = oViewModel.getData().type;
				// // var oModel = this.getView().getModel();
				// var oModel = this.getView().getModel("pageModel"); // rohit - change
				// var itab = oModel.getProperty("/wbsElementStr");
				// var oItabExt = itab[0].Zentry_tp;
				// if (oChangePro === "ChangeProject" || oItabExt === "E") {
				// 	var allMandt1 = this.onValidationChange();
				// 	if (!allMandt1) {
				// 		// MessageBox.show(
				// 		// 	"Mandatory existing Project Definition fields have not been populated. \r\n Please work with Global Order Management Team to resolve in COMPASS.",
				// 		// 	sap.m.MessageBox.Icon.ERROR, "Error");
				// 	} else {
				// 		MessageToast.show("Please complete all the mandatory fields.");
				// 	}
				// } else {
				// 	MessageToast.show("Please complete all the mandatory fields.");
				// }

			}
			// MessageToast.show("Coming Sooooon!!!");
		},
		onErrorBtnPress: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var oView = that.getView();
			var oDialog = oView.byId("idDialogpdf1");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.ErrorDisplay", that);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var oData = this.getView().getModel().getData().toError;
			var oModel = new sap.ui.model.json.JSONModel(oData);
			var oTable = this.byId("errorLog11");
			oTable.setModel(oModel);
			sap.ui.core.BusyIndicator.hide();

		},
		onErrorBtnPressWBS: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			// var oRow = oEvent.getParameter("row");
			// var oItem = oEvent.getParameter("item");
			// var wbsEleID = this.getView().getModel().getProperty("Zposid", oRow.getBindingContext());
			var oPath = oEvent.getSource().getBindingContext("pageModel").getPath();
			var wbsEleID = oEvent.getSource().getBindingContext("pageModel").getObject().Zposid;

			var that = this;
			var oView = that.getView();
			var oDialog = oView.byId("idDialogpdf");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.WBSErrorDisplay", that);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var wbsElement = this.getView().getModel().getData().toError;
			// var wbsElement = oModel.getProperty("/toError");
			var oData = wbsElement.filter(function (a) {
				return a.MSG_WBS === wbsEleID;
			});
			var oModel = new sap.ui.model.json.JSONModel(oData);
			var oTable = this.byId("errorLog1");
			oTable.setModel(oModel);
			sap.ui.core.BusyIndicator.hide();
		},
		onGetData: function (action, reqID, Status) {
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().type;
			if (action === "SUBMIT") {
				if (type === "ChangeRequest") {
					action = "CHNGRQUEST";
				} else if (type === "ChangeProject") {
					action = "CHNGPROJCT";
				} else if (type === "DuplicateExisting") {
					action = "CHNGPROJCT";
				} else {
					action;
				}
			} else {
				action;
			}

			// var itemDetails = this.getView().getModel().getData().wbsElementStr; // rohit - change
			// var itemDetails = this.getView().getModel("pageModel").getData().wbsElementStr; // rohit - change
			var itemDetails = JSON.parse(JSON.stringify(this.getView().getModel("pageModel").getData().wbsElementStr));
			var noItem = itemDetails.length;
			// this.getView().byId("idTable").setVisibleRowCount(noItem);
			this.getView().byId("idTable").setVisibleRowCount(8); // rohit -change
			var draftData = this.getView().getModel().getData().draftData;
			var oToDetails = this.getView().getModel().getData().toDetails;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var sDate = draftData.d.Guebg;
			if (sDate) {
				var n = sDate.getTimezoneOffset() / 60;
				if (Math.sign(n) === -1) {
					oDate1 = dateFormat.format(new Date(sDate));
					var oDate1 = oDate1 + "T14:00:00";
					var startDateObject = new Date(oDate1);
					draftData.d.Guebg = startDateObject;
				}
			}

			var eDate = draftData.d.Gueen;
			if (eDate) {
				var n = eDate.getTimezoneOffset() / 60;
				if (Math.sign(n) === -1) {
					oDate = dateFormat.format(new Date(eDate));
					var oDate = oDate + "T14:00:00";
					var endDateObject = new Date(oDate);
					draftData.d.Gueen = endDateObject;
				}
			}

			var ZzGlblProj = this.getView().byId("idGlobProj").getSelected();
			if (ZzGlblProj) {
				draftData.d.ZzGlblProj = "X";
			} else {
				draftData.d.ZzGlblProj = "";
			}
			var ZzEvExtract = this.getView().byId("idEvExtract").getSelected();
			if (ZzEvExtract) {
				draftData.d.ZzEvExtract = "X";
			} else {
				draftData.d.ZzEvExtract = "";
			}
			draftData.d.Bstdk = "0000-00-00"
				// delete draftData.d.Bstdk;
				/* below code is getting the id for search help(Tab 1) */
			draftData.d.ReqNo = reqID;
			// if (type === "ChangeProject") {
			draftData.d.Zpspid = this.getView().byId("idProjDefi").getValue();
			// }
			draftData.d.Zpspid = this.getView().byId("idProjDefi").getValue();

			/* below code is getting the id for search help(Tab 2) */

			if (this.getView().byId("idT1FinAnyst").getSelectedKey()) {
				draftData.d.toDetails.results[0].FinApp = this.getView().byId("idT1FinAnyst").getSelectedKey();
			} else {
				draftData.d.toDetails.results[0].FinApp = oToDetails.FinApp;
			}

			if (this.getView().byId("idT2FinAnyst").getSelectedKey()) {
				draftData.d.FinApp = this.getView().byId("idT2FinAnyst").getSelectedKey();
			} else {
				draftData.d.FinApp = draftData.d.FinApp;
			}

			if (this.getView().byId("idT2PersResp").getSelectedKey()) {
				draftData.d.Vernr = this.getView().byId("idT2PersResp").getSelectedKey();
			} else {
				draftData.d.Vernr = draftData.d.Vernr;
			}

			if (this.getView().byId("idT2ActMngr").getSelectedKey()) {
				draftData.d.Agm = this.getView().byId("idT2ActMngr").getSelectedKey();
			} else {
				draftData.d.Agm = draftData.d.Agm;
			}

			// }
			//537

			if (this.getView().byId("idT2ContractType").getSelectedKey()) {
				draftData.d.ZzContracttype = this.getView().byId("idT2ContractType").getSelectedKey();
			}
			if (this.getView().byId("idT2LdPracSet").getSelectedKey()) {
				draftData.d.Zzldpcid = this.getView().byId("idT2LdPracSet").getSelectedKey();
			}

			if (this.getView().byId("idT2ProjAdmin").getSelectedKey()) {
				draftData.d.PrjAd = this.getView().byId("idT2ProjAdmin").getSelectedKey();
			}

			if (this.getView().byId("idT2PrjSts").getSelectedKey()) {
				draftData.d.Zzpjsgst = this.getView().byId("idT2PrjSts").getSelectedKey();
			}
			if (this.getView().byId("idT2RevMthd").getSelectedKey()) {
				draftData.d.Zzrvrgmdcd = this.getView().byId("idT2RevMthd").getSelectedKey();
			}
			if (this.getView().byId("idT2ContractTrm").getSelectedKey()) {
				draftData.d.Zzcntrcd = this.getView().byId("idT2ContractTrm").getSelectedKey();
			}
			if (this.getView().byId("idT2OpporId").getSelectedKey()) {
				draftData.d.Zzsiebelid = this.getView().byId("idT2OpporId").getSelectedKey();
			}
			if (this.getView().byId("idT2Program").getSelectedKey()) {
				draftData.d.Zzpgid = this.getView().byId("idT2Program").getSelectedKey();
			}
			// }

			// draftData.d.Kostl = this.getView().byId("idT2ProjRespCC").getSelectedKey();
			draftData.d.Zpjcgid = this.getView().byId("idT2ProjCategory").getValue();
			// draftData.d.Zpgid = this.getView().byId("idT2ContractId").getSelectedKey();
			// draftData.d.Zkunnr = this.getView().byId("idT2ClientId").getSelectedKey(); 
			// draftData.d.Zzsoarincd = this.getView().byId("idT2IndusCode").getSelectedKey();

			// draftData.d.ZzContracttype = this.getView().byId("idT2ContractType").getSelectedKey();
			// draftData.d.Soldto = this.getView().byId("idT2CustId").getSelectedKey();
			// draftData.d.Zzldpcid = this.getView().byId("idT2LdPracSet").getSelectedKey();
			// draftData.d.PrjAd = this.getView().byId("idT2ProjAdmin").getSelectedKey();
			// draftData.d.FinApp = this.getView().byId("idT1FinAnyst").getSelectedKey();
			// draftData.d.Agm = this.getView().byId("idT2ActMngr").getSelectedKey();

			draftData.d.Action = action;

			var tab1Detail = this.getView().getModel().getData().toDetails;
			delete tab1Detail.__metadata
				//
			if (type === "OpprApp") {
				tab1Detail.FinApp = draftData.d.toDetails.results[0].FinApp;
			}
			//
			draftData.d.toDetails.results[0] = tab1Detail;
			draftData.d.toDetails.results[0].Zpspid = this.getView().byId("idProjDefi").getValue();
			draftData.d.toDetails.results[0].ProjTyp = this.getView().byId("idProjType").getSelectedKey();
			draftData.d.toDetails.results[0].ReasReq = this.getView().byId("idReqType").getSelectedKey();
			draftData.d.toDetails.results[0].ReqFun = this.getView().byId("idReqTypeFun").getSelectedKey();
			if (type === "OpprApp") {
				draftData.d.toDetails.results[0].Zflag = "X";
			}
			if (type === "ChangeProject") {
				// action = "CHNGPROJCT";
				var TypeReq1 = "ADD";
			} else if ((type === "OpprApp") && (itemDetails[0].Zentry_tp === "E" || itemDetails[0].Zentry_tp === "C")) {
				// action = "CHNGPROJCT";
				var TypeReq1 = "ADD";
			} else {
				var TypeReq1 = "CREATE";
			}
			draftData.d.toDetails.results[0].TypeReq = TypeReq1;
			draftData.d.toDetails.results[0].ReqDet = this.getView().byId("idReqTypeDtls").getSelectedKey();
			// draftData.d.toDetails.results[0].ReqFun = this.getView().byId("idReqTypeFun").getSelectedKey();
			// draftData.d.toDetails.results[0].FinApp = this.getView().byId("idT1FinAnyst").getSelectedKey();
			// draftData.d.toDetails.results[0].Email = this.getView().byId("idT1Email").getSelectedKey();
			draftData.d.toDetails.results[0].ReqNum = reqID;

			var a = this.getView().byId("idT1Email").getTokens().length;
			var emailID = [];
			for (var j = 0; j < a; j++) {
				emailID.push(this.getView().byId("idT1Email").getTokens()[j].getKey());
			}
			delete draftData.d.toDetails.results[0].Email;
			draftData.d.toDetails.results[0].Email = emailID.join(",");

			// draftData.d.toDetails.results[0].ChangedBy = this.getView().getModel("appView").oData.Requestor;
			// draftData.d.toDetails.results[0].ChangedOn = this.getView().getModel("appView").oData.ReqDate;
			draftData.d.toStatus.results[0].ActCom = this.getView().byId("idT2SubbComm").getValue();
			draftData.d.toDetails.results[0].Req_com = this.getView().byId("idT2SubbComm").getValue();

			// if (type === "ChangeProject") {

			var oUser = new UserInfo();
			var Requestor = oUser.getId();
			draftData.d.toStatus.results[0].ActId = Requestor;
			delete draftData.d.toStatus.results[0].__metadata;
			 //draftData.d.toStatus.results[0].ActId = "11596835";
			// }else if (type === "ChangeProject") {
			// 	var oUser = new UserInfo();
			// 	var Requestor = oUser.getId();
			// 	draftData.d.toStatus.results[0].ActId = Requestor;
			// }else{
			// 	draftData.d.toStatus.results[0].ActId = this.getView().getModel("appView").oData.Requestor;
			// }
			draftData.d.toStatus.results[0].ReqNum = reqID;

			if (draftData.d.toStatus.results[0].ActType === "CSI_APR" || draftData.d.toStatus.results[0].ActType === "AUTO_APPRL") {
				draftData.d.toStatus.results[0].ActType = "SUBMITTER";
			}
			draftData.d.toStatus.results[0].Status = Status;
			// draftData.d.toStatus.results[0].TimeStp = new Date();
			// draftData.d.toStatus.results[0].ActId = "";

			var tab1toAttach = this.getView().getModel().getData().toAttach;
			for (var i = 0; i < tab1toAttach.length; i++) {
				delete tab1toAttach[i].__metadata;
			}
			draftData.d.toAttach.results = tab1toAttach;

			if (type === "ChangeRequest" || type === "DuplicateExisting") {
				delete draftData.d.__metadata;
				delete draftData.d.SysId;
			}
			draftData.d.toError.results = [];
			delete draftData.d.toError.__deferred;

			for (var m = 0; m < itemDetails.length; m++) {
				delete itemDetails[m].__metadata;
				if (itemDetails[m].Vbegdat) {
					// change date from string to date field
					itemDetails[m].Vbegdat = this.onGlobalDateConversion(itemDetails[m].Vbegdat);

					// itemDetails[m].Vbegdat = new Date(itemDetails[m].Vbegdat);
				}
				if (itemDetails[m].Venddat) {
					// change date from string to date field
					itemDetails[m].Venddat = this.onGlobalDateConversion(itemDetails[m].Venddat);
					// itemDetails[m].Venddat = new Date(itemDetails[m].Venddat);
				}
				if (itemDetails[m].PrteEstrt) {
					// change date from string to date field
					itemDetails[m].PrteEstrt = this.onGlobalDateConversion(itemDetails[m].PrteEstrt);
					// itemDetails[m].PrteEstrt = new Date(itemDetails[m].PrteEstrt);
				}
				if (itemDetails[m].PrteEende) {
					// change date from string to date field
					itemDetails[m].PrteEende = this.onGlobalDateConversion(itemDetails[m].PrteEende);

					// itemDetails[m].PrteEende = new Date(itemDetails[m].PrteEende);
				}
				if (type === "DuplicateExisting") {
					itemDetails[m].Zentry_tp = ""
				}
			}
			debugger;
			draftData.d.toItem.results = itemDetails;

			var oTable = this.getView().byId("idTable");
			if (oTable.getRows().length > 1) {
				// draftData.d.toItem.results[0].PsPhido = oTable.getRows()[1].getCells()[1].getValue();
				if (itemDetails.length > 1) {

					draftData.d.toItem.results[0].PsPhido = itemDetails[1].Zposid;

				}

			}
			if (type === "OpprApp") {
				var oppData = this.getView().getModel().getProperty("/toOpprData");
				for (var i = 0; i < oppData.length; i++) {
					var oSafeCasId = oppData[i].CasesafeId;
					var oDataUp = itemDetails.filter(function (a) {
						return a.Safecase_id === oSafeCasId;
					});
					if (oDataUp.length === 0) {
						this.getView().getModel("appView").getData().oppSafeCaseid = false;
						this.getView().getModel("appView").refresh(true);
						break;
					} else {
						this.getView().getModel("appView").getData().oppSafeCaseid = true;
						this.getView().getModel("appView").refresh(true);
					}
				}

			}

			// draftData.d.toItem.results = this._fnRemoveFields(draftData.d.toItem.results); // rohit - change delete all valueState properties

			return draftData;
		},
		onFilterSelect: function (oEvent) {
			// var oBinding = this._oTable.getBinding("items"),
			this.getView().getModel("pageModel").refresh(true); // rohit - change 

			var sKey = oEvent.getParameter("key");
			var CurrTabNo = this.getView().getModel().getData().HeaderData.TabIconNo;
			/*======Tab 1 mandatory field!!!======*/
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().type;
			if (type === "View") {
				var CoCoT1 = this.getView().byId("idT1ComCode").getValue();
			} else if (type === "OpprApp") {
				var CoCoT1 = this.getView().byId("idT1ComCode").getValue();
			} else if (type === "") {
				var CoCoT1 = this.getView().byId("idT1ComCode").getSelectedKey();
				if (CoCoT1) {
					this.getView().byId("idT1ComCode").setValueState("None");
				} else {
					this.getView().byId("idT1ComCode").setValueState("Error");
				}
			} else {
				var CoCoT1 = this.getView().byId("idT1ComCode").getSelectedKey();
				if (!CoCoT1) {
					var CoCoT1 = this.getView().byId("idT1ComCode").getValue();
				}
			}

			var ProjTyT1 = this.getView().byId("idProjType").getValue();

			var ReqType = this.getView().byId("idReqType").getValue();
			var ReqTypeDtls = this.getView().byId("idReqTypeDtls").getValue();
			var ReqTypeFun = this.getView().byId("idReqTypeFun").getValue();
			var FinAnyst = this.getView().byId("idT1FinAnyst").getValue();
			var Priority = this.getView().byId("idT1Priority").getValue();
			var SubbComm = this.getView().byId("idT2SubbComm").getValue();
			var wbsType = this.getView().byId("idWBSTypeT1").getValue();

			/*======Tab 1 mandatory field!!!======*/
			var PrjDefT2 = this.getView().byId("idProjDefi").getValue();
			if (PrjDefT2.split(" ").length === 1 && PrjDefT2.length === 9) {

			} else {
				var PrjDefT2 = "";
			}
			var PrjDescT2 = this.getView().byId("idT4ProjDefDesc").getValue();
			var sDateT2 = this.getView().byId("idStartDate").getDateValue();
			var eDateT2 = this.getView().byId("idEnddate").getDateValue();
			var PerReqT2 = this.getView().byId("idT2PersResp").getValue();
			var PrjResT2 = this.getView().byId("idT2ProjRespCC").getValue();
			var BusnsAreaT2 = this.getView().byId("idT2BusnsArea").getValue();
			var PrftCenterT2 = this.getView().byId("idT2PrftCenter").getValue();

			var PrjCatT2 = this.getView().byId("idT2ProjCategory").getValue();
			var ContIDT2 = this.getView().byId("idT2ContractId").getValue();
			var ContTyT2 = this.getView().byId("idT2ContractType").getValue();
			// var LdPracSet2 = this.getView().byId("idT2LdPracSet").getValue();
			var PrjAdmT2 = this.getView().byId("idT2ProjAdmin").getValue();
			var FinAnaT2 = this.getView().byId("idT2FinAnyst").getValue();

			var ContractTrm = this.getView().byId("idT2ContractTrm").getValue();
			var ProjStatus = this.getView().byId("idT2PrjSts").getValue();

			if (sKey === "2") {
				if (CoCoT1 && ProjTyT1 && ReqType && ReqTypeDtls && ReqTypeFun && FinAnyst && Priority && SubbComm && wbsType) {
					this.getView().getModel().getData().HeaderData.TabIconNo = 2;
				} else {
					this.getView().byId("idIconTabBar").setSelectedKey("1");
					this.onValidation();
					if (CoCoT1) {
						this.getView().byId("idT1ComCode").setValueState("None");
					} else {
						this.getView().byId("idT1ComCode").setValue("");
						this.getView().byId("idT1ComCode").setValueState("Error");
					}
					MessageToast.show("Please fill all mandatory fields.");
				}

			} else if (sKey === "3" || sKey === "4") {
				if (sKey === "4") {
					var TableLength = this.getView().getModel("pageModel").getData().wbsElementStr.length;
					if (TableLength > 500) {
						sap.m.MessageToast.show("Please note this may take time for WBS Details with a large number of line items", {
							duration: 9000
						});
					}
					// var oViewModel = this.getView().getModel("appView");
					// 	var type = oViewModel.getData().type;
					// 	if (type === "OpprApp") {
					// 		this.onSelectOppAppDataTab4();
					// 	}
				}
				var RevMthdT2 = this.getView().byId("idT2RevMthd").getRequired();
				if (RevMthdT2) {
					var LdPracSetData = this.getView().byId("idT2RevMthd").getValue();
					if (LdPracSetData) {
						this.getView().byId("idT2RevMthd").setValueState("None");
					} else {
						this.getView().byId("idT2RevMthd").setValueState("Error");
					}
				} else {
					var LdPracSetData = "true";
				}

				var OppIdT2 = this.getView().byId("idT2OpporId").getRequired();
				if (OppIdT2) {
					var tab2OppID = this.getView().byId("idT2OpporId").getValue();
					if (tab2OppID) {
						this.getView().byId("idT2OpporId").setValueState("None");
					} else {
						this.getView().byId("idT2OpporId").setValueState("Error");
					}
				} else {
					this.getView().byId("idT2OpporId").setValueState("None");
					var tab2OppID = "true";
				}

				var OppIdT2 = this.getView().byId("idT2LdPracSet").getRequired();
				if (OppIdT2) {
					var LdPracSet2 = this.getView().byId("idT2LdPracSet").getValue();
					if (LdPracSet2) {
						this.getView().byId("idT2LdPracSet").setValueState("None");
					} else {
						this.getView().byId("idT2LdPracSet").setValueState("Error");
					}
				} else {
					this.getView().byId("idT2LdPracSet").setValueState("None");
					var LdPracSet2 = "true";
				}

				if (CoCoT1 && ProjTyT1 && ReqType && ReqTypeDtls && ReqTypeFun && FinAnyst && Priority && SubbComm && wbsType && LdPracSetData &&
					ContractTrm && tab2OppID && ProjStatus && PrjDefT2 && PrjDescT2 && sDateT2 && eDateT2 &&
					PerReqT2 && PrjResT2 && BusnsAreaT2 && PrftCenterT2 && PrjCatT2 && ContIDT2 && ContTyT2 && LdPracSet2 &&
					PrjAdmT2 && FinAnaT2) {
					this.getView().getModel().getData().HeaderData.TabIconNo = 3;
				} else {
					if (CoCoT1 && ProjTyT1 && ReqType && ReqTypeDtls && ReqTypeFun && FinAnyst && Priority && SubbComm && wbsType) {
						this.getView().byId("idIconTabBar").setSelectedKey("2");
					} else {
						this.getView().byId("idIconTabBar").setSelectedKey("1");
					}

					this.onValidation();
					//Added below code for adding new message for Change Project 
					// var oModel = this.getView().getModel();
					var oModel = this.getView().getModel("pageModel"); // rohit - change
					var itab = oModel.getProperty("/wbsElementStr");
					// var oItabExt = itab[0].Zentry_tp;
					var oKey = this.getView().byId("idIconTabBar").getSelectedKey();
					// if ((type === "ChangeProject" && oKey === "2") || (oItabExt === "E" && oKey === "2") || (oItabExt === "C" && oKey === "2")) {
					// 	// MessageBox.show(
					// 	// 	"Mandatory existing Project Definition fields have not been populated. \r\n Please work with Global Order Management Team to resolve in COMPASS.",
					// 	// 	sap.m.MessageBox.Icon.ERROR, "Error");

					// } else {
					MessageToast.show("Please fill all mandatory fields.");
					// }

				}
			}

		},
		// onSelectCheckBox: function (oEvent) {
		// 	var oID = oEvent.getSource().getId();
		// 	this.getView().byId(oID).setEditable(false);
		// },
		onGarbageValueservice: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			// var oInput = oView.byId(newID);
			var oInput = oEvent.getSource();
			var iRowIndex = this.onRowCountNew(oEvent);
			var oInput1 = oEvent.getSource().getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				oInput.setSelectedKey("");
				oInput.setValueState("Error");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr");
				oInput.setValue("");
				oInput.setSelectedKey("");
				wbsElement[iRowIndex].Zzsolseid = oInput1;
				oInput.setValueState("None");
			}
		},
		checkSpecialCharsTypeB: function (evt) {
			var oViewModel = this.getView().getModel("appView");
			var oAdmin = oViewModel.getData().Admin;
			var sReqType1 = this.getView().byId("idReqType").getValue();
			if (oAdmin && sReqType1 === "Business & Development Project") {
				var str = evt.getParameter("value");
				var sControlId = evt.getParameter("id");
				var s = "#";
				var s1 = "*";
				var s2 = "%";
				if (str.length >= 1) {
					if (s.indexOf(str.charAt(0)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValue(str.replace("#", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					} else {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValueStateText("None");
					}
				}
				for (var i = 0; i < str.length; i++) {
					var oNew1 = this.getView().byId(sControlId).getValue();
					if (s.indexOf(oNew1.charAt(0)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						var oNew = this.getView().byId(sControlId).getValue();
						this.getView().byId(sControlId).setValue(oNew.replace("#", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					}

					if (s1.indexOf(str.charAt(i)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValue(oNew1.replace("*", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					} else if (s2.indexOf(str.charAt(i)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValue(oNew1.replace("%", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					}
				}
			} else {
				this.onGarbageValue(evt);
			}

			// this.onSubEnable();
		},

		onGarbageValue: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				oInput.setSelectedKey("");
				// oInput.setValueState("Error");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				oInput.setValueState("None");
			}
		},
		onGarbageValueCust: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				oInput.setSelectedKey("");
				// oInput.setValueState("Error");
				oView.byId("idT2CustNme").setValue("");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				oInput.setValueState("None");
			}
		},

		validateFinAnalystChangeonTab: function (oInput) { // new validation to change financial analyst for table 

			var oModelTab = this.getView().getModel("pageModel"); // rohit - change
			var itab = oModelTab.getProperty("/wbsElementStr");
			for (var i = 0; i < itab.length; i++) {
				if (itab[i].FinApp !== oInput) { // assign the changed financial approver pernr to the table model "pageModel"

					itab[i].FinApp = oInput;

				}

			}
		},

		onGarbageValueDrop: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				oInput.setSelectedKey("");
				// oInput.setValueState("Error");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				oInput.setValueState("None");
			}
		},
		// OnClearCanType: function (oEvent) {
		// 	var sFncAnalystId = oEvent.getParameter("selectedItem").getKey();
		// },
		onChangeCanType: function (oEvent) {
			if (oEvent.getParameter("selectedItem") !== null) {
				var sSelectedItem = oEvent.getParameter("selectedItem").getAdditionalText();
				var sFncAnalystId = oEvent.getParameter("selectedItem").getKey();
				if (sSelectedItem === "1") {
					this.getView().byId("idForCastStr").setRequired(true);
					this.getView().byId("idPriority").setRequired(true);
					this.getView().byId("idAddPOC").setRequired(true);

					this.getView().byId("idCapRat").setRequired(false);
					this.getView().byId("idMarkup").setRequired(false);

					this.getView().byId("idAsstType").setRequired(true);
					this.getView().byId("idFinOpt").setRequired(true);
					this.getView().byId("idVendr").setRequired(true);
				} else if (sSelectedItem === "2") {
					this.getView().byId("idForCastStr").setRequired(false);
					this.getView().byId("idPriority").setRequired(false);
					this.getView().byId("idAddPOC").setRequired(true);

					this.getView().byId("idCapRat").setRequired(true);
					this.getView().byId("idMarkup").setRequired(true);

					this.getView().byId("idAsstType").setRequired(true);
					this.getView().byId("idFinOpt").setRequired(true);
					this.getView().byId("idVendr").setRequired(true);
				} else if (sSelectedItem === "3") {
					this.getView().byId("idAddPOC").setRequired(true);

					this.getView().byId("idForCastStr").setRequired(false);
					this.getView().byId("idPriority").setRequired(false);

					this.getView().byId("idCapRat").setRequired(false);
					this.getView().byId("idMarkup").setRequired(false);

					this.getView().byId("idAsstType").setRequired(false);
					this.getView().byId("idFinOpt").setRequired(false);
					this.getView().byId("idVendr").setRequired(false);
				} else {
					this.getView().byId("idForCastStr").setRequired(false);
					this.getView().byId("idPriority").setRequired(false);

					this.getView().byId("idCapRat").setRequired(false);
					this.getView().byId("idMarkup").setRequired(false);

					this.getView().byId("idAsstType").setRequired(false);
					this.getView().byId("idFinOpt").setRequired(false);
					this.getView().byId("idVendr").setRequired(false);
				}
			} else if (oEvent.getParameter("selectedItem") === null) {
				this.getView().byId("idForCastStr").setRequired(false);
				this.getView().byId("idAddPOC").setRequired(false);
				this.getView().byId("idPriority").setRequired(false);

				this.getView().byId("idCapRat").setRequired(false);
				this.getView().byId("idMarkup").setRequired(false);

				this.getView().byId("idAsstType").setRequired(false);
				this.getView().byId("idFinOpt").setRequired(false);
				this.getView().byId("idVendr").setRequired(false);
			}
		},
		onChangeCanType1: function (sSelectedItem) {
			// var sSelectedItem = oEvent.getParameter("selectedItem").getAdditionalText();
			// var sFncAnalystId = oEvent.getParameter("selectedItem").getKey();
			if (sSelectedItem === "1") {
				this.getView().byId("idForCastStr").setRequired(true);
				this.getView().byId("idPriority").setRequired(true);
				this.getView().byId("idAddPOC").setRequired(true);

				this.getView().byId("idCapRat").setRequired(false);
				this.getView().byId("idMarkup").setRequired(false);

				this.getView().byId("idAsstType").setRequired(true);
				this.getView().byId("idFinOpt").setRequired(true);
				this.getView().byId("idVendr").setRequired(true);
			} else if (sSelectedItem === "2") {
				this.getView().byId("idForCastStr").setRequired(false);
				this.getView().byId("idPriority").setRequired(false);
				this.getView().byId("idAddPOC").setRequired(true);

				this.getView().byId("idCapRat").setRequired(true);
				this.getView().byId("idMarkup").setRequired(true);

				this.getView().byId("idAsstType").setRequired(true);
				this.getView().byId("idFinOpt").setRequired(true);
				this.getView().byId("idVendr").setRequired(true);
			} else if (sSelectedItem === "1") {
				this.getView().byId("idAddPOC").setRequired(true);

				this.getView().byId("idForCastStr").setRequired(false);
				this.getView().byId("idPriority").setRequired(false);

				this.getView().byId("idCapRat").setRequired(false);
				this.getView().byId("idMarkup").setRequired(false);

				this.getView().byId("idAsstType").setRequired(false);
				this.getView().byId("idFinOpt").setRequired(false);
				this.getView().byId("idVendr").setRequired(false);
			} else {
				this.getView().byId("idForCastStr").setRequired(false);
				this.getView().byId("idPriority").setRequired(false);
				this.getView().byId("idAddPOC").setRequired(false);
				this.getView().byId("idCapRat").setRequired(false);
				this.getView().byId("idMarkup").setRequired(false);

				this.getView().byId("idAsstType").setRequired(false);
				this.getView().byId("idFinOpt").setRequired(false);
				this.getView().byId("idVendr").setRequired(false);
			}

		},
		onCheckWbsElement: function (oEvent) {
			var str = oEvent.getParameter("value");
		},

		onTokenUpdateL1: function (oEvent) {
			var sType = oEvent.getParameter("type");
			if (sType === "added") {
				var sKey = oEvent.getParameter("addedTokens")[0].getProperty("key");
				var oProjManager = this.getView().getModel().getProperty("/toDetails").Email;
				oProjManager.push({
					"key": sKey,
					"text": sKey
				});
			} else if (sType === "removed") { // the same did for removed 
				var sKey = oEvent.getParameter("removedTokens")[0].getProperty("key");
				var oProjManager = this.getView().getModel().getProperty("/toDetails").Email;
				oProjManager.pop({
					"key": sKey,
					"text": sKey
				});
			}
		},
		multiinputTimeTrack: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oMultiInpuidNonTrack = oView.byId(newID);
			oMultiInpuidNonTrack.setValue("");
			// var fValidator = function (args) {
			// 	var text = args.text;

			// 	return new Token({
			// 		key: text,
			// 		text: text
			// 	});
			// };
			// oMultiInpuidNonTrack.addValidator(fValidator);
		},
		newValidation: function () {

			// var oModel = this.getView().getModel();
			var aModel = this.getView().getModel("pageModel"); // rohit - change
			var oModel = this.getView().byId("idTable").getModel("pageModel"); // rohit - change
			var itab = oModel.getProperty("/wbsElementStr");
			var projType = this.getView().byId("idProjType").getSelectedKey();
			var oTable = this.getView().byId("idTable");
			var oWbsType = this.getView().byId("idWBSTypeT1").getValue();
			var oViewModel = this.getView().getModel("appView");
			var TYPE = oViewModel.getData().type;
			var oResult = true;
			/* PRJ_TYP2 === "Internal Project"*/
			// if(oTable.getRows().length !== 0){
			this.getView().byId("idIconTabBar").setSelectedKey("4");
			if (projType === "PRJ_TYP1") {
				for (var i = 0; i < itab.length; i++) {
					if (TYPE !== "ChangeProject" || itab[i].Zentry_tp !== "E" || itab[i].Zentry_tp !== "C") {
						// begin property changes - Rohit
						// if (itab[i].Zposid === "") {
						// 	var id = oTable.getRows()[i].getCells()[1].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[1].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Zposid = itab[i].Zposid;
						var sVal1 = Zposid ? "None" : "Error";
						if (sVal1 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/ZposidValueState", sVal1);

						// 	if (itab[i].Arktx === "") {
						// 	var id = oTable.getRows()[i].getCells()[2].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[2].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Arktx = itab[i].Arktx;
						var sVal2 = Arktx ? "None" : "Error";
						if (sVal2 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/ArktxValueState", sVal2);

						// if (itab[i].Bukrs === "") {
						// 	var id = oTable.getRows()[i].getCells()[6].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[6].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Bukrs = itab[i].Bukrs;
						var sVal3 = Bukrs ? "None" : "Error";
						if (sVal3 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/BukrsValueState", sVal3);

						// if (itab[i].Fkstl === "") {
						// 	var id = oTable.getRows()[i].getCells()[7].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[7].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Fkstl = itab[i].Fkstl;
						var sVal4 = Fkstl ? "None" : "Error";
						if (sVal4 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/FkstlValueState", sVal4);

						// if (itab[i].Pgsbr === "") {
						// 	var id = oTable.getRows()[i].getCells()[8].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[8].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Pgsbr = itab[i].Pgsbr;
						var sVal5 = Pgsbr ? "None" : "Error";
						if (sVal5 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PgsbrValueState", sVal5);

						// if (itab[i].Prctr === "") {
						// 	var id = oTable.getRows()[i].getCells()[9].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[9].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Prctr = itab[i].Prctr;
						var sVal6 = Prctr ? "None" : "Error";
						if (sVal6 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PrctrValueState", sVal6);

						// if (itab[i].Prart === "") {
						// 	var id = oTable.getRows()[i].getCells()[10].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[10].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Prart = itab[i].Prart;
						var sVal7 = Prart ? "None" : "Error";
						if (sVal7 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PrartValueState", sVal7);

						// if (itab[i].Zzsolseid === "") {
						// 	var id = oTable.getRows()[i].getCells()[15].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[15].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Zzsolseid = itab[i].Zzsolseid;
						var sVal8 = Zzsolseid ? "None" : "Error";
						if (sVal8 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/ZzsolseidValueState", sVal8);

						// if (itab[i].Systatusline === "") {
						// 	var id = oTable.getRows()[i].getCells()[16].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[16].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Systatusline = itab[i].Systatusline;
						var sVal9 = Systatusline ? "None" : "Error";
						if (sVal9 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/SystatuslineValueState", sVal9);

						// if (itab[i].Ustatusline === "") {
						// 	var id = oTable.getRows()[i].getCells()[17].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[17].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Ustatusline = itab[i].Ustatusline;
						var sVal10 = Ustatusline ? "None" : "Error";
						if (sVal10 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/UstatuslineValueState", sVal10);

						// if (itab[i].RaKey === "") {
						// 	var id = oTable.getRows()[i].getCells()[18].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[18].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var RaKey = itab[i].RaKey;
						var sVal11 = RaKey ? "None" : "Error";
						if (sVal11 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/RaKeyValueState", sVal11);

						// if (itab[i].PrjAd === "") {
						// 	var id = oTable.getRows()[i].getCells()[19].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[19].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }
						var PrjAd = itab[i].PrjAd;
						var sVal12 = PrjAd ? "None" : "Error";
						if (sVal12 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PrjAdValueState", sVal12);

						// if (itab[i].FinApp === "") {
						// 	var id = oTable.getRows()[i].getCells()[20].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[20].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var FinApp = itab[i].FinApp;
						var sVal13 = FinApp ? "None" : "Error";
						if (sVal13 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/FinAppValueState", sVal13);

						// if (itab[i].Wbsowner1 === "") {
						// 	var id = oTable.getRows()[i].getCells()[21].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[21].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Wbsowner1 = itab[i].Wbsowner1;
						var sVal14 = Wbsowner1 ? "None" : "Error";
						if (sVal14 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/Wbsowner1ValueState", sVal14);

						// if (itab[i].Vernr === "") {
						// 	var id = oTable.getRows()[i].getCells()[22].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[22].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }
						if (oWbsType === "C" || oWbsType === "L" || oWbsType === "B" || oWbsType === "M") {
							if (itab[i].Zzproj_Phase_Cd === "" || itab[i].Zzproj_Phase_Cd === undefined) {
								// 	var id = oTable.getRows()[i].getCells()[23].getId();
								// 	this.getView().byId(id).setValueState("Error");
								// 	oResult = false;
								// } else {
								// 	var id = oTable.getRows()[i].getCells()[23].getId();
								// 	this.getView().byId(id).setValueState("None");
								// }

								var ZzprojPhaseCd = itab[i].Zzproj_Phase_Cd;
								var sVal15 = ZzprojPhaseCd ? "None" : "Error";
								if (sVal15 === "Error") {
									oResult = false;
								}
								aModel.setProperty("/wbsElementStr/" + i + "/ZzprojPhaseCdValueState", sVal15);

							}

							// if (itab[i].Stufe !== "" && itab[i].Zposid !== "" && itab[i].Arktx !== "" && itab[i].Bukrs !== "" &&
							// 	itab[i].Fkstl !== "" && itab[i].Pgsbr !== "" && itab[i].Prctr !== "" && itab[i].Prart !== "" &&
							// 	itab[i].Zzsolseid !== "" && itab[i].Systatusline !== "" && itab[i].Ustatusline !== "" && itab[i].RaKey !== "" && itab[i].PrjAd !==
							// 	"" && itab[i].FinApp !== "" && itab[i].Wbsowner1 !== "" && itab[i].Vernr !== "" && itab[i].Zzproj_Phase_Cd !== "" && itab[i].Zzproj_Phase_Cd !==
							// 	undefined) {

							// } else {
							// 	return false;
							// 	MessageToast.show("Please complete all the mandatory fields in the WBS Details screen.");
							// }
						}

					}
				}

			} else if (projType === "PRJ_TYP2") {
				for (var i = 0; i < itab.length; i++) {
					if (TYPE !== "ChangeProject" || itab[i].Zentry_tp !== "E" || itab[i].Zentry_tp !== "C") {
						// if (itab[i].Zposid === "") {
						// 	var id = oTable.getRows()[i].getCells()[1].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[1].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }
						var Zposid1 = itab[i].Zposid;
						var sVal16 = Zposid1 ? "None" : "Error";
						if (sVal16 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/ZposidValueState", sVal16);

						var Arktx1 = itab[i].Arktx;
						var sVal17 = Arktx1 ? "None" : "Error";
						if (sVal17 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/ArktxValueState", sVal17);

						// if (itab[i].Bukrs === "") {
						// 	var id = oTable.getRows()[i].getCells()[6].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[6].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Bukrs1 = itab[i].Bukrs;
						var sVal18 = Bukrs1 ? "None" : "Error";
						if (sVal18 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/BukrsValueState", sVal18);

						// if (itab[i].Fkstl === "") {
						// 	var id = oTable.getRows()[i].getCells()[7].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[7].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Fkstl1 = itab[i].Fkstl;
						var sVal19 = Fkstl1 ? "None" : "Error";
						if (sVal19 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/FkstlValueState", sVal19);

						// if (itab[i].Pgsbr === "") {
						// 	var id = oTable.getRows()[i].getCells()[8].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[8].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Pgsbr1 = itab[i].Pgsbr;
						var sVal20 = Pgsbr1 ? "None" : "Error";
						if (sVal20 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PgsbrValueState", sVal20);

						// if (itab[i].Prctr === "") {
						// 	var id = oTable.getRows()[i].getCells()[9].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[9].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Prctr1 = itab[i].Prctr;
						var sVal21 = Prctr1 ? "None" : "Error";
						if (sVal21 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PrctrValueState", sVal21);

						// if (itab[i].Prart === "") {
						// 	var id = oTable.getRows()[i].getCells()[10].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[10].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Prart1 = itab[i].Prart;
						var sVal22 = Prart1 ? "None" : "Error";
						if (sVal22 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PrartValueState", sVal22);

						// if (itab[i].Systatusline === "") {
						// 	var id = oTable.getRows()[i].getCells()[15].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[15].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Systatusline1 = itab[i].Systatusline;
						var sVal23 = Systatusline1 ? "None" : "Error";
						if (sVal23 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/SystatuslineValueState", sVal23);

						// if (itab[i].Ustatusline === "") {
						// 	var id = oTable.getRows()[i].getCells()[16].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[16].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Ustatusline1 = itab[i].Ustatusline;
						var sVal24 = Ustatusline1 ? "None" : "Error";
						if (sVal24 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/UstatuslineValueState", sVal24);

						// if (itab[i].RaKey === "") {
						// 	var id = oTable.getRows()[i].getCells()[17].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[17].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var RaKey1 = itab[i].RaKey;
						var sVal25 = RaKey1 ? "None" : "Error";
						if (sVal25 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/RaKeyValueState", sVal25);

						// if (itab[i].PrjAd === "") {
						// 	var id = oTable.getRows()[i].getCells()[18].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[18].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var PrjAd1 = itab[i].PrjAd;
						var sVal26 = PrjAd1 ? "None" : "Error";
						if (sVal26 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/PrjAdValueState", sVal26);

						// if (itab[i].FinApp === "") {
						// 	var id = oTable.getRows()[i].getCells()[19].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[19].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var FinApp1 = itab[i].FinApp;
						var sVal27 = FinApp1 ? "None" : "Error";
						if (sVal27 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/FinAppValueState", sVal27);

						// if (itab[i].Wbsowner1 === "") {
						// 	var id = oTable.getRows()[i].getCells()[20].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[20].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }

						var Wbsowner11 = itab[i].Wbsowner1;
						var sVal28 = Wbsowner11 ? "None" : "Error";
						if (sVal28 === "Error") {
							oResult = false;
						}
						aModel.setProperty("/wbsElementStr/" + i + "/Wbsowner1ValueState", sVal28);

						// if (itab[i].Vernr === "") {
						// 	var id = oTable.getRows()[i].getCells()[21].getId();
						// 	this.getView().byId(id).setValueState("Error");
						// 	oResult = false;
						// } else {
						// 	var id = oTable.getRows()[i].getCells()[21].getId();
						// 	this.getView().byId(id).setValueState("None");
						// }
						var oViewModel = this.getView().getModel("appView");
						var oSpanProj = oViewModel.getData().oSpanProj;
						if (oSpanProj === "YES") {
							var Zzproj_Phase_Cd1 = itab[i].Zzproj_Phase_Cd;
							var sVal29 = Zzproj_Phase_Cd1 ? "None" : "Error";
							if (sVal29 === "Error") {
								oResult = false;
							}
							aModel.setProperty("/wbsElementStr/" + i + "/ZzprojPhaseCdValueState", sVal29);

							var Zzsolseid = itab[i].Zzsolseid;
							var sVal8 = Zzsolseid ? "None" : "Error";
							if (sVal8 === "Error") {
								oResult = false;
							}
							aModel.setProperty("/wbsElementStr/" + i + "/ZzsolseidValueState", sVal8);
						}
						if (oWbsType === "C" || oWbsType === "L" || oWbsType === "B" || oWbsType === "M") {
							// if (itab[i].Zzproj_Phase_Cd === "" || itab[i].Zzproj_Phase_Cd === undefined) {
							// 	var id = oTable.getRows()[i].getCells()[22].getId();
							// 	this.getView().byId(id).setValueState("Error");
							// 	oResult = false;
							// } else {
							// 	var id = oTable.getRows()[i].getCells()[22].getId();
							// 	this.getView().byId(id).setValueState("None");
							// }

							var Zzproj_Phase_Cd1 = itab[i].Zzproj_Phase_Cd;
							var sVal29 = Zzproj_Phase_Cd1 ? "None" : "Error";
							if (sVal29 === "Error") {
								oResult = false;
							}
							aModel.setProperty("/wbsElementStr/" + i + "/ZzprojPhaseCdValueState", sVal29);

						}

						// if (itab[i].Stufe !== "" && itab[i].Zposid !== "" && itab[i].Arktx !== "" && itab[i].Bukrs !== "" &&
						// 	itab[i].Fkstl !== "" && itab[i].Pgsbr !== "" && itab[i].Prctr !== "" && itab[i].Prart !== "" &&
						// 	itab[i].Systatusline !== "" && itab[i].Ustatusline !== "" && itab[i].RaKey !== "" && itab[i].PrjAd !==
						// 	"" && itab[i].FinApp !== "" && itab[i].Wbsowner1 !== "" && itab[i].Vernr !== "" && itab[i].Zzproj_Phase_Cd !== "" && itab[i].Zzproj_Phase_Cd !==
						// 	undefined) {

						// } else {
						// 	return false;
						// 	MessageToast.show("Please complete all the mandatory fields in the WBS Details screen.");
						// }
					}
				}
			}
			// }else{
			this.getView().byId("idIconTabBar").setSelectedKey("4");
			// 	MessageBox.show("Please check the WBS Details before the validate and submit.");
			// }

			return oResult; // rohit - change

		},

		onCancel: function (oEvent) {
			var oDailog = oEvent.getSource().getParent();
			oDailog.close();
			sap.ui.core.BusyIndicator.hide(); //UAT NCR - 341763
			oDailog.destroy();
		},

		/*IWO File Upload and Download*/
		// onUploadFileWBS: function () {
		// 	var oView = this.getView();
		// 	var oDialog = oView.byId("idDialog");
		// 	// create dialog lazily
		// 	if (!oDialog) {
		// 		// create dialog via fragment factory
		// 		oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.uploadFileWBS", this);
		// 		// connect dialog to view (models, lifecycle)
		// 		oView.addDependent(oDialog);
		// 	}
		// 	oDialog.open();

		// },
		onFileAction: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			switch (oItem.data("action")) {
			case "Download":
				this._downloadFileDialog(oEvent);
				break;
			case "DownloadRvw": //  Added for Phase3  -  Review - Download button
				this._downloadFileDialogReview(oEvent);
				break;
			case "Upload":
				this._uploadFileDialog();
				break;
			case "Attachment":
				this.handleAttachment();
				break;
			}
		},
		_downloadFileDialog: function (oEvent) {
			var oOrgModel = this.getOwnerComponent().getModel("oDataModelMng");
			var oModel = new sap.ui.model.odata.ODataModel(oOrgModel.sServiceUrl);
			// var Iwo = this.getView().getModel("appView").getData().iwoNo;
			// oModel.read("/IWOFileUploadSet(Uploadid='" + Iwo + "')/$value", {
			var oViewModel = this.getView().getModel("appView");
			var oType = oViewModel.getData().type;
			if (oType === "ChangeProject") {
				var Projectid = this.getView().byId("idProjDefi").getValue();
				if (Projectid) {
					var ReqNo = "";
					oModel.read("/WBSExcelDownloadSet(Zpspid='" + Projectid + "',ReqNo='" + ReqNo + "')/$value", {
						success: function (oData, response) {
							var file = response.requestUri;
							window.open(file);
						},
						error: function (oErr) {
							// console.error("error");
							// MessageBox.error(JSON.parse(oErr.responseText).error.innererror.errordetails[0].message);
							MessageBox.show("Unable to download", sap.m.MessageBox.Icon.ERROR, "Error");
						}
					});

				} else {
					MessageBox.show("Project ID is mandatory", sap.m.MessageBox.Icon.ERROR, "Error");
				}

			} else if (oType === "ChangeRequest" || oType === "View") {
				var oReq = oViewModel.getData().Requestid;
				var Projid = "";
				oModel.read("/WBSExcelDownloadSet(Zpspid='" + Projid + "',ReqNo='" + oReq + "')/$value", {
					success: function (oData, response) {
						var file = response.requestUri;
						window.open(file);
					},
					error: function (oErr) {
						// console.error("error");
						// MessageBox.error(JSON.parse(oErr.responseText).error.innererror.errordetails[0].message);
						MessageBox.show("Unable to download", sap.m.MessageBox.Icon.ERROR, "Error");
					}
				});
			}

		},
		_uploadFileDialog: function () {
			var oView = this.getView();
			var oDialog = oView.byId("idUploadDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.uploadFile", this);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
		},

		onUploadComplete: function (oEvent) {
			// var that = this;
			// var oResponse = "GB1-RGB2";
			// Begin of changes for Phase3 Srini  Vallepu
			var oResult = JSON.parse(oEvent.getParameter("responseRaw"));
			if (oResult.error) {
				this.getView().setBusy(false);
				sap.ui.core.BusyIndicator.hide();
				var oDailogUpload = this.getView().byId("idUploadDialog");
				oDailogUpload.close();
				oDailogUpload.destroy();
				MessageBox.error(oResult.error.message.value);
			} else {
				var that = this;
				var oResponse = JSON.parse(oEvent.getParameter("responseRaw"));
				var x = oResponse.d.ProjDef.toUpperCase();
				var oModel = this.getView().getModel("oDataModel");
				// oModel.read("/WBSExcel_UploadSet(Pspid='" + oResponse + "')", {
				oModel.read("/WBSExcel_UploadSet(Pspid='" + x + "')", {
					urlParameters: {
						"$expand": "toDetails,toItem,toExcelError"
					},
					success: function (oResponse) {
						var oViewModelUpload = that.getView().getModel("appView");
						var oUploadFlag = oViewModelUpload.getData().uploadFlag;
						if (oUploadFlag === "X" && (oResponse.toItem.results[0].Zentry_tp === "" || oResponse.toItem.results[0].Zentry_tp === "N")) {
							var oMsg = "Please use New Project/WBS App when uploading new project/WBS";
						} else if (oUploadFlag === "" && (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp ===
								"C")) {
							// var oMsg = "Please use Manage App when uploading changes to existing project/WBS";
							var oMsg =
								"Project Definition (Project ID) had been used/its for an existing Project/WBS, please regenerate your upload template using a new Project Definition (Project ID) for New Project Creation Request"
						}
						if (oMsg) {
							that.getView().setBusy(false);
							sap.ui.core.BusyIndicator.hide();
							var oDailogUpload = that.getView().byId("idUploadDialog");
							oDailogUpload.close();
							oDailogUpload.destroy();
							MessageBox.error(oMsg);
						} else {

							var oViewModel = that.getView().getModel("appView");
							oViewModel.getData().sys_orign = oResponse.Des_sys;
							oViewModel.getData().type = "uploadProject";
							oViewModel.getData().fixedWBSEle = oResponse.ProjDef; //Mayank: Added for change wbs element.
							that.getView().getModel("appView").refresh(true);

							var obj = that.getView().getModel().getData();

							obj.toDetails.ProjTyp = oResponse.toItem.results[0].Prart;
							that.getView().byId("idProjType").setValue(obj.toDetails.ProjTyp);
							if (obj.toDetails.ProjTyp === "C" || obj.toDetails.ProjTyp === "L") {
								obj.toDetails.ProjTyp = "PRJ_TYP1";
								var oProjectBox = that.getView().byId("idT2ContractType");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
									],
									and: true
								});
								// aFilters.push(oFilters);
								oBindingBox.filter(aFilters);

								var oBindingBoxT2 = that.getView().byId("idT2LdPracSet").getBinding("items");
								var aFiltersT2 = [];
								var oFiltersT2 = new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.NE, "BLANK");
								aFiltersT2.push(oFiltersT2);
								oBindingBoxT2.filter(aFiltersT2);

								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								var aFiltersT3 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
									],
									and: false
								});
								oBindingBoxT3.filter(aFiltersT3);

								var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
								if (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp === "C") {
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
											// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ2"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ3"),
										],
										and: false
									});

								} else {
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
											// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ2"),
											// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ3"),
										],
										and: false
									});

								}
								oBindingBoxT4.filter(aFiltersT4);
								var oProjectBox = that.getView().byId("idReqTypeDtls");
								var oBindingBox = oProjectBox.getBinding("items");
								var sSelectTRade = oResponse.toDetails.results[0].ReasReq;
								if (sSelectTRade === "WBS Add/Change including CAN") {
									var aFiltersTRade = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "WBS Add/Change including CAN")
										],
										and: false
									});

								} else if (sSelectTRade === "WBS Add/Change without CAN") {
									var aFiltersTRade = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "WBS Add/Change without CAN")
										],
										and: false
									});

								}

								// aFilters.push(oFilters);
								oBindingBox.filter(aFiltersTRade);

								that.getView().byId("idT2LdPracSet").setRequired(true);
								that.getView().byId("idT2LdPracSet").setEditable(true);
								that.getView().byId("idT2RevMthd").setRequired(true);
								that.getView().byId("idT2OpporId").setRequired(true);
								that.getView().byId("idT2ProjCategory").setEditable(false);

								if (oResponse.Zpgid !== "0040008064" && oResponse.Zpgid !== "0040008063") {

									obj.draftData.d.Zpgid = oResponse.Zpgid;
									obj.draftData.d.Zkunnr = oResponse.Zkunnr;
									obj.draftData.d.Zzsoarincd = oResponse.Zzsoarincd;

								}

								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().projType = "Trade";
								that.getView().getModel("appView").refresh(true);

							} else {
								obj.toDetails.ProjTyp = "PRJ_TYP2";
								var oViewModel = that.getView().getModel("appView");
								var oAdmin = oViewModel.getData().Admin;
								// Phase3  UAT issue .
								//that.getView().byId("idProjType").setEditable(false);
								//that.getView().byId("idProjType").setEnabled(false);
								if (oAdmin === true && oResponse.toItem.results[0].Prart === "B") {
									that.getView().byId("idT2OpporId").setRequired(true);
									that.getView().byId("idT2OpporId").setEditable(true);
									that.getView().byId("idT2LdPracSet").setEditable(true);
									that.getView().byId("idT2LdPracSet").setRequired(true);
									if (oResponse.Zzldpcid === "") {
										that.getView().byId("idT2LdPracSet").setValue("HQCEX");
										that.getView().byId("idT2LdPracSet").setSelectedKey("HQCEX");
									}
									that.getView().byId("idReqType").setValue("Business & Development Project");
									that.getView().byId("idReqType").setSelectedKey("REAS_REQ7");
									that.getView().byId("idReqType").setEditable(false);

									oViewModel.getData().oppAdmin = true;

									var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
									var aFiltersT3 = new sap.ui.model.Filter({
										//Phase3 UAT  Defect #342140
										// filters: [
										// 	new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
										// ],
										// and: true
										filters: [
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "B")
										],
										and: false
											// End of  Defect #342140
									});
									oBindingBoxT3.filter(aFiltersT3);

									var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
											// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
										],
										and: false
									});
									oBindingBoxT4.filter(aFiltersT4);

									var oProjectBox = that.getView().byId("idReqTypeDtls");
									var oBindingBox = oProjectBox.getBinding("items");
									var aFilters5 = [];
									// Begin of Defect #342140
									// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Business & Development Project");
									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET26");
									// End of Defect #342140
									aFilters5.push(oFilters);
									oBindingBox.filter(aFilters5);

								} else {
									that.getView().byId("idT2OpporId").setRequired(false);
									that.getView().byId("idT2OpporId").setEditable(false);
									that.getView().byId("idT2LdPracSet").setEditable(false);
									that.getView().byId("idT2LdPracSet").setRequired(false);
									oViewModel.getData().oppAdmin = false;

									var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5")
										],
										and: false
									});
									oBindingBoxT4.filter(aFiltersT4);
								}

								var oProjectBox = that.getView().byId("idT2ContractType");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = [];
								var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
								aFilters.push(oFilters);
								oBindingBox.filter(aFilters);

								that.getView().byId("idT2ProjCategory").setEditable(false);
								that.getView().byId("idT2ContractType").setEditable(false);
								// that.getView().byId("idT2LdPracSet").setEditable(false);
								// that.getView().byId("idT2LdPracSet").setValue("");
								// that.getView().byId("idT2LdPracSet").setSelectedKey("");
								// that.getView().byId("idT2LdPracSet").setRequired(false);

								that.getView().byId("idT2RevMthd").setEditable(false);
								that.getView().byId("idT2RevMthd").setRequired(false);
								that.getView().byId("idT2RevMthd").setValue("TE");
								// that.getView().byId("idT2OpporId").setRequired(false);

								// var PrartTyp1 = "0040008063";
								// var PrartTyp2 = "0040008064";
								if (oAdmin === true && oResponse.toItem.results[0].Prart === "B" && oResponse.Zpgid !== "0040008063") {
									obj.draftData.d.Zpgid = oResponse.Zpgid;
									obj.draftData.d.Zkunnr = oResponse.Zkunnr;
									obj.draftData.d.Zzsoarincd = oResponse.Zzsoarincd;
								} else if (oResponse.toItem.results[0].Prart !== "B") {
									if (oResponse.Zpgid === "0040008064" || oResponse.Zpgid === "0040008063") {
										obj.draftData.d.Zpgid = oResponse.Zpgid;
										obj.draftData.d.Zkunnr = oResponse.Zkunnr;
										obj.draftData.d.Zzsoarincd = oResponse.Zzsoarincd;
									}
								}

								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().projType = "Internal";
								that.getView().getModel("appView").refresh(true);

							}

							var sSelect = oResponse.toDetails.results[0].ReasReq;
							if (sSelect === "Standard Internal Project(Non-Funded)") {
								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								var aFiltersT3 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "E"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "M"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "O"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "W")
									],
									and: false
								});
								oBindingBoxT3.filter(aFiltersT3);

								var oProjectBox = that.getView().byId("idReqTypeDtls");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = [];
								if (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp === "C") {
									that.getView().byId("idReqType").setValue("Standard Internal Project(Non-Funded)");
									that.getView().byId("idReqType").setSelectedKey("Standard Internal Project(Non-Funded)");
									that.getView().byId("idReqType").setEditable(false);

									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20");
								} else {
									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET19");
								}

								aFilters.push(oFilters);
								oBindingBox.filter(aFilters);

								// var oProjectBox = that.getView().byId("idReqTypeDtls");
								// var oBindingBox = oProjectBox.getBinding("items");
								// var aFilters = [];
								// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Standard Internal Project(Funded)");
								// aFilters.push(oFilters);
								// oBindingBox.filter(aFilters);

							} else if (sSelect === "Standard Internal Project(Funded)") {
								// Begin of Defect = CR ID 342149
								// var oIntrnlComCode = oResponse.toDetails.results[0].Zbukrs;
								var oIntrnlComCode = oResponse.Zbukrs;
								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								if (oIntrnlComCode === "JP00") {
									var aFiltersT3 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "D"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
										],
										and: false
									});

								} else {
									var aFiltersT3 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
										],
										and: false
									});

								}
								// End of Defect = CR ID 342149
								oBindingBoxT3.filter(aFiltersT3);

								var oProjectBox = that.getView().byId("idReqTypeDtls");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = [];

								if (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp === "C") {
									that.getView().byId("idReqType").setValue("Standard Internal Project(Funded)");
									that.getView().byId("idReqType").setSelectedKey("Standard Internal Project(Funded)");
									that.getView().byId("idReqType").setEditable(false);
									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET23");
								} else {
									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET22");
								}
								aFilters.push(oFilters);
								oBindingBox.filter(aFilters);

								// var oProjectBox = that.getView().byId("idReqTypeDtls");
								// var oBindingBox = oProjectBox.getBinding("items");
								// var aFilters = [];
								// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Standard Internal Project(Non-Funded)");
								// aFilters.push(oFilters);
								// oBindingBox.filter(aFilters);

							} else if (sSelect === "Spanish Delivery Project") {
								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								var aFiltersT3 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J")
									],
									and: false
								});
								oBindingBoxT3.filter(aFiltersT3);

								var oProjectBox = that.getView().byId("idReqTypeDtls");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = [];
								if (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp === "C") {
									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET30");
								} else {
									var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET29");
								}
								aFilters.push(oFilters);
								oBindingBox.filter(aFilters);

								that.getView().byId("idT2OpporId").setRequired(true);
								that.getView().byId("idLblOpp").setRequired(true);
								that.getView().byId("idT2LdPracSet").setEditable(true);
								that.getView().byId("idT2LdPracSet").setRequired(true);
								// that.getView().byId("idT2RevMthd").setRequired(true);

								var oProjectBox = that.getView().byId("idT2ContractType");
								var oBindingBox = oProjectBox.getBinding("items");
								var aFilters = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
									],
									and: true
								});
								// aFilters.push(oFilters);
								oBindingBox.filter(aFilters);
								// var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
								// var aFiltersT4 = new sap.ui.model.Filter({
								// 	filters: [
								// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
								// 	],
								// 	and: false
								// });

								// oBindingBoxT4.filter(aFiltersT4);
								that.getView().byId("idReqType").setValue("Spanish Delivery Project");
								that.getView().byId("idReqType").setSelectedKey("Spanish Delivery Project");
								that.getView().byId("idReqType").setEditable(false);
								oViewModel.getData().projType = "Trade";
								oViewModel.getData().oSpanProj = "YES";
								that.getView().getModel("appView").refresh(true);

							}

							// obj.toDetails.ProjTyp = oResponse.results[0].toDetails.results[0].ProjTyp;
							// obj.toDetails.ReqFun = oResponse.results[0].toDetails.results[0].ReqFun;
							that.getView().byId("idT1ComCode").setSelectedKey(oResponse.Zbukrs);
							obj.toDetails.Zbukrs = oResponse.Zbukrs;
							obj.toDetails.ReasReq = oResponse.toDetails.results[0].ReasReq;
							that.onSelectReqTypeCrossApp(oResponse.toDetails.results[0].ReasReq);
							that.getView().byId("idReqType").setValue(oResponse.toDetails.results[0].ReasReq);

							var sSelect = oResponse.toDetails.results[0].ReqDetail;
							that.onDisplayPriority(sSelect);
							obj.toDetails.ReqDet = oResponse.toDetails.results[0].ReqDetail;
							that.getView().byId("idReqTypeDtls").setValue(oResponse.toDetails.results[0].ReqDetail);
							obj.draftData.d.Wbs_type = oResponse.toDetails.results[0].WbsType;

							// that.getView().byId("idReqTypeFun").setValue(oResponse.toDetails.results[0].ReqFun);
							if (oResponse.toDetails.results[0].ReqFun === "Finance Analyst") {
								obj.toDetails.ReqFun = "REQ_FUN1";
								that.getView().byId("idReqTypeFun").setSelectedKey("REQ_FUN1");
							} else if (oResponse.toDetails.results[0].ReqFun === "Business Account Manager") {
								obj.toDetails.ReqFun = "REQ_FUN2";
								that.getView().byId("idReqTypeFun").setSelectedKey("REQ_FUN2");
							} else if (oResponse.toDetails.results[0].ReqFun === "Project Manager") {
								obj.toDetails.ReqFun = "REQ_FUN3";
								that.getView().byId("idReqTypeFun").setSelectedKey("REQ_FUN3");
							} else if (oResponse.toDetails.results[0].ReqFun === "GSO-Backoffice Services") {
								obj.toDetails.ReqFun = "REQ_FUN4";
								that.getView().byId("idReqTypeFun").setSelectedKey("REQ_FUN4");
							} else {
								// that.getView().byId("idReqTypeFun").setSelectedKey("");
								obj.toDetails.ReqFun = "";
							}
							// that.getView().byId("idReqTypeFun").setSelectedKey(oResponse.toDetails.results[0].ReqFun);
							// obj.toDetails.ReqFun = that.getView().byId("idReqTypeFun").getSelectedKey();
							that.getView().byId("idProjType").setSelectedKey(obj.toDetails.ProjTyp);

							// that.getView().byId("idProjType").setValue(oResponse.results[0].toDetails.results[0].ProjTyp);

							// obj.toDetails.FinApp = oResponse.results[0].toDetails.results[0].FinAnalId;
							obj.toDetails.FinApp = oResponse.FinApp;
							// that.getView().byId("idT1FinAnyst").setProperty("selectedKey",oResponse.results[0].toDetails.results[0].FinAnalId);
							// obj.toDetails.Priority = oResponse.toDetails.results[0].Prty;
							// obj.toDetails.Email = oResponse.toDetails.results[0].FinEmail;

							var oEmail = oResponse.toDetails.results[0].FinEmail;
							var aLen = oEmail.length;
							if (aLen != 0) {
								var data = oEmail.split(",");
								var tokenValue = [];
								for (var i = 0; i < data.length; i++) {
									tokenValue.push(new Token({
										text: data[i],
										key: data[i]
									}));
								}
								var oMultiInput1 = that.getView().byId("idT1Email");
								oMultiInput1.setTokens(tokenValue);
							}

							obj.toDetails.Req_com = oResponse.toDetails.results[0].Comments;
							//obj.draftData.d.toItem.results = oResponse.results[0].toItem.results ; 

							//**************************TAB 2 Data Autopopulating*************************************
							// obj.draftData.d.Zpspid = oResponse.results[0].toItem.results[0].ProjDef;

							that.getView().byId("idProjDefi").setValue(oResponse.toItem.results[0].ProjDef);
							obj.draftData.d.Ktext = oResponse.Post1;
							obj.draftData.d.Zbukrs = oResponse.Zbukrs;
							// obj.draftData.d.Guebg = oResponse.Plfaz;
							obj.draftData.d.Guebg = that.StringToDate(oResponse.Plfaz);
							// obj.draftData.d.Gueen = oResponse.Plsez;
							obj.draftData.d.Gueen = that.StringToDate(oResponse.Plsez);
							obj.draftData.d.Vernr = oResponse.Vernr;
							// that.getView().byId("idT2PersResp").setProperty("selectedKey",oResponse.results[0].Vernr);
							obj.draftData.d.Kostl = oResponse.Kostl;
							// that.getView().byId("idT2ProjRespCC").setProperty("selectedKey",oResponse.results[0].Zzlfplenid);
							obj.draftData.d.Vgsbr = oResponse.Vgsbr;

							obj.draftData.d.Prctr = oResponse.Prctr;
							obj.draftData.d.Zpjcgid = oResponse.Zpjcgid;
							// obj.draftData.d.Zpgid = oResponse.Zpgid;
							// that.onSelectWbsType(oResponse.Zpgid);
							// that.getView().byId("idT2ContractId").setProperty("selectedKey",oResponse.results[0].Zpgid);
							// obj.draftData.d.Zkunnr = oResponse.Zkunnr;
							// obj.draftData.d.Zzsoarincd = oResponse.Zzsoarincd;
							obj.draftData.d.ZzContracttype = oResponse.ZzContracttype;
							// that.getView().byId("idT2ContractType").setProperty("selectedKey",oResponse.results[0].ZzContracttype);
							obj.draftData.d.Soldto = oResponse.Zzcuno;
							obj.draftData.d.Zzoycunm = oResponse.Zzoycunm;
							obj.draftData.d.Zzldpcid = oResponse.Zzldpcid;
							obj.draftData.d.PrjAd = oResponse.PrjAd;
							// that.getView().byId("idT2ProjAdmin").setProperty("selectedKey",oResponse.results[0].PrjAd);
							obj.draftData.d.FinApp = oResponse.FinApp;
							obj.draftData.d.Agm = oResponse.ZzoptyMgrResid;
							// that.getView().byId("idT2ActMngr").setProperty("selectedKey",oResponse.results[0].Agm);
							obj.draftData.d.Zzpjsgst = oResponse.Zzpjsgst;
							obj.draftData.d.Zzrvrgmdcd = oResponse.Zzrvrgmdcd;
							obj.draftData.d.Zzcntrcd = oResponse.Zzcntrcd;
							obj.draftData.d.Zzsiebelid = oResponse.Zzsiebelid;
							obj.draftData.d.Zzpgid = oResponse.Zzprogram;
							obj.draftData.d.ZzGlblProj = oResponse.ZzGlblProj;
							obj.draftData.d.ZzEvExtract = oResponse.ZzEvExtract;
							// ******************setting the selected key*************

							// draftData.d.toDetails.results[0].ProjTyp = that.getView().byId("idProjType").getSelectedKey();
							that.getView().byId("idReqType").setSelectedKey(oResponse.toDetails.results[0].ReasReq);
							that.getView().byId("idReqTypeDtls").setSelectedKey(oResponse.toDetails.results[0].ReqDetail);
							// that.getView().byId("idReqTypeFun").setSelectedKey(oResponse.toDetails.results[0].ReqFun);
							// that.getView().byId("idT1FinAnyst").setSelectedKey(oResponse.FinApp);

							// that.getView().byId("idT2PersResp").setSelectedKey(oResponse.Vernr);
							// that.getView().byId("idT2ProjRespCC").setSelectedKey(oResponse.Kostl);
							// that.getView().byId("idT2ProjAdmin").setSelectedKey(oResponse.results[0].PrjAd);
							// that.getView().byId("idT2ProjAdmin").setProperty("selectedKey", oResponse.PrjAd);
							// that.getView().byId("idT2FinAnyst").setSelectedKey(oResponse.FinApp);
							// that.getView().byId("idT2ActMngr").setSelectedKey(oResponse.ZzoptyMgrResid);

							// that.getView().byId("idT2ContractId").setSelectedKey(oResponse.Zpgid);
							that.getView().byId("idT2ContractType").setSelectedKey(oResponse.ZzContracttype);
							that.getView().byId("idT2LdPracSet").setSelectedKey(oResponse.Zzldpcid);
							// that.getView().byId("idT2PersResp").setSelectedKey(oResponse.Vernr);
							that.getView().byId("idT2PrjSts").setSelectedKey(oResponse.Zzpjsgst);
							that.getView().byId("idT2RevMthd").setSelectedKey(oResponse.Zzrvrgmdcd);
							that.getView().byId("idT2ContractTrm").setSelectedKey(oResponse.Zzcntrcd);
							that.getView().byId("idT2Program").setSelectedKey(oResponse.Zzprogram);
							// that.getView().byId("idT2OpporId").setSelectedKey(oResponse.Zzsiebelid);

							// ******************TAB 3 Auto Populate***********
							// if(obj.wbsElementStr.length)
							// Phase3  UAT issue .
							//that.getView().byId("idProjType").setEditable(false);
							var obj1 = [];
							// that.getView().byId("idTable").setVisibleRowCount(oResponse.toItem.results.length);
							that.getView().byId("idTable").setVisibleRowCount(8); // rohit -change
							for (var i = 0; i < oResponse.toItem.results.length; i++) {

								obj1.push({
									"Stufe": oResponse.toItem.results[i].Stufe,
									"Zpspid": oResponse.toItem.results[i].ProjDef,
									"Zposid": oResponse.toItem.results[i].Zposid,
									"Arktx": oResponse.toItem.results[i].Arktx,
									"Plakz_bool": oResponse.toItem.results[i].Plakz_bool,
									"Belkz_bool": oResponse.toItem.results[i].Belkz_bool,
									"Fakkz_bool": oResponse.toItem.results[i].Fakkz_bool,
									"Bukrs": oResponse.toItem.results[i].Bukrs,
									"Fkstl": oResponse.toItem.results[i].Fkstl,
									"Pgsbr": oResponse.toItem.results[i].Pgsbr,
									"Prctr": oResponse.toItem.results[i].Prctr,
									"Prart": oResponse.toItem.results[i].Prart,
									"ZsfdcOppid": oResponse.toItem.results[i].ZsfdcOppid,
									"Safecase_id": oResponse.toItem.results[i].Casesafe_id,
									"Sol_typ": oResponse.toItem.results[i].Sol_typ,
									"Cont_modl": oResponse.toItem.results[i].Cont_modl,
									"Zzsolseid": oResponse.toItem.results[i].Zzsolseid,
									"Systatusline": oResponse.toItem.results[i].Systatusline,
									"Ustatusline": oResponse.toItem.results[i].Ustatusline,
									"RaKey": oResponse.toItem.results[i].RaKey,
									"PrjAd": oResponse.toItem.results[i].PrjAd,
									"FinApp": oResponse.toItem.results[i].FinApp,
									"Wbsowner1": oResponse.toItem.results[i].Wbsowner1,
									"Vernr": oResponse.toItem.results[i].ZzvernrDelegate,
									"Zzproj_Phase_Cd": oResponse.toItem.results[i].Zzproj_Phase_Cd,
									"PrteEstrt": oResponse.toItem.results[i].Pstrt,
									"PrteEende": oResponse.toItem.results[i].Pende,
									"Zzriskind_bool": oResponse.toItem.results[i].Zzriskind_bool,
									"Zcats": oResponse.toItem.results[i].Zcats,
									"ZzPlanWaers": oResponse.toItem.results[i].ZzPlanWaers,
									"ZzUsr01": oResponse.toItem.results[i].ZzUsr01,
									"ZzUsr02": oResponse.toItem.results[i].ZzUsr02,
									"ZzUsr03": oResponse.toItem.results[i].ZzUsr03,
									"ZzTaskOrder": oResponse.toItem.results[i].ZzTaskorderT,
									"ZzGovCtrtype": oResponse.toItem.results[i].ZzGovCtrtype,
									"Usr01": oResponse.toItem.results[i].Usr01,
									"Vbegdat": oResponse.toItem.results[i].Vbgdat,
									"Venddat": oResponse.toItem.results[i].Vendat,
									"ZzTaskOrderCat": oResponse.toItem.results[i].ZzTaskOrderCat,
									"Zz_bpa": oResponse.toItem.results[i].Zmpcbpo,
									"ZzCapPt": oResponse.toItem.results[i].ZzCapPt,
									"ZzStrategy": oResponse.toItem.results[i].ZzStrategy,
									"Pspri": oResponse.toItem.results[i].Pspri,
									"ZzCapRat": oResponse.toItem.results[i].ZzCapRat,
									"ZzMarkup": oResponse.toItem.results[i].ZzMarkup,
									"ZzPtContact": oResponse.toItem.results[i].ZzPtContact,
									"ZzAtcode": oResponse.toItem.results[i].ZzAtcode,
									"Zz_focode": oResponse.toItem.results[i].Zz_focode,
									"Zz_vrcode": oResponse.toItem.results[i].Zz_vrcode,
									"Zproj_Subp_Cat_C": oResponse.toItem.results[i].Zproj_Subp_Cat_C,
									"Zz_gtmwbs": oResponse.toItem.results[i].ZzGtmwbs,
									"PsPhile": oResponse.toItem.results[i].PsPhile,
									"PsPhiup": oResponse.toItem.results[i].PsPhiup,
									"PsPhiri": oResponse.toItem.results[i].Ps_phiri,
									"PsPhido": oResponse.toItem.results[i].Ps_phido,
									"Zentry_tp": oResponse.toItem.results[i].Zentry_tp,
									"oldZposid": oResponse.toItem.results[i].Zposid //Mayank: Added for change wbs element.
										// "PsPhile": oResponse.toItem.results[i].PsPhile,
										// "PsPhiup": oResponse.toItem.results[i].PsPhiup
										// "PsPhiri":oResponse.toItem.results[i].PsPhiri,
										// "PsPhido":oResponse.toItem.results[i].PsPhido

								});
								obj1[i].Vbegdat = that.StringToDate(oResponse.toItem.results[i].Vbgdat);
								obj1[i].Venddat = that.StringToDate(oResponse.toItem.results[i].Vendat);
								obj1[i].PrteEstrt = that.StringToDate(oResponse.toItem.results[i].Pstrt);
								obj1[i].PrteEende = that.StringToDate(oResponse.toItem.results[i].Pende);

								// that.onSelectReqTypeCrossApp(oData.toDetails.results[0].ReasReq);

							}
							if (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp === "C") {
								that.byId("idProjDefi").setEnabled(false);
								that.getView().byId("idWbsGuided").setEnabled(false);
								if (oResponse.ZzGlblProj === "X") {
									that.getView().byId("idGlobProj").setEditable(false);
								}
								that.onSelectServiceOff();
								that.onSelectProjPhase();
							} else {
								that.onSelectServiceOff(oResponse.Vgsbr);
								that.onSelectProjPhase(oResponse.Vgsbr);
							}
							// for (var i = 0; i < oResponse.toItem.results.length; i++) {
							// 	// 
							if (oResponse.toItem.results[0].Zentry_tp === "E" || oResponse.toItem.results[0].Zentry_tp === "C") {
								// 		// that.byId("idProjDefi").setEnabled(false);
								// 		that.getView().byId("idWbsGuided").setEnabled(false);
								that.getView().byId("idT1ComCode").setEnabled(false);
								that.getView().byId("idWBSTypeT1").setEnabled(false);
								that.getView().byId("idProjType").setEnabled(false);
							}
							that.onSelectUserStatus(obj.toDetails.ProjTyp);

							// 		// that.getView().byId("idT1FinAnyst").setEnabled(false);
							that.getView().byId("idProjType").setEnabled(false);
							// 		that.getView().byId("idProjDefi").setEnabled(false);
							// 		that.getView().byId("idT4ProjDefDesc").setEditable(false);
							// 		that.getView().byId("idStartDate").setEnabled(false);
							// 		that.getView().byId("idEnddate").setEnabled(false);
							// 		that.getView().byId("idT2PersResp").setEditable(false);
							// 		that.getView().byId("idT2ProjRespCC").setEditable(false);
							// 		that.getView().byId("idT2ProjCategory").setEditable(false);
							// 		that.getView().byId("idT2ContractId").setEditable(false);
							// 		that.getView().byId("idT2ContractType").setEditable(false);
							// 		that.getView().byId("idT2CustId").setEditable(false);
							// 		that.getView().byId("idT2CustNme").setEditable(false);
							// 		that.getView().byId("idT2LdPracSet").setEditable(false);
							// 		that.getView().byId("idT2ProjAdmin").setEditable(false);
							// 		that.getView().byId("idT2FinAnyst").setEditable(false);
							// 		that.getView().byId("idT2ActMngr").setEditable(false);
							// 		that.getView().byId("idT2PrjSts").setEditable(false);
							// 		that.getView().byId("idT2RevMthd").setEditable(false);
							// 		that.getView().byId("idT2ContractTrm").setEditable(false);
							// 		that.getView().byId("idT2OpporId").setEditable(false);
							// 		that.getView().byId("idLblOpp").setRequired(true);
							// 		that.getView().byId("idT2Program").setEditable(false);
							// 		that.getView().byId("idGlobProj").setEditable(false);
							// 		that.getView().byId("idEvExtract").setEditable(false);
							// 		i = oResponse.toItem.results.length;
							// 	}
							// }
							obj.wbsElementStr = obj1;
							that.getView().getModel("pageModel").setProperty("/wbsElementStr", obj.wbsElementStr);

							/*Below code for load case safe id 341759 */
							var optID = [...new Map(oResponse.toItem.results.map(item => [item["ZsfdcOppid"], item])).values()];
							if (optID.length > 0) {
								that.onLoadCaseSafeChangeProjTab4(optID);
							}

							// obj.wbsElementStr = oResponse.results[0].toItem.results ;
							// ******************Name with Id for fields like PR*****************

							// that.sTerm1 = oData.Changed_by;
							that.sTerm2 = oResponse.FinApp;
							that.sTerm3 = oResponse.Vernr;
							that.sTerm4 = oResponse.PrjAd;
							that.sTerm5 = oResponse.FinApp;
							that.sTerm6 = oResponse.ZzoptyMgrResid;

							var aFilters = [];
							// aFilters.push(new sap.ui.model.Filter("Sysnam", sap.ui.model.FilterOperator.Contains, "COM"));
							aFilters.push(new sap.ui.model.Filter([
								// new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm1),
								new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm2),
								new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm3),
								new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm4),
								new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm5),
								new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, that.sTerm6),
							], false));
							var oModel1 = that.getView().getModel("oDataModel");
							oModel1.read("/Search_Finan_AnalystSet", {
								filters: aFilters,
								success: function (oResponse) {
									// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
									// return oModel;
									// var term1 = oResponse.results.filter(function (a) {
									// 	return a.Pernr === that.sTerm1;
									// });
									// if (term1.length !== 0) {
									// 	var oViewModel = that.getView().getModel("appView");
									// 	var firstName1 = term1[0].FirstName;
									// 	var lastName1 = term1[0].LastName;
									// 	var EmpID1 = term1[0].Pernr;
									// 	var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
									// 	oViewModel.getData().Requestor = oID;
									// 	that.getView().getModel("appView").refresh(true);
									// }

									var term2 = oResponse.results.filter(function (a) {
										return a.Pernr === that.sTerm2;
									});
									if (term2.length !== 0) {
										var firstName1 = term2[0].FirstName;
										var lastName1 = term2[0].LastName;
										var EmpID1 = term2[0].Pernr;
										if (EmpID1 !== "00000000") {
											var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
											that.getView().byId("idT1FinAnyst").setValue(oID);
										}
									}

									var term3 = oResponse.results.filter(function (a) {
										return a.Pernr === that.sTerm3;
									});
									if (term3.length !== 0) {
										var firstName1 = term3[0].FirstName;
										var lastName1 = term3[0].LastName;
										var EmpID1 = term3[0].Pernr;
										if (EmpID1 !== "00000000") {
											var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
											that.getView().byId("idT2PersResp").setValue(oID);
										}
									}

									var term4 = oResponse.results.filter(function (a) {
										return a.Pernr === that.sTerm4;
									});
									if (term4.length !== 0) {
										var firstName1 = term4[0].FirstName;
										var lastName1 = term4[0].LastName;
										var EmpID1 = term4[0].Pernr;
										if (EmpID1 !== "00000000") {
											var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
											that.getView().byId("idT2ProjAdmin").setValue(oID);
										}
									}

									var term5 = oResponse.results.filter(function (a) {
										return a.Pernr === that.sTerm5;
									});
									if (term5.length !== 0) {
										var firstName1 = term5[0].FirstName;
										var lastName1 = term5[0].LastName;
										var EmpID1 = term5[0].Pernr;
										if (EmpID1 !== "00000000") {
											var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
											that.getView().byId("idT2FinAnyst").setValue(oID);
										}
									}

									var term6 = oResponse.results.filter(function (a) {
										return a.Pernr === that.sTerm6;
									});
									if (term6.length !== 0) {
										var firstName1 = term6[0].FirstName;
										var lastName1 = term6[0].LastName;
										var EmpID1 = term6[0].Pernr;
										if (EmpID1 !== "00000000") {
											var oID = firstName1 + "," + lastName1 + "(" + EmpID1 + ")";
											that.getView().byId("idT2ActMngr").setValue(oID);
										}
									}

									var oModelExt = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
									var oExtline1 = oModelExt[0].Zentry_tp;
									if (oExtline1 === "E" || oExtline1 === "C") {
										//To Change app  title 
										var oView1 = that.getView().getParent();
										oView1.getService("ShellUIService").then(
											function (oService) {
												oService.setTitle("Manage Project Request");
											}
										);
										that.byId("HeaderID").setObjectTitle("Manage Project Request");
									} else {
										//To Change app  title 
										var oView1 = that.getView().getParent();
										oView1.getService("ShellUIService").then(
											function (oService) {
												oService.setTitle("New Project Request");
											}
										);
										that.byId("HeaderID").setObjectTitle("New Project Request");
										//
									}

								},
								error: function (oError) {}
							});

							that.getView().setBusy(false);
							sap.ui.core.BusyIndicator.hide();
							var oModel = that.getView().getModel();
							oModel.refresh();
							that.byId("idUploadDialog").close();
							if (oResponse.toExcelError.results.length !== 0) {
								sap.m.MessageToast.show("Upload completed with errors. Please check the error log.", {
									duration: 5000
								});
								that.getView().byId("idErrorBtn").setVisible(true);
								that.getView().getModel().getData().toError = oResponse.toExcelError.results;
							}
							if (oResponse.toItem.results[0].Prart === "C" || oResponse.toItem.results[0].Prart === "L") {
								that.onEnableDesableFields("C");
							} else {
								that.onEnableDesableFields("J");
							}

						}
					},
					error: function (oError) {
						that.getView().setBusy(false);
						sap.ui.core.BusyIndicator.hide();
						that._getDialog().close();
						MessageToast.show("System Error Occured from Backend !");

					}
				});

			}
			// End of changes for Phase3 Srini Vallepu
		},

		StringToDate: function (String) {
			var x = String;
			if (x === "00000000" || x === null || x === undefined || x === "") {
				return null;
			} else {
				var Year = x.substring(0, 4);
				var Month = x.substring(4, 6) - 1;
				var Day = x.substring(6, 8);
				return new Date(Date.UTC(Year, Month, Day));
			}

		},
		onTypeMissmatch: function (oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function (key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			MessageToast.show(oBundle.getText("XMSG_TYPEMISSMATCH", [oEvent.getParameter("fileType"), sSupportedFileTypes]));
		},
		onValueChange: function (oEvent) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			MessageToast.show(oBundle.getText("XMSG_VALUECHANGE", [oEvent.getParameter("newValue")]));
		},
		onUploadPress: function (oEvent) {
			var oFileUploader = this.getView().byId("idFileUploader");
			//disable message popover before another call
			// this.getView().byId("messBtn").setVisible(false);
			// oMessagePopover.setModel(new JSONModel([]));

			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			if (!oFileUploader.getValue()) {
				MessageToast.show(oBoundle.getText("XMSG_CHOOSEFILE"));
				return;
			}
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getView().getModel("oDataModel").getSecurityToken()
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "accept",
				value: "application/json"
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: ""
			}));
			this.getView().setBusy(true);
			oFileUploader.setSendXHR(true);
			oFileUploader.upload();
		},

		// onUploadComplete: function () {
		// 	this.onCancelIWO();
		// 	sap.m.MessageToast.show("File Uploaded Successfully...");
		// },
		onCancelIWO: function () {
			var oDailog = this.byId("idDialog");
			oDailog.close();
			oDailog.destroy();
		},
		// onDownladFileBtn: function () {
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	var oView = this.getView();
		// 	var oDialog = oView.byId("idDialog");
		// 	var oViewModel = this.getView().getModel("appView");
		// 	var Iwo = oViewModel.getData().iwoNo;
		// 	// var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZFILE_SRV");
		// 	var aFilters = [];
		// 	aFilters.push(new Filter("Iwo", sap.ui.model.FilterOperator.EQ, Iwo));
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	var that = this;
		// 	oModel.read("/IWOAttachSet", {
		// 		filters: aFilters,
		// 		success: function (oResponse) {
		// 			// create dialog lazily
		// 			if (!oDialog) {
		// 				// create dialog via fragment factory
		// 				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.downloadAttac", that);
		// 				// connect dialog to view (models, lifecycle)
		// 				oView.addDependent(oDialog);
		// 			}
		// 			oDialog.open();
		// 			var oModel3 = new sap.ui.model.json.JSONModel(oResponse.results);
		// 			oDialog.setModel(oModel3, "oData");
		// 			sap.ui.core.BusyIndicator.hide();
		// 		},
		// 		error: function (oError) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 		}
		// 	});

		// },
		// onDownladAttach: function (oEvent) {
		// 	var selItem = oEvent.getParameter("item").getBindingContextPath().split("/")[1];
		// 	var Iwo = oEvent.getSource().getParent().getSender();
		// 	var AttachID = oEvent.getSource().getParent().getTimestamp();
		// 	// var sUrl = "https://sapmdd-dxc.sapnet.dxccorp.net:8443/sap/opu/odata/sap/ZODATA_IWO_REQUEST_SRV/IWOAttachLineSet(Iwo='" + Iwo + "',Filename='" + fileName + "')/$value";
		// 	var sUrl = "/sap/opu/odata/sap/ZODATA_IWO_REQUEST_SRV/IWOAttachLineSet(AttachID='" + AttachID + "',Iwo='" + Iwo + "')/$value";
		// 	var httpUrl = window.location.href.split("/sap/")[0];
		// 	// var 0Url = "http://sapmdd-dxc.sapnet.dxccorp.net:8443";
		// 	var strUrl = httpUrl + sUrl;
		// 	window.open(strUrl);
		// },

		/*Below code foe WBS Project*/
		/*==================================*/
		//// ----------- vinodh ----------/////
		//TAB 1
		onSuggestionReqTyp: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Perid", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionReqType: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Perid", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionReqFun: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Project", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		//TAB 2
		onSuggestion1: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("FirstName", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("LastName", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Search_Finan_AnalystSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'sug');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onSuggestionT4CstCentr: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sComCode = this.getView().byId("idT2CoCode").getValue();
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sComCode)
				],
				and: true
			});
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Search_Cost_CenterSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {
					var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					oSource.setModel(oModel, 'costCenT4');
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onSuggestionT4OpporId: function (oEvent) {
			// var iRowIndex = this.onRowCount(oEvent);
			// var m = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[11].getId();
			// this.getView().byId(m).setSelectedKey("");

			var sRow = oEvent.getSource().getBindingContext("pageModel").getPath(); // rohit - change
			var sTerm = oEvent.getParameter("suggestValue");
			var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Search_OpportunityIDSet", {
				filters: [aFilters],
				urlParameters: {
					"$top": 100
				},
				success: function (oResponse) {

					// var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
					// oSource.setModel(oModel, 'oportuT4');
					that.getView().getModel("pageModel").setProperty(sRow + "/OpportuT4TempModel", oResponse.results); // rohit - change
					oSource._refreshItemsDelayed();
				},
				error: function (oError) {}
			});
		},
		onSuggestionOpporId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionT4CaseSafeid: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Uniq_id", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Zzsolseid", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Cnt_typ", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Sol_typ", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionCstCentr: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var sComCode = this.getView().byId("idT2CoCode").getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sComCode)
				],
				and: true
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionFncAnalyst: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("FirstName", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("LastName", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionPOC: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionProjPhase: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			// var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var busiArea = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].getValue();
			var busiArea = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Pgsbr;
			var projType = this.getView().byId("idProjType").getSelectedKey();
			var PrartTyp;
			if (projType === "PRJ_TYP1") {
				PrartTyp = "C";
			} else if (projType === "PRJ_TYP2") {
				PrartTyp = "J";
			}
			// var projType;
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pgsbr", sap.ui.model.FilterOperator.Contains, busiArea),
					new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.Contains, PrartTyp),
					new sap.ui.model.Filter("ZzprojPhaseCd", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: true
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionProjSubPhase: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Zprojsubpcatc", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Zprojsubphase", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Zprojsubpcat", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionmulEmail: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("NameFirst", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("NameLast", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onFncAnalystIdSelect: function (oEvent) {
			if (oEvent.getParameter("selectedItem") !== null) {
				var sFncAnalystId = oEvent.getParameter("selectedItem").getKey();
				var FinAnystTxt = oEvent.getParameter("selectedItem").getText();

				var oViewModel = this.getView().getModel("appView");
				var oType = oViewModel.getData().type;
				var itemDetails = this.getView().getModel("pageModel").getData().wbsElementStr;
				var oTable = this.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
				if (itemDetails.length > 0) {
					var allow = itemDetails[0].Zentry_tp;
				} else {
					var allow = "";
				}

				if (oType === "ChangeProject") {

				} else if (allow === "E" || allow === "C") {

				} else {
					this.getView().getModel().getData().draftData.d.FinApp = sFncAnalystId;
					// this.getView().byId("idT2FinAnyst").setSelectedKey(sFncAnalystId);
					this.getView().byId("idT2FinAnyst").setValue(FinAnystTxt);
					// if (oTable.length != 0) {

					// 	for (var i = 0; i < oTable.length; i++) {
					// 		// this.getView().getModel().getProperty("/wbsElementStr")[i].PrjAd = sSystem
					// 		this.getView().getModel("pageModel").getProperty("/wbsElementStr")[i].FinApp = sFncAnalystId // rohit - change
					// 	}

					// }

				}

			}
		},

		onSuggestionPrjTyp: function (oEvent) {
			var okey = oEvent.getSource().getSelectedKey();
			this.getView().byId("idProjType").setValueState("None");
			var t1CoCode = this.getView().byId("idT1ComCode").getValue();
			var projDef = this.getView().byId("idProjDefi").getValue();
			var projTypeName = this.getView().byId("idProjType").getValue();
			// var oModel = this.getView().getModel();
			var oModel = this.getView().getModel("pageModel"); // rohit - change
			var wbsEleCunt = oModel.getProperty("/wbsElementStr").length;
			var oViewModel = this.getView().getModel("appView");
			var oAppType = oViewModel.getData().type;
			if (wbsEleCunt >= 1) {
				var that = this;
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					content: new sap.m.Text({
						text: "Are you sure you want to change the Project Type? This will wipe out the data from the WBSE details screen. CONTINUE: OK / CANCEL."
					}),
					beginButton: new sap.m.Button({
						text: "Ok",
						press: function () {
							for (var i = wbsEleCunt - 1; i >= 0; i--) {
								// var idx = wbsEleCunt[i];
								// var oModel = that.getView().getModel();
								var oModel = that.getView().getModel("pageModel"); // rohit - change
								var itab = oModel.getProperty("/wbsElementStr");
								itab.splice(i, 1)
									// itab.push(itemRow);
								oModel.setProperty("/wbsElementStr", itab);
							}
							dialog.close();
							var wbsEleLevel = "1";
							var wbsDown = projDef.concat(".0", 1);
							var serOffering = "";
							var PsPhiup = "";
							var PsPhido = wbsDown;
							var PsPhile = "";
							var PsPhiri = "";
							that.getView().byId("idProjDefi").setValueState("None");
							that.onAddWbsEle(projDef, projDef, t1CoCode, 1, "REL", "CRTD", "BLANK", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
							if (okey === "PRJ_TYP1") {
								that.getView().byId("idT2ProjCategory").setValue("ES-NOSOAR");
								that.getView().byId("idT2ProjCategory").setEditable(false);
								that.getView().byId("idT2ContractType").setSelectedKey("500");
								that.getView().byId("idT2ContractType").setEditable(true);
								var oProjectBox = that.getView().byId("idT2ContractType");
								that.getView().byId("idT2LdPracSet").setEditable(true);
								//Added by  srini vallepu  for Scenario2 
								var oViewModelNav = that.getView().getModel("appView").getData().type;
								if (oViewModelNav !== "OpprApp") {
									that.getView().byId("idT2LdPracSet").setValue("");
									that.getView().byId("idT2LdPracSet").setSelectedKey("");
									// }else{
								}
								// oViewModel.getData().type = "OpprApp";
								// End of added Srini vallepu for scenario2 
								that.getView().byId("idT2LdPracSet").setRequired(true);
								that.getView().byId("idT2RevMthd").setEditable(true);
								that.getView().byId("idT2RevMthd").setRequired(true);
								that.getView().byId("idT2OpporId").setRequired(true);
								that.getView().byId("idT2OpporId").setEditable(true);
								that.getView().byId("idT2ContractTrm").setSelectedKey("");
								that.getView().byId("idT2ContractTrm").setValue("");

								that.getView().byId("idT2PrjSts").setSelectedKey("I");
								that.getView().byId("idT2PrjSts").setValue("I");
								if (oAppType !== "OpprApp") {
									that.getView().byId("idT2ContractId").setSelectedKey("");
									that.getView().byId("idT2ContractId").setValue("");
									that.getView().byId("idT2ClientId").setValue("");
									that.getView().byId("idT2IndusCode").setValue("");
								}
								var oBindingBox = oProjectBox.getBinding("items");
								// var aFilters = [];
								// var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300");
								// var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600");
								// var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700");

								var aFilters = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
										new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
									],
									and: true
								});
								// aFilters.push(oFilters);
								oBindingBox.filter(aFilters);

								var oBindingBoxT2 = that.getView().byId("idT2LdPracSet").getBinding("items");
								var aFiltersT2 = [];
								var oFiltersT2 = new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.NE, "BLANK");
								aFiltersT2.push(oFiltersT2);
								oBindingBoxT2.filter(aFiltersT2);

								var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
								var aFiltersT3 = new sap.ui.model.Filter({
									filters: [
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
										new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
									],
									and: false
								});
								oBindingBoxT3.filter(aFiltersT3);

								if (!oAppType) {
									var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
									// if (t1CoCode === "ES87" || t1CoCode === "ES88" || t1CoCode === "ES89") {
									// 	var aFiltersT4 = new sap.ui.model.Filter({
									// 		filters: [
									// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
									// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
									// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
									// 		],
									// 		and: false
									// 	});
									// } else {
									// 	var aFiltersT4 = new sap.ui.model.Filter({
									// 		filters: [
									// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
									// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ")
									// 		],
									// 		and: false
									// 	});
									// }

									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ")
										],
										and: false
									});
									oBindingBoxT4.filter(aFiltersT4);
								} else {
									// Begin of changes Phase3 Chnages Srini  Vallepu
									//begin of  Phase2 Code 
									// var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
									// var aFiltersT4 = new sap.ui.model.Filter({
									// 	filters: [
									// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ4"),
									// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ5"),
									// 		new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ7")
									// 	],
									// 	and: true
									// });
									// oBindingBoxT4.filter(aFiltersT4);
									// End of Phase2 Code
									var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");
									var aFiltersT4 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
											new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1")
										],
										and: false
									});
									oBindingBoxT4.filter(aFiltersT4);

									// End of changes Phase3 Chnages Srini  Vallepu
								}

								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().projType = "Trade";
								oViewModel.getData().projTypeid = okey;
								oViewModel.getData().projTypeName = projTypeName;
								that.getView().getModel("appView").refresh(true);
							} else if (okey === "PRJ_TYP2") {
								that.getView().byId("idT2ProjCategory").setValue("OTHER");
								that.getView().byId("idT2ProjCategory").setEditable(false);
								// that.getView().byId("idT2ContractType").setSelectedKey("300");
								// that.getView().byId("idT2ContractType").setEditable(false);
								that.getView().byId("idT2LdPracSet").setEditable(false);
								//Added by  srini vallepu  for Scenario2 
								var oViewModelNav = that.getView().getModel("appView").getData().type;
								if (oViewModelNav !== "OpprApp") {
									that.getView().byId("idT2LdPracSet").setValue("");
									that.getView().byId("idT2LdPracSet").setSelectedKey("");
									// }else{
								}
								// oViewModel.getData().type = "OpprApp";
								// End of added Srini vallepu for scenario2 

								that.getView().byId("idT2LdPracSet").setRequired(false);
								that.getView().byId("idT2RevMthd").setEditable(false);
								that.getView().byId("idT2RevMthd").setRequired(false);
								that.getView().byId("idT2RevMthd").setValue("TE");
								that.getView().byId("idT2OpporId").setRequired(false);
								that.getView().byId("idT2OpporId").setEditable(false);
								// that.getView().byId("idT2RevMthd").setEditable(false);
								that.getView().byId("idT2ContractTrm").setSelectedKey("TM");
								that.getView().byId("idT2ContractTrm").setValue("TM");
								that.getView().byId("idT2PrjSts").setSelectedKey("I");
								that.getView().byId("idT2PrjSts").setValue("I");
								// that.getView().byId("idT2ContractTrm").setRequired(false);
								// that.getView().byId("idT2PrjSts").setRequired(false);

								that.getView().byId("idT2RevMthd").setValueState("None");
								that.getView().byId("idT2ContractTrm").setValueState("None");
								that.getView().byId("idT2PrjSts").setValueState("None");
								if (oAppType !== "OpprApp") {
									that.getView().byId("idT2ContractId").setSelectedKey("");
									that.getView().byId("idT2ContractId").setValue("");
									that.getView().byId("idT2ClientId").setValue("");
									that.getView().byId("idT2IndusCode").setValue("");
								}

								// var oProjectBox = that.getView().byId("idT2ContractType");
								// var oBindingBox = oProjectBox.getBinding("items");
								// var aFilters = [];
								// var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
								// aFilters.push(oFilters);
								// oBindingBox.filter(aFilters);

								var oViewModel = that.getView().getModel("appView");
								if (oViewModel.getData().Admin) {
									var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
									var aFiltersT3 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
										],
										and: true
									});
									oBindingBoxT3.filter(aFiltersT3);

									var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");

									if (t1CoCode === "ES87" || t1CoCode === "ES88" || t1CoCode === "ES89") {
										var aFiltersT4 = new sap.ui.model.Filter({
											filters: [
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
											],
											and: false
										});

										// that.getView().byId("idT2ContractType").setSelectedKey("300");
										that.getView().byId("idT2ContractType").setEditable(true);
									} else {
										that.getView().byId("idT2ContractType").setSelectedKey("300");
										that.getView().byId("idT2ContractType").setEditable(false);
										var aFiltersT4 = new sap.ui.model.Filter({
											filters: [
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
											],
											and: false
										});
									}
									oBindingBoxT4.filter(aFiltersT4);
								} else {
									var oBindingBoxT3 = that.getView().byId("idWBSTypeT1").getBinding("items");
									var aFiltersT3 = new sap.ui.model.Filter({
										filters: [
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "C"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "L"),
											new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
										],
										and: true
									});
									oBindingBoxT3.filter(aFiltersT3);

									var oBindingBoxT4 = that.getView().byId("idReqType").getBinding("items");

									if (t1CoCode === "ES87" || t1CoCode === "ES88" || t1CoCode === "ES89") {
										// that.getView().byId("idT2ContractType").setSelectedKey("300");
										that.getView().byId("idT2ContractType").setEditable(true);

										var aFiltersT4 = new sap.ui.model.Filter({
											filters: [
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
												// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
											],
											and: false
										});
									} else {
										that.getView().byId("idT2ContractType").setSelectedKey("300");
										that.getView().byId("idT2ContractType").setEditable(false);

										var aFiltersT4 = new sap.ui.model.Filter({
											filters: [
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
												new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
												// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
											],
											and: false
										});
									}

									oBindingBoxT4.filter(aFiltersT4);
								}

								var oViewModel = that.getView().getModel("appView");
								oViewModel.getData().projType = "Internal";
								oViewModel.getData().projTypeid = okey;
								oViewModel.getData().projTypeName = projTypeName;
								that.getView().getModel("appView").refresh(true);
							}
							// sap.ui.core.BusyIndicator.hide();
							// dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: "Cancel",
						press: function () {
							sap.ui.core.BusyIndicator.hide();
							dialog.close();
							// Phase2 Warrenty  issue 
							var oViewModel = that.getView().getModel("appView");
							// oViewModel.getData().projType = "Trade";
							// oViewModel.getData().projTypeid = okey;
							// oViewModel.getData().projTypeName = projTypeName;
							// that.getView().getModel("appView").refresh(true);
							//
							// var oViewModel = that.getView().getModel("appView");
							// var oViewModelNew = that.getView().getModel();

							var oldValue1 = oViewModel.getData().projTypeid;
							var oldValue2 = oViewModel.getData().projTypeName;
							if (oldValue1) {
								that.getView().byId("idProjType").setSelectedKey(oldValue1);
								that.getView().byId("idProjType").setValue(oldValue2);
							} else {
								var oProj = oViewModel.getData().projType;
								if (oProj == "Trade") {
									that.getView().byId("idProjType").setSelectedKey("PRJ_TYP1");
									that.getView().byId("idProjType").setValue("Trade Project");

								} else {
									that.getView().byId("idProjType").setSelectedKey("PRJ_TYP2");
									that.getView().byId("idProjType").setValue("Internal Project");

								}

							}

						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();

			} else {
				if (okey === "PRJ_TYP1") {
					this.getView().byId("idT2ProjCategory").setValue("ES-NOSOAR");
					this.getView().byId("idT2ProjCategory").setEditable(false);
					this.getView().byId("idT2ContractType").setSelectedKey("500");
					this.getView().byId("idT2ContractType").setEditable(true);
					var oProjectBox = this.getView().byId("idT2ContractType");
					this.getView().byId("idT2LdPracSet").setEditable(true);
					// this.getView().byId("idT2LdPracSet").setValue("");
					//Added by  srini vallepu  for Scenario2 
					var oViewModelNav = this.getView().getModel("appView").getData().type;
					if (oViewModelNav !== "OpprApp") {
						this.getView().byId("idT2LdPracSet").setValue("");
						this.getView().byId("idT2LdPracSet").setSelectedKey("");
						// }else{
					}
					// oViewModel.getData().type = "OpprApp";
					// End of added Srini vallepu for scenario2 

					this.getView().byId("idT2LdPracSet").setRequired(true);
					this.getView().byId("idT2RevMthd").setEditable(true);
					this.getView().byId("idT2RevMthd").setRequired(true);
					this.getView().byId("idT2OpporId").setRequired(true);
					this.getView().byId("idT2OpporId").setEditable(true);
					this.getView().byId("idT2ContractTrm").setSelectedKey("");
					this.getView().byId("idT2ContractTrm").setValue("");

					this.getView().byId("idT2PrjSts").setSelectedKey("I");
					this.getView().byId("idT2PrjSts").setValue("I");
					if (oAppType !== "OpprApp") {
						this.getView().byId("idT2ContractId").setSelectedKey("");
						this.getView().byId("idT2ContractId").setValue("");
						this.getView().byId("idT2ClientId").setValue("");
						this.getView().byId("idT2IndusCode").setValue("");
					}
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
							new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
							new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
						],
						and: true
					});
					oBindingBox.filter(aFilters);
					var oBindingBoxT2 = this.getView().byId("idT2LdPracSet").getBinding("items");
					var aFiltersT2 = [];
					var oFiltersT2 = new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.NE, "BLANK");
					aFiltersT2.push(oFiltersT2);
					oBindingBoxT2.filter(aFiltersT2);

					var oBindingBoxT3 = this.getView().byId("idWBSTypeT1").getBinding("items");
					var aFiltersT3 = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "C"),
							new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "L")
						],
						and: false
					});
					oBindingBoxT3.filter(aFiltersT3);

					if (!oAppType) {
						var oBindingBoxT4 = this.getView().byId("idReqType").getBinding("items");
						// if (t1CoCode === "ES87" || t1CoCode === "ES88" || t1CoCode === "ES89") {
						// 	var aFiltersT4 = new sap.ui.model.Filter({
						// 		filters: [
						// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
						// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ"),
						// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6")
						// 		],
						// 		and: false
						// 	});
						// } else {
						// 	var aFiltersT4 = new sap.ui.model.Filter({
						// 		filters: [
						// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
						// 			new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ")
						// 		],
						// 		and: false
						// 	});
						// }

						var aFiltersT4 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ1"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ")
							],
							and: false
						});
						oBindingBoxT4.filter(aFiltersT4);
					} else {
						var oBindingBoxT4 = this.getView().byId("idReqType").getBinding("items");
						var aFiltersT4 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ4"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ5"),
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.NE, "REAS_REQ7")
							],
							and: true
						});
						oBindingBoxT4.filter(aFiltersT4);
					}

					var oViewModel = this.getView().getModel("appView");
					oViewModel.getData().projType = "Trade";
					oViewModel.getData().projTypeid = okey;
					oViewModel.getData().projTypeName = projTypeName;
					this.getView().getModel("appView").refresh(true);
				} else if (okey === "PRJ_TYP2") {
					this.getView().byId("idT2ProjCategory").setValue("OTHER");
					this.getView().byId("idT2ProjCategory").setEditable(false);
					this.getView().byId("idT2ContractType").setSelectedKey("300");
					this.getView().byId("idT2ContractType").setEditable(false);
					this.getView().byId("idT2LdPracSet").setEditable(false);
					// this.getView().byId("idT2LdPracSet").setValue("");
					//Added by  srini vallepu  for Scenario2 
					var oViewModelNav = this.getView().getModel("appView").getData().type;
					if (oViewModelNav !== "OpprApp") {
						this.getView().byId("idT2LdPracSet").setValue("");
						this.getView().byId("idT2LdPracSet").setSelectedKey("");
						// }else{
					}
					// oViewModel.getData().type = "OpprApp";
					// End of added Srini vallepu for scenario2 

					this.getView().byId("idT2LdPracSet").setRequired(false);
					this.getView().byId("idT2RevMthd").setEditable(false);
					this.getView().byId("idT2RevMthd").setRequired(false);
					this.getView().byId("idT2RevMthd").setValue("TE");
					this.getView().byId("idT2OpporId").setRequired(false);
					this.getView().byId("idT2OpporId").setEditable(false);
					this.getView().byId("idT2ContractTrm").setSelectedKey("TM");
					this.getView().byId("idT2ContractTrm").setValue("TM");
					this.getView().byId("idT2PrjSts").setSelectedKey("I");
					this.getView().byId("idT2PrjSts").setValue("I");
					// this.getView().byId("idT2ContractTrm").setRequired(false);
					// this.getView().byId("idT2PrjSts").setRequired(false);

					this.getView().byId("idT2RevMthd").setValueState("None");
					this.getView().byId("idT2ContractTrm").setValueState("None");
					this.getView().byId("idT2PrjSts").setValueState("None");
					if (oAppType !== "OpprApp") {
						this.getView().byId("idT2ContractId").setSelectedKey("");
						this.getView().byId("idT2ContractId").setValue("");
						this.getView().byId("idT2ClientId").setValue("");
						this.getView().byId("idT2IndusCode").setValue("");
					}

					var oViewModel = this.getView().getModel("appView");
					if (oViewModel.getData().Admin) {
						var oBindingBoxT3 = this.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oBindingBoxT4 = this.getView().byId("idReqType").getBinding("items");

						if (t1CoCode === "ES87" || t1CoCode === "ES88" || t1CoCode === "ES89") {
							// var oProjectBox = this.getView().byId("idT2ContractType");
							// var oBindingBox = oProjectBox.getBinding("items");
							// var aFilters = new sap.ui.model.Filter({
							// 	filters: [
							// 		new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
							// 		new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
							// 		new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
							// 	],
							// 	and: true
							// });
							// oBindingBox.filter(aFilters);

							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
								],
								and: false
							});
						} else {
							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
								],
								and: false
							});
							var oProjectBox = this.getView().byId("idT2ContractType");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}

						oBindingBoxT4.filter(aFiltersT4);
					} else {
						var oBindingBoxT3 = this.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "C"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "L"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.NE, "B")
							],
							and: true
						});
						oBindingBoxT3.filter(aFiltersT3);

						var oBindingBoxT4 = this.getView().byId("idReqType").getBinding("items");

						if (t1CoCode === "ES87" || t1CoCode === "ES88" || t1CoCode === "ES89") {
							var oProjectBox = this.getView().byId("idT2ContractType");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "300"),
									new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "600"),
									new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.NE, "700"),
								],
								and: true
							});
							oBindingBox.filter(aFilters);

							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ6"),
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
								],
								and: false
							});
						} else {
							var oProjectBox = this.getView().byId("idT2ContractType");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.EQ, "300");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);

							var aFiltersT4 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ4"),
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ5"),
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REAS_REQ7")
								],
								and: false
							});
						}

						oBindingBoxT4.filter(aFiltersT4);
					}
					var oViewModel = this.getView().getModel("appView");
					oViewModel.getData().projType = "Internal";
					oViewModel.getData().projTypeid = okey;
					oViewModel.getData().projTypeName = projTypeName;
					this.getView().getModel("appView").refresh(true);
				}
			}
		},
		onChangeWbsTypeTab1: function (oEvent) {
			var okey = oEvent.getSource().getSelectedKey();
			var sSelect = oEvent.getParameter("selectedItem").getKey();
			// var oModel = this.getView().getModel();
			var oModel = this.getView().getModel("pageModel"); // rohit - change
			var wbsEleCunt = oModel.getProperty("/wbsElementStr").length;
			var Pgsbr = this.getView().byId("idT2BusnsArea").getValue();
			this.onSelectProjPhase(Pgsbr);
			if (wbsEleCunt >= 1) {
				var oViewModel = oModel.getProperty("/wbsElementStr");
				for (var i = 0; i < wbsEleCunt; i++) {
					if (oViewModel[i].Zentry_tp !== "E" || oViewModel[i].Zentry_tp !== "C") {
						oViewModel[i].Prart = okey;
					}
				}
				MessageToast.show("WBS Type successfully changed.");
			}
			this.onInputValidation(oEvent);
		},
		onSelectReqType: function (oEvent) {
			var okey = oEvent.getSource().getSelectedKey();
			var sSelect = oEvent.getParameter("selectedItem").getKey();
			var oViewModel = this.getView().getModel("appView");
			var comCode = oViewModel.getData().comCode;
			var oComCode = this.getView().byId("idT1ComCode").getValue();
			var oType = oViewModel.getData().type;
			this.onInputValidation(oEvent);
			if (sSelect === "New Logo") {
				var oProjectBox = this.getView().byId("idReqTypeDtls");
				var oBindingBox = oProjectBox.getBinding("items");
				var aFilters = [];
				var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "New Logo");
				aFilters.push(oFilters);
				oBindingBox.filter(aFilters);
				if (oType === "OpprApp") {

				} else if (oType === "ChangeProject" || oType === "DuplicateExisting") {

				} else {
					this.getView().byId("idT2ContractId").setSelectedKey("");
					this.getView().byId("idT2ContractId").setValue("");
					this.getView().byId("idT2ClientId").setValue("");
					this.getView().byId("idT2IndusCode").setValue("");
				}

			} else {
				if (sSelect === "New Project") {
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "New Project");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);
				} else if (sSelect === "WBS Add/Change without CAN") {
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "WBS Add/Change without CAN");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);
				} else if (sSelect === "WBS Add/Change including CAN") {
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "WBS Add/Change including CAN");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);
				} else if (sSelect === "Standard Internal Project(Non-Funded)") {
					this.getView().byId("idT2LdPracSet").setValue("");
					this.getView().byId("idT2LdPracSet").setEditable(false);
					this.getView().byId("idT2LdPracSet").setRequired(false);
					this.getView().byId("idT2OpporId").setRequired(false);
					this.getView().byId("idT2OpporId").setEditable(false);
					this.getView().byId("idT2OpporId").setValue("");
					this.getView().byId("idGlobProj").setSelected(false);
					this.getView().byId("idGlobProj").setEditable(true);

					if (oType !== "ChangeProject") {
						this.getView().byId("idWBSTypeT1").setValue("");
						this.getView().byId("idT2RevMthd").setEditable(false);
					}
					// this.getView().byId("idGlobProj").setSelected(false);
					// this.getView().byId("idGlobProj").setEditable(true);

					if (this.getView().getModel("pageModel").getData().wbsElementStr.length === 0) {
						var oExtline = "";
					} else {
						var oExtline = this.getView().getModel("pageModel").getData().wbsElementStr[0].Zentry_tp;
					}

					if (oExtline === "E" || oExtline === "C") {

					} else {
						var oBindingBoxT3 = this.getView().byId("idWBSTypeT1").getBinding("items");
						var aFiltersT3 = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "E"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "M"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "O"),
								new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "W")
							],
							and: false
						});
						oBindingBoxT3.filter(aFiltersT3);
					}

					var oViewModel = this.getView().getModel("appView");
					var oAppType = oViewModel.getData().type;
					if (!oAppType) {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET19");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

					} else if (oAppType === "uploadProject") { // Phse3 UAT Defect CR ID 342149

						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET19");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

					} else if (oAppType === "ChangeProject") {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						// var aFilters = [];
						// var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20")
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET21")   new RCR phase2 
							],
							and: false
						});

						// aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

					} else if (oAppType === "DuplicateExisting") {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						// var aFilters = [];
						// var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET19")
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET21")   new RCR phase2 
							],
							and: false
						});

						// aFilters.push(oFilters);
						oBindingBox.filter(aFilters);
					} else if (oAppType === "ChangeRequest") {
						var oExtline = this.getView().getModel("pageModel").getData().wbsElementStr[0].Zentry_tp;
						if (oExtline === "E" || oExtline === "C") {
							var oProjectBox = this.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20")
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET21") new RCR phase2 
								],
								and: false
							});
							oBindingBox.filter(aFilters);

						} else {

							var oProjectBox = this.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET19");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}

					} else {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Standard Internal Project(Non-Funded)");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);
					}

				} else if (sSelect === "Standard Internal Project(Funded)") {
					this.getView().byId("idT2LdPracSet").setValue("");
					this.getView().byId("idT2LdPracSet").setEditable(false);
					this.getView().byId("idT2LdPracSet").setRequired(false);
					this.getView().byId("idT2OpporId").setRequired(false);
					this.getView().byId("idT2OpporId").setEditable(false);
					this.getView().byId("idT2OpporId").setValue("");
					this.getView().byId("idGlobProj").setSelected(false);
					this.getView().byId("idGlobProj").setEditable(true);

					// this.getView().byId("idWBSTypeT1").setValue("");
					if (oType !== "ChangeProject") {
						this.getView().byId("idWBSTypeT1").setValue("");
						this.getView().byId("idT2RevMthd").setEditable(false);
					}
					// this.getView().byId("idGlobProj").setSelected(false);
					// this.getView().byId("idGlobProj").setEditable(true);

					if (this.getView().getModel("pageModel").getData().wbsElementStr.length === 0) {
						var oExtline = "";
					} else {
						var oExtline = this.getView().getModel("pageModel").getData().wbsElementStr[0].Zentry_tp;
					}
					if (oExtline === "E" || oExtline === "C") {

					} else {
						var oComCode = this.getView().byId("idT1ComCode").getValue();
						var oBindingBoxT3 = this.getView().byId("idWBSTypeT1").getBinding("items");
						if (oComCode === "JP00") {
							var aFiltersT3 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "D"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
								],
								and: false
							});

						} else {
							var aFiltersT3 = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "J"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
									new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
								],
								and: false
							});
						}
						oBindingBoxT3.filter(aFiltersT3);
					}

					var oViewModel = this.getView().getModel("appView");
					var oAppType = oViewModel.getData().type;
					if (!oAppType) {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET22");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);
					} else if (oAppType === "uploadProject") { // Phse3 UAT Defect CR ID 342149

						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET22");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);

					} else if (oAppType === "ChangeProject") {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET23")
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET24") "new RCR phase2 "
							],
							and: false
						});
						oBindingBox.filter(aFilters);
					} else if (oAppType === "DuplicateExisting") {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						// var aFilters = [];
						// var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET20");
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET22")
								// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET21")   new RCR phase2 
							],
							and: false
						});

						// aFilters.push(oFilters);
						oBindingBox.filter(aFilters);
					} else if (oAppType === "ChangeRequest") {
						var oExtline = this.getView().getModel("pageModel").getData().wbsElementStr[0].Zentry_tp;
						if (oExtline === "E" || oExtline === "C") {
							var oProjectBox = this.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = new sap.ui.model.Filter({
								filters: [
									new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET23")
									// new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET24")  new RCR phase2 
								],
								and: false
							});
							oBindingBox.filter(aFilters);

						} else {

							var oProjectBox = this.getView().byId("idReqTypeDtls");
							var oBindingBox = oProjectBox.getBinding("items");
							var aFilters = [];
							var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET22");
							aFilters.push(oFilters);
							oBindingBox.filter(aFilters);
						}

					} else {
						var oProjectBox = this.getView().byId("idReqTypeDtls");
						var oBindingBox = oProjectBox.getBinding("items");
						var aFilters = [];
						var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Standard Internal Project(Funded)");
						aFilters.push(oFilters);
						oBindingBox.filter(aFilters);
					}

				} else if (sSelect === "Spanish Delivery Project") {
					//   Phase2 -  Opening  Popup  for  spanish model to select spanish project
					var oComCode = this.getView().byId("idT1ComCode").getValue();
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					// var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Spanish Delivery Project");
					var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET29");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);

					if (oComCode === "ES87" || oComCode === "ES88" || oComCode === "ES89") {
						var oView = this.getView();
						var oDialog = oView.byId("idIwoOwner");
						// create dialog lazily
						if (!oDialog) {
							// create dialog via fragment factory
							oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.spanish", this);
							oView.addDependent(oDialog);
							oDialog.open();
						}
						this.getView().byId("idT2LdPracSet").setRequired(true);
						this.getView().byId("idT2OpporId").setRequired(true);
						this.getView().byId("idT2OpporId").setEditable(true);
						this.getView().byId("idT2RevMthd").setEditable(true);
						this.getView().byId("idT2ContractType").setEditable(true);
						this.getView().byId("idGlobProj").setSelected(false);
						this.getView().byId("idGlobProj").setEditable(true);
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().projType = "Trade";
						this.getView().getModel("appView").refresh(true);
					}

					//   End of phase2 changes spanish  mdoel
				} else if (sSelect === "Business & Development Project") {
					this.getView().byId("idT2LdPracSet").setValue("HQCEX");
					this.getView().byId("idT2RevMthd").setEditable(false);
					this.getView().byId("idT2LdPracSet").setRequired(true);
					this.getView().byId("idT2OpporId").setRequired(true);
					this.getView().byId("idGlobProj").setSelected(true);
					this.getView().byId("idGlobProj").setEditable(false);
					// if (oType === "ChangeProject" || oType === "uploadProject") {
					// 	this.getView().byId("idT2OpporId").setEditable(false);
					// 	this.getView().byId("idT2LdPracSet").setEditable(false);
					// 	// this.getView().byId("idWBSTypeT1").setValue("HQCEX");
					// } else {
					this.getView().byId("idT2LdPracSet").setEditable(true);
					this.getView().byId("idT2OpporId").setEditable(true);
					// }
					var oComCode = this.getView().byId("idT1ComCode").getValue();
					var oBindingBoxT3 = this.getView().byId("idWBSTypeT1").getBinding("items");
					var aFiltersT3 = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "B"),
							// new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "R"),
							// new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "D"),
							// new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.EQ, "V")
						],
						and: false
					});
					oBindingBoxT3.filter(aFiltersT3);

					var oViewModel = this.getView().getModel("appView");
					var oAppType = oViewModel.getData().type;
					oViewModel.getData().oppAdmin = true;
					this.getView().getModel("appView").refresh(true);
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					if (oAppType === "ChangeProject" || oAppType === "uploadProject") {
						var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "Business & Development Project");
					} else {
						var oFilters = new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.EQ, "REQ_DET26");
					}

					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);

				}

				if (oType === "OpprApp") {

				} else if (oType === "ChangeProject" || oType === "DuplicateExisting") {

				} else {
					this.getView().byId("idT2ContractId").setSelectedKey("");
					this.getView().byId("idT2ContractId").setValue("");
					this.getView().byId("idT2ClientId").setValue("");
					this.getView().byId("idT2IndusCode").setValue("");
				}
			}

		},
		onSelectReqTypeCrossApp: function (sSelect) {
			// var okey = oEvent.getSource().getSelectedKey();
			// var sSelect = oEvent.getParameter("selectedItem").getKey();
			// this.onInputValidation(oEvent);
			if (sSelect === "New Logo") {
				var oProjectBox = this.getView().byId("idReqTypeDtls");
				var oBindingBox = oProjectBox.getBinding("items");
				var aFilters = [];
				var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "New Logo");
				aFilters.push(oFilters);
				oBindingBox.filter(aFilters);
			} else {
				if (sSelect === "New Project") {
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "New Project");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);
				} else if (sSelect === "WBS Add/Change without CAN") {
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "WBS Add/Change without CAN");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);
				} else if (sSelect === "WBS Add/Change including CAN") {
					var oProjectBox = this.getView().byId("idReqTypeDtls");
					var oBindingBox = oProjectBox.getBinding("items");
					var aFilters = [];
					var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "WBS Add/Change including CAN");
					aFilters.push(oFilters);
					oBindingBox.filter(aFilters);
				}
			}

		},
		onSelectReqTypeDetails: function (oEvent) {
			var okey = oEvent.getSource().getSelectedKey();
			var sSelect = oEvent.getParameter("selectedItem").getKey();
			this.onInputValidation(oEvent);
			this.onDisplayPriority(sSelect);

		},
		onSelectReqFunction: function (oEvent) {
			var okey = oEvent.getSource().getSelectedKey();
			var sSelect = oEvent.getParameter("selectedItem").getKey();
			var itemDetails = this.getView().getModel("pageModel").getData().wbsElementStr;
			if (itemDetails.length > 0) {
				// if (itemDetails[0].Zentry_tp === "E") {
				// 	var allow = "true";
				// } else {
				var allow = itemDetails[0].Zentry_tp;
				// }
			} else {
				var allow = "";
			}

			this.onInputValidation(oEvent);
			if (sSelect === "REQ_FUN1") {
				this.getView().byId("idT2FinAnyst").setValueState("None");
				var oViewModel = this.getView().getModel("appView");
				// var RequestorName = oViewModel.getData().RequestorName;
				// var Requestor = oViewModel.getData().Requestor;
				var oUser = new UserInfo();
				var Requestor = oUser.getId();
				var olastName = oUser.getUser().getLastName().toUpperCase();
				var ofirstName = oUser.getUser().getFirstName().toUpperCase();
				var RequestorName = ofirstName + "," + olastName;
				// if (RequestorName) {
				var reqFun = RequestorName + "(" + Requestor + ")";
				var oType = oViewModel.getData().type;

				//= "OpprApp";
				// this.getView().byId("idT1FinAnyst").setSelectedKey(Requestor);
				// if (oType === "OpprApp" || allow === "true") {
				if (oType === "OpprApp") {

				} else {
					this.getView().getModel().getData().toDetails.FinApp = Requestor;
					// this.getView().byId("idT1FinAnyst").setSelectedKey(Requestor);
					this.getView().byId("idT1FinAnyst").setValue(reqFun);

					// this.getView().getModel().setProperty("/toDetails/FinApp", Requestor);
					if (oType === "ChangeProject") {

					} else if (allow === "E" || allow === "C") {

					} else {
						this.getView().getModel().getData().draftData.d.FinApp = Requestor;
						this.getView().byId("idT2FinAnyst").setValue(reqFun);
					}

					// this.getView().byId("idT2FinAnyst").setSelectedKey(Requestor);
					// this.getView().byId("idT2FinAnyst").setValue(reqFun);
					// this.getView().getModel().setProperty("/draftData/d/FinApp", Requestor);
					// this.getView().byId("idT2FinAnyst").setValueState("None");
				}
			} else {
				// this.getView().getModel().getData().draftData.d.FinApp = "";
				// this.getView().getModel().getData().toDetails.FinApp = "";
				// this.getView().byId("idT1FinAnyst").setValue("");
				// this.getView().byId("idT1FinAnyst").setSelectedKey("");
				// this.getView().byId("idT2FinAnyst").setSelectedKey("");
				// this.getView().byId("idT2FinAnyst").setValue("");
			}
		},
		onSelectServiOffering: function (oEvent) {
			var okey = oEvent.getSource().getSelectedKey();
			this.onInputValidation(oEvent);
			var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
			var rrCoastCenter = oEvent.getParameter("selectedItem").getKey();
			var Prctr = sSystem.split(":")[0];
			var Gsber = sSystem.split(":")[1];
			// var iRowIndex = this.onRowCount(oEvent);
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var wbsElement = this.getView().getModel().getProperty("/wbsElementStr");
			var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
			if (Gsber !== "M") {
				wbsElement[iRowIndex].ZzTaskOrderCat = Gsber;
			} else {
				wbsElement[iRowIndex].ZzTaskOrderCat = "";
			}
		},

		// onSelectProjectType: function (oEvent) {
		// 	var okey = oEvent.getSource().getSelectedKey();
		// 	// var sSelect = oEvent.getParameter("selectedItem").getKey();
		// 	this.onInputValidation(oEvent);
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	if (okey === "PRJ_TYP1") {
		// 		this.getView().getModel().getProperty("/wbsElementStr")[0].Prart = "C";
		// 		// var aFilters = new sap.ui.model.Filter({
		// 		// 	filters: [
		// 		// 		new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.Contains, "C"),
		// 		// 	],
		// 		// 	and: false
		// 		// });
		// 		// var that = this;
		// 		// oModel.read("/Search_WBS_TypeSet", {
		// 		// 	filters: [aFilters],
		// 		// 	// urlParameters: {
		// 		// 	// 	"$top": 100
		// 		// 	// },
		// 		// 	success: function (oResponse) {
		// 		// 		that.getView().getModel().getData().wbsType = [];
		// 		// 		that.getView().getModel().getData().wbsType = oResponse.results;
		// 		// 		// var wbsTypeData = new sap.ui.model.json.JSONModel(oResponse.results);
		// 		// 		// var oModel = that.getView().getModel();
		// 		// 		// var wbsElement = oModel.getProperty("/wbsType");
		// 		// 		// wbsElement.push(wbsTypeData.getData());
		// 		// 		// oModel.setProperty("/wbsType", wbsElement);
		// 		// 	},
		// 		// 	error: function (oError) {}
		// 		// });

		// 	} else if (okey === "PRJ_TYP2") {
		// 		this.getView().getModel().getProperty("/wbsElementStr")[0].Prart = "E";
		// 		// var aFilters = new sap.ui.model.Filter({
		// 		// 	filters: [
		// 		// 		new sap.ui.model.Filter("Prart", sap.ui.model.FilterOperator.Contains, "E"),
		// 		// 	],
		// 		// 	and: false
		// 		// });
		// 		// var that = this;
		// 		// oModel.read("/Search_WBS_TypeSet", {
		// 		// 	filters: [aFilters],
		// 		// 	success: function (oResponse) {
		// 		// 		that.getView().getModel().getData().wbsType = [];
		// 		// 		that.getView().getModel().getData().wbsType = oResponse.results;
		// 		// 		// var wbsTypeData = new sap.ui.model.json.JSONModel(oResponse.results);
		// 		// 		// var oModel = that.getView().getModel();
		// 		// 		// var wbsElement = oModel.getProperty("/wbsType");
		// 		// 		// wbsElement.push(wbsTypeData.getData());
		// 		// 		// oModel.setProperty("/wbsType", wbsElement);
		// 		// 	},
		// 		// 	error: function (oError) {}
		// 		// });
		// 	}
		// },
		onSuggestionProjCatgry: function (oEvent) {

			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pjcgid", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pjcgds", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionPersResp: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("NameFirst", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("NameLast", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestSpanish: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSelectSpanish: function () {
			var oProjID = this.getView().byId("SpanishID").getSelectedKey();
			var Zbukrs = this.getView().byId("idT1ComCode").getValue();
			var TYPE = "Spanish";
			if (oProjID) {
				var oDailog = this.byId("idIwoOwner");
				oDailog.destroy();
				this.onLoadChnageSpanishProject(oProjID, Zbukrs, TYPE);
			} else {
				this.getView().byId("SpanishID").setValue("");
				sap.m.MessageToast.show("Please select Spanish project from the suggestion", {
					duration: 5000
				});
			}
		},
		onSuggestCustID: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionContractId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var projType = this.getView().byId("idProjType").getSelectedKey();
			var reqType = this.getView().byId("idWBSTypeT1").getSelectedKey();
			var oViewModel = this.getView().getModel("appView");
			if (!reqType) {
				var reqType = this.getView().byId("idWBSTypeT1").getValue();
			}
			var PrartTyp;
			if (projType === "PRJ_TYP1") {
				var PrartTyp1 = "0040008063";
				var PrartTyp2 = "0040008064";
				var aFilters = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.NE, PrartTyp1),
						new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.NE, PrartTyp2),
						new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, sTerm),
						// new sap.ui.model.Filter("zindustry", sap.ui.model.FilterOperator.Contains, sTerm),
					],
					and: true
				});
			} else if (projType === "PRJ_TYP2") {
				var PrartTyp1 = "0040008063";
				var PrartTyp2 = "0040008064";

				if (oViewModel.getData().Admin === true && reqType === "B") {
					var PrartTyp1 = "0040008063";
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.NE, PrartTyp1),
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, sTerm),
						],
						and: true
					});
				} else if (reqType === "E" || reqType === "M" || reqType === "O" || reqType === "W") {
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, PrartTyp1),
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, sTerm),
						],
						and: true
					});
				} else if (oViewModel.getData().oSpanProj === "YES") {

					var PrartTyp1 = "0040008063";
					var PrartTyp2 = "0040008064";
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.NE, PrartTyp1),
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.NE, PrartTyp2),
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, sTerm),
							// new sap.ui.model.Filter("zindustry", sap.ui.model.FilterOperator.Contains, sTerm),
						],
						and: true
					});

				} else if (reqType === "J" || reqType === "R" || reqType === "D" || reqType === "V") {
					var aFilters = new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, PrartTyp2),
							new sap.ui.model.Filter("Pgid", sap.ui.model.FilterOperator.Contains, sTerm),
						],
						and: true
					});
				}
			}
			//var oSource = oEvent.getSource();
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionClientId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Zindustry", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Zkunnr", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionIndusCode: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Soarindds", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Soarincd", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionContractType: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("ZzContracttype", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("ZzContrtypeDes", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionLdPractice: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pcid", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Pcds", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionProjAdmin: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name_First", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Name_Last", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionPrjStatus: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pjsgst", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionOppId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Optyid", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionCustId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);

		},
		onContractId: function (oEvent) {
			// var sSelectedItem = oEvent.getParameter("getselectedItem");
			//var sType = this.getView().byId("").getValue();
			var okey = oEvent.getSource().getSelectedKey();
			if (okey === "PRJ_TYP1") {
				this.getView().byId("idT2ProjCategory").setValue("0040008063", "0040008064");
			} else if (okey === "PRJ_TYP2") {
				this.getView().byId("idT2ProjCategory").setValue();
			}
			// var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();

			// this.getView().byId("idT2ContractId").setValue(sSystem);
		},
		//pending
		onSuggestionRevMthd: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pjsgst", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionContractTrm: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Cntrcd", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Cntrds", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		//pending
		onSuggestionProgram: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//var oSource = oEvent.getSource();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Zzprogram", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Zzprogramname", sap.ui.model.FilterOperator.Contains, sTerm),
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionTaskOrder: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Field", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Descripton", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
		},
		/// ---Vinodh validation ------/////
		onInputValidation: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			//get the field ID
			var fieldid = oEvent.getParameter("id");
			if (newValue === "") {
				sap.ui.getCore().byId(fieldid).setValueState("Error");
				sap.ui.getCore().byId(fieldid).setValueStateText("Please enter the value.");
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");

			}
		},

		onValidation: function (oEvent) {

			var requiredInputs = this.ListOfRequiredFields();
			var passedValidation = this.validateEventFeedbackForm(requiredInputs);
			if (passedValidation === false) {
				//show an error message, rest of code will not execute.
				return false;
			} else if (passedValidation === true) {
				//show an error message, rest of code will not execute.
				return true;
			}

		},
		onValidationProperty: function (oEvent) { // enable fields on Validate button press - Rohit
			var oModel = this.getView().getModel("pageModel").getData().wbsElementStr;

			for (var i = 0; i < oModel.length; i++) {

			}

		},

		ListOfRequiredFields: function () {
			let requiredInputs;
			return requiredInputs = ['idT1ComCode', 'idProjType', 'idReqType', 'idReqTypeDtls', 'idReqTypeFun', 'idT1FinAnyst',
				'idT1Priority',
				'idT2SubbComm', 'idProjDefi', 'idT4ProjDefDesc', 'idStartDate', 'idEnddate', 'idT2PersResp', 'idT2ContractTrm', 'idT2PrjSts',
				'idT2ProjRespCC', 'idT2BusnsArea', 'idT2PrftCenter', 'idT2ContractId', 'idT2ContractType', 'idT2ProjAdmin', 'idWBSTypeT1'
			];
		},
		// , 'idT2ProjCategory', 'idT2FinAnyst'
		validateEventFeedbackForm: function (requiredInputs) {

			var _self = this;
			var valid = true;
			requiredInputs.forEach(function (input) {
				var sInput = _self.getView().byId(input);
				//||sInput.getValue() == undefined
				// Phase3 UAT Issue -  Project Definition value - if not filled correlty need to give value state error.
				if (input === "idProjDefi") {
					if (sInput.getValue() == "" || sInput.getValue().split(" ").length !== 1 || sInput.getValue().length !== 9) {
						valid = false;
						sInput.setValueState("Error");
					} else {
						sInput.setValueState("None");
					}

				} else {
					if (sInput.getValue() == "") {
						valid = false;
						sInput.setValueState("Error");
					} else {
						sInput.setValueState("None");
					}

				}

			});
			return valid;
		},

		//// ----------- vinodh    END ----------/////

		/*======================Mayank=============================*/
		onDatePickerValidation: function (oEvent) {
			var selDate = oEvent.getSource().getDateValue();
			var fieldID = oEvent.getParameter("id");
			var weekNo = selDate.getDay();
			// if (weekNo === 6 || weekNo === 0) {
			// 	sap.m.MessageToast.show('Cannot select weekends');
			// this.byId(fieldID).setValue("");
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			// this.byId("idEnddate").setValue("").setValueState("Error");
			this.byId("idEnddate").setValue("");
			this.byId("idEnddate").setMinDate(new Date(Year, month, day));
			// } else {
			// 	var Year = oEvent.getSource().getDateValue().getFullYear();
			// 	var day = oEvent.getSource().getDateValue().getDate();
			// 	var month = oEvent.getSource().getDateValue().getMonth();
			// 	// this.byId("idEnddate").setValue("").setValueState("Error");
			// 	this.byId("idEnddate").setValue("");
			// 	this.byId("idEnddate").setMinDate(new Date(Year, month, day));
			// }
		},
		handleFragDateChangeFore: function (oEvent) {
			var selDate = oEvent.getSource().getDateValue();
			var fieldID = oEvent.getParameter("id");
			var weekNo = selDate.getDay();
			// if (weekNo === 6 || weekNo === 0) {
			// 	sap.m.MessageToast.show('Cannot select weekends');
			// this.byId(fieldID).setValue("");
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			// this.byId("endMassDate").setValue("").setValueState("Error");
			this.byId("idEnddateAddiField").setValue("");
			this.byId("idEnddateAddiField").setMinDate(new Date(Year, month, day));
			// } else {
			// 	var Year = oEvent.getSource().getDateValue().getFullYear();
			// 	var day = oEvent.getSource().getDateValue().getDate();
			// 	var month = oEvent.getSource().getDateValue().getMonth();
			// 	// this.byId("endMassDate").setValue("").setValueState("Error");
			// 	this.byId("idEnddateAddiField").setValue("");
			// 	this.byId("idEnddateAddiField").setMinDate(new Date(Year, month, day));
			// }
		},
		handleFragDateChangeBasic: function (oEvent) {

			var selDate = oEvent.getSource().getDateValue();
			var fieldID = oEvent.getParameter("id");
			var weekNo = selDate.getDay();
			// if (weekNo === 6 || weekNo === 0) {
			// 	sap.m.MessageToast.show('Cannot select weekends');
			// this.byId(fieldID).setValue("");
			var selDate = oEvent.getSource().getDateValue();
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			// this.byId("endMassDate").setValue("").setValueState("Error");
			var weekNo = selDate.getDay();
			this.byId("idBasicEDate").setValue("");
			this.byId("idBasicEDate").setMinDate(new Date(Year, month, day));
			// } else {
			// 	var selDate = oEvent.getSource().getDateValue();
			// 	var Year = oEvent.getSource().getDateValue().getFullYear();
			// 	var day = oEvent.getSource().getDateValue().getDate();
			// 	var month = oEvent.getSource().getDateValue().getMonth();
			// 	// this.byId("endMassDate").setValue("").setValueState("Error");
			// 	var weekNo = selDate.getDay();
			// 	this.byId("idBasicEDate").setValue("");
			// 	this.byId("idBasicEDate").setMinDate(new Date(Year, month, day));
			// }
		},
		onGetWeekDays: function (oEvent) {

			var selDate = oEvent.getSource().getDateValue();
			var fieldID = oEvent.getParameter("id");
			var weekNo = selDate.getDay();
			if (weekNo === 6 || weekNo === 0) {
				// sap.m.MessageToast.show('Cannot select weekends');
				// this.byId(fieldID).setValue("");
			}
		},
		checkSpecialChars1: function (evt) {
			var str = evt.getParameter("value");
			var sControlId = evt.getParameter("id");
			var s = "#";
			if (str.length === 1) {
				if (s.indexOf(str.charAt(0)) != -1) {
					this.getView().byId(sControlId).setValueState("None");
					this.getView().byId(sControlId).setValue(str.replace("#", ""));
					this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
				} else {
					this.getView().byId(sControlId).setValueState("None");
					this.getView().byId(sControlId).setValueStateText("None");
				}
			}
			// this.onSubEnable();
		},
		checkSpecialChars: function (evt) {
			var str = evt.getParameter("value");
			var sControlId = evt.getParameter("id");
			// var s = "*%!@$^&()+=-_[]\\\';,./{}|\":<>?";
			var s = "*%";
			var s1 = "#";
			for (var i = 0; i < str.length; i++) {
				if (i === 0 && s1.indexOf(str.charAt(0)) != -1) {
					this.getView().byId(sControlId).setValueState("None");
					this.getView().byId(sControlId).setValue(str.replace("#", ""));
					this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
				}
				if (s.indexOf(str.charAt(i)) != -1) {
					this.getView().byId(sControlId).setValueState("None");
					this.getView().byId(sControlId).setValue(str.slice(0, -1));
					this.getView().byId(sControlId).setValueStateText("Special characters are not allowed");
				} else {
					this.getView().byId(sControlId).setValueState("None");
					this.getView().byId(sControlId).setValueStateText("None");
				}
			}
			// this.onSubEnable();
		},
		// onAddComaDecilal: function (evt) {
		// 	var str = evt.getParameter("value");
		// 	var sControlId = evt.getParameter("id");
		// 	var nStr = str.replace(/,/g, '');
		// 	var oDeciml = parseFloat(nStr).toFixed(2);
		// 	var oSplit = oDeciml.split(".");
		// 	if(oSplit[0].length <= 13){
		// 		var nValue = oDeciml.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
		// 		this.getView().byId(sControlId).setValue(nValue);
		// 		this.getView().byId(sControlId).setValueState("None");
		// 	}else{
		// 		this.getView().byId(sControlId).setValueState("Error");
		// 		sap.m.MessageToast.show('please enter only 13 digit before the decimal');
		// 	}
		// },
		// check19carInt: function (evt) {
		// 	var str = evt.getParameter("value");
		// 	var sControlId = evt.getParameter("id");
		// 	var regex = /^[0-9.,]+$/;
		// 	var s = "/^[0-9.,]+$/";
		// 	if(regex.test(str)){
		// 		// if(str.length === 17){
		// 		// 	this.getView().byId(sControlId).setValue(str.slice(0, -1));
		// 		// 	this.getView().byId(sControlId).setValue(".");
		// 		// }
		// 	}else{
		// 		this.getView().byId(sControlId).setValue(str.slice(0, -1));
		// 	}
		// 	// for (var i = 0; i < str.length; i++) {
		// 	// 	if(i === 0){
		// 	// 		if(str === "."){
		// 	// 			this.getView().byId(sControlId).setValue(str.slice(0, -1));
		// 	// 		}
		// 	// 	}

		// 	// 	if (s.indexOf(str.charAt(i)) != -1) {
		// 	// 		var oNString = str.replace(str.charAt(i),"")
		// 	// 		str = oNString;
		// 	// 		this.getView().byId(sControlId).setValue(str);

		// 	// 	}else{
		// 	// 		// if(i === 16 && str.indexOf(".") !== -1){
		// 	// 		// 	if(str.charAt(i) === "."){
		// 	// 		// 	}else{
		// 	// 		// 		str = str.slice(0, -1) + ".";
		// 	// 		// 		this.getView().byId(sControlId).setValue(str);
		// 	// 		// 	}
		// 	// 		// }

		// 	// 	}
		// 	// }
		// },

		/*Below method for search help*/
		onSuggestionCoCode: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Compcode", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSelectCoastCenter: function (oEvent) {

			if (oEvent.getParameter("selectedItem") !== null) {
				var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
				var rrCoastCenter = oEvent.getParameter("selectedItem").getKey();
				var Prctr = sSystem.split("-")[0];
				var Gsber = sSystem.split("-")[1];
				// this.getView().byId("idT4CosCtr").setValue(rrCoastCenter);
				// this.getView().byId("idT2BusnsArea").setSelectedKey(Gsber);
				// this.getView().byId("idT2PrftCenter").setSelectedKey(Prctr);
				this.getView().byId("idT2BusnsArea").setValue(Gsber);
				this.getView().byId("idT2PrftCenter").setValue(Prctr);
				var oModel = this.getView().getModel("pageModel");

				var oViewModel = this.getView().getModel("appView");
				var oType = oViewModel.getData().type;
				var Zentry_tp = this.getView().getModel("pageModel").getData().wbsElementStr[0].Zentry_tp;
				// var oTable = this.getView().getModel().getProperty("/wbsElementStr");
				if (oType === "ChangeProject" || Zentry_tp === "E" || oType === "ChangeRequest" || Zentry_tp === "C") {
					this.onSelectServiceOff();
					this.onSelectProjPhase();
				} else {
					if (Zentry_tp === "E" || Zentry_tp === "C") {
						this.onSelectServiceOff();
						this.onSelectProjPhase();
					} else {
						//Begin of  Commented  for Phase2 RCR - RCR: 341703   // Srinivas vallepu 
						// var oTable = oModel.getProperty("/wbsElementStr"); // rohit - change
						// if (oTable.length != 0) {
						// 	// rohit - begin change
						// 	// this.getView().getModel().getProperty("/wbsElementStr")[0].Fkstl = rrCoastCenter;
						// 	// this.getView().getModel().getProperty("/wbsElementStr")[0].Pgsbr = Gsber;
						// 	// this.getView().getModel().getProperty("/wbsElementStr")[0].Prctr = Prctr;
						// 	oModel.getProperty("/wbsElementStr")[0].Fkstl = rrCoastCenter;
						// 	oModel.getProperty("/wbsElementStr")[0].Pgsbr = Gsber;
						// 	oModel.getProperty("/wbsElementStr")[0].Prctr = Prctr;
						// 	//rohit - end change
						// }

						// var oModel = this.getView().getModel();
						// var wbsEleCunt = oModel.getProperty("/wbsElementStr").length;
						// if (wbsEleCunt >= 1) {
						// 	var oViewModel = oModel.getProperty("/wbsElementStr");
						// 	for (var i = 0; i < wbsEleCunt; i++) {
						// 		oViewModel[i].Fkstl = rrCoastCenter;
						// 		oViewModel[i].Pgsbr = Gsber;
						// 		oViewModel[i].Prctr = Prctr;
						// 	}
						// }
						//End of Commented for Phase2 RCR - RCR: 341703   // Srinivas vallepu 
						this.onSelectServiceOff(Gsber);
						this.onSelectProjPhase(Gsber);
						var oViewModel = this.getView().getModel("appView");
						var type = oViewModel.getData().type;
						if (type === "OpprApp") {
							this.onSelectOppAppDataTab4();
						}
						var oAdmin = oViewModel.getData().Admin;
						var sReqType1 = this.getView().byId("idReqType").getValue();
						if (oAdmin && sReqType1 === "Business & Development Project") {
							this.onSelectOppAppDataTab4();
						}

					}

				}
			}

		},
		onSelectCoastCenterTab4: function (oEvent) {
			// var iRowIndex = this.onRowCount(oEvent);
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var keyID = oEvent.getSource().getSelectedKey();
			// var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
			var keyID = oEvent.getParameter("value");
			var pageContextid = oEvent.getSource().getBindingContext("pageModel").getPath(); // rohit - change
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Kostl", sap.ui.model.FilterOperator.Contains, keyID),
				],
				and: false
			});
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Search_Cost_CenterSet", {
				filters: [aFilters],
				success: function (oResponse) {

					var Prctr = oResponse.results[0].Prctr;
					var Gsber = oResponse.results[0].Gsber;
					// rohit - begin change
					// that.getView().getModel().getProperty("/wbsElementStr")[iRowIndex].Pgsbr = Gsber;
					// that.getView().getModel().getProperty("/wbsElementStr")[iRowIndex].Prctr = Prctr;
					that.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Pgsbr = Gsber;
					that.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Prctr = Prctr;
					// that.onSelectServiceOffTab4(Gsber, iRowIndex);
					// that.onSelectProjPhaseTab4(Gsber, iRowIndex);
					that.onSelectServiceOffTab4(Gsber, iRowIndex, pageContextid);
					that.onSelectProjPhaseTab4(Gsber, iRowIndex, pageContextid);
					// rohit - end change

				},
				error: function (oError) {}
			});

		},
		// onSelectWBStypeTab4: function (oEvent) {
		// 	var iRowIndex = this.onRowCount(oEvent);
		// 	var keyID = oEvent.getSource().getSelectedKey();
		// 	var Gsber = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].getValue();
		// 	this.onSelectProjPhaseTab4(Gsber, iRowIndex);
		// 	if (keyID === "R") {
		// 		wbsElement[iRowIndex].Ustatusline = "CATS";
		// 		var id = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[17].getId();

		// 		var oProjectBox = this.getView().byId(id);
		// 		var oBindingBox = oProjectBox.getBinding("items");
		// 		var aFilters = [];
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD");
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS");

		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.NE, "OPEN");
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.NE, "NOLA");
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.NE, "CANS");
		// 		aFilters.push(oFilters);
		// 		oBindingBox.filter(aFilters);
		// 	} else {
		// 		var id = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[17].getId();

		// 		var oProjectBox = this.getView().byId(id);
		// 		var oBindingBox = oProjectBox.getBinding("items");
		// 		var aFilters = [];
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD");
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN");
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA");

		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.NE, "CANS");
		// 		var oFilters = new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.NE, "CATS");
		// 		aFilters.push(oFilters);
		// 		oBindingBox.filter(aFilters);
		// 	}
		// },
		onSelectServiceOff: function (Gsber) {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			aFilters.push(new Filter("VGSBR", sap.ui.model.FilterOperator.EQ, Gsber));
			var that = this;
			if (Gsber) {
				oModel.read("/Search_Service_OfferingSet", {
					filters: aFilters,
					success: function (oResponse) {
						//rohit - change
						var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");

						for (var m = 0; m < tableData.length; m++) { // Mayank - change
							var contextid = "/wbsElementStr/" + m.toString();
							var oCurrServiOff = tableData[m].Zzsolseid;
							var oNewResult = oResponse.results.filter(function (a) {
								return a.Solseid === oCurrServiOff;
							});
							if (oNewResult.length >= 1) {
								that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);
							} else {
								var oNewSerOff = {
									PCSGID: "",
									Solseds: "",
									Solseid: oCurrServiOff,
									VGSBR: "",
									ZZ_TOC: ""
								};
								var OCopyData = oResponse.results;
								OCopyData.push(oNewSerOff);
								that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", OCopyData);
							}
						}

					},
					error: function (oError) {}
				});
			} else {
				oModel.read("/Search_Service_OfferingSet", {
					success: function (oResponse) {
						//rohit - change
						var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
						//341844 - 
						oResponse.results = [...new Map(oResponse.results.map(item => [item["Solseid"], item])).values()];

						for (var m = 0; m < tableData.length; m++) { // Mayank - change
							var contextid = "/wbsElementStr/" + m.toString();
							var oCurrServiOff = tableData[m].Zzsolseid;
							var oNewResult = oResponse.results.filter(function (a) {
								return a.Solseid === oCurrServiOff;
							});
							if (oNewResult.length >= 1) {
								that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);
							} else {
								var oNewSerOff = {
									PCSGID: "",
									Solseds: "",
									Solseid: oCurrServiOff,
									VGSBR: "",
									ZZ_TOC: ""
								};
								var OCopyData = oResponse.results;
								OCopyData.push(oNewSerOff);
								that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", OCopyData);
							}
							// that.getView().getModel("pageModel").setProperty(contextid + "/oServiOfferTempSet", oResponse.results);
						}
					},
					error: function (oError) {}
				});
			}

		},
		// onSelectWbsType: function (oValue) {
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	var aFilters = [];
		// 	if (oValue === "0040008064") {
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "J"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "R"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "D"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "B"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "V"));
		// 	} else if (oValue === "0040008063") {
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "E"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "M"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "O"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "W"));
		// 	} else {
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "C"));
		// 		aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "L"));
		// 	}

		// 	var that = this;
		// 	oModel.read("/Search_Proj_WBS_TypeSet", {
		// 		filters: aFilters,
		// 		success: function (oResponse) {
		// 			var oSerOff = new JSONModel(oResponse.results);
		// 			that.getView().setModel(oSerOff, "oWbsType");
		// 		},
		// 		error: function (oError) {}
		// 	});
		// },
		onSelectRAKey: function (oValue) {
			var oModel = this.getView().getModel("oDataModel");

			var that = this;
			oModel.read("/Search_RAKeySet", {
				success: function (oResponse) {
					var oRaKey = new JSONModel(oResponse.results);
					that.getView().setModel(oRaKey, "oRaKey");
				},
				error: function (oError) {}
			});
		},
		onSelectSystemStatus: function (oValue) {
			var oModel = this.getView().getModel("oDataModel");
			var that = this;
			oModel.read("/Search_System_StatusSet", {
				success: function (oResponse) {
					var oSysStatus = new JSONModel(oResponse.results);
					that.getView().setModel(oSysStatus, "oSysStatus");
				},
				error: function (oError) {}
			});
		},
		onSelectUserStatusaLL: function (prjType) {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			if (prjType === "PRJ_TYP2") {
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
			} else if (prjType === "PRJ_TYP1") {
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CSSP "));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "INTG "));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKAC "));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKCO"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "AMRT"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CCLS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
			} else {
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
			}

			var that = this;
			oModel.read("/Search_User_StatusSet", {
				filters: aFilters,
				success: function (oResponse) {
					var oUserStatus = new JSONModel(oResponse.results);
					that.getView().setModel(oUserStatus, "oUserStatusModel");
				},
				error: function (oError) {}
			});
		},
		onSelectProjPhase: function (Pgsbr) {
			var oModel = this.getView().getModel("oDataModel");
			var PrartTyp = this.getView().byId("idWBSTypeT1").getValue();
			var projType = this.getView().byId("idProjType").getSelectedKey();
			var PrartTyp;
			var aFilters = [];
			aFilters.push(new Filter("Pgsbr", sap.ui.model.FilterOperator.EQ, Pgsbr));
			aFilters.push(new Filter("Prart", sap.ui.model.FilterOperator.EQ, PrartTyp));
			var that = this;
			if (Pgsbr) {
				// filters: aFilters,
				oModel.read("/Search_proj_Phase_CodeSet", {
					urlParameters: {
						"$orderby": "ZzprojPhaseCd asc"
					},
					filters: aFilters,
					success: function (oResponse) {
						var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
						oResponse.results = [...new Map(oResponse.results.map(item => [item["ZzprojPhaseCd"], item])).values()];
						for (var m = 0; m < tableData.length; m++) {
							var contextid = "/wbsElementStr/" + m.toString();
							that.getView().getModel("pageModel").setProperty(contextid + "/oProjPhaseTempModl", oResponse.results);
						}
					},
					error: function (oError) {}
				});
			} else {
				oModel.read("/Search_proj_Phase_CodeSet", {
					urlParameters: {
						"$orderby": "ZzprojPhaseCd asc"
					},
					success: function (oResponse) {
						var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
						oResponse.results = [...new Map(oResponse.results.map(item => [item["ZzprojPhaseCd"], item])).values()];
						for (var m = 0; m < tableData.length; m++) {
							var contextid = "/wbsElementStr/" + m.toString();
							that.getView().getModel("pageModel").setProperty(contextid + "/oProjPhaseTempModl", oResponse.results);
						}
					},
					error: function (oError) {}
				});
			}

		},
		onLoadT1ProjType: function (oEvent) {
			var aKey = oEvent.getSource().getBindingContext().getObject('FIELD1');
		},
		onSelectcaseSafeID: function (oEvent) {
			// var iRowIndex = this.onRowCount(oEvent);
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			var keyID = oEvent.getSource().getSelectedKey();
			if (keyID != "") {
				var oAddiData = oEvent.getParameter("selectedItem").getAdditionalText();
				var Sol_typ = oAddiData.split("$")[0];
				var Cont_modl = oAddiData.split("$")[1];
				var Zzsolseid = oAddiData.split("$")[2];
				var Zz_toc = oAddiData.split("$")[3];
			} else {
				var Sol_typ = "";
				var Cont_modl = "";
				var Zzsolseid = "";
				var Zz_toc = "";
			}

			// var wbsElement = this.getView().getModel().getProperty("/wbsElementStr");
			var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
			wbsElement[iRowIndex].Sol_typ = Sol_typ;
			wbsElement[iRowIndex].Cont_modl = Cont_modl;
			wbsElement[iRowIndex].Zzsolseid = Zzsolseid;

			if (Zz_toc !== "M") {
				wbsElement[iRowIndex].ZzTaskOrderCat = Zz_toc;
			} else {
				wbsElement[iRowIndex].ZzTaskOrderCat = "";
			}

			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().type;
			if (type === "OpprApp") {
				var oppData = this.getView().getModel().getProperty("/toOpprData");
				var oDataUp = oppData.filter(function (a) {
					return a.CasesafeId === keyID;

				});
				var uniqID = oDataUp[0].UniqId;
				wbsElement[iRowIndex].UniqueId = uniqID;
			}

		},
		checkSpecialCharsTableOpp: function (evt) {
			var oViewModel = this.getView().getModel("appView");
			var oAdmin = oViewModel.getData().Admin;
			var sReqType1 = this.getView().byId("idReqType").getValue();
			if (oAdmin && sReqType1 === "Business & Development Project") {
				var str = evt.getParameter("value");
				var sControlId = evt.getParameter("id");
				var s = "#";
				var s1 = "*";
				var s2 = "%";
				if (str.length >= 1) {
					if (s.indexOf(str.charAt(0)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValue(str.replace("#", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					} else {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValueStateText("None");
					}
				}
				for (var i = 0; i < str.length; i++) {
					var oNew1 = this.getView().byId(sControlId).getValue();
					if (s.indexOf(oNew1.charAt(0)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						var oNew = this.getView().byId(sControlId).getValue();
						this.getView().byId(sControlId).setValue(oNew.replace("#", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					}

					if (s1.indexOf(str.charAt(i)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValue(oNew1.replace("*", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					} else if (s2.indexOf(str.charAt(i)) != -1) {
						this.getView().byId(sControlId).setValueState("None");
						this.getView().byId(sControlId).setValue(oNew1.replace("%", ""));
						this.getView().byId(sControlId).setValueStateText("Special characters # are not allowed");
					}
				}
			} else {
				// this.onGarbageValue(); 
				this.onChangeOpp(evt);
			}

			// this.onSubEnable();
		},
		onChangeOpp: function (oEvent) {
			var iRowIndex = this.onRowCountNew(oEvent);
			var newID = oEvent.getParameter("id");
			var oValue = oEvent.getParameter("value");
			if (oValue === "") {
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Safecase_id = "";
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Sol_typ = "";
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Cont_modl = "";
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Zzsolseid = "";
			}
		},
		onSelectOppIDTab4: function (oEvent) {

			// var iRowIndex = this.onRowCount(oEvent);
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var keyID = oEvent.getSource().getSelectedKey();
			// var keyID = oEvent.getParameter("value");
			var sRow = oEvent.getSource().getBindingContext("pageModel").getPath(); // rohit - change
			var keyID = oEvent.getParameters().selectedRow.mAggregations.cells[0].mProperties.text;
			// rohit - change begin
			// this.getView().getModel().getProperty("/wbsElementStr")[iRowIndex].Safecase_id = "";
			// this.getView().getModel().getProperty("/wbsElementStr")[iRowIndex].Sol_typ = "";
			// this.getView().getModel().getProperty("/wbsElementStr")[iRowIndex].Cont_modl = "";
			// this.getView().getModel().getProperty("/wbsElementStr")[iRowIndex].Zzsolseid = "";
			var sReqType1 = this.getView().byId("idReqType").getValue();
			if (sReqType1 !== "Business & Development Project") {
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Zzsolseid = "";
			}
			this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Safecase_id = "";
			this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Sol_typ = "";
			this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Cont_modl = "";
			// this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Zzsolseid = "";
			// rohit - change end
			// var id = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[12].getId();
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			aFilters.push(new Filter("Opt_id", sap.ui.model.FilterOperator.EQ, keyID));
			var that = this;
			oModel.read("/Search_Safecase_IDSet", {
				filters: aFilters,
				success: function (oResponse) {

					// var oSafecase = new JSONModel(oResponse.results);
					// that.getView().byId(id).setModel(oSafecase, "oSafecase");
					that.getView().getModel("pageModel").setProperty(sRow + "/oCaseSafeModel", oResponse.results); // rohit - change
				},
				error: function (oError) {}
			});
		},
		onSelectOppAppDataTab4: function (oEvent) {
			var oModel = this.getView().getModel("oDataModel");
			// var sRow = oEvent.getSource().getBindingContext("pageModel").getPath(); // rohit - change
			var oppData = this.getView().getModel().getProperty("/toOpprData");
			var oppID = oppData[0].OptId;
			var aFilters = [];
			for (var i = 0; i < oppData.length; i++) {
				aFilters.push(new sap.ui.model.Filter("Uniq_id", sap.ui.model.FilterOperator.Contains, oppData[i].CasesafeId));
			}
			aFilters.push(new sap.ui.model.Filter([
				new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, oppID),
			], false));
			// aFilters.push(new Filter("Opt_id", sap.ui.model.FilterOperator.EQ, keyID));
			var that = this;
			oModel.read("/Search_Safecase_IDSet", {
				filters: aFilters,
				success: function (oResponse) {
					var oSafecase = new JSONModel(oResponse.results);
					var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
					for (var m = 0; m < tableData.length; m++) { // rohit - change
						var contextid = "/wbsElementStr/" + m.toString();
						// 341869  
						//that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oResponse.results); // rohit - change

						var oCurrOptIF = that.getView().getModel("pageModel").getProperty(contextid + "/ZsfdcOppid");
						var oCurrCaseSafeID = tableData[m].Safecase_id;
						var oNewResult = oResponse.results.filter(function (a) {
							return a.Opt_id === oCurrOptIF;
						});

						if (oNewResult.length >= 1) {
							that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult);
						} else {
							var oNewCaseSafe = {
								Opt_id: "",
								Uniq_id: oCurrCaseSafeID,
								Zzsolseid: "",
								Cnt_typ: "",
								Sol_typ: "",
								Zz_toc: ""
							};
							var OCopyData = oResponse.results;
							OCopyData.push(oNewCaseSafe);
							that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", OCopyData);
						}
					}
				},
				error: function (oError) {}
			});
		},
		onSelectOppAppDataTab4All: function (oppID) {
			if (oppID) {
				var oModel = this.getView().getModel("oDataModel");
				// var oppData = this.getView().getModel().getProperty("/toOpprData");
				// var oppID = oppData[0].OptId;
				var aFilters = [];
				// for (var i = 0; i < oppData.length; i++) {
				// 	aFilters.push(new sap.ui.model.Filter("Uniq_id", sap.ui.model.FilterOperator.Contains, oppData[i].CasesafeId));
				// }
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, oppID),
				], false));
				var that = this;
				oModel.read("/Search_Safecase_IDSet", {
					filters: aFilters,
					success: function (oResponse) {
						var oSafecase = new JSONModel(oResponse.results);
						var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
						// for (var m = 0; m < tableData.length; m++) { // rohit - change
						// 	var contextid = "/wbsElementStr/" + m.toString();
						// 	that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oResponse.results); // rohit - change
						// }
						for (var m = 0; m < tableData.length; m++) { // rohit - change
							var contextid = "/wbsElementStr/" + m.toString();
							// 341869  
							//that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oResponse.results); // rohit - change

							var oCurrOptIF = that.getView().getModel("pageModel").getProperty(contextid + "/ZsfdcOppid");
							var oCurrCaseSafeID = tableData[m].Safecase_id;
							var oNewResult = oResponse.results.filter(function (a) {
								return a.Opt_id === oCurrOptIF;
							});

							if (oNewResult.length >= 1) {
								that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", oNewResult);
							} else {
								var oNewCaseSafe = {
									Opt_id: "",
									Uniq_id: oCurrCaseSafeID,
									Zzsolseid: "",
									Cnt_typ: "",
									Sol_typ: "",
									Zz_toc: ""
								};
								var OCopyData = oResponse.results;
								OCopyData.push(oNewCaseSafe);
								that.getView().getModel("pageModel").setProperty(contextid + "/oCaseSafeModel", OCopyData);
							}
						}
					},
					error: function (oError) {}
				});
			}
		},
		onSelectServiceOffTab4: function (Gsber, iRowIndex, pageContextid) {

			// var id = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[15].getId(); // rohit - change
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			aFilters.push(new Filter("VGSBR", sap.ui.model.FilterOperator.EQ, Gsber));
			var that = this;
			oModel.read("/Search_Service_OfferingSet", {
				filters: aFilters,
				success: function (oResponse) {

					// var oSerOff = new JSONModel(oResponse.results);
					// that.getView().byId(id).setModel(oSerOff, "oServiOffer");
					that.getView().getModel("pageModel").setProperty(pageContextid + "/oServiOfferTempSet", oResponse.results); // rohit - change
					// that.getView().getModel("pageModel").setProperty("/oServiOfferTempSet", oResponse.results); // rohit - change
				},
				error: function (oError) {}
			});
		},
		onSelectProjPhaseTab4: function (Gsber, iRowIndex, pageContextid) {

			// var wbsType = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[10].getValue(); // rohit - change
			// var getcurrrow = pageContextid.split("/")[2];
			// getcurrrow = parseInt(getcurrrow);
			// var wbsType = this.getView().getModel("pageModel").getData()[getcurrrow];
			// var oProjectBox = this.getView().byId(id); // rohit - change
			var wbsType = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Prart; // phase2 changes
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			aFilters.push(new Filter("Pgsbr", sap.ui.model.FilterOperator.EQ, Gsber));
			aFilters.push(new Filter("Prart", sap.ui.model.FilterOperator.EQ, wbsType));
			var that = this;
			oModel.read("/Search_proj_Phase_CodeSet", {
				filters: aFilters,
				urlParameters: {
					"$orderby": "ZzprojPhaseCd asc"
				},
				success: function (oResponse) {

					// var oProjPhase = new JSONModel(oResponse.results);
					// that.getView().byId(id).setModel(oProjPhase, "oProjPhase");

					that.getView().getModel("pageModel").setProperty(pageContextid + "/oProjPhaseTempModl", oResponse.results); // rohit - change

				},
				error: function (oError) {}
			});
		},
		// onSelectFinanceAnalyst: function (oEvent) {
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	var oModel = this.getView().getModel("oDataModel");

		// 	var that = this;
		// 	oModel.read("/Search_Finan_AnalystSet", {
		// 		success: function (oResponse) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 			var finAnly = new JSONModel(oResponse.results);
		// 			that.getView().setModel(finAnly, "oFinanceAnalyst");
		// 		},
		// 		error: function (oError) {}
		// 	});
		// },
		onSelectPersonResponsible: function (oEvent) {
			//Begin of  Commented  for Phase2 RCR - RCR: 341703   // Srinivas vallepu 
			// if (oEvent.getParameter("selectedItem") !== null) {
			// 	var sSystem = oEvent.getParameter("selectedItem").getKey();
			// 	var oTable = this.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
			// 	var oType = this.getView().getModel("appView").getData().type;
			// 	var oEntryType = oTable[0].Zentry_tp;
			// 	if (oTable.length != 0) {
			// 		if (oTable[0].Zentry_tp === "E" || oTable[0].Zentry_tp === "C" || oType === "ChangeProject") {

			// 		} else {
			// 			for (var i = 0; i < oTable.length; i++) {
			// 				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[i].Wbsowner1 = sSystem //rohit - change
			// 			}

			// 		}

			// 	}
			// }
			//End of Commented for Phase2 RCR - RCR: 341703   // Srinivas vallepu 
		},
		onSelectPrgContractID: function (oEvent) {
			if (oEvent.getParameter("selectedItem") !== null) {
				var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
				var rrCoastCenter = oEvent.getParameter("selectedItem").getKey();
				var zclntname = sSystem.split("-")[0];
				var zindustry = sSystem.split("-")[1];
				// this.getView().byId("idT4CosCtr").setValue(rrCoastCenter);
				// this.getView().byId("idT2ClientId").setSelectedKey(zclntname);
				// this.getView().byId("idT2IndusCode").setSelectedKey(zindustry);
				this.getView().byId("idT2ClientId").setValue(zclntname);
				this.getView().byId("idT2IndusCode").setValue(zindustry);
				// this.onSelectWbsType(rrCoastCenter);
			}

		},
		onSelectProjAdmin: function (oEvent) {
			//Begin of Commented for Phase2 RCR - RCR: 341703   // Srinivas vallepu 
			// var sSystem = oEvent.getParameter("selectedItem").getKey();
			// // var oTable = this.getView().getModel().getProperty("/wbsElementStr");
			// var oTable = this.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
			// var oType = this.getView().getModel("appView").getData().type;
			// var oEntryType = oTable[0].Zentry_tp;
			// if (oTable.length != 0) {
			// 	if (oEntryType === "E" || oEntryType === "C" || oType === "ChangeProject") {

			// 	} else {
			// 		for (var i = 0; i < oTable.length; i++) {
			// 			// this.getView().getModel().getProperty("/wbsElementStr")[i].PrjAd = sSystem
			// 			this.getView().getModel("pageModel").getProperty("/wbsElementStr")[i].PrjAd = sSystem // rohit - change
			// 		}
			// 		// this.getView().getModel().getProperty("/wbsElementStr")[0].PrjAd = sSystem;
			// 	}

			// }
			//End of Commented  for Phase2 RCR - RCR: 341703   // Srinivas vallepu 
		},
		onSelectOprtuID: function (oEvent) {
			var sSystem = oEvent.getParameter("selectedItem").getKey();
			// var oTable = this.getView().getModel().getProperty("/wbsElementStr");
			var oTable = this.getView().getModel("pageModel").getProperty("/wbsElementStr"); // rohit - change
			if (oTable.length != 0) {
				// this.getView().getModel().getProperty("/wbsElementStr")[0].ZsfdcOppid = sSystem;
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[0].ZsfdcOppid = sSystem; // rohit - change
			}
		},
		// onSelectT4CoastCenter: function (oEvent) {
		// 	var iRowIndex = this.onRowCount(oEvent); //Get Row index
		// 	var keyID = oEvent.getSource().getSelectedKey();

		// 	var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
		// 	var rrCoastCenter = oEvent.getParameter("selectedItem").getKey();
		// 	var Prctr = sSystem.split("-")[0];
		// 	var Gsber = sSystem.split("-")[1];

		// 	this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].setSelectedKey(Gsber);
		// 	this.getView().byId("idTable").getRows()[iRowIndex].getCells()[9].setSelectedKey(Prctr);
		// }, rohit - change

		onAllowEmpID: function (oEvent) {
			// 341845 - Addline
			var oValue = oEvent.getParameter("value");
			//341845  - Comment 
			//var oValue = oEvent.getSource()._sSelectedValue; //rohit - change
			var allow = isNaN(oValue);
			var oID = oEvent.getParameter("id");
			if (allow) {
				this.getView().byId(oID).setValue("");
				this.getView().byId(oID).setValueState("Error");
				MessageToast.show("Please select from dropdown or enter only Emp number.");
			} else { //rohit - change

				// var selectedIndex = oEvent.getSource().getBindingContext("pageModel").getPath();
				// selectedIndex = selectedIndex.split("/")[2];
				// oEvent.getSource().getBindingContext("pageModel").getProperty("/wbsElementStr")[selectedIndex].FinApp = oValue; // set selected value back to the row

			}
		},
		onSelectProjManager: function (oEvent) {

			// var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var projMngr = oEvent.getParameter("selectedItem").getKey();
			var projMgr = oEvent.getParameter("value");
			var allow = isNaN(projMgr); //true: string or false: number

			// var perResp = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[21].getValue();
			var perResp = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Wbsowner1;
			if (perResp === projMgr) {
				// this.getView().byId("idTable").getRows()[iRowIndex].getCells()[22].setValue("");
				// this.getView().byId("idTable").getRows()[iRowIndex].getCells()[22].setValueState("Error");
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Vernr = "";
				this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Vernr1ValueState = "Error";
				MessageToast.show("Project Manager and Person Responsible cannot be the same.");
			} else {
				if (allow) {
					// this.getView().byId("idTable").getRows()[iRowIndex].getCells()[22].setValue("");
					// this.getView().byId("idTable").getRows()[iRowIndex].getCells()[22].setValueState("Error");
					this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Vernr = "";
					this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Vernr1ValueState = "Error";
					MessageToast.show("Please select from dropdown or enter only Emp number.");
				} else {
					// this.getView().byId("idTable").getRows()[iRowIndex].getCells()[22].setValueState("None");
					this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Vernr1ValueState = "None";
				}

			}
			// var keyID = oEvent.getSource().getSelectedKey();

		},

		suggestionRowValidator: function (oColumnListItem) {
			var aCells = oColumnListItem.getCells();

			return new sap.ui.core.Item({
				key: aCells[1].getText(),
				text: aCells[0].getText()
			});
		},
		onRowCount: function (oEvent) {
			var oRow = oEvent.getSource().getParent(); //Get Row
			var oTable = oRow.getParent(); // Get Table
			return oTable.indexOfRow(oRow); //Get Row index
		},
		onRowCountNew: function (oEvent) {
			var sRow = oEvent.getSource().getBindingContext("pageModel").getPath();
			var oRowNum = sRow.split("/")[2];
			return parseInt(oRowNum, 10) //Get Row index
		},
		onCompanyCodeSelect: function (oEvent) {
			if (oEvent.getParameter("selectedItem") !== null) {
				var oViewModel = this.getView().getModel("appView");
				var oType = oViewModel.getData().type;
				if (oType === "DuplicateExisting") {

				} else {
					this.getView().byId("idProjType").setSelectedKey("");
				}
				this.getView().byId("idReqType").setSelectedKey("");
				this.getView().byId("idWBSTypeT1").setSelectedKey("");

				var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
				var sComCode = oEvent.getParameter("selectedItem").getKey();
				var SysId = sSystem.split("-")[0];
				var Proid = sSystem.split("-")[1];
				var oOrigSys = sSystem.split("-")[2];
				if (SysId === "COMPASS") {
					var oModel = this.getView().getModel();
					var oModelTab = this.getView().getModel("pageModel"); // rohit - change
					var wbsEleCunt = oModelTab.getProperty("/wbsElementStr").length;
					if (wbsEleCunt >= 1) {
						var oViewModel = oModel.getProperty("/wbsElementStr");
						var oViewModelTab = oModelTab.getProperty("/wbsElementStr");
						for (var i = 0; i < wbsEleCunt; i++) {
							// oViewModel[i].Bukrs = sComCode;
							oViewModelTab[i].Bukrs = sComCode;
							oViewModelTab[i].Fkstl = "";
							oViewModelTab[i].Pgsbr = "";
							oViewModelTab[i].Prctr = "";
						}
						var oViewModel1 = oModel.getProperty("/draftData");
						oViewModel1.d.Kostl = "";
						oViewModel1.d.Vgsbr = "";
						oViewModel1.d.Prctr = "";
						MessageToast.show("Successfully changed the Company code.");
						this.getView().byId("idProjDefi").setValue("");
						this.getView().byId("idProjDefi").setValueState("Error");
						this.getView().byId("idT2CoCode").setValue(sComCode);
						var m = Proid + "@-#####";
						this.getView().byId("idProjDefi").setMask(m);

						var mm = Proid + "1";
						this.getView().byId("idProjDefi").setValue(mm);

						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().sys_orign = oOrigSys;
						this.getView().getModel("appView").refresh(true);
					} else {
						this.getView().byId("idT2CoCode").setValue(sComCode);
						var m = Proid + "@-#####";
						this.getView().byId("idProjDefi").setMask(m);
						var mm = Proid + "1";
						this.getView().byId("idProjDefi").setValue(mm);
						var oViewModel = this.getView().getModel("appView");
						oViewModel.getData().sys_orign = oOrigSys;
						this.getView().getModel("appView").refresh(true);
					}

				} else {
					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: new sap.m.Text({
							text: "Are you sure you want to switch to C1 app?"
						}),
						beginButton: new sap.m.Button({
							text: "Ok",
							press: function () {
								sap.ushell.Container
									.getService("CrossApplicationNavigation")
									.toExternal({
										target: {
											semanticObject: "DXCGPRS",
											action: "createC1"
										},
										params: {
											"ComCode": sComCode
										},
										// appStateKey: oAppState.getKey()
									});
								// MessageToast.show("Please select Compass company code.");
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
								that.getView().byId("idT1ComCode").setValue("");
								MessageToast.show("Please select Compass company code.");
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
					// MessageToast.show("Please select Compass company code.");
				}
			}
		},
		onCustIDSelect: function (oEvent) {
			var sSystem = oEvent.getParameter("selectedItem").getAdditionalText();
			this.getView().byId("idT2CustNme").setValue(sSystem);
		},
		onSuggestionFNCANALYSID: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Perid", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionProjType: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Project", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionProfCtr: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Prctr", sap.ui.model.FilterOperator.Contains, sTerm),
					new sap.ui.model.Filter("Kokrs", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: false
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		// onSuggestionContract: function (oEvent) {
		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Cntrcd", sap.ui.model.FilterOperator.Contains, sTerm),
		// 			new sap.ui.model.Filter("Cntrds", sap.ui.model.FilterOperator.Contains, sTerm)
		// 		],
		// 		and: false
		// 	});
		// 	oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		// },

		onSuggestionSerOffer: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			// var iRowIndex = this.onRowCount(oEvent); //Get Row index
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var busiArea = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[8].getValue();
			var busiArea = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Pgsbr; // Changes for phase 2
			// var resCC = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[7].getValue();
			var aFilters = new sap.ui.model.Filter({
				filters: [
					// new sap.ui.model.Filter("PCSGID", sap.ui.model.FilterOperator.Contains, resCC),
					new sap.ui.model.Filter("VGSBR", sap.ui.model.FilterOperator.Contains, busiArea),
					new sap.ui.model.Filter("Solseid", sap.ui.model.FilterOperator.Contains, sTerm)
				],
				and: true
			});
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		/*Below method for WBS Guided Model and WBS element*/

		onNextWbsElement: function (oEvent) {
			var wbsLevel = this.getView().byId("idRangeSlider").getValue();
			wbsLevel = parseInt(wbsLevel, 10);
			var projDefValue = this.getView().byId("idProjDefi").getValue();
			var t1CoCode = this.getView().byId("idT1ComCode").getValue();
			var oktxt = this.getView().byId("idT4ProjDefDesc").getValue();
			var oOppID = this.getView().byId("idT2OpporId").getValue();
			var wbsEleLev1 = projDefValue;
			if (wbsEleLev1) {
				// var oModel = this.getView().getModel();
				var oModelTab = this.getView().getModel("pageModel"); // rohit - change
				var wbsEleCunt = oModelTab.getProperty("/wbsElementStr").length;
				// var selectedbusarea = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[0].Pgsbr; //rohit - change

				var tab3Valid = this.onTab3Validate();
				if (tab3Valid) {
					var a1 = oModelTab.getProperty("/wbsElementStr");
					a1[0].Arktx = oktxt;
					if (wbsEleCunt > 1) {
						var that = this;
						var dialog = new sap.m.Dialog({
							title: "Confirm",
							type: "Message",
							content: new sap.m.Text({
								text: "Regenerating the structure will clear the data from the WBS Details tab."
							}),
							beginButton: new sap.m.Button({
								text: "Ok",
								press: function () {
									// sap.ui.core.BusyIndicator.show(0);
									// that.getView().setBusy(true);

									var oGlobalBusyDialog = new sap.m.BusyDialog();
									oGlobalBusyDialog.open();
									for (var i = wbsEleCunt - 1; i >= 1; i--) {
										// var idx = wbsEleCunt[i];
										// var oModel = that.getView().getModel();
										var oModelTab = that.getView().getModel("pageModel"); // rohit - change
										var itab = oModelTab.getProperty("/wbsElementStr");
										itab.splice(i, 1)
											// itab.push(itemRow);
											// oModel.setProperty("/wbsElementStr", itab);
										oModelTab.setProperty("/wbsElementStr", itab); //rohit - change
									}

									dialog.close();
									that.onAddNextWBSElement(wbsEleLev1, t1CoCode, projDefValue);
									oGlobalBusyDialog.close();
									var selectedbusarea = that.getView().getModel("pageModel").getProperty("/wbsElementStr")[0].Pgsbr;
									that.onSelectServiceOff(selectedbusarea);
									that.onSelectProjPhase(selectedbusarea);
									var oProTyp = that.getView().byId("idProjType").getSelectedKey();
									that.onSelectUserStatus(oProTyp); //Mayank: To load User Status.
									that.onSelectOppAppDataTab4All(oOppID); //Mayank: To load Safecase id.
									// that.getView().setBusy(false);
									// sap.ui.core.BusyIndicator.hide();
								}
							}),
							endButton: new sap.m.Button({
								text: "Cancel",
								press: function () {
									sap.ui.core.BusyIndicator.hide();
									dialog.close();
								}
							}),
							afterClose: function () {
								dialog.destroy();
							}
						});
						dialog.open();
					} else {
						// sap.ui.core.BusyIndicator.show(0);
						// var a = new sap.m.BusyDialog()
						// a.open();
						// a.setBusyIndicatorDelay(100000);
						var oGlobalBusyDialog = new sap.m.BusyDialog();
						oGlobalBusyDialog.open();
						this.onAddNextWBSElement(wbsEleLev1, t1CoCode, projDefValue);
						oGlobalBusyDialog.close();
						// a.close();
						// sap.ui.core.BusyIndicator.hide();
						var selectedbusarea = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[0].Pgsbr;
						this.onSelectServiceOff(selectedbusarea);
						this.onSelectProjPhase(selectedbusarea);
						var oProTyp = this.getView().byId("idProjType").getSelectedKey();
						this.onSelectUserStatus(oProTyp); //Mayank: To load User Status.
						this.onSelectOppAppDataTab4All(oOppID); //Mayank: To load Safecase id.
					}
				} else {
					MessageToast.show("Please complete all the mandatory fields.");
				}
			} else {
				MessageToast.show("Please enter Project Definition.");
			}

		},
		onTab3Validate: function () {
			if (this.getView().byId("idLev2").getVisible()) {
				// var a2 = parseInt(this.getView().byId("idLev2").getValue(), 10);
				if (this.getView().byId("idLev2").getValue() === "") {
					this.getView().byId("idLev2").setValueState("Error");
					return false;
				} else {
					this.getView().byId("idLev2").setValueState("None");
				}
			} else {
				// var a2;
				this.getView().byId("idLev2").setValueState("None");
			}
			if (this.getView().byId("idLev3").getVisible()) {
				// var a3 = parseInt(this.getView().byId("idLev3").getValue(), 10);
				if (this.getView().byId("idLev3").getValue() === "") {
					this.getView().byId("idLev3").setValueState("Error");
					return false;
				} else {
					this.getView().byId("idLev3").setValueState("None");
				}
			} else {
				// var a3;
			}
			if (this.getView().byId("idLev4").getVisible()) {
				// var a4 = parseInt(this.getView().byId("idLev4").getValue(), 10);
				if (this.getView().byId("idLev4").getValue() === "") {
					this.getView().byId("idLev4").setValueState("Error");
					return false;
				} else {
					this.getView().byId("idLev4").setValueState("None");
				}
			} else {
				// var a4;
				this.getView().byId("idLev4").setValueState("None");
			}
			if (this.getView().byId("idLev5").getVisible()) {
				// var a5 = parseInt(this.getView().byId("idLev5").getValue(), 10);
				if (this.getView().byId("idLev5").getValue() === "") {
					this.getView().byId("idLev5").setValueState("Error");
					return false;
				} else {
					this.getView().byId("idLev5").setValueState("None");
				}
			} else {
				// var a5;
				this.getView().byId("idLev5").setValueState("None");
			}
			// if (this.getView().byId("idLev6").getVisible()) {
			// 	// var a6 = parseInt(this.getView().byId("idLev6").getValue(), 10);
			// 	if (this.getView().byId("idLev6").getValue() === "") {
			// 		this.getView().byId("idLev6").setValueState("Error");
			// 		return false;
			// 	} else {
			// 		this.getView().byId("idLev6").setValueState("None");
			// 	}
			// } else {
			// 	// var a6;
			// 	this.getView().byId("idLev6").setValueState("None");
			// }
			return true;
		},
		onAddNextWBSElement: function (wbsEleLev1, t1CoCode, projDefValue) {
			sap.ui.core.BusyIndicator.show(0);
			// this.getView().setBusy(true);
			if (this.getView().byId("idLev2").getVisible()) {
				var a2 = parseInt(this.getView().byId("idLev2").getValue(), 10);
			} else {
				var a2;
			}
			if (this.getView().byId("idLev3").getVisible()) {
				var a3 = parseInt(this.getView().byId("idLev3").getValue(), 10);
			} else {
				var a3;
			}
			if (this.getView().byId("idLev4").getVisible()) {
				var a4 = parseInt(this.getView().byId("idLev4").getValue(), 10);
			} else {
				var a4;
			}
			if (this.getView().byId("idLev5").getVisible()) {
				var a5 = parseInt(this.getView().byId("idLev5").getValue(), 10);
			} else {
				var a5;
			}
			// if (this.getView().byId("idLev6").getVisible()) {
			// 	var a6 = parseInt(this.getView().byId("idLev6").getValue(), 10);
			// } else {
			// 	var a6;
			// }
			var wbsEleList = [];
			wbsEleList.push(wbsEleLev1);
			var oModel = this.getView().getModel();

			var lev2 = [];
			var lev3 = [];
			var lev4 = [];
			var lev5 = [];

			/* i - it is for lavel 2*/
			for (var i = 1; i <= a2; i++) {
				if (i <= 9) {
					var wbsEle = wbsEleLev1.concat(".0", i);
					lev2.push(wbsEle);
					if (a3 > 0) {
						var wbsDown = wbsEle.concat(".0", 1);
					} else {
						var wbsDown = "";
					}

					if (i === 1 && a2 === 1) {
						var wbsLeft = "";
						var wbsRight = "";
					} else if (i === 1 && i < a2) {
						var right = wbsEleLev1.concat(".0", i + 1);
						var wbsLeft = "";
						var wbsRight = right;
					} else if (i !== 1 && i < a2) {
						var left = wbsEleLev1.concat(".0", i - 1);
						var right = wbsEleLev1.concat(".0", i + 1);
						var wbsLeft = left;
						var wbsRight = right;
					} else if (i !== 1 && i === a2) {
						var left = wbsEleLev1.concat(".0", i - 1);
						var wbsLeft = left;
						var wbsRight = "";
					}
					var serOffering = "";
					var PsPhiup = wbsEleLev1;
					var PsPhido = wbsDown;
					var PsPhile = wbsLeft;
					var PsPhiri = wbsRight;
					this.onAddWbsEle(projDefValue, wbsEle, t1CoCode, 2, "REL", "CRTD", "BLANK", PsPhiup, PsPhile, PsPhiri, PsPhido);
				} else {
					var wbsEle = wbsEleLev1.concat(".", i);
					lev2.push(wbsEle);
					if (a3 > 0) {
						var wbsDown = wbsEle.concat(".0", 1);
					} else {
						var wbsDown = "";
					}

					if (i === 1 && a2 === 1) {
						var wbsLeft = "";
						var wbsRight = "";
					} else if (i === 1 && i < a2) {
						var right = wbsEleLev1.concat(".", i + 1);
						var wbsLeft = "";
						var wbsRight = right;
					} else if (i !== 1 && i < a2) {
						var left = wbsEleLev1.concat(".", i - 1);
						var right = wbsEleLev1.concat(".", i + 1);
						var wbsLeft = left;
						var wbsRight = right;
					} else if (i !== 1 && i === a2) {
						var left = wbsEleLev1.concat(".", i - 1);
						var wbsLeft = left;
						var wbsRight = "";
					}
					var serOffering = "";
					var PsPhiup = wbsEleLev1;
					var PsPhido = wbsDown;
					var PsPhile = wbsLeft;
					var PsPhiri = wbsRight;
					this.onAddWbsEle(projDefValue, wbsEle, t1CoCode, 2, "REL", "CRTD", "BLANK", PsPhiup, PsPhile, PsPhiri, PsPhido);
				}
				/* j - it is for lavel 3*/
				for (var j = 1; j <= a3; j++) {
					var l3 = lev2.length;
					var wbsEleLev2 = lev2[l3 - 1];
					if (j <= 9) {
						var wbsEle3 = wbsEleLev2.concat(".0", j);
						lev3.push(wbsEle3);
						if (a4 > 0) {
							var wbsDown = wbsEle3.concat(".0", 1);
						} else {
							var wbsDown = "";
						}
						if (j === 1 && a3 === 1) {
							var wbsLeft = "";
							var wbsRight = "";
						} else if (j === 1 && j < a3) {
							var right = wbsEleLev2.concat(".0", j + 1);
							var wbsLeft = "";
							var wbsRight = right;
						} else if (j !== 1 && j < a3) {
							var left = wbsEleLev2.concat(".0", j - 1);
							var right = wbsEleLev2.concat(".0", j + 1);
							var wbsLeft = left;
							var wbsRight = right;
						} else if (j !== 1 && j === a3) {
							var left = wbsEleLev2.concat(".0", j - 1);
							var wbsLeft = left;
							var wbsRight = "";
						}
						var serOffering = "";
						var PsPhiup = wbsEleLev2;
						var PsPhido = wbsDown;
						var PsPhile = wbsLeft;
						var PsPhiri = wbsRight;
						this.onAddWbsEle(projDefValue, wbsEle3, t1CoCode, 3, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
					} else {
						var wbsEle3 = wbsEleLev2.concat(".", j);
						lev3.push(wbsEle3);
						if (a4 > 0) {
							var wbsDown = wbsEle3.concat(".0", 1);
						} else {
							var wbsDown = "";
						}
						if (j === 1 && a3 === 1) {
							var wbsLeft = "";
							var wbsRight = "";
						} else if (j === 1 && j < a3) {
							var right = wbsEleLev2.concat(".", j + 1);
							var wbsLeft = "";
							var wbsRight = right;
						} else if (j !== 1 && j < a3) {
							var left = wbsEleLev2.concat(".", j - 1);
							var right = wbsEleLev2.concat(".", j + 1);
							var wbsLeft = left;
							var wbsRight = right;
						} else if (j !== 1 && j === a3) {
							var left = wbsEleLev2.concat(".", j - 1);
							var wbsLeft = left;
							var wbsRight = "";
						}
						var serOffering = "";
						var PsPhiup = wbsEleLev2;
						var PsPhido = wbsDown;
						var PsPhile = wbsLeft;
						var PsPhiri = wbsRight;
						this.onAddWbsEle(projDefValue, wbsEle3, t1CoCode, 3, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
					}
					/* k - it is for lavel 4*/
					for (var k = 1; k <= a4; k++) {
						var l4 = lev3.length;
						var wbsEleLev3 = lev3[l4 - 1];
						if (k <= 9) {
							var wbsEle4 = wbsEleLev3.concat(".0", k);
							lev4.push(wbsEle4);
							if (a5 > 0) {
								var wbsDown = wbsEle4.concat(".0", 1);
							} else {
								var wbsDown = "";
							}
							if (k === 1 && a4 === 1) {
								var wbsLeft = "";
								var wbsRight = "";
							} else if (k === 1 && k < a4) {
								var right = wbsEleLev3.concat(".0", k + 1);
								var wbsLeft = "";
								var wbsRight = right;
							} else if (k !== 1 && k < a4) {
								var left = wbsEleLev3.concat(".0", k - 1);
								var right = wbsEleLev3.concat(".0", k + 1);
								var wbsLeft = left;
								var wbsRight = right;
							} else if (k !== 1 && k === a4) {
								var left = wbsEleLev3.concat(".0", k - 1);
								var wbsLeft = left;
								var wbsRight = "";
							}
							var serOffering = "";
							var PsPhiup = wbsEleLev3;
							var PsPhido = wbsDown;
							var PsPhile = wbsLeft;
							var PsPhiri = wbsRight;
							this.onAddWbsEle(projDefValue, wbsEle4, t1CoCode, 4, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
						} else {
							var wbsEle4 = wbsEleLev3.concat(".", k);
							lev4.push(wbsEle4);
							if (a5 > 0) {
								var wbsDown = wbsEle4.concat(".0", 1);
							} else {
								var wbsDown = "";
							}
							if (k === 1 && a4 === 1) {
								var wbsLeft = "";
								var wbsRight = "";
							} else if (k === 1 && k < a4) {
								var right = wbsEleLev3.concat(".", k + 1);
								var wbsLeft = "";
								var wbsRight = right;
							} else if (k !== 1 && k < a4) {
								var left = wbsEleLev3.concat(".", k - 1);
								var right = wbsEleLev3.concat(".", k + 1);
								var wbsLeft = left;
								var wbsRight = right;
							} else if (k !== 1 && k === a4) {
								var left = wbsEleLev3.concat(".", k - 1);
								var wbsLeft = left;
								var wbsRight = "";
							}
							var serOffering = "";
							var PsPhiup = wbsEleLev3;
							var PsPhido = wbsDown;
							var PsPhile = wbsLeft;
							var PsPhiri = wbsRight;
							this.onAddWbsEle(projDefValue, wbsEle4, t1CoCode, 4, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
						}
						/* l - it is for lavel 5 */
						for (var l = 1; l <= a5; l++) {
							var l5 = lev4.length;
							var wbsEleLev4 = lev4[l5 - 1];
							if (l <= 9) {
								var wbsEle5 = wbsEleLev4.concat(".0", l);
								lev5.push(wbsEle5);
								// if (a6 > 0) {
								// 	var wbsDown = wbsEle5.concat(".0", 1);
								// } else {
								// 	var wbsDown = "";
								// }
								if (l === 1 && a5 === 1) {
									var wbsLeft = "";
									var wbsRight = "";
								} else if (l === 1 && j < a5) {
									var right = wbsEleLev4.concat(".0", l + 1);
									var wbsLeft = "";
									var wbsRight = right;
								} else if (l !== 1 && l < a5) {
									var left = wbsEleLev4.concat(".0", l - 1);
									var right = wbsEleLev4.concat(".0", l + 1);
									var wbsLeft = left;
									var wbsRight = right;
								} else if (l !== 1 && l === a5) {
									var left = wbsEleLev4.concat(".0", l - 1);
									var wbsLeft = left;
									var wbsRight = "";
								}
								var serOffering = "";
								var PsPhiup = wbsEleLev4;
								// var PsPhido = wbsDown;
								var PsPhido = "";
								var PsPhile = wbsLeft;
								var PsPhiri = wbsRight;
								this.onAddWbsEle(projDefValue, wbsEle5, t1CoCode, 5, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
							} else {
								var wbsEle5 = wbsEleLev4.concat(".", l);
								lev5.push(wbsEle5);
								// if (a6 > 0) {
								// 	var wbsDown = wbsEle5.concat(".0", 1);
								// } else {
								// 	var wbsDown = "";
								// }
								if (l === 1 && a5 === 1) {
									var wbsLeft = "";
									var wbsRight = "";
								} else if (l === 1 && j < a5) {
									var right = wbsEleLev4.concat(".", l + 1);
									var wbsLeft = "";
									var wbsRight = right;
								} else if (l !== 1 && l < a5) {
									var left = wbsEleLev4.concat(".", l - 1);
									var right = wbsEleLev4.concat(".", l + 1);
									var wbsLeft = left;
									var wbsRight = right;
								} else if (l !== 1 && l === a5) {
									var left = wbsEleLev4.concat(".", l - 1);
									var wbsLeft = left;
									var wbsRight = "";
								}
								var serOffering = "";
								var PsPhiup = wbsEleLev4;
								// var PsPhido = wbsDown;
								var PsPhido = "";
								var PsPhile = wbsLeft;
								var PsPhiri = wbsRight;
								this.onAddWbsEle(projDefValue, wbsEle5, t1CoCode, 5, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
							}
							/* m - it is for lavel 6 */
							// for (var m = 1; m <= a6; m++) {
							// 	var l6 = lev5.length;
							// 	var wbsEleLev5 = lev5[l6 - 1];
							// 	if (m <= 9) {
							// 		var wbsEle6 = wbsEleLev5.concat(".0", m);
							// 		// if (a6 > 0) {
							// 		// 	var wbsDown = wbsEle6.concat(".0", 1);
							// 		// } else {
							// 		// 	var wbsDown = "";
							// 		// }
							// 		if (m === 1 && a6 === 1) {
							// 			var wbsmeft = "";
							// 			var wbsRight = "";
							// 		}
							// 		if (m === 1 && j < a6) {
							// 			var right = wbsEleLev5.concat(".0", m + 1);
							// 			var wbsmeft = "";
							// 			var wbsRight = right;
							// 		}
							// 		if (m !== 1 && m < a6) {
							// 			var meft = wbsEleLev5.concat(".0", m - 1);
							// 			var right = wbsEleLev5.concat(".0", m + 1);
							// 			var wbsmeft = meft;
							// 			var wbsRight = right;
							// 		}
							// 		if (m !== 1 && m === a6) {
							// 			var meft = wbsEleLev5.concat(".0", m - 1);
							// 			var wbsmeft = meft;
							// 			var wbsRight = "";
							// 		}

							// 		var serOffering = "";
							// 		var PsPhiup = wbsEleLev5;
							// 		var PsPhido = "";
							// 		var PsPhile = wbsmeft;
							// 		var PsPhiri = wbsRight;
							// 		this.onAddWbsEle(projDefValue, wbsEle6, t1CoCode, 6, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
							// 	} else {
							// 		var wbsEle6 = wbsEleLev5.concat(".", m);
							// 		if (m === 1 && a6 === 1) {
							// 			var wbsmeft = "";
							// 			var wbsRight = "";
							// 		}
							// 		if (m === 1 && j < a6) {
							// 			var right = wbsEleLev5.concat(".0", m + 1);
							// 			var wbsmeft = "";
							// 			var wbsRight = right;
							// 		}
							// 		if (m !== 1 && m < a6) {
							// 			var meft = wbsEleLev5.concat(".0", m - 1);
							// 			var right = wbsEleLev5.concat(".0", m + 1);
							// 			var wbsmeft = meft;
							// 			var wbsRight = right;
							// 		}
							// 		if (m !== 1 && m === a6) {
							// 			var meft = wbsEleLev5.concat(".0", m - 1);
							// 			var wbsmeft = meft;
							// 			var wbsRight = "";
							// 		}
							// 		var serOffering = "";
							// 		var PsPhiup = wbsEleLev5;
							// 		var PsPhido = "";
							// 		var PsPhile = wbsmeft;
							// 		var PsPhiri = wbsRight;
							// 		this.onAddWbsEle(projDefValue, wbsEle6, t1CoCode, 6, "REL", "OPEN", serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido);
							// 	}
							// }
						}
					}
				}
			}
			this.getView().byId("idIconTabBar").setSelectedKey("4");

			/* i - it is for lavel 1*/
			var oModel = this.getView().getModel("pageModel");
			var wbsElement = oModel.getProperty("/wbsElementStr")
				// var FinApp1 = this.getView().byId("idT2FinAnyst").getSelectedKey();

			if (this.getView().byId("idT2FinAnyst").getSelectedKey()) {
				var FinApp1 = this.getView().byId("idT2FinAnyst").getSelectedKey();
			} else {
				var FinApp1 = this.getView().getModel().getData().draftData.d.FinApp;
			}
			wbsElement[0].FinApp = FinApp1; //Mayank:Row 1 added the data

			if (this.getView().byId("idT2ProjAdmin").getSelectedKey()) {
				var PrjAd1 = this.getView().byId("idT2ProjAdmin").getSelectedKey();
			} else {
				var PrjAd1 = this.getView().getModel().getData().draftData.d.PrjAd;
			}
			wbsElement[0].PrjAd = PrjAd1; //Mayank: Row 1 added the data

			if (this.getView().byId("idT2PersResp").getSelectedKey()) {
				var Wbsowner1 = this.getView().byId("idT2PersResp").getSelectedKey();
			} else {
				var Wbsowner1 = this.getView().getModel().getData().draftData.d.Vernr;
			}
			wbsElement[0].Wbsowner1 = Wbsowner1; //Mayank:Row 1 added the data

			if (this.getView().byId("idT2ProjRespCC").getSelectedKey()) {
				var Kostl1 = this.getView().byId("idT2ProjRespCC").getSelectedKey();
			} else {
				var Kostl1 = this.getView().getModel().getData().draftData.d.Kostl;
			}
			wbsElement[0].Fkstl = Kostl1; //Mayank:Row 1 added the data

			if (this.getView().byId("idT2BusnsArea").getSelectedKey()) {
				var Vgsbr = this.getView().byId("idT2BusnsArea").getSelectedKey();
			} else {
				var Vgsbr = this.getView().getModel().getData().draftData.d.Vgsbr;
			}
			wbsElement[0].Pgsbr = Vgsbr;

			if (this.getView().byId("idT2PrftCenter").getSelectedKey()) {
				var Prctr = this.getView().byId("idT2PrftCenter").getSelectedKey();
			} else {
				var Prctr = this.getView().getModel().getData().draftData.d.Prctr;
			}
			wbsElement[0].Prctr = Prctr;

			// wbsElement[0].PrjAd = this.getView().byId("idT2ProjAdmin").getSelectedKey();
			// wbsElement[0].Wbsowner1 = this.getView().byId("idT2PersResp").getSelectedKey(); 
			// this.getView().byId("idTable").setVisibleRowCount(noItem);
			this.getView().byId("idTable").setVisibleRowCount(8); // rohit -change
			// this.getView().setBusy(false);
			sap.ui.core.BusyIndicator.hide();
		},
		onAddWbsEle: function (projDefValue, wbsEle, t1CoCode, level, sStatus, uStatus, serOffering, PsPhiup, PsPhile, PsPhiri, PsPhido) {
			// sap.ui.core.BusyIndicator.show(0);
			// var oModel = this.getView().getModel();
			var oModel = this.getView().getModel("pageModel"); // rohit - change
			var projType = this.getView().byId("idProjType").getSelectedKey();
			var PrartTyp = this.getView().byId("idWBSTypeT1").getValue();
			var oViewModel = this.getView().getModel("appView");
			if (projType === "PRJ_TYP1") {
				// var PrartTyp = "C";
			} else if (projType === "PRJ_TYP2") {
				// var PrartTyp = "";
				if (oViewModel.getData().Admin) {
					if (PrartTyp === "B") {
						if (level === 1 || level === 2) {
							serOffering = "BLANK";
						} else {
							serOffering = "C-OVHD";
						}
					} else {
						serOffering = "";
					}
				} else {
					serOffering = "";
				}
			}
			var oViewModel = this.getView().getModel("appView");
			var TYPE = oViewModel.getData().type;
			if (this.getView().getModel("pageModel").getProperty("/wbsElementStr").length > 0) {
				var oExtEntryType = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[0].Zentry_tp; // Phase2 Production issue.	
			} else {
				var oExtEntryType = "";
			}

			if (TYPE === "ChangeProject") {
				var indi = "N";
			} else if (TYPE === "ChangeRequest" && (oExtEntryType === "E" || oExtEntryType === "C")) { // Phase2 Production issue.
				var indi = "N";
			} else {
				var indi = "";
			}
			// if (TYPE === "OpprApp") {
			if (level === 1) {
				var oppID = "";
			} else if (level === 2) {
				var oppID = "";
			} else {
				var oppID = this.getView().byId("idT2OpporId").getValue();
			}
			// } else {
			// 	var oppID = "";
			// }

			if (this.getView().byId("idT2ProjAdmin").getSelectedKey()) {
				var PrjAd = this.getView().byId("idT2ProjAdmin").getSelectedKey();
			} else {
				var PrjAd = this.getView().getModel().getData().draftData.d.PrjAd;
			}
			//537
			// if (TYPE === "OpprApp") {
			// 	if (this.getView().byId("idT2PersResp").getSelectedKey()) {
			// 		var Wbsowner1 = this.getView().byId("idT2PersResp").getSelectedKey();

			// 	} else {
			// 		if (this.getView().byId("idT2PersResp").getValue()) {
			// 			var oResp = this.getView().byId("idT2PersResp").getValue();
			// 			var Wbsowner1 = oResp.split("(")[1].split(")")[0];
			// 		}

			// 	}

			// 	if (this.getView().byId("idT1FinAnyst").getSelectedKey()) {
			// 		var FinApp = this.getView().byId("idT1FinAnyst").getSelectedKey();
			// 	} else {
			// 		if (this.getView().byId("idT1FinAnyst").getValue()) {
			// 			var oFinApp = this.getView().byId("idT1FinAnyst").getValue();
			// 			var FinApp = oFinApp.split("(")[1].split(")")[0];
			// 		}
			// 	}

			// } else {

			if (this.getView().byId("idT2PersResp").getSelectedKey()) {
				var Wbsowner1 = this.getView().byId("idT2PersResp").getSelectedKey();
			} else {
				var Wbsowner1 = this.getView().getModel().getData().draftData.d.Vernr;
			}
			// var Vernr = this.getView().byId("idT2FinAnyst").getSelectedKey();
			if (this.getView().byId("idT2FinAnyst").getSelectedKey()) {
				var FinApp = this.getView().byId("idT2FinAnyst").getSelectedKey();
			} else {
				var FinApp = this.getView().getModel().getData().draftData.d.FinApp;
			}

			// }
			// 537

			var wbsElementRow = {
				"Zpspid": projDefValue,
				"Zposid": wbsEle,
				"oldZposid": wbsEle,
				"Bukrs": t1CoCode,
				"Arktx": "",
				"Stufe": level,
				"PsPhiup": PsPhiup,
				"PsPhile": PsPhile,
				"PsPhiri": PsPhiri,
				"PsPhido": PsPhido,
				"Plakz_bool": false,
				"Belkz_bool": false,
				"Fakkz_bool": false,
				"Safecase_id": "",
				"Sol_typ": "",
				"Cont_modl": "",
				"Fkstl": this.getView().byId("idT2ProjRespCC").getValue(),
				"Pgsbr": this.getView().byId("idT2BusnsArea").getValue(),
				"Prctr": this.getView().byId("idT2PrftCenter").getValue(),
				"Prart": PrartTyp,
				"Zzriskind_bool": false,
				"ZsfdcOppid": oppID,
				"RaKey": "PS-NRA",
				"Zzsolseid": serOffering,
				"Zcats": "",
				"ZzPlanWaers": "",
				"Systatusline": sStatus,
				"Ustatusline": uStatus,
				"ZzTaskOrder": "",
				"ZzGovCtrtype": "",
				"Usr01": "",
				"ZzUsr01": "",
				"ZzUsr02": "",
				"ZzUsr03": "",
				"PrjAd": PrjAd,
				"ZzTaskOrderCat": "",
				"Vernr": "",
				"ZzCapPt": "",
				"ZzStrategy": "",
				"Pspri": "",
				"ZzCapRat": "",
				"ZzMarkup": "",
				"ZzPtContact": "",
				"ZzAtcode": "",
				"Zz_vrcode": "",
				"Wbsowner1": Wbsowner1,
				"FinApp": FinApp,
				"Zentry_tp": indi
			};
			var wbsElement = oModel.getProperty("/wbsElementStr");
			wbsElement.push(wbsElementRow);
			oModel.setProperty("/wbsElementStr", wbsElement);
			// sap.ui.core.BusyIndicator.hide();
		},
		onDeleteWbsEle: function (oEvent) {
			var oTable = this.getView().byId("idTable");
			var aContexts = oTable.getSelectedIndices();
			var firstRow = 0;
			// var oModel = this.getView().getModel();
			var oModel = this.getView().getModel("pageModel"); // rohit - change
			var itab = oModel.getProperty("/wbsElementStr");

			if (aContexts.length !== 1) {
				MessageToast.show("Please select only one WBS Element to delete.");
			} else {
				var alwDele = itab[aContexts].Zentry_tp;
				if (alwDele === "E" || alwDele === "C") {
					MessageToast.show("Existing WBS elements cannot be deleted");
				} else {

					var that = this;
					var dialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: new sap.m.Text({
							text: "Are you sure you want to delete WBS Element?"
						}),
						beginButton: new sap.m.Button({
							text: "Ok",
							press: function () {
								// var aContexts = oTable.getSelectedIndices();
								var oTable1 = that.getView().byId("idTable");
								var selectedRow = oTable1.getSelectedIndices();
								if (selectedRow.length < 1) {
									MessageToast.show("Please select the WBS Element to delete.");
								} else if (selectedRow.length === 1) {
									//--> loop backward from the selected Rows
									for (var i = selectedRow.length - 1; i >= 0; i--) {
										var idx = selectedRow[i];
										// var oModel = that.getView().getModel();
										var oModel = that.getView().getModel("pageModel"); // rohit - change
										var itab = oModel.getProperty("/wbsElementStr");
										var nxtLvl = itab[idx].Stufe + 1;
										var oData1 = itab.filter(function (a) {
											return a.Stufe === nxtLvl;
										});
										var oData = oData1.filter(function (a) {
											return a.Zposid === itab[idx].PsPhido;
										});

										if (idx === 0) {
											firstRow = 1;
											MessageToast.show("Level 1 WBSE cannot be deleted.");
										} else {
											if (itab[idx].Stufe === 5) {
												var addPosition = itab.map(function (o) {
													return o.Zposid;
												}).indexOf(itab[idx].PsPhiup);
												itab[addPosition].PsPhido;
												itab[idx].Zposid;
												if (itab[addPosition].PsPhido === "") {

												} else if (itab[addPosition].PsPhido === itab[idx].Zposid) {
													itab[addPosition].PsPhido = "";
													if (itab[idx].PsPhiri) {
														var getPosiRight = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhiri);
														if (getPosiRight === -1) {

														} else {
															itab[addPosition].PsPhido = itab[idx].PsPhiri;
														}
													}
												} else {
													// itab[addPosition].PsPhido = "";
												}
												if (itab[idx].PsPhile) {
													var getPosiLeft = itab.map(function (o) {
														return o.Zposid;
													}).indexOf(itab[idx].PsPhile);
													if (getPosiLeft === -1) {

													} else {
														if (itab[idx].PsPhiri) {
															itab[getPosiLeft].PsPhiri = itab[idx].PsPhiri;
														} else {
															itab[getPosiLeft].PsPhiri = "";
														}
													}
												}
												if (itab[idx].PsPhiri) {
													var getPosRight = itab.map(function (o) {
														return o.Zposid;
													}).indexOf(itab[idx].PsPhiri);
													if (getPosRight === -1) {

													} else {
														if (itab[idx].PsPhile) {
															itab[getPosRight].PsPhile = itab[idx].PsPhile;
														} else {
															itab[getPosRight].PsPhile = "";
														}
													}
												}
												itab.splice(idx, 1);
												oModel.setProperty("/wbsElementStr", itab);
												MessageToast.show("WBS deleted.");
											} else if (itab[idx].PsPhido) {
												if (oData1.length === 0) {
													var addPosition = itab.map(function (o) {
														return o.Zposid;
													}).indexOf(itab[idx].PsPhiup);
													itab[addPosition].PsPhido;
													itab[idx].Zposid;
													if (itab[addPosition].PsPhido === "") {

													} else if (itab[addPosition].PsPhido === itab[idx].Zposid) {
														itab[addPosition].PsPhido = "";
														if (itab[idx].PsPhiri) {
															var getPosiRight = itab.map(function (o) {
																return o.Zposid;
															}).indexOf(itab[idx].PsPhiri);
															if (getPosiRight === -1) {

															} else {
																// itab[addPosition].PsPhido = itab[idx].PsPhiri;
															}
														}
													} else {
														// itab[addPosition].PsPhido = "";
													}
													if (itab[idx].PsPhile) {
														var getPosiLeft = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhile);
														if (getPosiLeft === -1) {

														} else {
															if (itab[idx].PsPhiri) {
																itab[getPosiLeft].PsPhiri = itab[idx].PsPhiri;
															} else {
																itab[getPosiLeft].PsPhiri = "";
															}
														}
													}
													if (itab[idx].PsPhiri) {
														var getPosRight = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhiri);
														if (getPosRight === -1) {

														} else {
															if (itab[idx].PsPhile) {
																itab[getPosRight].PsPhile = itab[idx].PsPhile;
															} else {
																itab[getPosRight].PsPhile = "";
															}
														}
													}
													itab.splice(idx, 1);
													oModel.setProperty("/wbsElementStr", itab);
													MessageToast.show("WBS deleted.");
												} else {
													if (oData.length === 0) {
														var addPosition = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhiup);
														itab[addPosition].PsPhido;
														itab[idx].Zposid;
														if (itab[addPosition].PsPhido === "") {

														} else if (itab[addPosition].PsPhido === itab[idx].Zposid) {
															itab[addPosition].PsPhido === "";
															if (itab[idx].PsPhiri) {
																var getPosiRight = itab.map(function (o) {
																	return o.Zposid;
																}).indexOf(itab[idx].PsPhiri);
																if (getPosiRight === -1) {

																} else {
																	itab[addPosition].PsPhido === itab[idx].PsPhiri;
																}
															}
														} else {
															// itab[addPosition].PsPhido === "";
														}
														if (itab[idx].PsPhile) {
															var getPosiLeft = itab.map(function (o) {
																return o.Zposid;
															}).indexOf(itab[idx].PsPhile);
															if (getPosiLeft === -1) {

															} else {
																if (itab[idx].PsPhiri) {
																	itab[getPosiLeft].PsPhiri = itab[idx].PsPhiri;
																} else {
																	itab[getPosiLeft].PsPhiri = "";
																}
															}
														}
														if (itab[idx].PsPhiri) {
															var getPosRight = itab.map(function (o) {
																return o.Zposid;
															}).indexOf(itab[idx].PsPhiri);
															if (getPosRight === -1) {

															} else {
																if (itab[idx].PsPhile) {
																	itab[getPosRight].PsPhile = itab[idx].PsPhile;
																} else {
																	itab[getPosRight].PsPhile = "";
																}
															}
														}
														itab.splice(idx, 1);
														oModel.setProperty("/wbsElementStr", itab);
														MessageToast.show("WBS deleted.");
													} else {
														MessageToast.show("Please delete child WBS before deleting parent WBS.");
													}
												}

											} else if (!itab[idx].PsPhido) {
												if (oData1.length === 0 && oData.length === 0) {
													var addPosition = itab.map(function (o) {
														return o.Zposid;
													}).indexOf(itab[idx].PsPhiup);
													itab[addPosition].PsPhido;
													itab[idx].Zposid;
													if (itab[addPosition].PsPhido === "") {

													} else if (itab[addPosition].PsPhido === itab[idx].Zposid) {
														itab[addPosition].PsPhido = "";
														if (itab[idx].PsPhiri) {
															var getPosiRight = itab.map(function (o) {
																return o.Zposid;
															}).indexOf(itab[idx].PsPhiri);
															if (getPosiRight === -1) {

															} else {
																itab[addPosition].PsPhido = itab[idx].PsPhiri;
															}
														}
													} else {
														// itab[addPosition].PsPhido === "";
													}
													if (itab[idx].PsPhile) {
														var getPosiLeft = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhile);
														if (getPosiLeft === -1) {

														} else {
															if (itab[idx].PsPhiri) {
																itab[getPosiLeft].PsPhiri = itab[idx].PsPhiri;
															} else {
																itab[getPosiLeft].PsPhiri = "";
															}
														}
													}
													if (itab[idx].PsPhiri) {
														var getPosRight = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhiri);
														if (getPosRight === -1) {

														} else {
															if (itab[idx].PsPhile) {
																itab[getPosRight].PsPhile = itab[idx].PsPhile;
															} else {
																itab[getPosRight].PsPhile = "";
															}
														}
													}
													itab.splice(idx, 1);
													oModel.setProperty("/wbsElementStr", itab);
													MessageToast.show("WBS deleted.");
												} else {
													if (oData.length === 0) {
														var addPosition = itab.map(function (o) {
															return o.Zposid;
														}).indexOf(itab[idx].PsPhiup);
														itab[addPosition].PsPhido;
														itab[idx].Zposid;
														if (itab[addPosition].PsPhido === "") {

														} else if (itab[addPosition].PsPhido === itab[idx].Zposid) {
															itab[addPosition].PsPhido = "";
															if (itab[idx].PsPhiri) {
																var getPosiRight = itab.map(function (o) {
																	return o.Zposid;
																}).indexOf(itab[idx].PsPhiri);
																if (getPosiRight === -1) {

																} else {
																	itab[addPosition].PsPhido = itab[idx].PsPhiri;
																}
															}
														} else {
															// itab[addPosition].PsPhido = "";
														}
														if (itab[idx].PsPhile) {
															var getPosiLeft = itab.map(function (o) {
																return o.Zposid;
															}).indexOf(itab[idx].PsPhile);
															if (getPosiLeft === -1) {

															} else {
																if (itab[idx].PsPhiri) {
																	itab[getPosiLeft].PsPhiri = itab[idx].PsPhiri;
																} else {
																	itab[getPosiLeft].PsPhiri = "";
																}
															}
														}
														if (itab[idx].PsPhiri) {
															var getPosRight = itab.map(function (o) {
																return o.Zposid;
															}).indexOf(itab[idx].PsPhiri);
															if (getPosRight === -1) {

															} else {
																if (itab[idx].PsPhile) {
																	itab[getPosRight].PsPhile = itab[idx].PsPhile;
																} else {
																	itab[getPosRight].PsPhile = "";
																}
															}
														}
														itab.splice(idx, 1);
														oModel.setProperty("/wbsElementStr", itab);
														MessageToast.show("WBS deleted.");
													} else {
														MessageToast.show("Please delete child WBS before deleting parent WBS.");
													}
												}
											}

										}
									}
									oTable1.clearSelection();
									that.onUpdateDefaultRowValue(itab, "DEL");
								} else {
									MessageToast.show("Please select only one WBS Element to delete.");
								}
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function () {
							dialog.destroy();
						}
					});
					dialog.open();
				}
			}

		},
		onUpdateDefaultRowValue: function (oData, oCondi) {
			if (oCondi === "ADD") {
				var oLength = oData.length - 1;
			} else if (oCondi === "DEL") {
				var oLength = oData.length;
			}
			var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr");
			var oTable1 = this.getView().byId("idTable");
			for (var i = 0; i < oLength; i++) {
				// var id = oTable1.getRows()[i].getCells()[1].getId();
				// this.getView().byId(id).getInterface()._$input[0].defaultValue = oData[i].Zposid
				wbsElement[i].oldZposid = wbsElement[i].Zposid; // for phase2 table
			}
		},
		onAutopopulateAddi: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var oRow = oEvent.getParameter("row");
			var rowNo = oEvent.getSource().getParent().getParent().getIndex();
			var oItem = oEvent.getParameter("item");
			// var wbsEleID = this.getView().getModel().getProperty("Zposid", oRow.getBindingContext());
			// var wbsEleID = this.getView().getModel("pageModel").getProperty("Zposid", oRow.getBindingContext()); rohit - change
			var wbsEleID = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[rowNo].Zposid; // rohit - change
			this.getView().getModel().getData().HeaderData.addiFildRowCont = rowNo;

			// var oModel = this.getView().getModel();
			var oModel = this.getView().getModel("pageModel"); // rohit - change
			var wbsElement = oModel.getProperty("/wbsElementStr");
			var oData = wbsElement.filter(function (a) {
				return a.Zposid === wbsEleID;
			});
			var oView = this.getView();
			var oDialog = oView.byId("idDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.Compass.WbsCompassRequest.fragments.WbsDetailAdditFields", this);
				oView.addDependent(oDialog);
			}
			oDialog.open();
			var oViewModel = this.getView().getModel("appView");
			var type = oViewModel.getData().type;
			var projType = this.getView().byId("idProjType").getSelectedKey();
			if (projType === "PRJ_TYP1") {

			} else if (projType === "PRJ_TYP2") {
				// var reqType = this.getView().byId("idReqType").getValue();
				// if (reqType = "Spanish Delivery Project") {

				// } else {
				this.onPopUpDisplayTnternal();
				// }
			}

			if (type === "View") {
				this.onPopUpDisplay();
			}
			var compCode = this.getView().byId("idT1ComCode").getSelectedKey();
			if ((compCode === "ES87" || compCode === "ES88" || compCode === "ES89") && projType === "PRJ_TYP2") {
				this.getView().byId("idGTMwbs").setEditable(true);
				this.getView().byId("idGTMwbs").setEnabled(true);
				this.getView().byId("idRiskInd").setEditable(false);
			}

			// if (oData[0].ZzTaskOrderCat !== "M" && oData[0].ZzTaskOrderCat !== "") {
			// 	this.getView().byId("idTaskOrder").setEditable(false);
			// } else {
			// 	this.getView().byId("idTaskOrder").setEditable(true);
			// }

			if (oData[0].Ustatusline === "CANS" || oData[0].Ustatusline === "CSSP" || oData[0].Ustatusline === "CCLS") {
				this.getView().byId("idCanType").setRequired(true);
				this.getView().byId("idAddPOC").setRequired(true);
			} else {
				this.getView().byId("idCanType").setRequired(false);
				this.getView().byId("idAddPOC").setRequired(false);
			}

			// if (projType === "PRJ_TYP1") {

			// } else if (projType === "PRJ_TYP2") {
			// 	this.onPopUpDisplayTnternal();
			// }
			// if (oData[0].Zentry_tp === "E") {
			// 	this.onPopUpDisplay();
			// }
			this.onChangeCanType1(oData[0].ZzCapPt);
			// oModel.getProperty("/additionData").push(oData[0]);;
			if (oData[0].ZzGovCtrtype) {
				this.getView().byId("idContType").setValue(oData[0].ZzGovCtrtype);
				this.getView().byId("idContType").setSelectedKey(oData[0].ZzGovCtrtype);
			}
			if (oData[0].ZzCapPt) {
				// this.getView().byId("idContType").setValue(oData[0].ZzGovCtrtype);
				this.getView().byId("idCanType").setSelectedKey(oData[0].ZzCapPt);
			}
			if (oData[0].Pspri) {
				// this.getView().byId("idContType").setValue(oData[0].ZzGovCtrtype);
				this.getView().byId("idPriority").setSelectedKey(oData[0].Pspri);
			}
			var oModel1 = new sap.ui.model.json.JSONModel(oData[0]);
			oDialog.setModel(oModel1, "WbsElem");
			sap.ui.core.BusyIndicator.hide();
		},
		onGlobalDateConversion: function (currdate) {
			// global date conversion logic - Rohit 

			if (typeof (currdate) === "string") {
				// 	var n = sDate1.getTimezoneOffset() / 60;
				// 	if (Math.sign(n) === -1) {
				// 		oDate1 = dateFormat.format(new Date(sDate1));
				// 		var oDate1 = oDate1 + "T14:00:00";
				// 		var startDateObject = new Date(oDate1);
				// 		currdate = startDateObject;
				// 		// draftData.d.Guebg = startDateObject;
				// 	} else {

				// 		var sDate1 = currdate;
				// 		sDate1 = sDate1.split("T");
				// 		var sDateonly = sDate1[0].split("-");
				// 		var findate = new Date(sDateonly[0], sDateonly[1] - 1, sDateonly[2]);
				// 		currdate = findate;
				// 	}
				// } else {

				var sDate1 = currdate;
				sDate1 = sDate1.split("T");
				// var sDateonly = sDate1[0].split("-");
				// var findate = new Date(sDateonly[0], sDateonly[1] - 1, sDateonly[2]);
				// var sDateonly =  sDate1[0];
				var findate = new Date(sDate1[0] + "T14:00:00");
				currdate = findate;
			}
			return currdate;
		},
		onAutopopulateAddiSave: function (oEvent) {

			sap.ui.core.BusyIndicator.show(0);
			if (this.onAutopopuAddiSaveValida()) {
				// var oModel = this.getView().getModel();
				var oModel = this.getView().getModel("pageModel"); // rohit - change
				var wbsElement = oModel.getProperty("/wbsElementStr");
				var selctRowCount = this.getView().getModel().getData().HeaderData.addiFildRowCont;
				var popUpData = this.getView().byId("idDialog").getModel("WbsElem");
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd"
				});
				if (popUpData.getData().PrteEstrt) {
					var sDate1 = popUpData.getData().PrteEstrt;
					var n = sDate1.getTimezoneOffset() / 60;
					if (Math.sign(n) === -1) {
						oDate1 = dateFormat.format(new Date(sDate1));
						var oDate1 = oDate1 + "T14:00:00";
						var startDateObject = new Date(oDate1);
						wbsElement[selctRowCount].PrteEstrt = startDateObject;
						// draftData.d.Guebg = startDateObject;
					} else {
						wbsElement[selctRowCount].PrteEstrt = popUpData.getData().PrteEstrt;
					}

				} else {
					wbsElement[selctRowCount].PrteEstrt = popUpData.getData().PrteEstrt;
				}

				if (popUpData.getData().PrteEende) {
					var sDate2 = popUpData.getData().PrteEende;
					var n = sDate2.getTimezoneOffset() / 60;
					if (Math.sign(n) === -1) {
						oDate1 = dateFormat.format(new Date(sDate2));
						var oDate1 = oDate1 + "T14:00:00";
						var startDateObject = new Date(oDate1);
						wbsElement[selctRowCount].PrteEende = startDateObject;
						// draftData.d.Guebg = startDateObject;
					} else {
						wbsElement[selctRowCount].PrteEende = popUpData.getData().PrteEende;
					}

				} else {
					wbsElement[selctRowCount].PrteEende = popUpData.getData().PrteEende;
				}

				// wbsElement[selctRowCount].PrteEende = popUpData.getData().PrteEende;

				wbsElement[selctRowCount].Zzriskind_bool = popUpData.getData().Zzriskind_bool;
				wbsElement[selctRowCount].Zcats = this.getView().byId("idTimeTrack").getValue();
				wbsElement[selctRowCount].ZzPlanWaers = this.getView().byId("idPlnRevCurr").getValue();
				wbsElement[selctRowCount].ZzUsr01 = popUpData.getData().ZzUsr01;
				wbsElement[selctRowCount].ZzUsr02 = popUpData.getData().ZzUsr02;
				wbsElement[selctRowCount].ZzUsr03 = popUpData.getData().ZzUsr03;
				wbsElement[selctRowCount].ZzTaskOrder = popUpData.getData().ZzTaskOrder;
				wbsElement[selctRowCount].ZzGovCtrtype = this.getView().byId("idContType").getValue();
				wbsElement[selctRowCount].Usr01 = popUpData.getData().Usr01;

				if (popUpData.getData().Vbegdat) {
					var sDate3 = popUpData.getData().Vbegdat;
					var n = sDate3.getTimezoneOffset() / 60;
					if (Math.sign(n) === -1) {
						oDate1 = dateFormat.format(new Date(sDate3));
						var oDate1 = oDate1 + "T14:00:00";
						var startDateObject = new Date(oDate1);
						wbsElement[selctRowCount].Vbegdat = startDateObject;
						// draftData.d.Guebg = startDateObject;
					} else {
						wbsElement[selctRowCount].Vbegdat = popUpData.getData().Vbegdat;
					}

				} else {
					wbsElement[selctRowCount].Vbegdat = popUpData.getData().Vbegdat;
				}
				// wbsElement[selctRowCount].Vbegdat = popUpData.getData().Vbegdat;
				if (popUpData.getData().Venddat) {
					var sDate4 = popUpData.getData().Venddat;
					var n = sDate4.getTimezoneOffset() / 60;
					if (Math.sign(n) === -1) {
						oDate1 = dateFormat.format(new Date(sDate4));
						var oDate1 = oDate1 + "T14:00:00";
						var startDateObject = new Date(oDate1);
						wbsElement[selctRowCount].Venddat = startDateObject;
						// draftData.d.Guebg = startDateObject;
					} else {
						wbsElement[selctRowCount].Venddat = popUpData.getData().Venddat;
					}

				} else {
					wbsElement[selctRowCount].Venddat = popUpData.getData().Venddat;
				}
				// wbsElement[selctRowCount].Venddat = popUpData.getData().Venddat;

				wbsElement[selctRowCount].ZzTaskOrderCat = popUpData.getData().ZzTaskOrderCat;
				// wbsElement[selctRowCount].Vernr = this.getView().byId("idProjMngr").getSelectedKey();
				wbsElement[selctRowCount].ZzCapPt = this.getView().byId("idCanType").getSelectedKey();

				wbsElement[selctRowCount].ZzStrategy = this.getView().byId("idForCastStr").getValue();
				wbsElement[selctRowCount].Pspri = this.getView().byId("idPriority").getSelectedKey();
				wbsElement[selctRowCount].ZzCapRat = popUpData.getData().ZzCapRat;
				wbsElement[selctRowCount].ZzMarkup = popUpData.getData().ZzMarkup;
				wbsElement[selctRowCount].ZzPtContact = popUpData.getData().ZzPtContact;
				wbsElement[selctRowCount].ZzAtcode = this.getView().byId("idAsstType").getValue();
				wbsElement[selctRowCount].Zz_focode = this.getView().byId("idFinOpt").getValue();
				wbsElement[selctRowCount].Zz_vrcode = this.getView().byId("idVendr").getValue();
				wbsElement[selctRowCount].Zproj_Subp_Cat_C = this.getView().byId("idProjSubPhase").getValue();
				wbsElement[selctRowCount].Zz_gtmwbs = this.getView().byId("idGTMwbs").getValue();
				this.onCancel(oEvent);
				var wbsEleID = wbsElement[selctRowCount].Zposid;
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("WBS details saved " + wbsEleID);
			} else {
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Please fill all mandatory fields.");
			}

		},
		onAutopopuAddiSaveValida: function (oEvent) {
			if (this.getView().byId("idCanType").getRequired()) {
				if (this.getView().byId("idCanType").getValue()) {
					var idCanType = true;
					this.getView().byId("idCanType").setValueState("None");
				} else {
					var idCanType = false;
					this.getView().byId("idCanType").setValueState("Error");
				}
			} else {
				var idCanType = true;
				this.getView().byId("idCanType").setValueState("None");
			}
			if (this.getView().byId("idForCastStr").getRequired()) {
				if (this.getView().byId("idForCastStr").getValue()) {
					var idForCastStr = true;
					this.getView().byId("idForCastStr").setValueState("None");
				} else {
					var idForCastStr = false;
					this.getView().byId("idForCastStr").setValueState("Error");
				}
			} else {
				var idForCastStr = true;
				this.getView().byId("idForCastStr").setValueState("None");
			}

			if (this.getView().byId("idPriority").getRequired()) {
				if (this.getView().byId("idPriority").getValue()) {
					var idPriority = true;
					this.getView().byId("idPriority").setValueState("None");
				} else {
					var idPriority = false;
					this.getView().byId("idPriority").setValueState("Error");
				}
			} else {
				var idPriority = true;
				this.getView().byId("idPriority").setValueState("None");
			}

			if (this.getView().byId("idCapRat").getRequired()) {
				if (this.getView().byId("idCapRat").getValue()) {
					var idCapRat = true;
					this.getView().byId("idCapRat").setValueState("None");
				} else {
					var idCapRat = false;
					this.getView().byId("idCapRat").setValueState("Error");
				}
			} else {
				var idCapRat = true;
				this.getView().byId("idCapRat").setValueState("None");
			}

			if (this.getView().byId("idMarkup").getRequired()) {
				if (this.getView().byId("idMarkup").getValue()) {
					var idMarkup = true;
					this.getView().byId("idMarkup").setValueState("None");
				} else {
					var idMarkup = false;
					this.getView().byId("idMarkup").setValueState("Error");
				}
			} else {
				var idMarkup = true;
				this.getView().byId("idMarkup").setValueState("None");
			}

			if (this.getView().byId("idAddPOC").getRequired()) {
				if (this.getView().byId("idAddPOC").getValue()) {
					var idAddPOC = true;
					this.getView().byId("idAddPOC").setValueState("None");
				} else {
					var idAddPOC = false;
					this.getView().byId("idAddPOC").setValueState("Error");
				}
			} else {
				var idAddPOC = true;
				this.getView().byId("idAddPOC").setValueState("None");
			}

			if (this.getView().byId("idAsstType").getRequired()) {
				if (this.getView().byId("idAsstType").getValue()) {
					var idAsstType = true;
					this.getView().byId("idAsstType").setValueState("None");
				} else {
					var idAsstType = false;
					this.getView().byId("idAsstType").setValueState("Error");
				}
			} else {
				var idAsstType = true;
				this.getView().byId("idAsstType").setValueState("None");
			}

			if (this.getView().byId("idFinOpt").getRequired()) {
				if (this.getView().byId("idFinOpt").getValue()) {
					var idFinOpt = true;
					this.getView().byId("idFinOpt").setValueState("None");
				} else {
					var idFinOpt = false;
					this.getView().byId("idFinOpt").setValueState("Error");
				}
			} else {
				var idFinOpt = true;
				this.getView().byId("idFinOpt").setValueState("None");
			}

			if (this.getView().byId("idVendr").getRequired()) {
				if (this.getView().byId("idVendr").getValue()) {
					var idVendr = true;
					this.getView().byId("idVendr").setValueState("None");
				} else {
					var idVendr = false;
					this.getView().byId("idVendr").setValueState("Error");
				}
			} else {
				var idVendr = true;
				this.getView().byId("idVendr").setValueState("None");
			}

			if (idCanType && idForCastStr && idPriority && idCapRat && idMarkup && idAddPOC && idAsstType && idFinOpt && idVendr) {
				return true;
			} else {
				return false;
			}
		},
		onClearData: function (oEvent) {
			this.getView().byId("idReqTypeFun").setSelectedKey("");
			this.getView().byId("idReqTypeDtls").setSelectedKey("");

			this.getView().byId("idT1ComCode").setEditable(true);
			this.getView().byId("idProjType").setEditable(true);

			this.getView().byId("idProjDefi").setMask("##@-####");
			this.getView().byId("idProjDefi").setValue("");
			this.getView().byId("idT1ComCode").setSelectedKey("");
			this.getView().byId("idWBSTypeT1").setSelectedKey("");
			this.getView().byId("idT2PersResp").setSelectedKey("");
			this.getView().byId("idT2ProjRespCC").setSelectedKey("");

			this.getView().byId("idT2ContractId").setSelectedKey("");
			this.getView().byId("idT2CustId").setSelectedKey("");
			this.getView().byId("idT2LdPracSet").setSelectedKey("");
			this.getView().byId("idT2ProjAdmin").setSelectedKey("");
			this.getView().byId("idT2ActMngr").setSelectedKey("");
			this.getView().byId("idT2OpporId").setSelectedKey("");
			this.getView().byId("idT1FinAnyst").setSelectedKey("");
			this.getView().byId("idT2Program").setSelectedKey("");
			this.getView().byId("fileUploader").setValue("");
			this.getView().byId("idT1Email").removeAllTokens()
			var oView = this.getView().getModel().getData();
			/*below code for remove to Details*/
			delete oView.toDetails.ReqNum;
			delete oView.toDetails.Zbukrs;
			delete oView.toDetails.Zpspid;
			// delete oView.toDetails.Zvbeln;
			delete oView.toDetails.ProjTyp;
			delete oView.toDetails.ReasReq;
			delete oView.toDetails.ReqDet;
			delete oView.toDetails.Priority;
			delete oView.toDetails.ReqFun;
			delete oView.toDetails.TypeReq;
			delete oView.toDetails.Req_com;
			// delete oView.toDetails.FinApp;
			oView.toDetails.Email = [];
			/*below code for remove to status*/
			oView.draftData.d.toItem.results = [];
			delete oView.draftData.d.toStatus.results[0].ReqNum;
			delete oView.draftData.d.toStatus.results[0].StCount;
			delete oView.draftData.d.toStatus.results[0].ActType;
			// delete oView.draftData.d.toStatus.results[0].ActId;
			oView.draftData.d.toStatus.results[0].ActType = "SUBMITTER";
			delete oView.draftData.d.toStatus.results[0].TimeStp;
			delete oView.draftData.d.toStatus.results[0].ActCom;
			delete oView.draftData.d.toStatus.results[0].Status;

			delete oView.draftData.d.ReqNo;
			delete oView.draftData.d.Zbukrs;
			delete oView.draftData.d.Zpspid;
			// delete oView.draftData.d.Zvbeln;
			delete oView.draftData.d.Soldto;
			delete oView.draftData.d.Payer;
			delete oView.draftData.d.ShipTo;
			delete oView.draftData.d.BillTo;
			delete oView.draftData.d.Ktext;
			delete oView.draftData.d.Zzoycunm;
			// delete oView.draftData.d.Vernr; 
			// delete oView.draftData.d.Kostl;
			delete oView.draftData.d.Vgsbr;
			delete oView.draftData.d.Prctr;
			delete oView.draftData.d.PrjTyp;
			delete oView.draftData.d.PrjStp;
			delete oView.draftData.d.Zpjcgid;
			// delete oView.draftData.d.Zpgid; 
			delete oView.draftData.d.Zkunnr;
			delete oView.draftData.d.Zzsoarincd;
			delete oView.draftData.d.ZriskInd;
			delete oView.draftData.d.ZzCasId
			delete oView.draftData.d.Waers;
			delete oView.draftData.d.Bstnk;
			delete oView.draftData.d.Bstdkull;
			delete oView.draftData.d.Zterm;
			delete oView.draftData.d.Zzcntrcd;
			delete oView.draftData.d.ZPtReason;
			delete oView.draftData.d.Vtweg;
			delete oView.draftData.d.Spart;
			delete oView.draftData.d.Kvgr1;
			delete oView.draftData.d.Perfk;
			delete oView.draftData.d.Guebg;
			delete oView.draftData.d.Gueen;
			// delete oView.draftData.d.Agm;
			delete oView.draftData.d.Wbsowner1;
			delete oView.draftData.d.Wbsowner2;
			delete oView.draftData.d.DraftIa;
			delete oView.draftData.d.FinApp;
			// delete oView.draftData.d.PrjAd;
			delete oView.draftData.d.PrjAc;
			delete oView.draftData.d.Bds;
			delete oView.draftData.d.InvRec;
			delete oView.draftData.d.ZzContracttype;
			// delete oView.draftData.d.Zzldpcid;
			delete oView.draftData.d.Zzpjsgst;
			delete oView.draftData.d.Zzrvrgmdcd;
			// delete oView.draftData.d.Zzsiebelid;
			// delete oView.draftData.d.Zzpgid;
			delete oView.draftData.d.ZzGlblProj;
			delete oView.draftData.d.ZzEvExtract;
			delete oView.draftData.d.Action;
			oView.wbsElementStr = [];
			oView.toError = [];

			var oUser = new UserInfo();
			var ouserId = oUser.getId();
			var oFullName = oUser.getUser().getFullName().toUpperCase();
			var oViewModel = this.getView().getModel("appView");
			oViewModel.getData().Requestid = "";
			oViewModel.getData().RequestorName = oFullName;
			oViewModel.getData().Requestor = ouserId;
			oViewModel.getData().EstatTxt = "Create";
			oViewModel.getData().oppSafeCaseid = true;
			oViewModel.getData().ReqDate = new Date().toDateString();
			this.getView().getModel("appView").refresh(true);
			this.getView().byId("idIconTabBar").setSelectedKey("1");
		},
		onAddWbsSibling1: function (oEvent) {
			var PsPhiup;
			var PsPhile;
			var PsPhiri;
			var PsPhido;
			var projDefValue = this.getView().byId("idProjDefi").getValue();
			var t1CoCode = this.getView().byId("idT1ComCode").getValue();
			var oTable = this.getView().byId("idTable");
			var aContexts = oTable.getSelectedIndices();
			if (aContexts.length === 1) {
				var currRow = aContexts[0];
				// var oModel = this.getView().getModel();
				var oModel = this.getView().getModel("pageModel"); // rohit - change
				var wbsElement = oModel.getProperty("/wbsElementStr");
				var currWbsEle = wbsElement[currRow].Zposid;
				var currLvl = wbsElement[currRow].Stufe;

				var currWbsEleUP = wbsElement[currRow].PsPhiup;
				var oDataUp = wbsElement.filter(function (a) {
					return a.PsPhiup === currWbsEleUP;
				});
				var oDataUpNew = oDataUp[oDataUp.length - 1].Zposid;
				var last2digit = oDataUpNew.slice(-2);
				// if (last2digit == "99") {

				// 	// MessageToast.show("Maximum WBS level allowed is only 99.");

				// } else {
				var num = parseInt(last2digit, 10);
				var Description = "New Sibling for " + currWbsEle;
				if (currLvl !== 1) {
					if (num < 10) {
						if (num === 9) {
							var mm = oDataUpNew.slice(0, -2);
							var wbsEle = mm.concat("", num + 1);
						} else {
							var mm = oDataUpNew.slice(0, -1);
							//Phase3 UAT Issue -  Hierarchy 
							if (currWbsEleUP === mm) {
								var wbsEle = oDataUpNew;
							} else {
								var wbsEle = mm.concat("", num + 1);
							}

						}

						var currPsPhiup = wbsElement[currRow].PsPhiup;
						// var oData = wbsElement.filter(function (a) {
						// 	return a.PsPhiup === currPsPhiup;
						// });
						// var lastwbsEle = oData[oData.length - 1].Zposid;
						// var last2digit = lastwbsEle.slice(-2);
						// var num = parseInt(last2digit, 10);
						// var mm = wbsEle.slice(0, -1);
						// var wbsEle = mm.concat("", num + 1);
						/*====================below code for getting the position====================*/
						if (currLvl === 2) {
							var addPosition = wbsElement.length;
						} else if (currLvl === 3) {
							// var currPsPhiup = wbsElement[currRow].PsPhiup;
							// var oDataPos = wbsElement.map(function (o) {
							// 	return o.Zposid;
							// }).indexOf(currPsPhiup);
							// var oNext2EbsEle = wbsElement[oDataPos].PsPhiri;
							// if (oNext2EbsEle) {
							// 	var oDataPos1 = wbsElement.map(function (o) {
							// 		return o.Zposid;
							// 	}).indexOf(oNext2EbsEle);
							// 	var addPosition = oDataPos1;
							// } else {
							// 	var addPosition = wbsElement.length;
							// }

							var currWBS88 = wbsElement[currRow].Zposid;
							currWBS88 = currWBS88.slice(0, -3)
							var currWbsIncludes = wbsElement.filter(function (obj) {
								//check if object value contains value you are looking for
								if (obj.Zposid.includes(currWBS88)) {
									//add this object to the filtered array
									return obj;
								}
							});

							if (currWbsIncludes) {
								var currWbsIncludesLastWBS = currWbsIncludes[currWbsIncludes.length - 1].Zposid;
								var addPosition = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(currWbsIncludesLastWBS);
								addPosition = addPosition + 1;
							} else {
								var addPosition = wbsElement.length
							}
						} else if (currLvl === 4) {
							/*====================below code for getting the position====================*/
							var last2digit = currPsPhiup.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = currPsPhiup.slice(0, -1);
							var wbsEle1 = wbsElement[currRow].PsPhiup
								// var mm = wbsEle.slice(0, -1);
								// var num1 = wbsEle.slice(-2);

							var pos = wbsElement.map(function (o) {
								return o.Zposid;
							}).indexOf(wbsEle1);
							var oNew = wbsElement[pos].PsPhiri;
							if (oNew !== "") {
								var pos = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(oNew);
								// Begin of Phase3 UAT issue 
								// var addPosition = pos;   ///  Commented phase3 UAT issue  
								if (pos) {
									var addPosition = pos;
								} else {
									var addPosition = wbsElement.length;
								}

								// End of Phase3 UAT issue
							} else {
								// if (pos === -1) {
								var wbsEle1 = wbsElement[currRow].PsPhiup;
								var pos = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(wbsEle1);
								var wbsEle2 = wbsElement[pos].PsPhiup
								var pos1 = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(wbsEle2);
								if (wbsElement[pos1].PsPhiri !== "") {
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(wbsElement[pos1].PsPhiri);
								} else {
									var addPosition = wbsElement.length;
								}
								// var addPosition = wbsElement.length;
								// var addPosition = currRow + 1;
								// } else {
								// 	var addPosition = pos;
								// }
							}

						} else if (currLvl === 5) {
							var wbsEle1 = wbsElement[currRow].PsPhiup;
							var leftWbs = wbsElement.filter(function (a) {
								return a.PsPhiup === wbsEle1;
							});
							var addPosition = wbsElement.map(function (o) {
								return o.Zposid;
							}).indexOf(leftWbs[leftWbs.length - 1].Zposid) + 1;
						} else {
							/*====================below code for getting the position====================*/
							var last2digit = currPsPhiup.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = currPsPhiup.slice(0, -1);
							var wbsEle1 = mm.concat("", num + 1);
							// var mm = wbsEle.slice(0, -1);
							// var num1 = wbsEle.slice(-2);

							var pos = wbsElement.map(function (o) {
								return o.Zposid;
							}).indexOf(wbsEle1);
							if (pos === -1) {
								var addPosition = wbsElement.length;
								// var addPosition = currRow + 1;
							} else {
								var addPosition = pos;
							}
							// var addPosition = pos;

						}
						/*====================below code for getting the up, Down, left, Right Key====================*/
						PsPhile = oDataUpNew;
						PsPhiup = wbsElement[currRow].PsPhiup;
						PsPhido = "";
						PsPhiri = "";
						/*===================================================================================================*/
						var preWbsEle = PsPhile;
						var addPosiToRight = wbsElement.map(function (o) {
							return o.Zposid;
						}).indexOf(PsPhile);
						wbsElement[addPosiToRight].PsPhiri = wbsEle;
						if (wbsEle.slice(-3) === "100") {
							wbsEle = wbsEle.slice(0, -3);
							wbsElement[addPosiToRight].PsPhiri = wbsEle;
							// MessageToast.show("Maximum WBS level allowed is only 99000000000000000.");
						} else {
							wbsEle = wbsEle;
							wbsElement[addPosiToRight].PsPhiri = wbsEle;
						}
						/*====================================================================================================*/
						this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
							PsPhido);
					} else {
						//Phase3 UAT Issue 
						if (currWbsEleUP === mm) {
							var wbsEle = oDataUpNew;
						} else {
							var mm = oDataUpNew.slice(0, -2);
							var wbsEle = mm.concat("", num + 1);
						}
						// if (oData1.length !== 0) {
						var currPsPhiup = wbsElement[currRow].PsPhiup;
						// var oData = wbsElement.filter(function (a) {
						// 	return a.PsPhiup === currPsPhiup;
						// });
						// var lastwbsEle = oData[oData.length - 1].Zposid;
						// var last2digit = lastwbsEle.slice(-2);
						// var num = parseInt(last2digit, 10);
						// var mm = wbsEle.slice(0, -2);
						// var wbsEle = mm.concat("", num + 1);
						/*====================below code for getting the position====================*/
						if (currLvl === 2) {
							var addPosition = wbsElement.length;
						} else if (currLvl === 3) {
							// var currPsPhiup = wbsElement[currRow].PsPhiup;
							// var oDataPos = wbsElement.map(function (o) {
							// 	return o.Zposid;
							// }).indexOf(currPsPhiup);
							// var oNext2EbsEle = wbsElement[oDataPos].PsPhiri;
							// if (oNext2EbsEle) {
							// 	var oDataPos1 = wbsElement.map(function (o) {
							// 		return o.Zposid;
							// 	}).indexOf(oNext2EbsEle);
							// 	var addPosition = oDataPos1;
							// } else {
							// 	var addPosition = wbsElement.length;
							// }

							var currWBS88 = wbsElement[currRow].Zposid;
							currWBS88 = currWBS88.slice(0, -3)
							var currWbsIncludes = wbsElement.filter(function (obj) {
								//check if object value contains value you are looking for
								if (obj.Zposid.includes(currWBS88)) {
									//add this object to the filtered array
									return obj;
								}
							});

							if (currWbsIncludes) {
								var currWbsIncludesLastWBS = currWbsIncludes[currWbsIncludes.length - 1].Zposid;
								var addPosition = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(currWbsIncludesLastWBS);
								addPosition = addPosition + 1;
							} else {
								var addPosition = wbsElement.length
							}
						} else if (currLvl === 4) {
							/*====================below code for getting the position====================*/
							var last2digit = currPsPhiup.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = currPsPhiup.slice(0, -1);
							var wbsEle1 = wbsElement[currRow].PsPhiup
								// var mm = wbsEle.slice(0, -1);
								// var num1 = wbsEle.slice(-2);

							var pos = wbsElement.map(function (o) {
								return o.Zposid;
							}).indexOf(wbsEle1);
							var oNew = wbsElement[pos].PsPhiri;
							if (oNew !== "") {
								var pos = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(oNew);
								// Begin of PHase3 UAT issue
								// var addPosition = pos;   //Commented Phase3 UAT issue 
								if (pos) {
									var addPosition = pos;
								} else {
									var addPosition = wbsElement.length;
								}

								// End of Phase3 UAT issue
							} else {
								// if (pos === -1) {
								var wbsEle1 = wbsElement[currRow].PsPhiup;
								var pos = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(wbsEle1);
								var wbsEle2 = wbsElement[pos].PsPhiup
								var pos1 = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(wbsEle2);
								if (wbsElement[pos1].PsPhiri !== "") {
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(wbsElement[pos1].PsPhiri);
								} else {
									var addPosition = wbsElement.length;
								}
								// var addPosition = wbsElement.length;
								// var addPosition = currRow + 1;
								// } else {
								// 	var addPosition = pos;
								// }
							}

						} else if (currLvl === 5) {
							var wbsEle1 = wbsElement[currRow].PsPhiup;
							var leftWbs = wbsElement.filter(function (a) {
								return a.PsPhiup === wbsEle1;
							});
							var addPosition = wbsElement.map(function (o) {
								return o.Zposid;
							}).indexOf(leftWbs[leftWbs.length - 1].Zposid) + 1;
						} else {
							/*====================below code for getting the position====================*/
							var last2digit = currPsPhiup.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = currPsPhiup.slice(0, -2);
							var wbsEle1 = mm.concat("", num + 1);
							// var mm = wbsEle.slice(0, -1);
							// var num1 = wbsEle.slice(-2);

							var pos = wbsElement.map(function (o) {
								return o.Zposid;
							}).indexOf(wbsEle1);
							if (pos === -1) {
								var addPosition = wbsElement.length;
								// var addPosition = currRow + 1;
							} else {
								var addPosition = pos;
							}
							// var addPosition = pos;

							/*===================================*/
						}

						/*====================below code for getting the up, Down, left, Right Key====================*/
						PsPhile = oDataUpNew;
						PsPhiup = wbsElement[currRow].PsPhiup;
						PsPhido = "";
						PsPhiri = "";
						/*===================================================================================================*/
						var preWbsEle = PsPhile;
						var addPosiToRight = wbsElement.map(function (o) {
							return o.Zposid;
						}).indexOf(PsPhile);
						wbsElement[addPosiToRight].PsPhiri = wbsEle;
						if (wbsEle.slice(-3) === "100") {
							wbsEle = wbsEle.slice(0, -3);
							wbsElement[addPosiToRight].PsPhiri = wbsEle;
							// MessageToast.show("Maximum WBS level allowed is only 99000000000000000.");
						} else {
							wbsEle = wbsEle;
							wbsElement[addPosiToRight].PsPhiri = wbsEle;
						}
						/*====================================================================================*/
						this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
							PsPhido);

					}
				} else {
					MessageToast.show("Cannot add sibling to level 1 WBS.");
				}
				// }

			} else {
				MessageToast.show("Please select only one WBS.");
			}
			this.getView().byId("idTable").clearSelection();
		},
		// onAddWbsSibling: function (oEvent) {
		// 	var PsPhiup;
		// 	var PsPhile;
		// 	var PsPhiri;
		// 	var PsPhido;
		// 	var projDefValue = this.getView().byId("idProjDefi").getValue();
		// 	var t1CoCode = this.getView().byId("idT1ComCode").getValue();
		// 	var oTable = this.getView().byId("idTable");
		// 	var aContexts = oTable.getSelectedIndices();
		// 	if (aContexts.length === 1) {
		// 		var currRow = aContexts[0];
		// 		var oModel = this.getView().getModel();
		// 		var wbsElement = oModel.getProperty("/wbsElementStr");
		// 		var currWbsEle = wbsElement[currRow].Zposid;
		// 		var currLvl = wbsElement[currRow].Stufe;
		// 		var last2digit = currWbsEle.slice(-2);
		// 		var num = parseInt(last2digit, 10);
		// 		var Description = "New Sibling for " + currWbsEle;
		// 		if (currLvl !== 1) {
		// 			if (num < 10) {
		// 				var mm = currWbsEle.slice(0, -1);
		// 				var wbsEle = mm.concat("", num + 1);
		// 				var oData = wbsElement.filter(function (a) {
		// 					return a.Stufe === currLvl;
		// 				});
		// 				var oData1 = oData.filter(function (a) {
		// 					return a.Zposid === wbsEle;
		// 				});
		// 				if (oData1.length !== 0) {
		// 					// var wbsNo = [];
		// 					for (var j = 0; j < oData.length; j++) {
		// 						var last2digit = wbsEle.slice(-2);
		// 						var num = parseInt(last2digit, 10);
		// 						var mm = wbsEle.slice(0, -1);
		// 						var wbsEle = mm.concat("", num + 1);
		// 						// wbsNo.push(wbsEle);
		// 						var oData = wbsElement.filter(function (a) {
		// 							return a.Stufe === currLvl;
		// 						});
		// 						var oData1 = oData.filter(function (a) {
		// 							return a.Zposid === wbsEle;
		// 						});
		// 						if (oData1.length === 0) {
		// 							break;
		// 						}
		// 					}
		// 					if (currLvl === 2) {
		// 						var addPosition = wbsElement.length;
		// 					} else {
		// 						/*====================below code for getting the position====================*/
		// 						var mm = wbsEle.slice(0, -1);
		// 						var num1 = wbsEle.slice(-2);
		// 						var wbsEle1 = mm.concat("", num1 - 1);
		// 						var pos = wbsElement.map(function (o) {
		// 							return o.Zposid;
		// 						}).indexOf(wbsEle1);
		// 						var addPosition = pos + 1;
		// 						// var mj = wbsElement[currRow].PsPhiup;
		// 						// var m = mj.slice(-2);
		// 						// var mm1 = mj.slice(0, -2);
		// 						// var num = parseInt(m, 10);
		// 						// if (num < 10) {
		// 						// 	var nextwbsEleLe = mm1.concat("0", num + 1);
		// 						// } else {
		// 						// 	var nextwbsEleLe = mm1.concat("", num + 1);
		// 						// }
		// 						// var addPosition = wbsElement.map(function (o) {
		// 						// 	return o.Zposid;
		// 						// }).indexOf(nextwbsEleLe);
		// 						// if (addPosition === -1) {
		// 						// 	// var addPosition = wbsElement.length;
		// 						// 	var addPosition = currRow + 1;
		// 						// }
		// 						/*===================================*/
		// 					}
		// 					/*====================below code for getting the up, Down, left, Right Key====================*/
		// 					var last2digit = wbsEle.slice(-2);
		// 					var num = parseInt(last2digit, 10);
		// 					var mm = wbsEle.slice(0, -1);
		// 					var wbsEleLe = mm.concat("", num - 1);
		// 					var leftWbs = wbsElement.filter(function (a) {
		// 						return a.Zposid === wbsEleLe;
		// 					});
		// 					if (leftWbs.length === 1) {
		// 						PsPhile = wbsEleLe;
		// 					} else {
		// 						PsPhile = "";
		// 					}
		// 					PsPhiup = wbsElement[currRow].PsPhiup;
		// 					PsPhido = "";
		// 					PsPhiri = "";
		// 					/*===================================================================================================*/
		// 					var preWbsEle = PsPhile;
		// 					var addPosiToRight = wbsElement.map(function (o) {
		// 						return o.Zposid;
		// 					}).indexOf(PsPhile);
		// 					wbsElement[addPosiToRight].PsPhiri = wbsEle;
		// 					/*====================================================================================================*/
		// 					this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
		// 						PsPhido);

		// 				} else {
		// 					if (currLvl === 2) {
		// 						var addPosition = wbsElement.length;
		// 					} else {
		// 						/*====================below code for getting the position====================*/
		// 						var mj = wbsElement[currRow].PsPhiup;
		// 						var m = mj.slice(-2);
		// 						var mm1 = mj.slice(0, -2);
		// 						var num = parseInt(m, 10);
		// 						if (num < 10) {
		// 							var nextwbsEleLe = mm1.concat("0", num + 1);
		// 						} else {
		// 							var nextwbsEleLe = mm1.concat("", num + 1);
		// 						}
		// 						var addPosition = wbsElement.map(function (o) {
		// 							return o.Zposid;
		// 						}).indexOf(nextwbsEleLe);
		// 						if (addPosition === -1) {
		// 							// var addPosition = wbsElement.length;
		// 							var addPosition = currRow + 1;
		// 						}
		// 						/*===================================*/
		// 					}
		// 					/*====================below code for getting the up, Down, left, Right Key====================*/
		// 					var last2digit = wbsEle.slice(-2);
		// 					var num = parseInt(last2digit, 10);
		// 					var mm = wbsEle.slice(0, -1);
		// 					var wbsEleLe = mm.concat("", num - 1);
		// 					var leftWbs = wbsElement.filter(function (a) {
		// 						return a.Zposid === wbsEleLe;
		// 					});
		// 					if (leftWbs.length === 1) {
		// 						PsPhile = wbsEleLe;
		// 					} else {
		// 						PsPhile = "";
		// 					}
		// 					PsPhiup = wbsElement[currRow].PsPhiup;
		// 					PsPhido = "";
		// 					PsPhiri = "";
		// 					/*===================================================================================================*/
		// 					var preWbsEle = PsPhile;
		// 					var addPosiToRight = wbsElement.map(function (o) {
		// 						return o.Zposid;
		// 					}).indexOf(PsPhile);
		// 					wbsElement[addPosiToRight].PsPhiri = wbsEle;
		// 					/*====================================================================================*/
		// 					this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
		// 						PsPhido);
		// 				}
		// 			} else {
		// 				var mm = currWbsEle.slice(0, -2);
		// 				var wbsEle = mm.concat("", num);
		// 				var oData = wbsElement.filter(function (a) {
		// 					return a.Stufe === currLvl;
		// 				});
		// 				var oData1 = oData.filter(function (a) {
		// 					return a.Zposid === wbsEle;
		// 				});
		// 				if (oData1.length !== 0) {
		// 					for (var j = 0; j < oData.length; j++) {
		// 						var last2digit = wbsEle.slice(-2);
		// 						var num = parseInt(last2digit, 10);
		// 						var mm = wbsEle.slice(0, -2);
		// 						var wbsEle = mm.concat("", num + 1);
		// 						var oData = wbsElement.filter(function (a) {
		// 							return a.Stufe === currLvl;
		// 						});
		// 						var oData1 = oData.filter(function (a) {
		// 							return a.Zposid === wbsEle;
		// 						});
		// 						if (oData1.length === 0) {
		// 							break;
		// 						}
		// 					}
		// 					if (currLvl === 2) {
		// 						var addPosition = wbsElement.length;
		// 					} else {
		// 						/*====================below code for getting the position====================*/
		// 						var mm = wbsEle.slice(0, -2);
		// 						var num1 = wbsEle.slice(-2);
		// 						var wbsEle1 = mm.concat("", num1 - 1);
		// 						var pos = wbsElement.map(function (o) {
		// 							return o.Zposid;
		// 						}).indexOf(wbsEle1);
		// 						var addPosition = pos + 1;
		// 						// var mj = wbsElement[currRow].PsPhiup;
		// 						// var m = mj.slice(-2);
		// 						// var mm1 = mj.slice(0, -2);
		// 						// var num = parseInt(m, 10);
		// 						// if (num < 10) {
		// 						// 	var nextwbsEleLe = mm1.concat("0", num + 1);
		// 						// } else {
		// 						// 	var nextwbsEleLe = mm1.concat("", num + 1);
		// 						// }
		// 						// var addPosition = wbsElement.map(function (o) {
		// 						// 	return o.Zposid;
		// 						// }).indexOf(nextwbsEleLe);
		// 						// if (addPosition === -1) {
		// 						// 	// var addPosition = wbsElement.length;
		// 						// 	var addPosition = currRow + 1;
		// 						// }
		// 						/*===================================*/
		// 					}
		// 					/*====================below code for getting the up, Down, left, Right Key====================*/
		// 					var last2digit = wbsEle.slice(-2);
		// 					var num = parseInt(last2digit, 10);
		// 					var mm = wbsEle.slice(0, -1);
		// 					var wbsEleLe = mm.concat("", num - 1);
		// 					var leftWbs = wbsElement.filter(function (a) {
		// 						return a.Zposid === wbsEleLe;
		// 					});
		// 					if (leftWbs.length === 1) {
		// 						PsPhile = wbsEleLe;
		// 					} else {
		// 						PsPhile = "";
		// 					}
		// 					PsPhiup = wbsElement[currRow].PsPhiup;
		// 					PsPhido = "";
		// 					PsPhiri = "";
		// 					/*===================================================================================================*/
		// 					var preWbsEle = PsPhile;
		// 					var addPosiToRight = wbsElement.map(function (o) {
		// 						return o.Zposid;
		// 					}).indexOf(PsPhile);
		// 					wbsElement[addPosiToRight].PsPhiri = wbsEle;
		// 					/*====================================================================================*/
		// 					this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
		// 						PsPhido);

		// 				} else {
		// 					if (currLvl === 2) {
		// 						var addPosition = wbsElement.length;
		// 					} else {
		// 						/*====================below code for getting the position====================*/
		// 						var mj = wbsElement[currRow].PsPhiup;
		// 						var m = mj.slice(-2);
		// 						var mm1 = mj.slice(0, -2);
		// 						var num = parseInt(m, 10);
		// 						if (num < 10) {
		// 							var nextwbsEleLe = mm1.concat("0", num + 1);
		// 						} else {
		// 							var nextwbsEleLe = mm1.concat("", num + 1);
		// 						}
		// 						var addPosition = wbsElement.map(function (o) {
		// 							return o.Zposid;
		// 						}).indexOf(nextwbsEleLe);
		// 						if (addPosition === -1) {
		// 							// var addPosition = wbsElement.length;
		// 							var addPosition = currRow + 1;
		// 						}
		// 						/*===================================*/
		// 					}
		// 					/*====================below code for getting the up, Down, left, Right Key====================*/
		// 					var last2digit = wbsEle.slice(-2);
		// 					var num = parseInt(last2digit, 10);
		// 					var mm = wbsEle.slice(0, -1);
		// 					var wbsEleLe = mm.concat("", num - 1);
		// 					var leftWbs = wbsElement.filter(function (a) {
		// 						return a.Zposid === wbsEleLe;
		// 					});
		// 					if (leftWbs.length === 1) {
		// 						PsPhile = wbsEleLe;
		// 					} else {
		// 						PsPhile = "";
		// 					}
		// 					PsPhiup = wbsElement[currRow].PsPhiup;
		// 					PsPhido = "";
		// 					PsPhiri = "";
		// 					/*===================================================================================================*/
		// 					var preWbsEle = PsPhile;
		// 					var addPosiToRight = wbsElement.map(function (o) {
		// 						return o.Zposid;
		// 					}).indexOf(PsPhile);
		// 					wbsElement[addPosiToRight].PsPhiri = wbsEle;
		// 					/*====================================================================================*/
		// 					this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
		// 						PsPhido);
		// 				}
		// 			}
		// 		} else {
		// 			MessageToast.show("Cannot add sibling to level 1 WBS.");
		// 		}
		// 	} else {
		// 		MessageToast.show("Please select only one WBS.");
		// 	}
		// 	this.getView().byId("idTable").clearSelection();
		// 	// MessageToast.show("Coming Sooooon!!!");
		// },
		onAddSiblingChild: function (projDefValue, wbsEle, t1CoCode, currLvl, addPosition, Description, CurrRow, PsPhiup, PsPhile, PsPhiri,
			PsPhido) {
			// var oModel = this.getView().getModel();
			var oModel = this.getView().getModel("pageModel") // rohit - change
			var wbsElement = oModel.getProperty("/wbsElementStr");
			var projType = this.getView().byId("idProjType").getSelectedKey();
			var PrartTyp = this.getView().byId("idWBSTypeT1").getValue();
			if (projType === "PRJ_TYP1") {
				var taskOrder = wbsElement[CurrRow].ZzTaskOrder;
			} else if (projType === "PRJ_TYP2") {
				var taskOrder = "";
			}
			if (currLvl === 2 && projType === "PRJ_TYP1") {
				var uStatus = "CRTD";
				var serOff = "BLANK";
			} else if (currLvl === 2 && projType === "PRJ_TYP2") {
				var uStatus = "CRTD";
				//
				var serOff;
				if (this.getView().getModel("appView").getData().oSpanProj == "YES") {
					serOff = "BLANK"
				} else {
					serOff = "";
				}
			} else {
				var uStatus = "OPEN";
				var serOff = "";
			}
			if (currLvl > 2) {
				var serOff = wbsElement[CurrRow].Zzsolseid;
				var Vernr = wbsElement[CurrRow].Vernr;
				var ZzTaskOrderCat = wbsElement[CurrRow].ZzTaskOrderCat;
			} else {
				var ZzTaskOrderCat = "";
				var Vernr = "";
			}
			var Zzproj_Phase_Cd = wbsElement[CurrRow].Zzproj_Phase_Cd;
			// var Vernr = wbsElement[CurrRow].Vernr;

			if (this.getView().byId("idT2ProjAdmin").getSelectedKey()) {
				var PrjAd = this.getView().byId("idT2ProjAdmin").getSelectedKey();
			} else {
				var PrjAd = this.getView().getModel().getData().draftData.d.PrjAd;
			}

			//
			var oTYPE = this.getView().getModel("appView").getData().type;
			//537

			if (this.getView().byId("idT2PersResp").getSelectedKey()) {
				var Wbsowner1 = this.getView().byId("idT2PersResp").getSelectedKey();
			} else {
				var Wbsowner1 = this.getView().getModel().getData().draftData.d.Vernr;
			}
			// var Vernr = this.getView().byId("idT2FinAnyst").getSelectedKey();
			if (this.getView().byId("idT1FinAnyst").getSelectedKey()) {
				var FinApp = this.getView().byId("idT2FinAnyst").getSelectedKey();
			} else {
				var FinApp = this.getView().getModel().getData().draftData.d.FinApp;
			}
			// }
			// 537
			//Begin of changes scenario2 -  Srini vallepu

			var oViewModelNavManage = this.getView().getModel("appView").getData().type;
			var oExtline = wbsElement[0].Zentry_tp;
			if ((oViewModelNavManage === "OpprApp") && (oExtline === "E" || oExtline === "C")) {
				var oppData = this.getView().getModel().getProperty("/toOpprData");
				var oppID = oppData[0].OptId;
				// if (currLvl === 3) {
				if (currLvl >= 3) {
					var ZsfdcOppid = oppID;
					var Safecase_id = "";
					var serOff = "";
					var UniqueId = "";
					var Sol_typ = "";
					var Cont_modl = "";
				} else {
					var ZsfdcOppid = wbsElement[CurrRow].ZsfdcOppid;
					var Safecase_id = wbsElement[CurrRow].Safecase_id;
					var serOff = wbsElement[CurrRow].Zzsolseid;
					var UniqueId = wbsElement[CurrRow].UniqueId;
					var Sol_typ = wbsElement[CurrRow].Sol_typ;
					var Cont_modl = wbsElement[CurrRow].Cont_modl;
				}
			} else {
				if (window.location.href.split("#")[1].split("?")[1] != undefined) {
					if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {
						var oppData = this.getView().getModel().getProperty("/toOpprData");
						var oppID = oppData[0].OptId;
						if (currLvl > 2) {
							var ZsfdcOppid = oppID;
						}
					} else {
						if (currLvl > 2) {
							var ZsfdcOppid = wbsElement[CurrRow].ZsfdcOppid;
						}
					}

				} else {
					if (currLvl > 2) {
						var ZsfdcOppid = wbsElement[CurrRow].ZsfdcOppid;
					}
				}
				var Safecase_id = wbsElement[CurrRow].Safecase_id;
				var UniqueId = wbsElement[CurrRow].UniqueId;
				var Sol_typ = wbsElement[CurrRow].Sol_typ;
				var Cont_modl = wbsElement[CurrRow].Cont_modl;
			}

			//End of changes scenario2 -  Srini vallepu
			// var Safecase_id = wbsElement[CurrRow].Safecase_id;   commented  by  vallepu scenario2
			// var Sol_typ = wbsElement[CurrRow].Sol_typ;
			// var Cont_modl = wbsElement[CurrRow].Cont_modl;
			// var ZsfdcOppid = wbsElement[CurrRow].ZsfdcOppid;   Commented by Vallepu  scenario2 

			var oViewModel = this.getView().getModel("appView");
			var TYPE = oViewModel.getData().type;
			if (TYPE === "ChangeProject") {
				var indi = "N";
			} else if (TYPE === "ChangeRequest") {
				if (wbsElement[0].Zentry_tp === "E" || wbsElement[0].Zentry_tp === "C") {
					var indi = "N";
				} else {
					var indi = "";
				}

			} else if (TYPE === "OpprApp") {
				var indi = "N";
			} else {
				var indi = "";
			}
			var wbsElementRow = {
				"Zpspid": projDefValue,
				"Zposid": wbsEle,
				"oldZposid": wbsEle,
				"Bukrs": t1CoCode,
				"Arktx": Description,
				"Stufe": currLvl,
				"PsPhiup": PsPhiup,
				"PsPhile": PsPhile,
				"PsPhiri": PsPhiri,
				"PsPhido": PsPhido,
				"Plakz_bool": false,
				"Belkz_bool": false,
				"Fakkz_bool": false,
				"Safecase_id": Safecase_id,
				"Sol_typ": Sol_typ,
				"Cont_modl": Cont_modl,
				"Fkstl": wbsElement[CurrRow].Fkstl,
				"Pgsbr": wbsElement[CurrRow].Pgsbr,
				"Prctr": wbsElement[CurrRow].Prctr,
				"Prart": PrartTyp,
				"Zzriskind_bool": false,
				"ZsfdcOppid": ZsfdcOppid,
				"RaKey": "PS-NRA",
				"Zzsolseid": serOff,
				"Zcats": "",
				"ZzPlanWaers": "",
				"Systatusline": "REL",
				"Ustatusline": uStatus,
				"ZzTaskOrder": taskOrder,
				"ZzGovCtrtype": wbsElement[CurrRow].ZzGovCtrtype,
				"Vbegdat": wbsElement[CurrRow].Vbegdat,
				"Venddat": wbsElement[CurrRow].Venddat,
				"Usr01": "",
				"ZzUsr01": "",
				"ZzUsr02": "",
				"ZzUsr03": "",
				"PrjAd": wbsElement[CurrRow].PrjAd,
				"ZzTaskOrderCat": ZzTaskOrderCat,
				"Vernr": Vernr,
				"ZzCapPt": "",
				"ZzStrategy": "",
				"Pspri": "",
				"ZzCapRat": "",
				"ZzMarkup": "",
				"ZzPtContact": "",
				"ZzAtcode": "",
				"Zz_vrcode": "",
				"Wbsowner1": wbsElement[CurrRow].Wbsowner1,
				"FinApp": wbsElement[CurrRow].FinApp,
				"Zzproj_Phase_Cd": wbsElement[CurrRow].Zzproj_Phase_Cd,
				"Zentry_tp": indi,
				"UniqueId": UniqueId
			};
			// "ErrType": "W"
			var wbsElement6 = oModel.getProperty("/wbsElementStr");
			// wbsElement6.push(wbsElementRow);
			// var addPosition = parseInt(currLvl, 10) + 1;
			wbsElement6.splice(addPosition, 0, wbsElementRow);
			oModel.setProperty("/wbsElementStr", wbsElement6);
			var itemDetails = oModel.getData().wbsElementStr;

			var contextid = "/wbsElementStr/" + CurrRow;
			var oNewContextid = "/wbsElementStr/" + addPosition;
			var CurrProjPhaseData = this.getView().getModel("pageModel").getProperty(contextid + "/oProjPhaseTempModl");
			var CurrServiceOffData = this.getView().getModel("pageModel").getProperty(contextid + "/oServiOfferTempSet");
			var CurrSafeCaseData = this.getView().getModel("pageModel").getProperty(contextid + "/oCaseSafeModel");
			var UserStatusData = this.getView().getModel("pageModel").getProperty(contextid + "/oUserStatusModel");
			this.getView().getModel("pageModel").setProperty(oNewContextid + "/oProjPhaseTempModl", CurrProjPhaseData);
			this.getView().getModel("pageModel").setProperty(oNewContextid + "/oServiOfferTempSet", CurrServiceOffData);
			// Added by  Srinivas Vallepu -  UAT NCR - 341869 // 12/01/2022
			if (oViewModelNavManage === "OpprApp") {
				var oModel = this.getView().getModel("oDataModel");
				var oppData = this.getView().getModel().getProperty("/toOpprData");
				var oppID = oppData[0].OptId;
				var aFilters = [];
				for (var i = 0; i < oppData.length; i++) {
					aFilters.push(new sap.ui.model.Filter("Uniq_id", sap.ui.model.FilterOperator.Contains, oppData[i].CasesafeId));
				}
				aFilters.push(new sap.ui.model.Filter([
					new sap.ui.model.Filter("Opt_id", sap.ui.model.FilterOperator.Contains, oppID),
				], false));
				if (aFilters.length !== 0) {
					var that = this;
					oModel.read("/Search_Safecase_IDSet", {
						filters: aFilters,
						success: function (oResponse) {
							if (oResponse.results.length > 0) {
								var oSafecase = new JSONModel(oResponse.results);
								// that.getView().getModel("pageModel").setProperty(oNewContextid + "/oCaseSafeModel", oSafecase);	
								that.getView().getModel("pageModel").setProperty(oNewContextid + "/oCaseSafeModel", oResponse.results);
							}
						},
						error: function (oError) {}
					});

				}
			} else {
				this.getView().getModel("pageModel").setProperty(oNewContextid + "/oCaseSafeModel", CurrSafeCaseData);
			}
			this.getView().getModel("pageModel").setProperty(oNewContextid + "/oUserStatusModel", UserStatusData);

			var noItem = itemDetails.length;
			// this.getView().byId("idTable").setVisibleRowCount(noItem);
			this.getView().byId("idTable").setVisibleRowCount(8); // rohit -change
			this.onUpdateDefaultRowValue(wbsElement6, "ADD");
		},
		onAddWbsChild: function (oEvent) {
			var PsPhiup;
			var PsPhile;
			var PsPhiri;
			var PsPhido;
			var projDefValue = this.getView().byId("idProjDefi").getValue();
			var t1CoCode = this.getView().byId("idT1ComCode").getValue();
			var oTable = this.getView().byId("idTable");
			var aContexts = oTable.getSelectedIndices();
			if (aContexts.length === 1) {
				var currRow = aContexts[0];
				// var oModel = this.getView().getModel();
				var oModel = this.getView().getModel("pageModel"); // rohit - change
				var wbsElement = oModel.getProperty("/wbsElementStr");
				var currWbsEle = wbsElement[currRow].Zposid;
				var currLvl = wbsElement[currRow].Stufe;
				// var nextWbsEle = wbsElement[currRow + 1].Zposid;
				var nextLvl = currLvl + 1;
				// var last2digit = nextWbsEle.slice(-2);
				// var num = parseInt(last2digit, 10);
				var Description = "New Child WBS for L" + currLvl;
				if (currLvl !== 5) {
					if (0 < 10) {
						// var mm = nextWbsEle.slice(0, -1);
						var wbsEle = currWbsEle.concat(".0", 1);
						var oData = wbsElement.filter(function (a) {
							return a.Stufe === nextLvl;
						});
						var oData1 = oData.filter(function (a) {
							return a.Zposid === wbsEle;
						});
						//if (oData1.length !== 0 || wbsEle.split(".")[2] === "01") { // Phase3 UAT issue

						if (oData1.length !== 0) {
							// if (oData1.length !== 0 ){
							// if (oData.length > 1 ){        //  Phase3 UAT issue Begin
							for (var j = 0; j < oData.length; j++) {
								if (wbsEle.split(".")[2] === "01") { // Phase3 UAT issue  for heirachy 
									var oDataL1 = wbsElement.filter(function (a) {
										return a.Stufe === nextLvl;
									});
									var oData1L1 = oDataL1.filter(function (a) {
										return a.Zposid === wbsEle;
									});
									if (oData1L1.length !== 0) {
										var last2digit = wbsEle.slice(-2);
										var num = parseInt(last2digit, 10);
										// var mm = wbsEle.slice(0, -1);
										// Phase3 UAT Issue 
										if (last2digit >= 9) {
											var mm = wbsEle.slice(0, -2);
										} else {
											var mm = wbsEle.slice(0, -1);
										}
										// var wbsEle = mm.concat("", num + 1);
										// Begin of Phase3 UAT issue
										if (currWbsEle === mm) {

										} else {
											var wbsEle = mm.concat("", num + 1);
										}

										//End of Phase3 UAT issue
										// Begin of Phase3 UAT issue 
										if (wbsEle.slice(-3) === "100") {
											wbsEle = wbsEle.slice(0, -3);
										}
										// End of Phase3 UAT issue
									} else {

										var oWbsHeighestvalue = wbsElement.length - 1;

										PsPhile = wbsElement[oWbsHeighestvalue].Zposid;
									}
								} else {
									var last2digit = wbsEle.slice(-2);
									var num = parseInt(last2digit, 10);
									// Phase3 UAT Issue 
									if (last2digit >= 9) {
										var mm = wbsEle.slice(0, -2);
									} else {
										var mm = wbsEle.slice(0, -1);
									}
									// Begin of Phase3 UAT issue
									if (currWbsEle === mm) {

									} else {
										var wbsEle = mm.concat("", num + 1);
									}

									//End of Phase3 UAT issue
									// Begin of Phase3 UAT issue 
									if (wbsEle.slice(-3) === "100") {
										wbsEle = wbsEle.slice(0, -3);
									}
									// End of Phase3 UAT issue
								}
								var oData = wbsElement.filter(function (a) {
									return a.Stufe === nextLvl;
								});
								var oData1 = oData.filter(function (a) {
									return a.Zposid === wbsEle;
								});
								if (oData1.length === 0) {
									break;
								}
							}
							// }else{
							// 	wbsEle = "";
							// }                            //  Phase3 UAT issue End 

							/*====================below code for getting the position====================*/
							if (currLvl === 1) {
								var addPosition = wbsElement.length;
							} else if (currLvl === 3) {

								var currWbsEle = wbsElement[currRow].Zposid;
								var oDataVal = wbsElement.filter(function (a) {
									return a.PsPhiup === currWbsEle;
								});
								//Phase3 UAT issue
								if (oDataVal.length > 0) {
									// var addPosition = wbsElement.map(function (o) {    //  commented on 25-Mar-Hierarchy issue
									// 	return o.Zposid;
									// }).indexOf(oDataVal[oDataVal.length - 1].Zposid);  // End of commented on 25-Mar-Hierarchy issue
									// var currLevel = wbsElement[currRow].Stufe;
									//   var oDataLevelCurr = wbsElement.filter(function (a) {
									// 	return a.Stufe === currLevel;
									// });
									var currWBS = wbsElement[currRow].Zposid;
									var currWbsIncludes = wbsElement.filter(function (obj) {
										//check if object value contains value you are looking for
										if (obj.Zposid.includes(currWBS)) {
											//add this object to the filtered array
											return obj;
										}
									});

									if (currWbsIncludes) {
										var currWbsIncludesLastWBS = currWbsIncludes[currWbsIncludes.length - 1].Zposid;
										var addPosition = wbsElement.map(function (o) {
											return o.Zposid;
										}).indexOf(currWbsIncludesLastWBS);
									} else {
										// var addPosition = wbsElement.length
									}
								} else {
									addPosition = -1;
								}
								// End of Phase3 UAT issue 
								if (addPosition === -1) {
									addPosition = currRow + 1;
								} else {
									addPosition = addPosition + 1;
								}
							} else if (currLvl === 4) {
								var currWbsEle = wbsElement[currRow].Zposid;
								var oDataVal = wbsElement.filter(function (a) {
									return a.PsPhiup === currWbsEle;
								});
								//Phase3 UAT issue
								if (oDataVal.length > 0) {
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(oDataVal[oDataVal.length - 1].Zposid);
								} else {
									addPosition = -1;

								}
								if (addPosition === -1) {
									addPosition = currRow + 1;
								} else {
									addPosition = addPosition + 1;
								}
							} else {
								var m = currWbsEle.slice(-2);
								var mm1 = currWbsEle.slice(0, -2);
								var num = parseInt(m, 10);
								if (m === "99") {
									var nextParentWbs = wbsElement[currRow].PsPhiri;
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(nextParentWbs)
									if (addPosition === -1) {
										var mj = wbsElement[currRow].PsPhiup;
										if (mj) {
											var m = mj.slice(-2);
											var mm1 = mj.slice(0, -2);
											var num = parseInt(m, 10);
											if (num < 10) {
												var nextwbsEleLe = mm1.concat("0", num + 1);
											} else {
												var nextwbsEleLe = mm1.concat("", num + 1);
											}
											var addPosition = wbsElement.map(function (o) {
												return o.Zposid;
											}).indexOf(nextwbsEleLe);
											if (addPosition === -1) {
												var addPosition = wbsElement.length;
											}
										} else {
											var addPosition = wbsElement.length;
										}
									}
								} else {
									// L1 Child issue 
									// if (num < 10) {
									// 	var nextwbsEleLe = mm1.concat("0", num + 1);
									// } else {
									// 	var nextwbsEleLe = mm1.concat("", num + 1);
									// }
									// var addPosition = wbsElement.map(function (o) {
									// 	return o.Zposid;
									// }).indexOf(nextwbsEleLe);var currWBS = wbsElement[currRow].Zposid;

									//

									var currWBS = wbsElement[currRow].Zposid;
									var currWbsIncludes = wbsElement.filter(function (obj) {
										//check if object value contains value you are looking for
										if (obj.Zposid.includes(currWBS)) {
											//add this object to the filtered array
											return obj;
										}
									});

									if (currWbsIncludes) {
										var currWbsIncludesLastWBS = currWbsIncludes[currWbsIncludes.length - 1].Zposid;
										var addPosition = wbsElement.map(function (o) {
											return o.Zposid;
										}).indexOf(currWbsIncludesLastWBS);
									}

									if (addPosition === -1) {
										var mj = wbsElement[currRow].PsPhiup;
										if (mj) {
											var m = mj.slice(-2);
											var mm1 = mj.slice(0, -2);
											var num = parseInt(m, 10);
											if (num < 10) {
												var nextwbsEleLe = mm1.concat("0", num + 1);
											} else {
												var nextwbsEleLe = mm1.concat("", num + 1);
											}
											// Begin of changes for Hierarchy issue -31-03-22
											// var addPosition = wbsElement.map(function (o) {  //  Commented 31-mar-222 L2 Position issue
											// 	return o.Zposid;
											// }).indexOf(nextwbsEleLe);
											var currWBS = wbsElement[currRow].Zposid;
											var currWbsIncludes = wbsElement.filter(function (obj) {
												//check if object value contains value you are looking for
												if (obj.Zposid.includes(currWBS)) {
													//add this object to the filtered array
													return obj;
												}
											});

											if (currWbsIncludes) {
												var currWbsIncludesLastWBS = currWbsIncludes[currWbsIncludes.length - 1].Zposid;
												var addPosition = wbsElement.map(function (o) {
													return o.Zposid;
												}).indexOf(currWbsIncludesLastWBS);
											}

											// End of changes for Hierarchy issue - 31-03-22
											if (addPosition === -1) {
												addPosition = wbsElement.length;
											} else {
												addPosition = addPosition + 1;
											}
										} else {
											var addPosition = wbsElement.length;
										}
									} else {
										addPosition = addPosition + 1;
									}
								}
							}

							/*===================================*/
							/*====================Add down key in selected item======================================*/

							/*============================================================================================*/
							/*====================below code for getting the up, Down, left, Right Key====================*/
							var last2digit = wbsEle.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = wbsEle.slice(0, -1);
							var wbsEleLe = mm.concat("", num - 1);
							// Phase3 UAT issue 
							// var leftWbs = wbsElement.filter(function (a) {
							// 	return a.Zposid === wbsEleLe;
							// });
							// var leftWbs = wbsElement.filter(function (a) {
							// 	return a.Zposid === currWbsEle;
							// });
							var leftWbs = wbsElement.filter(function (obj) {
								//loop through each object
								// for (Zposid in obj) {
								//check if object value contains value you are looking for
								if (obj.Zposid.includes(currWbsEle)) {
									//add this object to the filtered array
									return obj;
								}
								// }
							});
							// end of phase3 UAT issue
							// Phase3 UAT issue
							if (!PsPhile) {
								// if (leftWbs.length === 1) {   // phase3 UAT issue 
								if (leftWbs.length >= 1) {
									var oLeftwbsseqNumber = leftWbs.length - 1;
									if (oData.length != 0) {
										PsPhile = leftWbs[oLeftwbsseqNumber].Zposid;
									} else {
										PsPhile = "";
									}

									// PsPhile = wbsEleLe;
								} else {
									PsPhile = "";
								}

							}
							PsPhiup = wbsElement[currRow].Zposid;
							PsPhido = "";
							PsPhiri = "";
							/*===================================================================================================*/
							var currDown = wbsElement[currRow].PsPhido;
							if (currDown === "") {
								wbsElement[currRow].PsPhido = wbsEle;
							}
							var preWbsEle = PsPhile;
							if (preWbsEle) {
								var addPosiToRight = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(PsPhile);
								if (oData.length != 0) {
									wbsElement[addPosiToRight].PsPhiri = wbsEle;
								}

							}

							/*===================================================================================================*/
							this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, nextLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
								PsPhido);

						} else {
							if (oData1.length === 0) {
								var currWBS = wbsElement[currRow].Zposid;
								var currWbsIncludes = wbsElement.filter(function (obj) {
									//check if object value contains value you are looking for
									if (obj.Zposid.includes(currWBS)) {
										//add this object to the filtered array
										return obj;
									}
								});

								if (currWbsIncludes) {
									var currWbsIncludesLastWBS = currWbsIncludes[currWbsIncludes.length - 1].Zposid;
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(currWbsIncludesLastWBS);
									// L1 delete all childs
									// if (addPosition) {
									// 	addPosition = addPosition + 1;
									// }
									// new code
									addPosition = addPosition + 1;

								} else {
									var addPosition = currRow + 1;
									//	var addPosition = wbsElement.length + 1;
								}

							} else {
								var addPosition = parseInt(nextLvl, 10) + 1;
							}
							/*====================Add down key in selected item======================================*/

							/*============================================================================================*/
							var last2digit = wbsEle.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = wbsEle.slice(0, -1);
							var wbsEleLe = mm.concat("", num - 1);
							var leftWbs = wbsElement.filter(function (a) {
								return a.Zposid === wbsEleLe;
							});
							if (leftWbs.length === 1) {
								PsPhile = wbsEleLe;
							} else {
								PsPhile = "";
							}
							PsPhiup = wbsElement[currRow].Zposid;
							PsPhido = "";
							// Phase3 UAT issue - Hierarchy 
							if (oData.length !== 0) {
								PsPhiri = oData[0].Zposid;
								var addPosiToRight = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(PsPhiri);
								wbsElement[addPosiToRight].PsPhile = wbsEle;
							} else {
								PsPhiri = "";
							}
							//end of changes

							/*===================================================================================================*/
							var currDown = wbsElement[currRow].PsPhido;
							if (currDown === "") {
								wbsElement[currRow].PsPhido = wbsEle;
							}
							var preWbsEle = PsPhile;
							if (preWbsEle) {
								var addPosiToRight = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(PsPhile);
								wbsElement[addPosiToRight].PsPhiri = wbsEle;
							}

							/*===================================================================================================*/
							this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, nextLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
								PsPhido);
						}
					} else {
						var mm = nextWbsEle.slice(0, -2);
						var wbsEle = mm.concat("", num);
						var oData = wbsElement.filter(function (a) {
							return a.Stufe === nextLvl;
						});
						var oData1 = oData.filter(function (a) {
							return a.Zposid === wbsEle;
						});
						if (oData1.length !== 0) {
							for (var j = 0; j < oData.length; j++) {
								var last2digit = wbsEle.slice(-2);
								var num = parseInt(last2digit, 10);
								var mm = wbsEle.slice(0, -2);
								var wbsEle = mm.concat("", num + 1);
								var oData = wbsElement.filter(function (a) {
									return a.Stufe === nextLvl;
								});
								var oData1 = oData.filter(function (a) {
									return a.Zposid === wbsEle;
								});
								if (oData1.length === 0) {
									break;
								}
							}
							/*==============below code for getting the position====================*/
							if (currLvl === 1) {
								var addPosition = wbsElement.length;
							} else if (currLvl === 4) {
								var currWbsEle = wbsElement[currRow].Zposid;
								var oDataVal = wbsElement.filter(function (a) {
									return a.PsPhiup === currWbsEle;
								});
								var addPosition = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(oDataVal[oDataVal.length - 1].Zposid);
								if (addPosition === -1) {
									addPosition = currRow + 1;
								} else {
									addPosition = addPosition + 1;
								}
							} else {
								var m = currWbsEle.slice(-2);
								var mm1 = currWbsEle.slice(0, -2);
								var num = parseInt(m, 10);
								if (m === "99") {
									var nextParentWbs = wbsElement[currRow].PsPhiri;
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(nextParentWbs)
									if (addPosition === -1) {
										var mj = wbsElement[currRow].PsPhiup;
										if (mj) {
											var m = mj.slice(-2);
											var mm1 = mj.slice(0, -2);
											var num = parseInt(m, 10);
											if (num < 10) {
												var nextwbsEleLe = mm1.concat("0", num + 1);
											} else {
												var nextwbsEleLe = mm1.concat("", num + 1);
											}
											var addPosition = wbsElement.map(function (o) {
												return o.Zposid;
											}).indexOf(nextwbsEleLe);
											if (addPosition === -1) {
												var addPosition = wbsElement.length;
											}
										} else {
											var addPosition = wbsElement.length;
										}
									}
								} else {
									if (num < 10) {
										var nextwbsEleLe = mm1.concat("0", num + 1);
									} else {
										var nextwbsEleLe = mm1.concat("", num + 1);
									}
									var addPosition = wbsElement.map(function (o) {
										return o.Zposid;
									}).indexOf(nextwbsEleLe);
									if (addPosition === -1) {
										var mj = wbsElement[currRow].PsPhiup;
										if (mj) {
											var m = mj.slice(-2);
											var mm1 = mj.slice(0, -2);
											var num = parseInt(m, 10);
											if (num < 10) {
												var nextwbsEleLe = mm1.concat("0", num + 1);
											} else {
												var nextwbsEleLe = mm1.concat("", num + 1);
											}
											var addPosition = wbsElement.map(function (o) {
												return o.Zposid;
											}).indexOf(nextwbsEleLe);
											if (addPosition === -1) {
												var addPosition = wbsElement.length;
											}
										} else {
											var addPosition = wbsElement.length;
										}
									}
								}

							}

							/*===================================*/
							/*====================Add down key in selected item======================================*/

							/*============================================================================================*/
							var last2digit = wbsEle.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = wbsEle.slice(0, -2);
							if (mm === 10) {
								var wbsEleLe = mm.concat("0", num - 1);
							} else {
								var wbsEleLe = mm.concat("", num - 1);
							}
							var leftWbs = wbsElement.filter(function (a) {
								return a.Zposid === wbsEleLe;
							});
							if (leftWbs.length === 1) {
								PsPhile = wbsEleLe;
							} else {
								PsPhile = "";
							}
							PsPhiup = wbsElement[currRow].Zposid;
							PsPhido = "";
							PsPhiri = "";
							/*===================================================================================================*/
							var currDown = wbsElement[currRow].PsPhido;
							if (currDown === "") {
								wbsElement[currRow].PsPhido = wbsEle;
							}
							var preWbsEle = PsPhile;
							if (preWbsEle) {
								var addPosiToRight = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(PsPhile);
								wbsElement[addPosiToRight].PsPhiri = wbsEle;
							}
							/*===================================================================================================*/
							this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, nextLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
								PsPhido);

						} else {
							if (oData1.length === 0) {
								var addPosition = currRow + 1;
							} else {
								var addPosition = parseInt(nextLvl, 10) + 1;
							}
							/*====================Add down key in selected item======================================*/

							/*============================================================================================*/
							var last2digit = wbsEle.slice(-2);
							var num = parseInt(last2digit, 10);
							var mm = wbsEle.slice(0, -2);
							if (mm === 10) {
								var wbsEleLe = mm.concat("0", num - 1);
							} else {
								var wbsEleLe = mm.concat("", num - 1);
							}
							var leftWbs = wbsElement.filter(function (a) {
								return a.Zposid === wbsEleLe;
							});
							if (leftWbs.length === 1) {
								PsPhile = wbsEleLe;
							} else {
								PsPhile = "";
							}
							PsPhiup = wbsElement[currRow].Zposid;
							PsPhido = "";
							PsPhiri = "";
							/*===================================================================================================*/
							var currDown = wbsElement[currRow].PsPhido;
							if (currDown === "") {
								wbsElement[currRow].PsPhido = wbsEle;
							}
							var preWbsEle = PsPhile;
							if (preWbsEle) {
								var addPosiToRight = wbsElement.map(function (o) {
									return o.Zposid;
								}).indexOf(PsPhile);
								wbsElement[addPosiToRight].PsPhiri = wbsEle;
							}
							/*===================================================================================================*/
							this.onAddSiblingChild(projDefValue, wbsEle, t1CoCode, nextLvl, addPosition, Description, currRow, PsPhiup, PsPhile, PsPhiri,
								PsPhido);
						}
					}
				} else {
					MessageToast.show("Child WBS can only be added for level 2 to level 5.");
				}
			} else {
				MessageToast.show("Please select only one WBS.");
			}
			this.getView().byId("idTable").clearSelection();
			// MessageToast.show("Coming Sooooon!!!");
		},
		onConvUprCase: function (oEvent) {
			var projDefi = oEvent.getParameter("value").toUpperCase();
			var id = oEvent.getParameter("id");
			this.getView().byId(id).setValue(projDefi);
		},
		onSetProjDefiDataTab4: function (oEvent) {
			var projDefi = oEvent.getParameter("value").toUpperCase();
			if (projDefi.split(" ").length === 1) {
				this.getView().byId("idProjDefi").setValueState("None");
				var t1CoCode = this.getView().byId("idT1ComCode").getValue();

				var oViewModel = this.getView().getModel("appView");
				oViewModel.getData().fixedWBSEle = projDefi;
				this.getView().getModel("appView").refresh(true);

				this.getView().byId("idProjDefi").setValue(projDefi);
				var fist2ComCode = t1CoCode.substring(0, 2);
				var first2ProjDef = projDefi.substring(0, 2);
				if (fist2ComCode === first2ProjDef || t1CoCode === "NL03" || t1CoCode === "CR00" || t1CoCode === "CR01" || t1CoCode === "CHZS") {
					// var oModel = this.getView().getModel();
					var oModel = this.getView().getModel("pageModel"); // rohit - change
					var wbsEleCunt = oModel.getProperty("/wbsElementStr").length;
					if (wbsEleCunt >= 1) {
						var that = this;
						var dialog = new sap.m.Dialog({
							title: "Confirm",
							type: "Message",
							content: new sap.m.Text({
								text: "Changing the Project Definition will change all the WBS element in WBS Details tab"
							}),
							beginButton: new sap.m.Button({
								text: "Ok",
								press: function () {
									var itemDetails = that.getView().getModel("pageModel").getData().wbsElementStr;
									var noItem = itemDetails.length;
									var currValue = itemDetails[0].Zposid;
									var newValue = projDefi;
									for (var i = 0; i < noItem; i++) {
										itemDetails[i].Zposid = itemDetails[i].Zposid.replace(currValue, newValue);
										itemDetails[i].Zpspid = itemDetails[i].Zpspid.replace(currValue, newValue);
										if (itemDetails[i].PsPhido) {
											itemDetails[i].PsPhido = itemDetails[i].PsPhido.replace(currValue, newValue);
										}
										if (itemDetails[i].PsPhiup) {
											itemDetails[i].PsPhiup = itemDetails[i].PsPhiup.replace(currValue, newValue);
										}
										if (itemDetails[i].PsPhile) {
											itemDetails[i].PsPhile = itemDetails[i].PsPhile.replace(currValue, newValue);
										}
										if (itemDetails[i].PsPhiri) {
											itemDetails[i].PsPhiri = itemDetails[i].PsPhiri.replace(currValue, newValue);
										}
									}
									dialog.close();
								}
							}),
							endButton: new sap.m.Button({
								text: "Cancel",
								press: function () {
									sap.ui.core.BusyIndicator.hide();
									dialog.close();
									// var oldValue1 = that.getView().getModel().getProperty("/wbsElementStr")[0].Zpspid;
									var oldValue1 = that.getView().getModel("pageModel").getProperty("/wbsElementStr")[0].Zpspid; // rohit - change
									that.getView().byId("idProjDefi").setValue(oldValue1);
								}
							}),
							afterClose: function () {
								dialog.destroy();
							}
						});
						dialog.open();
					} else {
						var oViewModel = this.getView().getModel("appView");
						var type = oViewModel.getData().type;
						if (type === "OpprApp") {
							var wbsEle = projDefi.concat(".01");
							var PsPhido = wbsEle.concat(".01");
							// this.onAddWbsEle(projDefi, projDefi, t1CoCode, 1, "REL", "CRTD", "BLANK");
							this.onAddWbsEle(projDefi, projDefi, t1CoCode, 1, "REL", "CRTD", "BLANK", "", "", "", wbsEle);
							// this.onAddWbsEle(projDefValue, wbsEle, t1CoCode, 2, "REL", "CRTD", "BLANK", PsPhiup, PsPhile, PsPhiri, PsPhido);
							this.onAddWbsEle(projDefi, wbsEle, t1CoCode, 2, "REL", "CRTD", "BLANK", projDefi, "", "", PsPhido);

							var oppData = this.getView().getModel().getProperty("/toOpprData");
							for (var i = 1; i <= oppData.length; i++) {
								// for (var i = 1; i <= 4; i++) {
								// this.onAddWbsEle(projDefi, wbsEle, t1CoCode, 2, "REL", "OPEN", "");
								if (i === 1) {
									var wbsEle3 = PsPhido;
									this.onAddWbsEle(projDefi, wbsEle3, t1CoCode, 3, "REL", "OPEN", "", wbsEle, "", "", "");
								} else {
									// var oModel = this.getView().getModel();
									var oModel = this.getView().getModel("pageModel"); // rohit - change
									var wbsElement = oModel.getProperty("/wbsElementStr");
									var preWbsNo = wbsElement.length - 1;
									var PsPhile = wbsElement[preWbsNo].Zposid;

									var last2digit = PsPhile.slice(-2);
									var num = parseInt(last2digit, 10);
									var mm = PsPhile.slice(0, -1);
									var wbsEle1 = mm.concat("", num + 1);

									wbsElement[preWbsNo].PsPhiri = wbsEle1;
									var PsPhiri = "";
									this.onAddWbsEle(projDefi, wbsEle1, t1CoCode, 3, "REL", "OPEN", "", wbsEle, PsPhile, PsPhiri, "");
								}

							}
							this.onSelectOppAppDataTab4();
							this.onSelectUserStatus();
						} else {
							var wbsEleLevel = "1";
							this.getView().byId("idProjDefi").setValueState("None");
							this.onAddWbsEle(projDefi, projDefi, t1CoCode, 1, "REL", "CRTD", "BLANK");
						}

						// var wbsEleLevel = "1";
						// this.getView().byId("idProjDefi").setValueState("None");
						// this.onAddWbsEle(projDefi, projDefi, t1CoCode, 1, "REL", "CRTD", "BLANK");
					}

				} else {
					MessageToast.show("First 2 characters of the Project Definition should match the Company Code.");
				}
			} else {
				this.getView().byId("idProjDefi").setValueState("Error");
				MessageToast.show("Project definition cannot contain spaces.");
			}

		},

		onChangeWBSElem: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);

			var oModel = this.getView().getModel("pageModel");
			var wbsElement = oModel.getProperty("/wbsElementStr")
				// this.onUpdateDefaultRowValue(wbsElement);

			var wbsEle = oEvent.getParameter("value");
			var id = oEvent.getParameter("id");
			// var iRowIndex = this.onRowCount(oEvent);
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			// var oldValue = this.getView().byId(id).getInterface()._$input[0].defaultValue;
			var oldValue = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].oldZposid; // for phase2 table

			var oViewModel = this.getView().getModel("appView");
			var oDefaultWBS = oViewModel.getData().fixedWBSEle;
			var oCurrDefaultWBS = wbsEle.split(".")[0];
			var oExtChangeLine = wbsElement[0].Zentry_tp;
			if (wbsEle === "" || oDefaultWBS !== oCurrDefaultWBS) {
				this.getView().byId(id).setValue(oldValue);
				sap.ui.core.BusyIndicator.hide();
				if (oExtChangeLine === "E" || oExtChangeLine === "C") {
					sap.m.MessageToast.show("Change Project ID mask on existing project is not allowed", {
						duration: 5000
					});
				} else {
					sap.m.MessageToast.show("Change project ID in the WBS details page is not allowed, please change in the project definition page", {
						duration: 5000
					});

				}
			} else {
				var oModel = this.getView().getModel("pageModel");
				var wbsElement = oModel.getProperty("/wbsElementStr")

				var oExixWbsEle = wbsElement.filter(function (a) {
					return a.Zposid === wbsEle;
				});
				if (oExixWbsEle.length <= 1) {
					var m = oldValue.split(".");
					if (m[m.length - 1] === "") {
						for (var i = 0; i < wbsElement.length; i++) {
							if (wbsElement[i].PsPhiri === oldValue) {
								wbsElement[i].PsPhiri = wbsElement[i].PsPhiri.replace(oldValue, wbsEle);
							}
						}
					} else {
						for (var i = 0; i < wbsElement.length; i++) {
							if (wbsElement[i].Zposid) {
								wbsElement[i].Zposid = wbsElement[i].Zposid.replace(oldValue, wbsEle);
								// var id1 = this.getView().byId("idTable").getRows()[iRowIndex].getCells()[1].getId();
								// this.getView().byId(id1).getInterface()._$input[0].defaultValue = wbsElement[i].Zposid;
								this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].oldZposid = wbsElement[i].Zposid;
							}
							if (wbsElement[i].PsPhido) {
								wbsElement[i].PsPhido = wbsElement[i].PsPhido.replace(oldValue, wbsEle);
							}
							if (wbsElement[i].PsPhiri) {
								wbsElement[i].PsPhiri = wbsElement[i].PsPhiri.replace(oldValue, wbsEle);
							}
							if (wbsElement[i].PsPhile) {
								wbsElement[i].PsPhile = wbsElement[i].PsPhile.replace(oldValue, wbsEle);
							}
							if (wbsElement[i].PsPhiup) {
								wbsElement[i].PsPhiup = wbsElement[i].PsPhiup.replace(oldValue, wbsEle);
							}
						}
					}

					// this.getView().byId(id).getInterface()._$input[0].defaultValue = wbsEle;
					this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].oldZposid = wbsEle; // for phase2 table
					sap.ui.core.BusyIndicator.hide();
					// MessageToast.show("WBS changed " + wbsElement[iRowIndex].Stufe);
					sap.m.MessageToast.show("WBS changed", {
						duration: 5000
					});
					this.onUpdateDefaultRowValue(wbsElement, "DEL")
				} else {
					this.getView().byId(id).setValue(oldValue);
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("WBS Element already exists in the structure, please use a different number.", {
						duration: 5000
					});
				}
			}

			// }
		},
		onSetLevel: function (oEvent) {
			var wbsLevel = this.getView().byId("idRangeSlider").getValue();
			wbsLevel = parseInt(wbsLevel, 10);

			if (wbsLevel < 2) {
				this.getView().byId("idRangeSlider").setValue(2);
				this.getView().byId("idLev2").setVisible(true);
				this.getView().byId("idLev3").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev4").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev5").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev6").setVisible(false).setValueState("None").setValue("");
			} else if (wbsLevel === 2) {
				this.getView().byId("idLev2").setVisible(true);
				this.getView().byId("idLev3").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev4").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev5").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev6").setVisible(false).setValueState("None").setValue("");
			} else if (wbsLevel === 3) {
				this.getView().byId("idLev2").setVisible(true);
				this.getView().byId("idLev3").setVisible(true);
				this.getView().byId("idLev4").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev5").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev6").setVisible(false).setValueState("None").setValue("");
			} else if (wbsLevel === 4) {
				this.getView().byId("idLev2").setVisible(true);
				this.getView().byId("idLev3").setVisible(true);
				this.getView().byId("idLev4").setVisible(true);
				this.getView().byId("idLev5").setVisible(false).setValueState("None").setValue("");
				this.getView().byId("idLev6").setVisible(false).setValueState("None").setValue("");
			} else if (wbsLevel === 5) {
				this.getView().byId("idLev2").setVisible(true);
				this.getView().byId("idLev3").setVisible(true);
				this.getView().byId("idLev4").setVisible(true);
				this.getView().byId("idLev5").setVisible(true);
				this.getView().byId("idLev6").setVisible(false).setValueState("None").setValue("");
			} else if (wbsLevel > 5) {
				this.getView().byId("idRangeSlider").setValue(5);
				sap.m.MessageToast.show("Please select WBS between levels 2 & 5.", {
					duration: 5000
				});
				this.getView().byId("idLev2").setVisible(true);
				this.getView().byId("idLev3").setVisible(true);
				this.getView().byId("idLev4").setVisible(true);
				this.getView().byId("idLev5").setVisible(true);
				this.getView().byId("idLev6").setVisible(false).setValueState("None").setValue("");
			}
			// else if (wbsLevel === 6) {
			// 	this.getView().byId("idLev2").setVisible(true);
			// 	this.getView().byId("idLev3").setVisible(true);
			// 	this.getView().byId("idLev4").setVisible(true);
			// 	this.getView().byId("idLev5").setVisible(true);
			// 	this.getView().byId("idLev6").setVisible(true);
			// }
		},
		onSetMax99: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var wbsLevel = this.getView().byId(newID).getValue();
			wbsLevel = parseInt(wbsLevel, 10);
			if (wbsLevel >= 5) {
				this.getView().byId(newID).setValue(5);
			} else if (wbsLevel === 0) {
				this.getView().byId(newID).setValue(1);
			}
		},
		onSetMax100: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var wbsLevel = this.getView().byId(newID).getValue();
			wbsLevel = parseInt(wbsLevel, 10);
			if (wbsLevel >= 100) {
				this.getView().byId(newID).setValue(100);
			} else if (wbsLevel <= 0) {
				this.getView().byId(newID).setValue(0);
			}
			// this.checkSpecialChars(oEvent);
		},
		onNoValidation: function (oEvent) {
			var newValue = oEvent.getParameter("value");
			var fieldid = oEvent.getParameter("id");
			var regex = /^[0-9]*$/;
			if (newValue === "") {
				// sap.ui.getCore().byId(fieldid).setValueState("Error");
				sap.ui.getCore().byId(fieldid).setValueStateText("Enter Number only.");
			} else if (!newValue.match(regex)) {
				sap.ui.getCore().byId(fieldid).setValue(newValue.replace(/[^0-9-]/g, ""));
				// sap.ui.getCore().byId(fieldid).setValueStateText("Enter Number only.");
			} else {
				sap.ui.getCore().byId(fieldid).setValueState("None");
			}
			this.onInputValidation(oEvent);
			this.onSetMax100(oEvent);
			this.checkSpecialChars(oEvent);
			// this.onInputVelidationL1(oEvent);
		},
		handleUploadPress: function (oEvent) {
			var oFileUploader = this.getView().byId("fileUploader");

			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first");
				return;
			} else {
				// var oAllow = this.onAttachDocCarRestrict(oFileUploader.getValue());
				sap.ui.core.BusyIndicator.show(0);
				var oModel1 = this.getView().getModel("oDataModel");
				var oAttach = oFileUploader.getValue();
				var that = this;
				oModel1.read("/AttachSplCharSet", {
					success: function (oResponse) {
						var odata = oResponse.results;
						var odatalen = oResponse.results.length;
						var oAllow = true;
						var oSpChar = "";
						for (var i = 0; i < odatalen; i++) {
							var oSpCar = oResponse.results[i].Value;
							if (oSpChar === "") {
								if (oSpCar === "'") {
									oSpChar = '" ' + oSpCar + ' "' + " , ";
								} else {
									oSpChar = '"' + oSpCar + '"' + " , ";
								}

							} else {
								if (oSpCar === "'") {
									oSpCar = '" ' + oSpCar + ' "' + " , ";
								} else {
									oSpCar = '"' + oSpCar + '"' + " , ";
								}
								oSpChar = oSpChar + oSpCar;
							}

						}
						for (var i = 0; i < odatalen; i++) {
							var oSpCar = oResponse.results[i].Value;
							var oResult = oAttach.includes(oSpCar);
							if (oResult) {
								oAllow = false;
								break;
							}
						}
						if (oAllow) {
							var file = [];
							that.browsePayload = [];
							var obj = [];
							var name = [];
							var type = [];
							var domRef = oFileUploader.getFocusDomRef();

							for (var i = 0; i < domRef.files.length; i++) {
								file[i] = domRef.files[i];
								name[i] = file[i].name;
								type[i] = file[i].type;
								// File Reader will start reading the file

								var reader = new FileReader();
								reader.readAsDataURL(file[i]);

							}
							var oModel = that.getView().getModel("appView");
							var Owner = oModel.getData().Owner;
							var projType = that.getView().byId("idProjType").getSelectedKey();
							if (projType === "PRJ_TYP1") {
								projType = "C";
							} else if (projType === "PRJ_TYP2") {
								projType = "J";
							}
							// var timeStamp = oModel.getData().ReqDate;
							var attachment = that.getView().getModel().getData().toAttach;
							that.getView().byId("idIWOUpload").setEnabled(true);
							var that1 = that;
							reader.onload = function (event) {
								for (var i = 0; i < domRef.files.length; i++) {
									// get an access to the content to the file
									var vContent = event.currentTarget.result;
									if (type[i] === "") {
										var fileData = vContent.split(";base64,")[1];
									} else {
										var dataRemove = "data:" + type[i] + ";base64,";
										var fileData = vContent.replace(dataRemove, "");
									}

									var length = attachment.length;
									// that.postFileToBackend(workorderId, that.fileName, that.fileType, vContent);
									for (var j = 0; j < length; j++) {
										if (name[i] === attachment[j].Filename) {
											MessageToast.show("You have selected the same file again" + name[i]);
											this.flag = true;
											// return;
										} else {
											if (j === attachment.length - 1 && this.flag !== true) {
												attachment.push({
													"Reqid": "",
													"Projty": projType,
													"Filename": name[i],
													"Mimetype": type[i],
													"Data": fileData,
													"Ernam": Owner,
													"DocSubType": ""
												});
											}
										}

									}
									if (i === 0 && attachment.length === 0) {
										attachment.push({
											"Reqid": "",
											"Projty": projType,
											"Filename": name[i],
											"Mimetype": type[i],
											"Data": fileData,
											"Ernam": Owner,
											"DocSubType": ""
										});
									}
								};
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show("Files successfully uploaded. Please see the attachment section for the uploaded files.");

								// that.getView().byId("fileUploader").setValue("");
							}
						} else {
							sap.ui.core.BusyIndicator.hide();
							oFileUploader.setValue("");
							sap.m.MessageToast.show("The following character is not allowed in the attachment filename:" + oSpChar, {
								duration: 5000
							});
						}
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
					}
				});
				// if(oAllow){
				// 	var file = [];
				// 	this.browsePayload = [];
				// 	var obj = [];
				// 	var name = [];
				// 	var type = [];
				// 	var domRef = oFileUploader.getFocusDomRef();

				// 	for (var i = 0; i < domRef.files.length; i++) {
				// 		file[i] = domRef.files[i];
				// 		name[i] = file[i].name;
				// 		type[i] = file[i].type;
				// 		// File Reader will start reading the file

				// 		var reader = new FileReader();
				// 		reader.readAsDataURL(file[i]);

				// 	}
				// 	var oModel = this.getView().getModel("appView");
				// 	var Owner = oModel.getData().Owner;
				// 	var projType = this.getView().byId("idProjType").getSelectedKey();
				// 	if (projType === "PRJ_TYP1") {
				// 		projType = "C";
				// 	} else if (projType === "PRJ_TYP2") {
				// 		projType = "J";
				// 	}
				// 	// var timeStamp = oModel.getData().ReqDate;
				// 	var attachment = this.getView().getModel().getData().toAttach;
				// 	this.getView().byId("idIWOUpload").setEnabled(true);
				// 	var that = this;
				// 	reader.onload = function (event) {
				// 		for (var i = 0; i < domRef.files.length; i++) {
				// 			// get an access to the content to the file
				// 			var vContent = event.currentTarget.result;
				// 			if (type[i] === "") {
				// 				var fileData = vContent.split(";base64,")[1];
				// 			} else {
				// 				var dataRemove = "data:" + type[i] + ";base64,";
				// 				var fileData = vContent.replace(dataRemove, "");
				// 			}

				// 			var length = attachment.length;
				// 			// that.postFileToBackend(workorderId, that.fileName, that.fileType, vContent);
				// 			for (var j = 0; j < length; j++) {
				// 				if (name[i] === attachment[j].Filename) {
				// 					MessageToast.show("You have selected the same file again" + name[i]);
				// 					this.flag = true;
				// 					// return;
				// 				} else {
				// 					if (j === attachment.length - 1 && this.flag !== true) {
				// 						attachment.push({
				// 							"Reqid": "",
				// 							"Projty": projType,
				// 							"Filename": name[i],
				// 							"Mimetype": type[i],
				// 							"Data": fileData,
				// 							"Ernam": Owner,
				// 							"DocSubType": ""
				// 						});
				// 					}
				// 				}

				// 			}
				// 			if (i === 0 && attachment.length === 0) {
				// 				attachment.push({
				// 					"Reqid": "",
				// 					"Projty": projType,
				// 					"Filename": name[i],
				// 					"Mimetype": type[i],
				// 					"Data": fileData,
				// 					"Ernam": Owner,
				// 					"DocSubType": ""
				// 				});
				// 			}
				// 		};
				// 		MessageToast.show("Files successfully uploaded. Please see the attachment section for the uploaded files.");

				// 		// that.getView().byId("fileUploader").setValue("");
				// 	}
				// }else{
				// 	sap.m.MessageToast.show("Please change the file name.", {
				// 		duration: 5000
				// 	});	
				// }
			}

		},
		onAttachDocCarRestrict: function (oAttach) {
			sap.ui.core.BusyIndicator.show(0);
			var oModel1 = this.getView().getModel("oDataModel");
			var oAttach = oAttach;
			var that = this;
			oModel1.read("/AttachSplCharSet", {
				success: function (oResponse) {
					var odata = oResponse.results;
					var odatalen = oResponse.results.length;
					var oAllow = true;
					for (var i = 0; i < odatalen; i++) {

					}
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					return false;
				}
			});
		},
		handleAttachment: function (oEvent) {
			this.getView().byId("fileUploader").setValue("");
			sap.ui.core.BusyIndicator.show(0);
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				var that = this;
				var oView = that.getView();
				var oModel = that.getView().getModel();
				// that.getView().setModel(oModel);
				var oDialog = oView.byId("idViewAttachment");
				oDialog = sap.ui.xmlfragment("idViewAttachment", "WBS.Compass.WbsCompassRequest.fragments.downloadAttac", that);
				// connect dialog to view (models, lifecycle)
				oView.addDependent(oDialog);
			}
			oDialog.open();
			// var oData = this.getView().getModel().getData().toAttach;
			// var oModel = new sap.ui.model.json.JSONModel(oData);
			// var oTable = this.byId("list");
			// oTable.setModel(oModel);
			sap.ui.core.BusyIndicator.hide();
		},
		// onDeleteAttach: function (oEvent) {
		// 	var sPath = oEvent.getSource().getParent().getBindingContext().sPath;
		// 	// var sPath = oEvent.getSource().getParent().getBindingContextPath();
		// 	var index = sPath.slice(sPath.length - 1);
		// 	var attachment = this.getView().getModel().getData().toAttach;
		// 	// attachment[index].pop();
		// 	var attachment = this.getView().getModel().getData().toAttach;
		// 	var reqNumber = attachment[index].Reqid;
		// 	var fileName = attachment[index].Filename;
		// 	var oModel = this.getView().getModel("oDataModel");
		// 	var that = this;
		// 	if (attachment[index].Reqid) {
		// 		oModel.setUseBatch(true);
		// 		oModel.setDeferredGroups(["foo"]);
		// 		var mParameters = {
		// 			groupId: "foo",
		// 			success: function (oResponse) {
		// 				sap.ui.core.BusyIndicator.hide();
		// 				attachment.splice(index, 1);
		// 				var oModel1 = that.getView().getModel();
		// 				oModel1.refresh();
		// 				sap.m.MessageToast.show("Attachment deleted.", {
		// 					duration: 5000
		// 				});
		// 				// that.onCancel();
		// 				// that.onGetAttachment();
		// 			},
		// 			error: function (oError) {
		// 				sap.ui.core.BusyIndicator.hide();
		// 				sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
		// 					duration: 5000
		// 				});
		// 			}
		// 		};

		// 		var sPath1 = "/WBSAttachSet(Reqid='" + reqNumber + "',Filename='" + fileName + "')";
		// 		oModel.remove(sPath1, mParameters);
		// 		oModel.submitChanges(mParameters);
		// 	}

		// }
		onDeleteAttach: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContext().sPath;
			// var sPath = oEvent.getSource().getParent().getBindingContextPath();
			var index = sPath.slice(sPath.length - 1);
			var attachment = this.getView().getModel().getData().toAttach;
			// attachment[index].pop();
			var attachment = this.getView().getModel().getData().toAttach;
			var reqNumber = attachment[index].Reqid;
			var fileName = attachment[index].Filename;
			var AttachID = attachment[index].AttachID;

			if (attachment[index].Reqid) {
				var oDataModel = this.getView().getModel("oDataModel");
				// var sPath1 = "/WBSAttachSet(Reqid='" + reqNumber + "',Filename='" + fileName + "')";  // Phase2 Changed to Attached ID is key
				var sPath1 = "/WBSAttachSet(Reqid='" + reqNumber + "',AttachID='" + AttachID + "')";
				var that = this;
				oDataModel.remove(sPath1, {
					success: function (oResponse) {
						sap.ui.core.BusyIndicator.hide();
						attachment.splice(index, 1);
						var oModel = that.getView().getModel();
						oModel.refresh();
						sap.m.MessageToast.show("Attachment deleted.", {
							duration: 9000
						});
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						sap.m.MessageToast.show("System  Error Occurred from the  back end!!!", {
							duration: 5000
						});
					}
				});
			} else {
				attachment.splice(index, 1);
				var oModel = this.getView().getModel();
				oModel.refresh();

			}
		},
		onValidationChange: function (oEvent) {

			var requiredInputs = this.ListOfRequiredFieldsChange();
			var passedValidation = this.validateEventFeedbackForm(requiredInputs);
			if (passedValidation === false) {
				//show an error message, rest of code will not execute.
				return false;
			} else if (passedValidation === true) {
				//show an error message, rest of code will not execute.
				return true;
			}

		},
		ListOfRequiredFieldsChange: function () {
			let requiredInputs;
			// return requiredInputs = ['idT2ComCode', 'idProjType', 'idReqType', 'idReqTypeDtls', 'idReqTypeFun', 'idT1FinAnyst',
			// 	'idT1Priority',
			// 	'idT2SubbComm', 'idProjDefi', 'idT4ProjDefDesc', 'idStartDate', 'idEnddate', 'idT2PersResp', 'idT2ContractTrm', 'idT2PrjSts',
			// 	'idT2ProjRespCC', 'idT2BusnsArea', 'idT2PrftCenter', 'idT2ContractId', 'idT2ContractType', 'idT2ProjAdmin', 'idWBSTypeT1'
			// ];

			return requiredInputs = ['idProjDefi', 'idT4ProjDefDesc', 'idT2CoCode', 'idStartDate', 'idEnddate', 'idT2PersResp',
				'idT2ProjRespCC', 'idT2BusnsArea', 'idT2PrftCenter', 'idT2ProjCategory', 'idT2ContractId', 'idT2ContractType', 'idT2ProjAdmin'
			];
		},
		_fnRemoveFields: function (oData) {
			// remove temporary binding for Table - rohit change
			for (var i = 0; i < oData.length; i++) {
				delete oData[i].oldZposid;
				delete oData[i].ZposidValueState;
				delete oData[i].ArktxValueState;
				delete oData[i].BukrsValueState;
				delete oData[i].FkstlValueState;
				delete oData[i].PgsbrValueState;
				delete oData[i].PrctrValueState;
				delete oData[i].PrartValueState;
				delete oData[i].ZzsolseidValueState;
				delete oData[i].SystatuslineValueState;
				delete oData[i].UstatuslineValueState;
				delete oData[i].RaKeyValueState;
				delete oData[i].PrjAdValueState;
				delete oData[i].FinAppValueState;
				delete oData[i].Wbsowner1ValueState;
				delete oData[i].Vernr1ValueState;
				delete oData[i].ZzprojPhaseCdValueState;
				delete oData[i].OpportuT4TempModel; //OpportuT4TempModel delete
				delete oData[i].oCaseSafeModel; // temp model delete
				delete oData[i].oServiOfferTempSet; // temp model delete for oSeriv
				delete oData[i].oUserStatusModel; // temp model delete for User Status
				delete oData[i].oProjPhaseTempModl; // temp model for Project Phase

				// Performance issue -Start 
				delete oData[i].IconColor; // Icon  color  change  property 

				// Performance issue -End 

			}
			return oData;
		},
		onfilenameLengthExceed: function () {
			MessageBox.show("File Name should not more than 100 characters ", sap.m.MessageBox.Icon.ERROR, "Error");
		},

		onSelectUserStatus: function (prjType) {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			if (prjType === "PRJ_TYP2") {
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
			} else if (prjType === "PRJ_TYP1") {
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CSSP "));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "INTG "));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKAC "));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKCO"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "AMRT"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CCLS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
			} else {
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
				aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
			}

			var that = this;
			oModel.read("/Search_User_StatusSet", {
				filters: aFilters,
				success: function (oResponse) {
					var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");

					for (var m = 0; m < tableData.length; m++) { // rohit - change
						var contextid = "/wbsElementStr/" + m.toString();
						that.getView().getModel("pageModel").setProperty(contextid + "/oUserStatusModel", oResponse.results);

					}
				},
				error: function (oError) {}
			});
		},
		onSelectUserStatusTab4: function (prjType, row, keyID) {
			var oModel = this.getView().getModel("oDataModel");
			var aFilters = [];
			if (prjType === "PRJ_TYP2") {
				if (keyID === "CLSD" || keyID === "TECO") {
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
				} else {
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
				}

			} else if (prjType === "PRJ_TYP1") {
				if (keyID === "CLSD" || keyID === "TECO") {
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CCLS"));
				} else {
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "OPEN"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "NOLA"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CANS"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CRTD"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CATS"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CLSD"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CSSP "));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "INTG "));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKAC "));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "WKCO"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "AMRT"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "CCLS"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "MIGR"));
					aFilters.push(new Filter("Value", sap.ui.model.FilterOperator.EQ, "ZCLS"));
				}

			}

			var that = this;
			oModel.read("/Search_User_StatusSet", {
				filters: aFilters,
				success: function (oResponse) {

					var tableData = that.getView().getModel("pageModel").getProperty("/wbsElementStr");
					var contextid = "/wbsElementStr/" + row;
					that.getView().getModel("pageModel").setProperty(contextid + "/oUserStatusModel", oResponse.results);
				},
				error: function (oError) {}
			});
		},
		onSelectSystmSts: function (oEvent) {
			var iRowIndex = this.onRowCountNew(oEvent); // for phase2 table
			var oViewModel = this.getView().getModel("appView");
			var oExtEntry = this.getView().getModel("pageModel").getProperty("/wbsElementStr")[iRowIndex].Zentry_tp;
			var keyID = oEvent.getSource().getSelectedKey();
			if (oExtEntry === "E" || oExtEntry === "C") {
				if (keyID === "CLSD" || keyID === "TECO") {
					// var oAddiData = oEvent.getParameter("selectedItem").getAdditionalText();
					var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr");
					var oWbsNumber = wbsElement[iRowIndex].Zposid;
					var owbsElementLenght = wbsElement.length;
					var oProTyp = this.getView().byId("idProjType").getSelectedKey();
					for (var i = 0; i < owbsElementLenght; i++) {
						var oWbsNumberTable = wbsElement[i].Zposid;
						var oChangeOrNot = oWbsNumberTable.startsWith(oWbsNumber, 0);
						if (oChangeOrNot === true) {
							var contextid = "/wbsElementStr/" + i;
							if (keyID === "TECO") {
								if (wbsElement[i].ZzCapPt) {
									this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "CCLS");
								} else {
									this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "CLSD");
								}

								if (this.getView().getModel("pageModel").getProperty(contextid + "/Systatusline") === "CLSD") {
									this.getView().getModel("pageModel").setProperty(contextid + "/Systatusline", "CLSD");
								} else {
									this.getView().getModel("pageModel").setProperty(contextid + "/Systatusline", "TECO");
								}
							} else if (keyID === "CLSD") {
								if (wbsElement[i].ZzCapPt) {
									this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "CCLS");
								} else {
									this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "CLSD");
								}
								this.getView().getModel("pageModel").setProperty(contextid + "/Systatusline", "CLSD");
							}
							this.onSelectUserStatusTab4(oProTyp, i, keyID);
						}

					}
				} else {
					var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr");
					var oWbsNumber = wbsElement[iRowIndex].Zposid;
					var oProTyp = this.getView().byId("idProjType").getSelectedKey();
					if (wbsElement[iRowIndex].Stufe === 2 || wbsElement[iRowIndex].Stufe === 1) {
						var contextid = "/wbsElementStr/" + iRowIndex;
						this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "CRTD");
					}
					this.onSelectUserStatusTab4(oProTyp, iRowIndex, keyID);
				}

				// else {
				// 	var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr");
				// 	var oWbsNumber = wbsElement[iRowIndex].Zposid;
				// 	var owbsElementLenght = wbsElement.length;
				// 	var oProTyp = this.getView().byId("idProjType").getSelectedKey();
				// 	for (var i = 0; i < owbsElementLenght; i++) {
				// 		var oWbsNumberTable = wbsElement[i].Zposid;
				// 		var oChangeOrNot = oWbsNumberTable.startsWith(oWbsNumber, 0);
				// 		if (oChangeOrNot === true) {
				// 			var contextid = "/wbsElementStr/" + i;
				// 			if (wbsElement[i].Stufe > 2) {
				// 				this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "");
				// 				this.getView().getModel("pageModel").setProperty(contextid + "/Systatusline", keyID);

				// 				this.onSelectUserStatusTab4(oProTyp, i, keyID);
				// 			} else {
				// 				// this.getView().getModel("pageModel").setProperty(contextid + "/Ustatusline", "CRTD");
				// 				// this.getView().getModel("pageModel").setProperty(contextid + "/Systatusline", keyID);
				// 				this.onSelectUserStatusTab4(oProTyp, i, keyID);
				// 			}

				// 		}

				// 	}

				// }

			}
		},
		onCancelSpanish: function (oEvent) {
			// this.getView().byId("idReqType").setValue("");
			this.getView().byId("idReqType").setSelectedKey("");
			this.getView().byId("idT2LdPracSet").setRequired(false);
			this.getView().byId("idT2OpporId").setRequired(false);
			this.getView().byId("idT2OpporId").setEditable(false);
			this.getView().byId("idT2RevMthd").setEditable(false);
			this.getView().byId("idT2ContractType").setEditable(true);
			this.getView().byId("idGlobProj").setSelected(false);
			this.getView().byId("idGlobProj").setEditable(true);
			var oViewModel = this.getView().getModel("appView");
			oViewModel.getData().projType = "Internal";
			this.getView().getModel("appView").refresh(true);
			var oDailog = this.byId("idIwoOwner");
			oDailog.destroy();

		},
		onGarbageValueSafeCaseId: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				oInput.setSelectedKey("");
				// oInput.setValueState("Error");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				oInput.setValueState("None");
			}
		},
		onGarbageValueAgm: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oInput = oView.byId(newID);
			var oInput1 = oView.byId(newID).getSelectedKey();
			if (!oInput1) {
				oInput.setValue("");
				// oInput.setValueState("Error");
				this.getView().getModel().setProperty("/draftData/d/Agm", "");
				oInput.setValueStateText("Select the value from suggestion.");
			} else {
				oInput.setValueState("None");
			}
		},
		_fnReadEnableDesableFields: function (projType) {
			var that = this;
			return new Promise(
				function (resolve, reject) {
					var oModel = that.getView().getModel("oDataModel");
					oModel.read("/WBSHeaderChngFlgSet('" + projType + "')", {
						urlParameters: {
							'$expand': "toItmChngFlg"
						},
						success: function (oResponse) {
							delete oResponse.__metadata;
							delete oResponse.toItmChngFlg.__metadata;
							var oViewModel = that.getView().getModel("appView");
							var wbsType = that.getView().byId("idWBSTypeT1").getValue();
							if (oViewModel.getData().Admin === true && wbsType === "B") {
								oResponse.Zzldpcid = "X";
								oResponse.Zzsiebelid = "X";
								oResponse.toItmChngFlg.ZzTaskOrderCat = "X";
							}

							var EnableDesable = new JSONModel(oResponse);
							that.getView().setModel(EnableDesable, "EnableDesable");

							var toItmChngFlg = new JSONModel(oResponse.toItmChngFlg);
							that.getView().setModel(toItmChngFlg, "toItmChngFlg");
							resolve(oResponse);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				});
		},
		_downloadFileDialogReview: function (oEvent) {
				var oOrgModel = this.getOwnerComponent().getModel("oDataModelMng");
				var oModel = new sap.ui.model.odata.ODataModel(oOrgModel.sServiceUrl);
				// var Iwo = this.getView().getModel("appView").getData().iwoNo;
				// oModel.read("/IWOFileUploadSet(Uploadid='" + Iwo + "')/$value", {
				var oViewModel = this.getView().getModel("appView");
				var oType = oViewModel.getData().type;
				// if (oType === "ChangeProject") {
				// 	var Projectid = this.getView().byId("idProjDefi").getValue();
				// 	if (Projectid) {
				// 		var ReqNo = "";
				// 		oModel.read("/WBSExcelDownloadSet(Zpspid='" + Projectid + "',ReqNo='" + ReqNo + "')/$value", {
				// 			success: function (oData, response) {
				// 				var file = response.requestUri;
				// 				window.open(file);
				// 			},
				// 			error: function (oErr) {
				// 				// console.error("error");
				// 				// MessageBox.error(JSON.parse(oErr.responseText).error.innererror.errordetails[0].message);
				// 				MessageBox.show("Unable to download", sap.m.MessageBox.Icon.ERROR, "Error");
				// 			}
				// 		});

				// 	} else {
				// 		MessageBox.show("Project ID is mandatory", sap.m.MessageBox.Icon.ERROR, "Error");
				// 	}

				// } else if (oType === "ChangeRequest" || oType === "View") {
				// var oCuurentSystem = window.location.href.split("//")[1].split("-")[0];
				// if (oCuurentSystem === "sapmdp") {
				// 	MessageBox.show("This is Phase3 change", sap.m.MessageBox.Icon.ERROR, "Error");
				// } else {
				if (oType === "View") {
					var oReq = oViewModel.getData().Requestid;
					var Projid = "";
					oModel.read("/WBSExcelRevDownloadSet(Zpspid='" + Projid + "',ReqNo='" + oReq + "')/$value", {
						success: function (oData, response) {
							var file = response.requestUri;
							window.open(file);
						},
						error: function (oErr) {
							// console.error("error");
							// MessageBox.error(JSON.parse(oErr.responseText).error.innererror.errordetails[0].message);
							MessageBox.show("Unable to download", sap.m.MessageBox.Icon.ERROR, "Error");
						}
					});
				}
				// }

			}
			// onSelectUserStatusT4: function (oEvent) {
			// 	var okey = oEvent.getSource().getSelectedKey();
			// 	this.onInputValidation(oEvent);
			// 	var iRowIndex = this.onRowCountNew(oEvent);
			// 	var wbsElement = this.getView().getModel("pageModel").getProperty("/wbsElementStr");
			// 	var oGtmWbs = wbsElement[iRowIndex].Zz_gtmwbs;
			// 	var oSpanish = this.getView().byId("idReqType").getSelectedKey();
			// 	if (oSpanish === "Spanish Delivery Project" && oGtmWbs !== "") {
			// 		if (okey === "CLSD") {
			// 			var oMsg = "User Status of mapping/linked Delivery WBS elements must be set to Close prior";
			// 			sap.m.MessageToast.show(oMsg, {
			// 				duration: 5000
			// 			});
			// 		}
			// 	}
			// }
	});
});