sap.ui.define([
	"WBS/Compass/WbsCompassRequest/test/unit/controller/View1.controller"
], function () {
	"use strict";
});