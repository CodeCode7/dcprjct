/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"WBS/Compass/WbsCompassRequest/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});