sap.ui.define(function () {
	"use strict";
	return {
		getIcon: function (sStatus) {

			switch (sStatus) {
			case "E":
				if ((this.getParent().getModel().getData().toError.length === 0) || (this.getParent().getModel("pageModel").getData().wbsElementStr.length > 52) ) {
					this.getParent().removeStyleClass("errorIcon");
					return 'sap-icon://message-error';
				} else {
					this.getParent().addStyleClass("errorIcon");
					return 'sap-icon://message-error';
				}
			case "S":
				this.getParent().removeStyleClass("errorIcon");
				return 'sap-icon://message-error';
			default:
				this.getParent().removeStyleClass("errorIcon");
				return 'sap-icon://message-error';
			}

		}
	};
}, true);