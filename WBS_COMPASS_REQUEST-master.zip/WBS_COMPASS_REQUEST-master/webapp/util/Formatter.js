sap.ui.define(["sap/m/Token"], function (Token) {
	"use strict";

	return {
		CheckBoxClick: function (sValue) {
			if (sValue === "X") {
				return true;
			} else {
				return false;
			}
		},
		maskInput: function (sValue) {
			switch (sValue) {
			case 1:
				return "##@-#####";
			case 2:
				return "##@-#####.$$";
			case 3:
				return "##@-#####.$$.$$";
			case 4:
				return "##@-#####.$$.$$.$$";
			case 5:
				return "##@-#####.$$.$$.$$.$$";
			case 6:
				return "##@-#####.$$.$$.$$.$$.$$";
			default:
				return "##@-#####";
			}
		},
		PriorityData: function (sValue) {
			switch (sValue) {
			case "1":
				return "1 CONTRACT-PENALTY";
			case "2":
				return "2 CONTRACT-NOPENALTY";
			case "3":
				return "3 HIGH";
			case "4":
				return "4 MEDIUM";
			case "5":
				return "5 LOW";
			case "6":
				return "6 UNSIGNED GROWTH";
			default:
				return "";
			}
		},
		canType: function (sValue) {
			switch (sValue) {
			case "1":
				return "STANDARD";
			case "2":
				return "RESALE";
			case "3":
				return "RLT TARGET";
			default:
				return "";
			}
		},
		levl1or2Disable: function (sValue) {
			switch (sValue) {
			case 1:
				return false;
			case 2:
				return false;
			default:
				return true;
			}
		},
		levl1Disable: function (sValue) {
			switch (sValue) {
			case 1:
				return false;
			case 2:
				return true;
			default:
				return true;
			}
		},
		ChanProjEdit: function (sValue) {
			switch (sValue) {
			case "E":
				return false;
			case "N":
				return true;
			case "C":
				return false;
			default:
				return true;
			}
		},
		columnDisabledOppInter: function (sValue, oValue) {
			if (oValue) {
				return true;
			} else {
				switch (sValue) {
				case "Trade":
					return true;
				case "Internal":
					return false;
				default:
					return true;
				}
			}

		},
		columnDisabled: function (sValue) {
			switch (sValue) {
			case "Trade":
				return true;
			case "Internal":
				return false;
			default:
				return true;
			}
		},
		taskOrdrColDisabled: function (sValue) {
			if (sValue === "Trade") {
				return true;
			} else if (sValue === "Internal") {
				return false;
			}
		},
		enableDesableChanProj: function (sValue) {
			switch (sValue) {
			case "X":
				return true;
			default:
				return false;
			}
		},
		columnDisabledtype: function (sValue) {
			switch (sValue) {
			case "OpprApp":
				return false;
			default:
				return true;
			}
		},
		AttachBtnEnabled: function (sValue) {
			if (sValue) {
				return true;
			} else {
				return false;
			}
		},
		PersonResp: function (sValue) {
			if (sValue) {
				var m = this.getView().byId("idT2PersResp").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},
		ProjType: function (sValue) {
			switch (sValue) {
			case "C":
				return "Trade Project";
			case "J":
				return "Internal Project";
			case "PRJ_TYP1":
				return "Trade Project";
			case "PRJ_TYP2":
				return "Internal Project";
			default:
				return "";
			}
		},
		ChanProjPhaseMndt: function (sValue) {
			switch (sValue) {
			case "C":
				return true;
			case "L":
				return true;
			case "B":
				return true;
			case "M":
				return true;
			default:
				return false;
			}
		},
		ReqType: function (sValue) {
			var m = this.getView().byId("idReqType").getItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},
		ReqTypeDetails: function (sValue) {
			var m = this.getView().byId("idReqTypeDtls").getItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},

		ReqTypeFunction: function (sValue) {
			// var m = this.getView().byId("idReqTypeFun").getItems();
			// var oData = m.filter(function (a) {
			// 	return a.mProperties.key === sValue;
			// });
			// if (oData[0] === undefined) {
			// 	return sValue;
			// } else {
			// 	return oData[0].getText();
			// }
			switch (sValue) {
			case "REQ_FUN1":
				return "Finance Analyst";
			case "REQ_FUN2":
				return "Business Account Manager";
			case "REQ_FUN3":
				return "Project Manager";
			case "REQ_FUN4":
				return "GSO–Backoffice Services";
			default:
				return "";
			}
		},
		FinanceAnyst: function (sValue) {
			if (sValue) {
				var m = this.getView().byId("idT1FinAnyst").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},
		FinanceAnystT2: function (sValue) {
			if (sValue) {
				var m = this.getView().byId("idT2FinAnyst").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},
		AccountManagerT2: function (sValue) {
			if (sValue) {
				var m = this.getView().byId("idT2ActMngr").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},
		/*Tab 2*/
		ContractType: function (sValue) {
			var m = this.getView().byId("idT2ContractType").getItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},
		ProjectAdmin: function (sValue) {
			/*below code for Input fields*/
			if (sValue) {
				var m = this.getView().byId("idT2ProjAdmin").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},
		ActManger: function (sValue) {
			/*below code for Input fields*/
			if (sValue) {
				var m = this.getView().byId("idT2ActMngr").getSuggestionItems();
				var oData = m.filter(function (a) {
					return a.mProperties.key === sValue;
				});
				if (oData[0] === undefined) {
					if (sValue !== "00000000") {
						return sValue;
					} else {
						sValue = "";
						return sValue;
					}
				} else {
					return oData[0].getText();
				}
			} else {
				if (sValue !== "00000000") {
					return sValue;
				} else {
					sValue = "";
					return sValue;
				}
			}
		},
		RevMethdod: function (sValue) {
			/*below code for comboBox*/
			var m = this.getView().byId("idT2RevMthd").getItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},
		ContractTerm: function (sValue) {
			/*below code for Input fields*/
			var m = this.getView().byId("idT2ContractTrm").getSuggestionItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},
		T2Program: function (sValue) {
			/*below code for Input fields*/
			var m = this.getView().byId("idT2Program").getSuggestionItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},
		ProjectCategory: function (sValue) {
			/*below code for Input fields*/
			var m = this.getView().byId("idT2ProjCategory").getItems();
			var oData = m.filter(function (a) {
				return a.mProperties.key === sValue;
			});
			if (oData[0] === undefined) {
				return sValue;
			} else {
				return oData[0].getText();
			}
		},

		/*Below old Code*/
		getMessageType: function (sStatus) {
			switch (sStatus) {
			case "S":
				return 'Success';
			case "E":
				return 'Error';
			case "W":
				return 'Warning';
			case "I":
				return 'Information';
			default:
				return 'Error';
			}
		},
		getMessageTypeRow: function (sStatus) {
			switch (sStatus) {
			case "S":
				return 'Success';
			case "E":
				return 'Error';
			case "W":
				return 'Warning';
			case "I":
				return 'Information';
			default:
				return 'Information';
			}
		},
		getColorRow: function (sStatus) {
			switch (sStatus) {
			case "N":
				return 'Success';
			case "C":
				return 'Warning';
			case "E":
				return 'Information';
			default:
				return 'Success';
			}
		},
		EnabledField: function (sValue) {
			var oViewModel = this.getView().getModel("appView");
			if (oViewModel !== undefined) {
				var AType = oViewModel.getData().editableType;
				if (AType === "V") {
					return false;
				} else {
					return true;
				}
			}
		},
		getmasterWBSCombo: function (sStatus) {
			var condi2 = window.location.href.split("#")[1].split("?")[1].split("&")[2].split("=")[1];
			// if (condi2 === "AdditionOfRes") {
			// 	return true;
			// }else{
			// 	return false;
			// }
		},
		twoDecimalValue: function (sValue) {
			var oValue;
			if (sValue === null) {
				oValue = "";
			} else {
				var num = parseFloat(sValue);
				oValue = num.toFixed(2);
			}
			return oValue;
		},
		// removeDecimalValue: function (sValue) {
		// 	var nValue;
		// 	if (sValue) {
		// 		nValue = Math.round(sValue);
		// 		// return nValue;
		// 	} else {
		// 		nValue;

		// 	}
		// 		return nValue;
		// },
		getSowText: function (sStatus) {
			if (sStatus !== null && sStatus !== "") {
				var getData = this.getView().getModel("oSowAppView").oData;
				var json = getData.filter(function (a) {
					return a.Jobsubcat === sStatus;
				});
				return json[0].Jobsubcattext;
			}
		},
		multiInputFormat: function (args) {
			if (args != null) {
				// 				var text = args;
				// 				var n = args.split(",").length;
				// // 				var m = "00";
				// 				var m = new Token({key: args.split(",")[0], text: args.split(",")[0]});
				var appData = {
					tokens: [{
						text: "Deskjet Printer",
						key: "DP"
					}, {
						text: "LCD Display",
						key: "LCD"
					}]
				};

				var dataModel = new sap.ui.model.json.JSONModel(appData);

				return dataModel;

			}
		},
		dateFormat: function (sValue) {
			var str;
			if (sValue === null) {
				str = "";
			} else {
				str = sValue.substring(0, sValue.length - 1);
				str = str.substring(1);

				str = str.replace(/\D/g, "");
				var dt = new Date(eval(str));
				var oDateFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					format: "yMMMd"
				});
				str = oDateFormat.format(dt);
			}
			//sValue = sValue.replace("/", "");
			return str;

		},
		breakLineName: function (sStatus) {
			var m = sStatus;
			var name = "";
			if (sStatus === null || sStatus === undefined) {
				var name = "";
			} else {
				var n = m.split(",");
				for (var i = 0; i < n.length; i++) {
					var nameCount = i + 1;
					name = name + nameCount + ") " + n[i] + "\n";
				}
			}
			return name;
		},
		ChanProjEditIndi: function (aValue) {
			// if(sValue === "E" || sValue === "C"){
			if (aValue) {
				return false;
			} else {
				return true;
			}
			// }else{
			// 	return true;
			// }
		},
		ChanProjEditIndiLevel: function (aValue, oValue) {
			// if(oValue === 1 || oValue === 2){    // for phase2 changes
			if (oValue === 1) {
				return false;
			} else {
				// if(sValue === "E" || sValue === "C"){
				if (aValue) {
					return false;
				} else {
					return true;
				}
				// }else{
				// 	return true;
				// }
			}

		},
		lvl1or2typeENoneditable: function (sValue, aValue, oValue) {
			if (sValue === "") {
				switch (oValue) {
				case 1:
					return false;
				case 2:
					return false;
				default:
					return true;
				}
			} else if (sValue === "ChangeProject") {
				if (aValue === "E" || aValue === "C") {
					switch (oValue) {
					case 1:
						return false;
					case 2:
						return false;
					default:
						return true;
					}
				} else {
					switch (oValue) {
					case 1:
						return false;
					case 2:
						return false;
					default:
						return true;
					}
				}
			} else if (sValue === "ChangeRequest") {
				if (aValue === "E" || aValue === "C") {
					switch (oValue) {
					case 1:
						return false;
					case 2:
						return false;
					default:
						return true;
					}
				} else {
					switch (oValue) {
					case 1:
						return false;
					case 2:
						return false;
					default:
						return true;
					}
				}
			} else {
				switch (oValue) {
				case 1:
					return false;
				case 2:
					return false;
				default:
					return true;
				}
			}
		},
		taskColumnDisabled: function (sValue, aValue, oValue, bValue) {
			if (oValue === "View") {
				return false;
			} else {
				if (sValue === "Trade") {
					switch (aValue) {
					case 1:
						return false;
					case 2:
						return false;
					default:
						return true;
					}
				} else {
					if (bValue === "B") {
						// return true;
						switch (aValue) {
						case 1:
							return false;
						case 2:
							return false;
						default:
							return true;
						}

					} else {
						return false;
					}

				}
			}

		},
		WBSType: function (sValue) {
			switch (sValue) {
			case "B":
				return "B : MPC - Cust Biz Devt";
			case "C":
				return "C : MPC - Cust Chargeable Delivery";
			case "D":
				return "D : MPC - SW Devt for Cust Resale";
			case "E":
				return "E : MPC - Internal Project Non-Chargeable";
			case "J":
				return "J : MPC - Internal Project Chargeable";
			case "L":
				return "L : MPC -Cust Chrg Del onÂ non-Compass CoCode";
			case "M":
				return "M : MPC -Cust Biz Devt onÂ non-Compass CoCode";
			case "O":
				return "O : MPC -Int Proj Chrg on non-Compass CoCode";
			case "R":
				return "R : MPC - Volumetric Project";
			case "V":
				return "V : MPC - Billable Pursuit Sales costs";
			case "W":
				return "W : MPC - Non-Billable Pursuit Sales costs";
			}
		},
	};
});