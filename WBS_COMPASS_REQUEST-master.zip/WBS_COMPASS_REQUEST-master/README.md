# WBS_COMPASS_REQUEST
GPRS - WBS Creation  for Compass
