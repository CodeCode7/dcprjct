sap.ui.define([
			"sap/ui/core/mvc/Controller",
			"sap/ui/core/Core",
			"sap/ui/layout/HorizontalLayout",
			"sap/ui/layout/VerticalLayout",
			"sap/m/Dialog",
			"sap/m/DialogType",
			"sap/m/Button",
			"sap/m/ButtonType",
			"sap/m/Label",
			"sap/m/MessageToast",
			"sap/m/Text",
			"sap/m/TextArea",
			"sap/ui/model/Filter",
			"sap/ui/model/FilterOperator",
			"sap/ui/core/BusyIndicator", "sap/m/Token",
			"sap/ui/model/json/JSONModel", "sap/ui/model/odata/v2/ODataModel",
			"sap/m/SearchField",
			"sap/ui/table/library",
			"sap/m/MessageBox",
			//row colour
			"sap/ui/table/RowSettings",
			//row colour
			"OppDat/model/formatter"

		], function (Controller, Core, HorizontalLayout, VerticalLayout, Dialog, DialogType, Button, ButtonType, Label, MessageToast, Text,
			TextArea, Filter, FilterOperator, BusyIndicator, Token, JSONModel, ODataModel, SearchField, library, MessageBox, RowSettings, formatter) {
			"use strict";
			var SortOrder = library.SortOrder;
			return Controller.extend("OppDat.controller.View1", {
					formatter: formatter,
					onInit: function () {

						this.oModel = this.getOwnerComponent().getModel("oDataModel");

						//set the model on view to be used by the UI controls
						this.getView().setModel(this.oModel);
						/*	var tableData = this.getView().byId("ManageOpportunityTable");
											var x = tableData.getBinding("items");
											var filt = new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.EQ, "NoData");
											x.filter(filt);*/

						// https://sapmdd-dxc.sapnet.dxccorp.net:8443/sap/bc/ui2/flp#DXCGPRS-manageOpportunity?OptId=OPX-0020512182?Zbukrs=GBA5&TYPE=OppIdMange
						var condi1 = window.location.href.split("#")[1].split("?").length;

						// var condi1 = 0;
						if (condi1 > 1) {
							var optid = window.location.href.split("#")[1].split("?")[1].split("&")[0].split("=")[1];

							var zbukrs = window.location.href.split("#")[1].split("?")[2].split("&")[0].split("=")[1];

							this.byId("inpOppId").setValue(optid);
							this.byId("inpCcode").setValue(zbukrs);

							this.onSearch();

						}

						this.getView().setModel(new JSONModel({}), "localModel");
						var emptyMod = new JSONModel({
							oppDataSet: []
						});
						this.getView().setModel(emptyMod, "tabModel"); //set table model

					},
					// OnTokenUpdate: function (oEvent) {

					// 	this.onSearch(oEvent); // call the search event // rohit - update
					// },
					onAfterRendering: function () {

					},

					onSuggestionOppId: function (oEvent) {
						var sTerm = oEvent.getParameter("suggestValue");
						var oSource = oEvent.getSource();
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.Contains, sTerm),

							],
							and: false
						});
						oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
					},

					onSuggestionCCODE: function (oEvent) {
						var sTerm = oEvent.getParameter("suggestValue");
						var oSource = oEvent.getSource();
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Zbukrs", sap.ui.model.FilterOperator.Contains, sTerm)

							],
							and: false
						});
						oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
					},

					onSuggestionPerAssi: function (oEvent) {
						var sTerm = oEvent.getParameter("suggestValue");
						var oSource = oEvent.getSource();
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("PerAsn", sap.ui.model.FilterOperator.Contains, sTerm),
								new sap.ui.model.Filter("PerAsnEmail", sap.ui.model.FilterOperator.Contains, sTerm)
							],
							and: false
						});
						// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
					},

					onSuggestionStatus: function (oEvent) {
						var sTerm = oEvent.getParameter("suggestValue");
						var oSource = oEvent.getSource();
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("ZStatus", sap.ui.model.FilterOperator.Contains, sTerm)
								// new sap.ui.model.Filter("PerAsnEmail", sap.ui.model.FilterOperator.Contains, sTerm)
							],
							and: false
						});
						// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
					},

					// Filter new code

					// *****************f4 HelpFilter code Start

					onSuggestionF4CCode: function (oEvent1) {
						var sTerm = oEvent1.getParameter("suggestValue");
						// var oSource = oEvent.getSource();
						var aFilters = new sap.ui.model.Filter({
							filters: [
								new sap.ui.model.Filter("Bukrs", sap.ui.model.FilterOperator.Contains, sTerm)
								// new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.Contains, "C")
							],
							and: false
						});
						oEvent1.getSource().getBinding("suggestionItems").filter(aFilters);
					},

					onSuggestionF4PersonAss: function (oEvent) {
						var sTerm = oEvent.getParameter("suggestValue");
						// var oSource = oEvent.getSource();
						var aFilters = new sap.ui.model.Filter({
							filters: [

								new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
								new sap.ui.model.Filter("NameFirst", sap.ui.model.FilterOperator.Contains, sTerm),
								new sap.ui.model.Filter("NameLast", sap.ui.model.FilterOperator.Contains, sTerm),
								new sap.ui.model.Filter("Cname", sap.ui.model.FilterOperator.Contains, sTerm)

							],
							and: false
						});
						oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
					},

					// *****************f4 HelpFilter code End
					addRow: function (oEvent) {
						var that = this;
						var oList = this.getView().byId("ManageOpportunityTable");
						// var length = oList.getSelectedContexts("tabModel").length;
						var length = oList.getSelectedIndices().length; // rohit - change

						if (this.ind === "") {
							if (length > 1) {
								sap.m.MessageToast.show("Please select only one line item at a time");
								return;
							}

						}
						var data = oList.getModel("tabModel").getData().oppDataSet;
						var ref = oList.getSelectedIndices()[0];
						// //bharghava
						// var oModel = this.getView().getModel("tabModel");
						// var wbsElement = oModel.getProperty("/tableData");
						// //bharghava
						var obj = data[ref];

						var objMap = this.getView().getModel("localModel").getData();

						// var unqId;
						// if (objMap[obj.OptId]) {
						// 	unqId = objMap[obj.OptId]
						// } else {
						// 	unqId = obj.uniq_cnt;
						// }

						var term1 = data.filter(function (a) {
							return a.OptId === data[ref].OptId;
						});
						var unqId = term1[term1.length - 1].uniq_cnt;
						// unqId = data[data.length - 1].uniq_cnt;
						// if (this.OptIdVal === obj.OptId) {
						// 	//	if (this.ing === "X") {
						// 	unqId = data[data.length - 1].UniqId;

						// 	//	}

						// } else {
						// 	this.ind = "";
						// }

						//	this.ing = "X";
						var val = Number(unqId.split("-")[2]);
						var val2 = (unqId).split("-");
						val2.pop(val2[2]);
						val2.push(val + 1);

						var valLength = val2[2].toString().length

						if (valLength === 1) {
							val2[2] = "00" + val2[2]
						}
						if (valLength === 2) {
							val2[2] = "0" + val2[2]
						}

						//var obj1 = obj;
						var status = "NEW"
						var prjNo = "0000000000"
						var perAsn = "00000000"
						var obj1 = {

							ChangedAt: obj.ChangedAt,
							ChangedOn: obj.ChangedOn,

							CrtdOn: obj.CrtdOn,
							CrtdAt: obj.CrtdAt,
							Sysid: obj.Sysid,
							// WiId: obj.WiId,
							ZStatus: status,
							PrjReqNo: prjNo,
							// DoNotprs: obj.DoNotprs,
							DisPos: obj.DisPos,
							DispChCmt: obj.DispChCmt,
							// NotPrssCmt: obj.NotPrssCmt,
							TcvVal: obj.TcvVal,
							PerAsnEmail: obj.PerAsnEmail,
							PerAsn: perAsn,
							OmpEmail: obj.OmpEmail,
							OmpId: obj.OmpId,
							AgmEmail: obj.AgmEmail,
							ActGm: obj.ActGm,
							FinAnl: obj.FinAnl,
							FinEmail: obj.FinEmail,
							PerResp: obj.PerResp,
							PerEmail: obj.PerEmail,
							TclVal: obj.TclVal,
							// SalStage: obj.SalStage,
							SalesStage: obj.SalesStage,
							CaseIdDes: obj.CaseIdDes,

							CasesafeId: obj.CasesafeId,
							// Zbukrs: obj.Zbukrs,
							ContModl: obj.ContModl,
							SolTyp: obj.SolTyp,
							Zzsolseid: obj.Zzsolseid,
							Mandt: obj.Mandt,
							Zpspid: obj.Zpspid,
							OptId: obj.OptId,
							uniq_cnt: val2.join("-"),
							// OptManag: obj.OptManag,

							// ReqNum: obj.ReqNum,

							// Soldto: obj.Soldto,

							ind: "X",
							//row colour
							rowStatus: "Information"
								//row colour
						};

						this.OptIdVal = obj1.OptId
						obj1.UniqId = val2.join("-");
						oList.getModel("tabModel").setSizeLimit("1000");

						oList.getModel("tabModel").getData().oppDataSet.push(obj1);
						//bharghava
						var oView = this.getView();
						var oTable = oView.byId("ManageOpportunityTable");
						oTable.sort(oView.byId("idoptid"), SortOrder.Ascending, true);
						//bharghava
						// bharghava
						var a = oList.getModel("tabModel").getData();
						a.oppDataSet.sort(function (a, b) {
							var nameA = a.OptId; // ignore upper and lowercase
							var nameB = b.OptId; // ignore upper and lowercase
							if (nameA < nameB) {
								return -1;
							}
							if (nameA > nameB) {
								return 1;
							}

							// names must be equal
							return 0;
						});

						oList.getModel("tabModel").refresh(true);

						if (this.ind === "") {
							oList.clearSelection(); // clear selected rows
						}

						this.ind = "X";
						oList.setFirstVisibleRow(data.length - 8); // scroll to the last 5 columns of the table
						// oList.setSelectedIndex(data.length - 1); // set last row as the selected row

						//bharghava

						// if(ind === "X"){

						// }
						// var oView = this.getView();
						// var oTable = oView.byId("ManageOpportunityTable");
						// oTable.sort(oView.byId("idoptid"), SortOrder.Ascending, true);
						//bharghava

					},

					// 		// **************************Code for Search functionality************************************
					onSearch: function (oEvent) {

						// this.SetInd = "";
						this.changeInd = "";
						this.ing = "";
						this.OptIdVal = "";
						var Model1 = new JSONModel({

						});
						//rohit - change
						// var tableId = this.getView().byId("ManageOpportunityTable");

						// tableId.setModel(Model1, "tabModel");
						//rohit - end of change

						this.selOppId = [];
						// this.selChangedate = [];
						this.selCompany = [];
						this.selStatus = [];

						this.selPA = [];

						var that = this;
						// tableData.clearSelection();
						this.finalFilters = [];
						this.ind = "";
						var itemProj = this.byId("inpOppId").getValue();
						if (itemProj !== "") {
							this.finalFilters.push(new sap.ui.model.Filter("OptId", sap.ui.model.FilterOperator.EQ, itemProj));
						}

						var itemProj = this.byId("inpCcode").getValue();
						if (itemProj !== "") {
							this.finalFilters.push(new sap.ui.model.Filter("Zbukrs", sap.ui.model.FilterOperator.EQ, itemProj));
						}

						var fromDate = this.byId("DRS3").getProperty("dateValue");
						var toDate = this.byId("DRS3").getProperty("secondDateValue");
						if (fromDate !== null && toDate !== null) {

							this.finalFilters.push(new sap.ui.model.Filter("CrtdOn", sap.ui.model.FilterOperator.BT, fromDate, toDate));

						}

						var itemProj = this.byId("inpPerAss").getValue();
						if (itemProj !== "") {
							this.finalFilters.push(new sap.ui.model.Filter("PerAsn", sap.ui.model.FilterOperator.EQ, itemProj));
						}

						if (this.selStatus) {
							// var itemstat = this.byId("inpStatus").getSelectedItems();
							var itemstat = this.byId("inpStatus").getSelectedItems();
							// if (itemProj !== "") {
							for (var count = 0; count < itemstat.length; count++) {
								var status = itemstat[count].getKey();
								this.finalFilters.push(new sap.ui.model.Filter("ZStatus", sap.ui.model.FilterOperator.EQ, status));
								// }

							}
						}
						//for checkbox 

						// var PendingOppId = this.byId("PendingOppId").getProperty("selected");

						// if (PendingOppId === true) {

						// 	this.finalFilters.push(new sap.ui.model.Filter("ZStatus", sap.ui.model.FilterOperator.EQ, "NEW"));
						// }

						//for checkbox

						var eventprop = oEvent; // rohit - changes
						if (this.finalFilters.length !== 0) {
							var oDta = this.getOwnerComponent().getModel("oDataModel");

							BusyIndicator.show();

							var sorter = new sap.ui.model.Sorter("OptId", false);

							oDta.read("/OPPORTUNITYID_NOTIFICATIONSet", {
								filters: this.finalFilters,
								success: function (oData, oResponse) {
									BusyIndicator.hide();

									// this.byId("ManageOpportunityTable").setVisibleRowCount(oData.results.length);
									if (oData === null || oData === undefined) {
										var sMessage = "Unexpected system error occurred; please log a support ticket";
										sap.m.MessageToast.show(sMessage);
										return;
									}
									// rohit - begin change
									// var tableModel = new JSONModel(oData.results);
									// var tableData = that.getView().byId("ManageOpportunityTable");
									// tableData.getModel("tabModel").getProperty("/oppDataSet").setData(oData);
									// tableData.setModel(tableModel, "tabModel");
									that.getView().getModel("tabModel").setProperty("/oppDataSet", oData.results); // set table model rohit 
									that.getView().byId("ManageOpportunityTable").setVisibleRowCount(5);
									that.onSelectGo(eventprop);

									//bharghava
									that.getView().byId("idopp").setText("Opportunity Header/Billing Data (" + oData.results.length + ")")
										// that.onSelect();
										//bharghava
										// rohit - end change
										// Disable row according conditions
										//	var x = tableData.getBinding("items");
										//	x.filter(that.finalFilters);

								},
								error: function (err) {
									BusyIndicator.hide();
								}
							});
						} else {

							// this.initiateCompass();
							this.onInit();
							BusyIndicator.hide();
						}

					},
					onGarbageValue: function (oEvent) {
						var newID = oEvent.getParameter("id");
						var oView = this.getView();
						var oInput = oView.byId(newID);
						var oInput1 = oView.byId(newID).getSelectedKey();
						if (!oInput1) {
							oInput.setValue("");
							oInput.setValueState("Error");
							oInput.setValueStateText("Select the value from suggestion.");
						} else {
							oInput.setValueState("None");
						}
						var id = this.byId("ManageOpportunityTable");
						var items = id.getSelectedIndex();
						var tableModel = this.getView().getModel("tabModel").getData().oppDataSet[items];
						tableModel.Bukrs = oInput1;
						this.getView().getModel("tabModel").refresh(true);
					},

					checkDone: function (oEvent) {
						var check = oEvent.getParameter("selected");
						var oPath = oEvent.getSource().getBindingContext("tabModel").getPath();
						var oNewPath = Number(oPath.split("/")[2]);
						var tabModel = this.getView().getModel("tabModel");

						if (check === true) {
							// oEvent.oSource.getParent().getCells()[16].setEditable(true);
							tabModel.setProperty("/oppDataSet/" + oNewPath + "/DoNotprs", "X");
							tabModel.setProperty("/oppDataSet/" + oNewPath + "/oReason", true);
							// oEvent.oSource.getBindingContext("tabModel").getObject().DoNotprs = "X";
							// this.SetInd = "X";

						} else {
							// oEvent.oSource.getParent().getCells()[16].setEditable(false);
							tabModel.setProperty("/oppDataSet/" + oNewPath + "/DoNotprs", "");
							tabModel.setProperty("/oppDataSet/" + oNewPath + "/oReason", false);

						}
						// this.getView().getModel("tabModel").refresh(true);

					},

					initiate: function () {
						BusyIndicator.show();
					},
					onSave: function (evt1) {

						var that = this;
						//bharghava

						// var oList = this.getView().byId("ManageOpportunityTable");
						// var length = oList.getSelectedIndex("tabModel").length;
						// if (length < 1) {
						// 	sap.m.MessageToast.show("Please select atleast one line item");
						// 	return;
						// }
						//bharghava
						var id = this.byId("ManageOpportunityTable");
						var items1 = id.getSelectedIndex(); //get selected items of the table
						// var tableModel = this.getView().getModel("tabModel").getData().oppDataSet; // table binded model 
						//Phase2 changes by Bharghava Reddy
						var items = id.getSelectedIndices();
						var tableModel = this.getView().getModel("tabModel").getData().oppDataSet;
						var tableModel1 = this.getView().getModel("tabModel").getData().oppDataSet[items1];
						//bharghava
						// var id = that.byId("ManageOpportunityTable");
						var firstselitem = id.getSelectedIndices()[0];
						var allSelectedItems = id.getSelectedIndices();
						var tabModel = id.getModel("tabModel");
						var tableModel = that.getView().getModel("tabModel").getData().oppDataSet;
						var items3 = tabModel.getData().oppDataSet;
						//01/12/2021
						var doNotCom = items3[firstselitem].NotPrssCmt;
						//01/12/2021
						var cocode = items3[firstselitem].Zbukrs;
						if (cocode === "") {
							sap.m.MessageToast.show("Fill mandaroty Fields");
							//bharghava
							// if (!tableModel1.Bukrs) {
							// 	sap.m.MessageToast.show("Company code is mandatory");

						} else {

							var oModel = this.getOwnerComponent().getModel("oDataModel");
							this.oModel = oModel;
							oModel.setUseBatch(true);
							oModel.setDeferredGroups(["foo"]);
							var mParameters = {
								groupId: "foo",
								success: function (oResponse) {
									that.changeInd = ""
										// 
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("Data saved", {
										duration: 5000
											// oModel.refresh();

									});
									var tableModel1 = new JSONModel();
									tableModel1.setData([]);
									that.getView().setModel(tableModel1, "tabModel");

									that.byId("searchId").fireSearch();
									that.oModel.refresh();
								},

								error: function (oError) {
									sap.ui.core.BusyIndicator.hide();
									sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
										duration: 5000
									});
								}
							};

							for (var i = 0; i < items.length; i++) {

								// var a = aContexts[i]; // getting selected row number.
								var selectedref = items[i]; // get the selected references of the table
								var obj = tableModel[selectedref]; // get the data from the model for selected indices

								var select = obj.DoNotprs;
								// var select = items[i].getCells()[15].getSelected();
								// var PerAsn = items[i].getCells()[13].getSelectedKey();

								// var checkInd = ""
								// if (select === true) {
								// 	checkInd = "X"
								// }
								//var PerAsn = obj.PerAsn.split("(")[1].split(")")[0];			

								if (obj.PerAsn.split("(")[1] === undefined) {
									// if (obj.PerAsn.split("(")[1] === undefined || obj.PerAsn === "") {
									var PerAsn = obj.PerAsn;
								} else {
									var PerAsn = obj.PerAsn.split("(")[1].split(")")[0];
								}
								var DoNotprs = "X"
								var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj.UniqId + "',OptId='" + obj.OptId + "')";
								if (obj.ind === "X") {
									sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet";
								}
								var DoNotprs = "X"
								var oData = {
									"d": {

										"OptId": obj.OptId,
										"DispChCmt": obj.DispChCmt,
										"PerAsn": PerAsn,
										// "PerAsn": obj.PerAsn.split("(")[1].split(")")[0],
										"UniqId": obj.UniqId,
										"Zbukrs": obj.Zbukrs,
										"NotPrssCmt": obj.NotPrssCmt,
										"DoNotprs": select
									}
								};

								if (obj.ind === "X") {
									delete(obj.ind);
									oData = {
										"d": {
											"Mandt": obj.Mandt,
											"UniqId": obj.UniqId,
											"OptId": obj.OptId,
											"Zpspid": obj.Zpspid,
											"Zzsolseid": obj.Zzsolseid,
											"SolTyp": obj.SolTyp,
											"ContModl": obj.ContModl,
											"Zbukrs": obj.Zbukrs,
											"CasesafeId": obj.CasesafeId,
											"CaseIdDes": obj.CaseIdDes,
											"SalesStage": obj.SalesStage,
											"PerResp": obj.PerResp,
											"PerEmail": obj.PerEmail,
											"FinAnl": obj.FinAnl,
											"FinEmail": obj.FinEmail,
											"ActGm": obj.ActGm,
											"AgmEmail": obj.AgmEmail,
											"OmpId": obj.OmpId,
											"OmpEmail": obj.OmpEmail,
											"PerAsn": PerAsn,
											// "PerAsn": obj.PerAsn.split("(")[1].split(")")[0],
											"PerAsnEmail": obj.PerAsnEmail,
											"TclVal": obj.TclVal,
											"DisPos": obj.DisPos,
											"DispChCmt": obj.DispChCmt,
											"DoNotprs": obj.DoNotprs,
											"NotPrssCmt": obj.NotPrssCmt,
											"PrjReqNo": obj.PrjReqNo,
											"ZStatus": obj.ZStatus,
											"WiId": obj.WiId,
											"Sysid": obj.Sysid,
											"CrtdOn": obj.CrtdOn,
											"CrtdAt": obj.CrtdAt,
											"ChangedOn": obj.ChangedOn,
											"ChangedAt": obj.ChangedAt

										}
									};

									oModel.create(sPath1, oData, mParameters);
								} else {

									oModel.update(sPath1, oData, mParameters);
								}

							}

							oModel.submitChanges(mParameters);
							// this.getView().getModel("tabModel").refresh(true); // rohit - changes
						}
						//Phase2 changes by Bharghava Reddy
					},

					// End of save button

					onSelect: function (evt) {

						var id = this.byId("ManageOpportunityTable");

						this.ary = []

						//
						var tabModel = this.getView().getModel("tabModel");
						var fielddata = tabModel.getData().oppDataSet;
						var select = evt.getSource().getSelectedIndex();
						var unSelect = evt.getParameter("rowIndices")[0];
						var oCount;
						if (select !== -1) {
							oCount = select;
						} else {
							oCount = unSelect;
						}
						if (fielddata[oCount].ZStatus !== "NEW") {
							evt.getSource().removeSelectionInterval(oCount, oCount);
						} else {
							if (select !== -1) {

								if (fielddata[select].ZStatus === "NEW") {
									tabModel.setProperty("/oppDataSet/" + select + "/oFlag", true);
									// tabModel.setProperty("/oppDataSet/" + select + "/DoNotprs", "");
								} else {
									tabModel.setProperty("/oppDataSet/" + unSelect + "/oFlag", false);
								}

								// this.getView().getModel("tabModel").getData().oppDataSet[2].oFlag
								// this.getView().getModel("tabModel").getData().oppDataSet[select].oFlag = true;
								// evt.getSource().getColumns()[15].getTemplate().setEditable()

							} else {
								tabModel.setProperty("/oppDataSet/" + unSelect + "/oFlag", false);
								// var unSelect = evt.getParameter("rowIndices")[0];
								// evt.getSource().getColumns()[15].getTemplate().setEditable(false)
								// this.getView().getModel("tabModel").getData().oppDataSet[select].oFlag =false;

							}
							//

							//rohit - begin change //
							// var that = this;
							var tbl = this.getView().byId("ManageOpportunityTable");
							// this.SelectedIndex = tbl.getSelectedIndex();
							// tbl.addDelegate({
							// 	onAfterRendering: function () {
							// 		var count = this.getVisibleRowCount();
							// 		var selectAllId = "#" + this.getId() + "-selall";
							// 		// $(selectAllId).addClass("disabledbutton");
							// 		var tabModel = this.getModel("tabModel");
							// 		var fielddata = tabModel.getData().oppDataSet; // get all the table data
							// 		if (fielddata.length > 0) {
							// 			for (var i = 0; i < count; i++) {

							// 				var columId = "#" + this.getId() + "-rowsel" + i;
							// 				// if (fielddata[i].ZStatus.toUpperCase() !== "NEW" || fielddata[i].DoNotprs.toUpperCase() === "X") {
							// 				if (fielddata[i].ZStatus.toUpperCase() !== "NEW") {
							// 					$(columId).addClass("disabledbutton");
							// 					tabModel.setProperty("/oppDataSet/" + i + "/ZbukrsFlag", false);
							// 					tabModel.setProperty("/oppDataSet/" + i + "/ZPerAsnFlag", false);
							// 					// tabModel.setProperty("/oppDataSet/" + i + "ZNotPrssCmtFlag", false);

							// 				} else {
							// 					// $(columId).removeClass("disabledbutton");
							// 				}

							// 			// if (fielddata[i].NotPrssCmt === "") {
							// 			// 	// tabItems[j].setSelected(false);

							// 			// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", true);
							// 			// } else {
							// 			// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", false);
							// 			// }

							// 			// if (fielddata[i].DoNotprs.toUpperCase() === "X") {

							// 			// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", false);

							// 			// } else {
							// 			// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", true);
							// 			// }

							// 			}

							// 		}

							// 	}
							// }, tbl);

							// if (this.SelectedIndex === -1) {
							// 	var selObj = evt.getSource().getBinding().getContexts()[0].getModel().getData().oppDataSet[this.oldIndex];
							// 	selObj.DoNotprs = "";
							// 	selObj.NotPrssCmt = "";

							// 	// alert(this.SelectedIndex );
							// } else {
							// 	this.oldIndex = this.SelectedIndex;
							// 	// alert(this.SelectedIndex ) ;    
							// }

							tbl.setVisibleRowCount(8);

							// tbl.rerender();

							//rohit - end change
							// this.byId("NPR").setEnabled(true);
							// this.byId("MEP1").setEnabled(true);
							this.getView().getModel("tabModel").refresh(true);
						}
					},
					onSelectGo: function (evt) {

						var id = this.byId("ManageOpportunityTable");

						this.ary = []
							//bharghav
							//bharghva
							//
							// var tabModel = this.getModel("tabModel");
							// var fielddata = tabModel.getData().oppDataSet;
							// var select = evt.getSource().getSelectedIndex();

						// if (select !== -1) {

						// 	if(fielddata[select].ZStatus === "NEW" ){
						// 		tabModel.setProperty("/oppDataSet/" + i + "/oFlag", true);
						// 	}else{
						// 		tabModel.setProperty("/oppDataSet/" + i + "/oFlag", false);
						// 	}

						// 	// this.getView().getModel("tabModel").getData().oppDataSet[2].oFlag
						// 	// this.getView().getModel("tabModel").getData().oppDataSet[select].oFlag = true;
						// 	// evt.getSource().getColumns()[15].getTemplate().setEditable()

						// } else {
						// 	tabModel.setProperty("/oppDataSet/" + i + "/oFlag", false);
						// 	// var unSelect = evt.getParameter("rowIndices")[0];
						// 	// evt.getSource().getColumns()[15].getTemplate().setEditable(false)
						// 	// this.getView().getModel("tabModel").getData().oppDataSet[select].oFlag =false;

						// }
						//

						//rohit - begin change //
						var that = this;
						var tbl = this.getView().byId("ManageOpportunityTable");
						this.SelectedIndex = tbl.getSelectedIndex();
						tbl.addDelegate({
							onAfterRendering: function () {
								var count = this.getVisibleRowCount();
								var selectAllId = "#" + this.getId() + "-selall";
								// $(selectAllId).addClass("disabledbutton");
								var tabModel = this.getModel("tabModel");
								var fielddata = tabModel.getData().oppDataSet; // get all the table data
								if (fielddata.length > 0) {
									for (var j = 0; j < fielddata.length; j++) {
										tabModel.setProperty("/oppDataSet/" + j + "/oFlag", false);
										tabModel.setProperty("/oppDataSet/" + j + "/oReason", false);
									}
									for (var i = 0; i < count; i++) {

										var columId = "#" + this.getId() + "-rowsel" + i;
										// if (fielddata[i].ZStatus.toUpperCase() !== "NEW" || fielddata[i].DoNotprs.toUpperCase() === "X") {
										if (fielddata[i].ZStatus.toUpperCase() !== "NEW") {
											// $(columId).addClass("disabledbutton");
											tabModel.setProperty("/oppDataSet/" + i + "/ZbukrsFlag", false);
											tabModel.setProperty("/oppDataSet/" + i + "/ZPerAsnFlag", false);
											// tabModel.setProperty("/oppDataSet/" + i + "ZNotPrssCmtFlag", false);

										} else {
											// $(columId).removeClass("disabledbutton");
										}

										// if (fielddata[i].NotPrssCmt === "") {
										// 	// tabItems[j].setSelected(false);

										// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", true);
										// } else {
										// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", false);
										// }

										// if (fielddata[i].DoNotprs.toUpperCase() === "X") {

										// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", false);

										// } else {
										// 	tabModel.setProperty("/oppDataSet/" + i + "/ZNotPrssCmtFlag", true);
										// }

									}

								}

							}
						}, tbl);

						// if (this.SelectedIndex === -1) {
						// 	var selObj = evt.getSource().getBinding().getContexts()[0].getModel().getData().oppDataSet[this.oldIndex];
						// 	selObj.DoNotprs = "";
						// 	selObj.NotPrssCmt = "";

						// 	// alert(this.SelectedIndex );
						// } else {
						// 	this.oldIndex = this.SelectedIndex;
						// 	// alert(this.SelectedIndex ) ;    
						// }

						tbl.setVisibleRowCount(8);

						// tbl.rerender();

						//rohit - end change
						// this.byId("NPR").setEnabled(true);
						// this.byId("MEP1").setEnabled(true);

						this.getView().getModel("tabModel").refresh(true);

					},
					// onInputChange: function (oEvent) {
					// 	this.changeInd = "X"

					// },
					// onInputChange1: function (oEvent) {
					// 	this.changeInd = "X"

					// },

					// Onpress Button code Added

					onPress: function (oEvent) {
						var that = this;
						var id = that.byId("ManageOpportunityTable");
						var firstselitem = id.getSelectedIndices()[0];
						var allSelectedItems = id.getSelectedIndices();
						var tabModel = id.getModel("tabModel");
						var tableModel = that.getView().getModel("tabModel").getData().oppDataSet;
						var items = tabModel.getData().oppDataSet;

						if (id.getSelectedIndices().length > 0) {
							this.getView().byId("NPR").setEnabled(true);
						} else {
							this.getView().byId("NPR").setEnabled(false);
						}
						//select all combination OPP and company code should be same
						var oList = this.getView().byId("ManageOpportunityTable");
						var length = oList.getSelectedIndices().length;
						var tabModel10 = oList.getModel("tabModel");
						// var length = oList.getSelectedContexts("tabModel").length;
						var obj = that.getView().getModel("tabModel").getData().oppDataSet;
						var oData = oList.getModel("tabModel").getData();
						//select all combination OPP and company code should be same

						// var oppOwner = id.getSelectedItem().getCells()[2].getValue();
						var cocode = items[firstselitem].Zbukrs;
						if (cocode === "") {
							sap.m.MessageToast.show("Company code is mandatory");

							if (cocode === "") {
								// id.getSelectedItem().getCells()[5].setValueState("Error");
								tabModel.setProperty("/oppDataSet/" + firstselitem + "/ZBukrsValueState", "Error");
								// id.getSelectedItem().getCells()[6].setEditable(true);
							} else {
								tabModel.setProperty("/oppDataSet/" + firstselitem + "/ZBukrsValueState", "None");

							}

							// if( !cocode == ""){

							// 	sap.m.MessageToast.show("Company Code");
							// }
							return;
						}
						// var id = that.byId("ManageOpportunityTable");
						// var items = id.getSelectedIndices();
						var oModel = that.getOwnerComponent().getModel("oDataModel");
						this.oModel = oModel;
						oModel.setUseBatch(true);
						oModel.setDeferredGroups(["foo"]);
						var mParameters = {
							groupId: "foo",
							success: function (oResponse) {
								sap.ui.core.BusyIndicator.hide();
								if (oResponse.__batchResponses === undefined) {

									// var that = this;

									var rowSelected = that.getView().byId("ManageOpportunityTable");

									var items = that.getView().getModel("tabModel").getData().oppDataSet;

									var arry = [];
									var navAryy1 = [];
									var logicInd = "";
									var logicInd1 = "";
									// var org = {};
									var Action = "";
									//Bharghav
									var rowid = [];
									for (var i = 0; i < allSelectedItems.length; i++) {
										rowid.push(items[allSelectedItems[i]]);
										var org = {};
										var obj = items[allSelectedItems[i]];
										arry.push(obj);
										// Bharghava
										// var obj = rowid[i].getBindingContext("tabModel").getObject();

										if (obj.SysId === "COMPASS") {
											Action = "create";
										}
										if (obj.SysId === "C1") {
											Action = "createC1";
										}

										// arry.push(obj);
										org.Zbukrs = obj.Zbukrs;
										org.UniqId = obj.UniqId;
										org.CasesafeId = obj.CasesafeId;
										org.OptId = obj.OptId;
										navAryy1.push(org);

										if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE") {

											logicInd = "X";

										} else {
											logicInd1 = "Y";
										}

									}

									var counts = {};
									var a = arry;

									var track = {};
									var op = [];
									var ind = ""

									// 
									// ************************
									var results = a.reduce((op, inp) => {

										if (!track[inp.OptId]) {
											op.push(inp)
											track[inp.OptId] = inp
												//	ind="Y"
										} else {
											//	ind = "X"
										}
										return op
									}, [])

									if (results.length > 1) {
										sap.m.MessageToast.show("Please select rows with the same Opp id and Company Code");
										return;
									}
									//select all combination OPP and company code should be same
									var ary = []
									var oData1 = that.getView().getModel("tabModel").getData().oppDataSet;
									// var oData1 = oData.oppDataSet;
									for (var j = 0; j < oData1.length; j++) {
										if ((obj.OptId === oData1[j].OptId) && (obj.Zbukrs === oData1[j].Zbukrs) && oData1[j].ZStatus === "NEW") {
											ary.push(oData1[j])
										}
									}
									if (rowid.length !== ary.length) {
										sap.m.MessageToast.show("Please select rows with the same Combination");
										return;
									}
									//select all combination OPP and company code should be same
									var results = a.reduce((op, inp) => {

										if (!track[inp.Zbukrs]) {
											op.push(inp)
											track[inp.Zbukrs] = inp
												//	ind="Y"
										} else {
											//	ind = "X"
										}
										return op
									}, [])

									if (results.length > 1) {
										sap.m.MessageToast.show("Please select rows with the same company code");
										return;
									}
									// ***************************

									// var navAryy = JSON.stringify(navAryy1);

									// multiple line

									jQuery.sap.require("jquery.sap.storage")
									var oStorage = new jQuery.sap.storage(jQuery.sap.storage.Type.local);

									// multiple line

									/*	if (this.SolTyp.toUpperCase() === "NEW LOGO" || this.SolTyp.toUpperCase() === "CROSS SELL" || this.SolTyp.toUpperCase() ===
											"NEW WORK")*/
									if (logicInd1 === "Y" && logicInd === "") {

										// if (this.SolTyp === "NEW LOGO" || this.SolTyp === "CROSS SELL" || this.SolTyp === "NEW WORK") {

										// MessageBox.information("Do you want to Navigation create new project request .", {
										// 	actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
										// 	emphasizedAction: MessageBox.Action.OK,
										// 	onClose: function (sAction) {
										// 		if (sAction === "OK") {

										// multiple line
										if (oStorage.get("oppData")) {
											//oStorage.clear();
										}

										oStorage.put("oppData", navAryy1);
										// multiple line
										var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
										navigationService.toExternal({
											target: {
												semanticObject: "DXCGPRS",
												action: Action
											},
											params: {

												"navAryy": "navAryy"
											}

										});

									} else {

										var dialog = new Dialog({
											title: 'Warning - Disposition Change',
											type: 'Message',
											contentWidth: "400px",
											contentHeight: "250px",
											resizable: true,
											content: [
												new Label({
													text: 'Please enter reason for changing disposition',
													labelFor: 'submitDialogTextarea'
												}),
												new TextArea('submitDialogTextarea', {
													liveChange: function (oEvent) {
														var sText = oEvent.getParameter('value');
														var parent = oEvent.getSource().getParent();

														// parent.getBeginButton().setEnabled(sText.length > 0);
														// if (sText.length > 254) {

														if (sText.length > 250) {
															parent.getBeginButton().setEnabled(false);
														} else {
															parent.getBeginButton().setEnabled(sText.length > 0);
														}
														var oTextArea = oEvent.getSource(),
															iValueLength = oTextArea.getValue().length,
															iMaxLength = oTextArea.getMaxLength(),
															sState = iValueLength > iMaxLength ? "Error" : "None";

														oTextArea.setValueState(sState);

													},
													width: '100%',
													height: "140px",
													maxLength: 250,
													showExceededText: true,
													valueStateText: 'Max. 250 characters are allowed',
													placeholder: 'Disposition Change comments (Mandatory) Max Lenght 250 characters'
												})
											],
											beginButton: new Button({
												text: 'Submit',
												enabled: false,
												press: function (evt) {

													var text = evt.oSource.oParent.getContent()[1].getValue();

													// var children = create.concat(text);
													var create = "X";

													var children = create.concat(text);
													// var children = text.endsWith("X");

													var id = that.byId("ManageOpportunityTable");
													var selectedIndices = id.getSelectedIndices();
													var items = that.getView().getModel("tabModel").getData().oppDataSet;
													var oModel = that.getOwnerComponent().getModel("oDataModel");

													oModel.setUseBatch(true);
													oModel.setDeferredGroups(["foo"]);
													var mParameters = {
														groupId: "foo",
														success: function (oResponse) {

															sap.ui.core.BusyIndicator.hide();
															sap.m.MessageToast.show("Data saved", {
																// duration: 5000

															});
															// multiple line
															if (oStorage.get("oppData")) {
																//oStorage.clear();
															}

															oStorage.put("oppData", navAryy1);
															// multiple line
															var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
															navigationService.toExternal({
																target: {
																	semanticObject: "DXCGPRS",
																	action: Action
																},
																params: {

																	"navAryy": "navAryy"
																}

															});

														},

														error: function (oError) {
															sap.ui.core.BusyIndicator.hide();
															sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
																// duration: 5000
															});
														}
													};

													for (var k = 0; k < selectedIndices.length; k++) {
														// var a = aContexts[i]; // getting selected row number.
														var actindices = selectedIndices[k];
														var obj1 = items[actindices];

														var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj1.UniqId + "',OptId='" + obj1.OptId + "')/";

														var oData = {
															"d": {

																"OptId": obj1.OptId,
																"DispChCmt": children,
																//	"PerAsn": obj.PerAsn,
																"UniqId": obj1.UniqId,
																// "DoNotprs": children
																///	"Zbukrs": obj.Zbukrs,
																//	"NotPrssCmt": obj.NotPrssCmt
															}
														};

														oModel.update(sPath1, oData, mParameters);
													}
													oModel.submitChanges(mParameters);

												}
											}),
											endButton: new Button({
												text: 'Cancel',
												press: function () {
													dialog.close();
												}
											}),
											afterClose: function () {
												dialog.destroy();
											}
										});

										dialog.open();

									}

								} else if (oResponse.__batchResponses[0].response) {
									sap.m.MessageToast.show("Save Changes before Create", {

											duration: 5000

										}

									);
									return;
								}
								// var id = that.byId("ManageOpportunityTable");
								// var items = id.getSelectedItems();
								var rowSelected = that.getView().byId("ManageOpportunityTable");
								var items = that.getView().getModel("tabModel").getData().oppDataSet;
								// var rowid = rowSelected.getSelectedItems();
								var arry = [];
								var navAryy1 = [];
								var logicInd = "";
								var logicInd1 = "";
								// var org = {};
								//
								//bharghava
								var Action = "";
								var rowid = [];
								for (var i = 0; i < allSelectedItems.length; i++) {

									rowid.push(items[allSelectedItems[i]]);
									var org = {};
									var obj = items[allSelectedItems[i]];
									arry.push(obj);

									//bharghava

									// for (var i = 0; i < allSelectedItems.length; i++) {
									// 	var rowid = items[allSelectedItems[i]];
									// 	var org = {};
									// 	var obj = rowid;
									// 	arry.push(obj);

									// var obj = rowid[i].getBindingContext("tabModel").getObject();

									if (obj.SysId === "COMPASS") {
										Action = "create";
									}
									if (obj.SysId === "C1") {
										Action = "createC1";
									}

									// arry.push(obj);
									org.Zbukrs = obj.Zbukrs;
									org.UniqId = obj.UniqId;
									org.CasesafeId = obj.CasesafeId;
									org.OptId = obj.OptId;
									navAryy1.push(org);

									if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE") {

										logicInd = "X";

									} else {
										logicInd1 = "Y";
									}

								}

								var counts = {};
								var a = arry;

								var track = {};
								var op = [];
								var ind = ""

								// 
								// ************************
								var results = a.reduce((op, inp) => {

									if (!track[inp.OptId]) {
										op.push(inp)
										track[inp.OptId] = inp
											//	ind="Y"
									} else {
										//	ind = "X"
									}
									return op
								}, [])

								if (results.length > 1) {
									sap.m.MessageToast.show("Please select rows with the same Opp id and Company Code");
									return;
								}
								//select all combination OPP and company code should be same
								var ary = []
								var oData1 = that.getView().getModel("tabModel").getData().oppDataSet;
								for (var j = 0; j < oData1.length; j++) {
									if ((obj.OptId === oData1[j].OptId) && (obj.Zbukrs === oData1[j].Zbukrs) && oData1[j].ZStatus === "NEW") {
										ary.push(oData1[j])
									}
								}
								if (rowid.length !== ary.length) {
									sap.m.MessageToast.show("Please select rows with the same Combination");
									return;
								}
								//select all combination OPP and company code should be same

								var results = a.reduce((op, inp) => {

									if (!track[inp.Zbukrs]) {
										op.push(inp)
										track[inp.Zbukrs] = inp
											//	ind="Y"
									} else {
										//	ind = "X"
									}
									return op
								}, [])

								if (results.length > 1) {
									sap.m.MessageToast.show("Please select rows with the same company code");
									return;
								}
								// ***************************

								// var navAryy = JSON.stringify(navAryy1);

								// multiple line

								jQuery.sap.require("jquery.sap.storage")
								var oStorage = new jQuery.sap.storage(jQuery.sap.storage.Type.local);

								// multiple line

								/*	if (this.SolTyp.toUpperCase() === "NEW LOGO" || this.SolTyp.toUpperCase() === "CROSS SELL" || this.SolTyp.toUpperCase() ===
										"NEW WORK")*/
								if (logicInd1 === "Y" && logicInd === "") {

									// if (this.SolTyp === "NEW LOGO" || this.SolTyp === "CROSS SELL" || this.SolTyp === "NEW WORK") {

									// MessageBox.information("Do you want to Navigation create new project request .", {
									// 	actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
									// 	emphasizedAction: MessageBox.Action.OK,
									// 	onClose: function (sAction) {
									// 		if (sAction === "OK") {

									// multiple line
									if (oStorage.get("oppData")) {
										//oStorage.clear();
									}

									oStorage.put("oppData", navAryy1);
									// multiple line
									var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
									navigationService.toExternal({
										target: {
											semanticObject: "DXCGPRS",
											action: Action
										},
										params: {

											"navAryy": "navAryy"
										}

									});

								} else {

									var dialog1 = new Dialog({
										title: 'Warning - Disposition Change',
										type: 'Message',
										contentWidth: "400px",
										contentHeight: "250px",
										resizable: true,
										content: [
											new Label({
												text: 'Please enter reason for changing disposition',
												labelFor: 'submitDialogTextarea'
											}),
											new TextArea('submitDialogTextarea', {
												liveChange: function (oEvent) {
													var sText = oEvent.getParameter('value');
													var parent = oEvent.getSource().getParent();

													// parent.getBeginButton().setEnabled(sText.length > 0);
													if (sText.length > 250) {
														parent.getBeginButton().setEnabled(false);
													} else {
														parent.getBeginButton().setEnabled(sText.length > 0);
													}
													var oTextArea = oEvent.getSource(),
														iValueLength = oTextArea.getValue().length,
														iMaxLength = oTextArea.getMaxLength(),
														sState = iValueLength > iMaxLength ? "Error" : "None";

													oTextArea.setValueState(sState);

												},
												width: '100%',
												height: "140px",
												maxLength: 250,
												showExceededText: true,
												valueStateText: 'Max. 250 characters are allowed',
												placeholder: 'Disposition Change comments (Mandatory) Max Lenght 250 characters'
											})
										],
										beginButton: new Button({
											text: 'Submit',
											enabled: false,
											press: function (evt) {

												var text = evt.oSource.oParent.getContent()[1].getValue();

												// var children = create.concat(text);
												var create = "X";

												var children = create.concat(text);
												// var children = text.endsWith("X");

												var id = that.byId("ManageOpportunityTable");
												var selectedIndices = id.getSelectedIndices();
												var items = that.getView().getModel("tabModel").getData().oppDataSet;
												var oModel = that.getOwnerComponent().getModel("oDataModel");

												oModel.setUseBatch(true);
												oModel.setDeferredGroups(["foo"]);
												var mParameters = {
													groupId: "foo",
													success: function (oResponse) {

														sap.ui.core.BusyIndicator.hide();
														sap.m.MessageToast.show("Data saved", {
															// duration: 5000

														});
														// multiple line
														if (oStorage.get("oppData")) {
															//oStorage.clear();
														}

														oStorage.put("oppData", navAryy1);
														// multiple line
														var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
														navigationService.toExternal({
															target: {
																semanticObject: "DXCGPRS",
																action: Action
															},
															params: {

																"navAryy": "navAryy"
															}

														});

													},

													error: function (oError) {
														sap.ui.core.BusyIndicator.hide();
														sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
															// duration: 5000
														});
													}
												};

												for (var k = 0; k < selectedIndices.length; k++) {
													// var a = aContexts[i]; // getting selected row number.
													var actindices = selectedIndices[k];
													var obj1 = items[actindices];

													var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj1.UniqId + "',OptId='" + obj1.OptId + "')/";

													var oData = {
														"d": {

															"OptId": obj1.OptId,
															"DispChCmt": children,
															//	"PerAsn": obj.PerAsn,
															"UniqId": obj1.UniqId,
															// "DoNotprs": children
															///	"Zbukrs": obj.Zbukrs,
															//	"NotPrssCmt": obj.NotPrssCmt
														}
													};

													oModel.update(sPath1, oData, mParameters);
												}
												oModel.submitChanges(mParameters);

											}
										}),
										endButton: new Button({
											text: 'Cancel',
											press: function () {
												dialog1.close();
											}
										}),
										afterClose: function () {
											dialog1.destroy();
										}
									});

									dialog1.open();

								}
							},

							error: function (oError) {
								sap.ui.core.BusyIndicator.hide();
								// sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
								// 	duration: 5000
								// });

								// sap.m.MessageToast.show("Please Save data before process");
							}
						};
						var id = that.byId("ManageOpportunityTable");

						var items = id.getSelectedIndices(); //get selected items of the table
						var tableModel = that.getView().getModel("tabModel").getData().oppDataSet; // table binded model
						for (var i = 0; i < items.length; i++) {

							var selectedref = items[i]; // get the selected references of the table
							var obj = tableModel[selectedref]; // get the data from the model for selected indices

							var select = obj.DoNotprs;
							// var PerAsn = items[i].getCells()[13].getSelectedKey();
							var checkInd = ""
							if (select === true) {
								checkInd = "X"
							}
							var sPath1 = "/Create_proj_checkSet";
							var oData = {
								"d": {
									"UniqId": obj.UniqId,
									"Bukrs": obj.Zbukrs
								}
							};

							oModel.create(sPath1, oData, mParameters);
						}

						oModel.submitChanges(mParameters);

						//Warenty issue End
					},

					onPress1: function () {

						var that = this;
						var id = that.byId("ManageOpportunityTable");
						var firstselitem = id.getSelectedIndices()[0];
						var allSelectedItems = id.getSelectedIndices();
						var tabModel = id.getModel("tabModel");
						var tableModel = that.getView().getModel("tabModel").getData().oppDataSet;
						var items = tabModel.getData().oppDataSet;

						if (id.getSelectedIndices().length > 0) {
							this.getView().byId("NPR").setEnabled(true);
						} else {
							this.getView().byId("NPR").setEnabled(false);
						}
						//select all combination OPP and company code should be same
						var oList = this.getView().byId("ManageOpportunityTable");
						var length = oList.getSelectedIndices().length;
						var tabModel10 = oList.getModel("tabModel");
						// var length = oList.getSelectedContexts("tabModel").length;
						var obj = that.getView().getModel("tabModel").getData().oppDataSet;
						var oData = oList.getModel("tabModel").getData();
						//select all combination OPP and company code should be same

						// var oppOwner = id.getSelectedItem().getCells()[2].getValue();
						var cocode = items[firstselitem].Zbukrs;
						if (cocode === "") {
							sap.m.MessageToast.show("Company code is mandatory");

							if (cocode === "") {
								// id.getSelectedItem().getCells()[5].setValueState("Error");
								tabModel.setProperty("/oppDataSet/" + firstselitem + "/ZBukrsValueState", "Error");
								// id.getSelectedItem().getCells()[6].setEditable(true);
							} else {
								tabModel.setProperty("/oppDataSet/" + firstselitem + "/ZBukrsValueState", "None");

							}

							return;
						}
						var oModel = that.getOwnerComponent().getModel("oDataModel");
						this.oModel = oModel;
						oModel.setUseBatch(true);
						oModel.setDeferredGroups(["foo"]);
						var mParameters = {
								groupId: "foo",
								success: function (oResponse) {
									sap.ui.core.BusyIndicator.hide();
									if (oResponse.__batchResponses === undefined) {
										// var that = this;

										var rowSelected = that.getView().byId("ManageOpportunityTable");
										var items = that.getView().getModel("tabModel").getData().oppDataSet;
										// var rowid = rowSelected.getSelectedItems();
										var arry = [];
										var navAryy1 = [];
										var logicInd = "";
										var logicInd1 = "";

										// for (var i = 0; i < rowid.length; i++) {
										// 	var org = {};
										// 	var obj = rowid[i].getBindingContext("tabModel").getObject();
										// 	arry.push(obj);
										var Action = "";
										var rowid = [];
										// for (var i = 0; i < allSelectedItems.length; i++) { // rohit - change
										// 	var rowid = items[allSelectedItems[i]];
										// 	var org = {};
										// 	var obj = rowid;
										// 	arry.push(obj);
										//bharghava

										for (var i = 0; i < allSelectedItems.length; i++) {
											rowid.push(items[allSelectedItems[i]]);
											var org = {};
											var obj = items[allSelectedItems[i]];
											arry.push(obj);
											//bharghava
											if (obj.SysId === "COMPASS") {
												Action = "create";
											}
											if (obj.SysId === "C1") {
												Action = "createC1";
											}
											org.Zbukrs = obj.Zbukrs;
											org.UniqId = obj.UniqId;
											org.CasesafeId = obj.CasesafeId;
											org.OptId = obj.OptId;
											navAryy1.push(org);

											// if (obj.SolTyp.toUpperCase() === "UP SELL" || obj.SolTyp.toUpperCase() === "RENEWAL" || obj.SolTyp.toUpperCase() ===
											// 	"RENEWAL+NEW WORK")
											// var flag = "";
											// if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE")

											if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE" || obj
												.DisPos
												.toUpperCase() === "")

											{
												logicInd = "X";
											} else {
												logicInd1 = "Y"
											}

										}

										// if (logicInd === "X" && logicInd1 === "Y") {
										// 	// flag = "Y"
										// }

										var counts = {};
										var a = arry;

										var track = {};
										var op = [];
										var ind = ""

										var results = a.reduce((op, inp) => {

											if (!track[inp.OptId]) {
												op.push(inp)
												track[inp.OptId] = inp
													//	ind="Y"
											} else {
												//	ind = "X"
											}
											return op
										}, [])

										if (results.length > 1) {
											sap.m.MessageToast.show("Please select rows with the same Opp id and Company Code");
											return;
										}
										//select all combination OPP and company code should be same
										var ary = []
										var oData1 = that.getView().getModel("tabModel").getData().oppDataSet;
										// var oData1 = oData.oppDataSet;
										for (var j = 0; j < oData1.length; j++) {
											if ((obj.OptId === oData1[j].OptId) && (obj.Zbukrs === oData1[j].Zbukrs) && oData1[j].ZStatus === "NEW") {
												ary.push(oData1[j])
											}
										}
										if (rowid.length !== ary.length) {
											sap.m.MessageToast.show("Please select rows with the same Combination");
											return;
										}
										//select all combination OPP and company code should be same

										var results = a.reduce((op, inp) => {

											if (!track[inp.Zbukrs]) {
												op.push(inp)
												track[inp.Zbukrs] = inp
													//	ind="Y"
											} else {
												//	ind = "X"
											}
											return op
										}, [])

										if (results.length > 1) {
											sap.m.MessageToast.show("Please select rows with the same company code");
											return;
										}

										// var results = a.reduce((op, inp) => {
										// 	if (!track[inp.Zbukrs]) {
										// 		op.push(inp)
										// 		track[inp.Zbukrs] = inp
										// 	} else {
										// 		ind = "X"
										// 	}
										// 	return op
										// }, [])

										// if (ind === "X") {
										// 	sap.m.MessageToast.show("dsjkfdjskds");
										// 	return;
										// }

										/*	if (this.SolTyp.toUpperCase() === "NEW LOGO" || this.SolTyp.toUpperCase() === "CROSS SELL" || this.SolTyp.toUpperCase() ===
												"NEW WORK")*/
										// var navAryy = JSON.stringify(navAryy1);
										// multiple line
										jQuery.sap.require("jquery.sap.storage")
										var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
										// multiple line

										// if ((logicInd === "X" && logicInd1 === "") || logicInd1 === "")

										// if (logicInd === "X" && logicInd === "")
										// (logicInd1 === "Y" && logicInd === "")

										if ((logicInd === "X" && logicInd === "") || logicInd === "X")

										{
											// multiple line
											if (oStorage.get("oppData")) {
												//oStorage.clear();
											}

											oStorage.put("oppData", navAryy1);
											// multiple line
											var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
											navigationService.toExternal({
												target: {
													semanticObject: "DXCGPRS",
													action: "manage"
												},
												params: {

													"navAryy": "navAryy"
												}

											});

										} else {

											var dialog = new Dialog({
												title: 'Warning - Disposition Change',
												type: 'Message',
												contentWidth: "400px",
												contentHeight: "250px",
												resizable: true,
												content: [
													new Label({
														text: 'Please enter reason for changing disposition',
														labelFor: 'submitDialogTextarea'
													}),
													new TextArea('submitDialogTextarea', {
														liveChange: function (oEvent) {
															var sText = oEvent.getParameter('value');
															var parent = oEvent.getSource().getParent();

															parent.getBeginButton().setEnabled(sText.length > 0);
															if (sText.length > 250) {
																parent.getBeginButton().setEnabled(false);
															} else {
																parent.getBeginButton().setEnabled(sText.length > 0);
															}
															var oTextArea = oEvent.getSource(),
																iValueLength = oTextArea.getValue().length,
																iMaxLength = oTextArea.getMaxLength(),
																sState = iValueLength > iMaxLength ? "Error" : "None";

															oTextArea.setValueState(sState);
														},
														width: '100%',
														height: "140px",
														maxLength: 250,
														showExceededText: true,
														valueStateText: 'Max. 250 characters are allowed',
														placeholder: 'Disposition Change comments (Mandatory) Max Length 250 characters'
													})
												],
												beginButton: new Button({
													text: 'Submit',
													enabled: false,
													press: function (evt) {

														var text = evt.oSource.oParent.getContent()[1].getValue();

														var create = "Y";

														var children = create.concat(text);
														var id = that.byId("ManageOpportunityTable");
														var selectedIndices = id.getSelectedIndices();
														// var items = id.getSelectedItems();
														var oModel = that.getOwnerComponent().getModel("oDataModel");

														oModel.setUseBatch(true);
														oModel.setDeferredGroups(["foo"]);
														var mParameters = {
															groupId: "foo",
															success: function (oResponse) {

																sap.ui.core.BusyIndicator.hide();
																sap.m.MessageToast.show("Data Saved", {
																	// duration: 5000

																});
																// multiple line
																if (oStorage.get("oppData")) {
																	//oStorage.clear();
																}

																oStorage.put("oppData", navAryy1);
																// multiple line
																var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
																navigationService.toExternal({
																	target: {
																		semanticObject: "DXCGPRS",
																		action: "manage"
																	},
																	params: {

																		"navAryy": "navAryy"
																	}

																});

															},

															error: function (oError) {
																sap.ui.core.BusyIndicator.hide();
																sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
																	duration: 5000
																});
															}
														};
														//
														for (var k = 0; k < selectedIndices.length; k++) {
															// var a = aContexts[i]; // getting selected row number.
															var actindices = selectedIndices[k];
															var obj1 = items[actindices];
															//

															// for (var k = 0; k < items.length; k++) {
															// 	// var a = aContexts[i]; // getting selected row number.

															// 	var actindices = selectedIndices[k];
															// 	var obj1 = items[actindices];

															// var obj1 = items[k].getBindingContext("tabModel").getObject();

															var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj1.UniqId + "',OptId='" + obj1.OptId + "')/";

															var oData = {
																"d": {
																	"OptId": obj1.OptId,
																	"DispChCmt": children,
																	"UniqId": obj1.UniqId,
																	// "DoNotprs": flag
																}
															};

															oModel.update(sPath1, oData, mParameters);
														}
														oModel.submitChanges(mParameters);

													}
												}),
												endButton: new Button({
													text: 'Cancel',
													press: function () {
														dialog.close();
													}
												}),
												afterClose: function () {
													dialog.destroy();
												}
											});

											dialog.open();

										}
									} else if (oResponse.__batchResponses[0].response) {
										sap.m.MessageToast.show("Save Changes before Amend", {

												duration: 5000

											}

										);
										return;
									}
									var rowSelected = that.getView().byId("ManageOpportunityTable");
									var items = that.getView().getModel("tabModel").getData().oppDataSet;
									// var rowid = rowSelected.getSelectedItems();
									var arry = [];
									var navAryy1 = [];
									var logicInd = "";
									var logicInd1 = "";

									// for (var i = 0; i < rowid.length; i++) {
									// 	var org = {};
									// 	var obj = rowid[i].getBindingContext("tabModel").getObject();
									// 	arry.push(obj);
									// for (var i = 0; i < allSelectedItems.length; i++) { // rohit - change
									// 	var rowid = items[allSelectedItems[i]];
									// 	var org = {};
									// 	var obj = rowid;
									// 	arry.push(obj);
									//bharghava
									var Action = "";
									var rowid = [];
									for (var i = 0; i < allSelectedItems.length; i++) {

										rowid.push(items[allSelectedItems[i]]);
										var org = {};
										var obj = items[allSelectedItems[i]];
										arry.push(obj);

										//bharghava

										org.Zbukrs = obj.Zbukrs;
										org.UniqId = obj.UniqId;
										org.CasesafeId = obj.CasesafeId;
										org.OptId = obj.OptId;
										navAryy1.push(org);

										// if (obj.SolTyp.toUpperCase() === "UP SELL" || obj.SolTyp.toUpperCase() === "RENEWAL" || obj.SolTyp.toUpperCase() ===
										// 	"RENEWAL+NEW WORK")
										// var flag = "";
										// if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE")

										if (obj.DisPos.toUpperCase() === "NEW WBS ON EXISTING PROJECT" || obj.DisPos.toUpperCase() === "EXISTING WBS CHANGE" || obj.DisPos
											.toUpperCase() === "")

										{
											logicInd = "X";
										} else {
											logicInd1 = "Y"
										}

									}

									// if (logicInd === "X" && logicInd1 === "Y") {
									// 	// flag = "Y"
									// }

									var counts = {};
									var a = arry;

									var track = {};
									var op = [];
									var ind = ""

									var results = a.reduce((op, inp) => {

										if (!track[inp.OptId]) {
											op.push(inp)
											track[inp.OptId] = inp
												//	ind="Y"
										} else {
											//	ind = "X"
										}
										return op
									}, [])

									if (results.length > 1) {
										sap.m.MessageToast.show("Please select rows with the same Opp id and Company Code");
										return;
									}
									//select all combination OPP and company code should be same
									var ary = []
									var oData1 = that.getView().getModel("tabModel").getData().oppDataSet;
									for (var j = 0; j < oData1.length; j++) {
										if ((obj.OptId === oData1[j].OptId) && (obj.Zbukrs === oData1[j].Zbukrs) && oData1[j].ZStatus === "NEW") {
											ary.push(oData1[j])
										}
									}
									if (rowid.length !== ary.length) {
										sap.m.MessageToast.show("Please select rows with the same Combination");
										return;
									}
									//select all combination OPP and company code should be same

									var results = a.reduce((op, inp) => {

										if (!track[inp.Zbukrs]) {
											op.push(inp)
											track[inp.Zbukrs] = inp
												//	ind="Y"
										} else {
											//	ind = "X"
										}
										return op
									}, [])

									if (results.length > 1) {
										sap.m.MessageToast.show("Please select rows with the same company code");
										return;
									}

									// var results = a.reduce((op, inp) => {
									// 	if (!track[inp.Zbukrs]) {
									// 		op.push(inp)
									// 		track[inp.Zbukrs] = inp
									// 	} else {
									// 		ind = "X"
									// 	}
									// 	return op
									// }, [])

									// if (ind === "X") {
									// 	sap.m.MessageToast.show("dsjkfdjskds");
									// 	return;
									// }

									/*	if (this.SolTyp.toUpperCase() === "NEW LOGO" || this.SolTyp.toUpperCase() === "CROSS SELL" || this.SolTyp.toUpperCase() ===
											"NEW WORK")*/
									// var navAryy = JSON.stringify(navAryy1);
									// multiple line
									jQuery.sap.require("jquery.sap.storage")
									var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
									// multiple line

									// if ((logicInd === "X" && logicInd1 === "") || logicInd1 === "")

									// if (logicInd === "X" && logicInd === "")
									// (logicInd1 === "Y" && logicInd === "")

									if ((logicInd === "X" && logicInd === "") || logicInd === "X")

									{
										// multiple line
										if (oStorage.get("oppData")) {
											//oStorage.clear();
										}

										oStorage.put("oppData", navAryy1);
										// multiple line
										var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
										navigationService.toExternal({
											target: {
												semanticObject: "DXCGPRS",
												action: "manage"
											},
											params: {

												"navAryy": "navAryy"
											}

										});

									} else {

										var dialog1 = new Dialog({
													title: 'Warning - Disposition Change',
													type: 'Message',
													contentWidth: "400px",
													contentHeight: "250px",
													resizable: true,
													content: [
														new Label({
															text: 'Please enter reason for changing disposition',
															labelFor: 'submitDialogTextarea'
														}),
														new TextArea('submitDialogTextarea', {
															liveChange: function (oEvent) {
																var sText = oEvent.getParameter('value');
																var parent = oEvent.getSource().getParent();

																parent.getBeginButton().setEnabled(sText.length > 0);
																if (sText.length > 250) {
																	parent.getBeginButton().setEnabled(false);
																} else {
																	parent.getBeginButton().setEnabled(sText.length > 0);
																}
																var oTextArea = oEvent.getSource(),
																	iValueLength = oTextArea.getValue().length,
																	iMaxLength = oTextArea.getMaxLength(),
																	sState = iValueLength > iMaxLength ? "Error" : "None";

																oTextArea.setValueState(sState);
															},
															width: '100%',
															height: "140px",
															maxLength: 250,
															showExceededText: true,
															valueStateText: 'Max. 250 characters are allowed',
															placeholder: 'Disposition Change comments (Mandatory) Max Length 250 characters'
														})
													],
													beginButton: new Button({
															text: 'Submit',
															enabled: false,
															press: function (evt) {

																var text = evt.oSource.oParent.getContent()[1].getValue();

																var create = "Y";

																var children = create.concat(text);
																var id = that.byId("ManageOpportunityTable");
																// var items = id.getSelectedItems();
																var oModel = that.getOwnerComponent().getModel("oDataModel");
																var selectedIndices = id.getSelectedIndices();
																oModel.setUseBatch(true);
																oModel.setDeferredGroups(["foo"]);
																var mParameters = {
																	groupId: "foo",
																	success: function (oResponse) {

																		sap.ui.core.BusyIndicator.hide();
																		sap.m.MessageToast.show("Data Saved", {
																			// duration: 5000

																		});
																		// multiple line
																		if (oStorage.get("oppData")) {
																			//oStorage.clear();
																		}

																		oStorage.put("oppData", navAryy1);
																		// multiple line
																		var navigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
																		navigationService.toExternal({
																			target: {
																				semanticObject: "DXCGPRS",
																				action: "manage"
																			},
																			params: {

																				"navAryy": "navAryy"
																			}

																		});

																	},

																	error: function (oError) {
																		sap.ui.core.BusyIndicator.hide();
																		sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
																			duration: 5000
																		});
																	}
																};
																//
																for (var k = 0; k < selectedIndices.length; k++) {
																	// var a = aContexts[i]; // getting selected row number.
																	var actindices = selectedIndices[k];
																	var obj1 = items[actindices];
																	//
																	// for (var k = 0; k < items.length; k++) {
																	// 	// var a = aContexts[i]; // getting selected row number.
																	// 	var obj1 = items[k].getBindingContext("tabModel").getObject();

																		var sPath1 = "/OPPORTUNITYID_NOTIFICATIONSet(UniqId='" + obj1.UniqId + "',OptId='" + obj1.OptId + "')/";

																		var oData = {
																			"d": {
																				"OptId": obj1.OptId,
																				"DispChCmt": children,
																				"UniqId": obj1.UniqId,
																				// "DoNotprs": flag
																			}
																		};

																		oModel.update(sPath1, oData, mParameters);
																	}
																	oModel.submitChanges(mParameters);

																}
															}),
														endButton: new Button({
															text: 'Cancel',
															press: function () {
																dialog1.close();
															}
														}),
														afterClose: function () {
															dialog1.destroy();
														}
													});

												dialog1.open();

											}
											// }	

									},

									error: function (oError) {
										sap.ui.core.BusyIndicator.hide();
										// sap.m.MessageToast.show("Unexpected system error occurred; please log a support ticket", {
										// 	duration: 5000
										// });

										// sap.m.MessageToast.show("Please Save data before process");
									}
								};
								////////////////////////////////////////////////////////////////
								var items = id.getSelectedIndices(); //get selected items of the table
								var tableModel = that.getView().getModel("tabModel").getData().oppDataSet; // table binded model
								for (var i = 0; i < items.length; i++) {

									var selectedref = items[i]; // get the selected references of the table
									var obj = tableModel[selectedref]; // get the data from the model for selected indices

									var select = obj.DoNotprs;
									// var PerAsn = items[i].getCells()[13].getSelectedKey();
									var checkInd = ""
									if (select === true) {
										checkInd = "X"
									}
									var sPath1 = "/Create_proj_checkSet";
									var oData = {
										"d": {
											"UniqId": obj.UniqId,
											"Bukrs": obj.Zbukrs
										}
									};

									oModel.create(sPath1, oData, mParameters);
								}

								oModel.submitChanges(mParameters);

								//Warenty issue End
							},

					});

			});