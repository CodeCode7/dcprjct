sap.ui.define([
	"sap/m/MessageToast", "sap/m/MessageBox", "sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel", "sap/ui/model/odata/ODataModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/BusyIndicator"
], function (MessageToast, MessageBox, Controller, JSONModel, ODataModel, Filter, FilterOperator, BusyIndicator) {
	"use strict";

	return Controller.extend("InitiateClosureProcess.controller.View1", {

		onInit: function () {

			// var oModel = this.getOwnerComponent().getModel("oDataICP");

			var that = this;
			// var oDta = this.getOwnerComponent().getModel("oDataICP");
			var Services = "/sap/opu/odata/SAP/ZODATA_WBS_CLS_INIT_SRV";
			var oDta = new sap.ui.model.odata.ODataModel(Services, true);
			this.finalFilters = [];
			this.finalFilters.push(new sap.ui.model.Filter("SysId", sap.ui.model.FilterOperator.EQ, "C1"));
			BusyIndicator.show();
			oDta.read("/cocodeSet", {
				filters: this.finalFilters,
				success: function (oData, oResponse) {

					BusyIndicator.hide();
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					// debugger;
					that.companyCode = new JSONModel(oData.results);
					this.getView().byId("Ccode").setModel(that.companyCode);
				}.bind(this),
				error: function (err) {
					BusyIndicator.hide();
				}
			});
			oDta.read("/Proj_typ", {
				filters: this.finalFilters,
				success: function (oData, oResponse) {

					BusyIndicator.hide();
					// this.byId("Ccode").setVisibleRowCount(oData.results.length);
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					// debugger;
					that.projectType = new JSONModel(oData.results);
					this.getView().byId("PType").setModel(that.projectType);
				}.bind(this),
				error: function (err) {
					BusyIndicator.hide();
				}
			});

			// this.getView().getModel("oDataICP").getData();
			// this.getView().setModel(oModel);
		},
		onChange: function (oEvent) {
			var erp = oEvent.getParameter("selectedItem").getText();

			if (erp === "COMPASS") {
				this.getView().byId("Co_Code").setVisible(false);
				this.getView().byId("Project_Type").setVisible(false);
				this.getView().byId("Sys_Stat").setVisible(false);
				this.getView().byId("WBS_CDate").setVisible(false);
				//this.getView().byId("WBS_EDate").setVisible(false);
			} else {
				this.getView().byId("Co_Code").setVisible(true);
				this.getView().byId("Project_Type").setVisible(true);
				this.getView().byId("Sys_Stat").setVisible(true);
				this.getView().byId("WBS_CDate").setVisible(true);
				//this.getView().byId("WBS_EDate").setVisible(true);
			}
		},
		// handleChange :function(oEvent){
		// 	// debugger;
		//         var Year = oEvent.getSource().getDateValue().getFullYear();
		//          var day = oEvent.getSource().getDateValue().getDate();
		//          var month = oEvent.getSource().getDateValue().getMonth();
		//          // this.byId("DP2").setValue("");
		//          this.byId("DP2").setMinDate(new Date(Year, month, day));

		// },
		handleChangeEDate: function (oEvent) {
			// debugger;
			var Year = oEvent.getSource().getDateValue().getFullYear();
			var day = oEvent.getSource().getDateValue().getDate();
			var month = oEvent.getSource().getDateValue().getMonth();
			// this.byId("DP1").setValue("");
			this.byId("DP1").setMaxDate(new Date(Year, month, day));

		},

		onInitiate: function (oEvent) {
			var val = this.getView().byId("inpERP").getSelectedKey();
			// var oModel = this.getOwnerComponent().getModel("oDataICP");

			var Services = "/sap/opu/odata/SAP/ZODATA_WBS_CLS_INIT_SRV";
			var CreateoModel = new ODataModel(Services, true);
			if (val === "Compass") {
				var systemId = "COMPASS";
				var CompData = {
					"system_id": systemId
						// "comp_code" : "",
						// "proj_type" : "",
						// "sys_status" : "",
						// // "start_date" : "",
						// // "end_date" : ""
				};
				// CompData.system_id ="COMPASS";
				sap.ui.core.BusyIndicator.show(0);

				// oModel.update(sPath,CompData,mParameters);
				CreateoModel.update("/SystemSet(system_id=" + "'" + systemId + "')", CompData, {
					success: function (response) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.success("The Initiation process for Compass ERP is started in the background");

					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error in Initiating the WBS Closure Process");

					}
				});

			} else if (val === "C1") {
				sap.ui.core.BusyIndicator.show(0);
				var C1Data = {};

				var CCode = this.getView().byId("Ccode").getValue();
				var ProjType = this.getView().byId("PType").getValue();
				var SysStatus = this.getView().byId("SysStatus").getValue();
				// var CDate = this.getView().byId("DP1").getValue();
				// var EDate = this.getView().byId("DP2").getValue();

				var CDate = this.byId("DRS3").getProperty("dateValue");
				var EDate = this.byId("DRS3").getProperty("secondDateValue");
				var oDate1;
				var oDate2;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
				if (CDate) {
				var n = CDate.getTimezoneOffset() / 60;
				if (Math.sign(n) === -1) {
					oDate1 = dateFormat.format(new Date(CDate));
					CDate = oDate1 + "T14:00:00";
					CDate = new Date(CDate);
				
						}
					}
					
					
				if (EDate) {
				var n = EDate.getTimezoneOffset() / 60;
				if (Math.sign(n) === -1) {
					oDate2 = dateFormat.format(new Date(EDate));
					EDate = oDate2 + "T14:00:00";
					EDate = new Date(EDate);
				
						}
					}

				if (CDate === "" && EDate === "") {

					C1Data = {
						"system_id": val,
						"comp_code": CCode,
						"proj_type": ProjType,
						"sys_status": SysStatus,
						"beg_date": null,
						"end_date": null
					};

					CreateoModel.update("/SystemSet(system_id=" + "'" + val + "')", C1Data, {
						success: function (response) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.success("The Initiation process for C1 ERP is started in the background");

						},
						error: function (oError) {
							sap.ui.core.BusyIndicator.hide();
							var errmsg = JSON.parse(oError.response.body).error.message.value;
							// debugger;
							MessageBox.error(errmsg);

						}
					});
				} else if (CDate !== "" && EDate !== "") {
					C1Data = {
						"system_id": val,
						"comp_code": CCode,
						"proj_type": ProjType,
						"sys_status": SysStatus,
						"beg_date": CDate,
						"end_date": EDate
					};

					CreateoModel.update("/SystemSet(system_id=" + "'" + val + "')", C1Data, {
						success: function (response) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.success("The Initiation process for C1 ERP is started in the background");

						},
						error: function (oError) {
							sap.ui.core.BusyIndicator.hide();
							var errmsg = JSON.parse(oError.response.body).error.message.value;
							// debugger;
							MessageBox.error(errmsg);
							// MessageBox.error("Error in Initiating the WBS Closure Process");           

						}
					});
				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Please Enter WBS creation Date as well as End Date");
				}

			} else {
				MessageBox.error("Please Select  ERP");
			}

		}
	});

});