/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"WBS/manage/ZWBS_Manage/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"WBS/manage/ZWBS_Manage/test/integration/pages/App",
	"WBS/manage/ZWBS_Manage/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "WBS.manage.ZWBS_Manage.view.",
		autoWait: true
	});
});