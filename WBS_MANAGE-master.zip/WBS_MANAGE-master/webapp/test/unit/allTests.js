sap.ui.define([
	"WBS/manage/ZWBS_Manage/test/unit/controller/App.controller"
], function () {
	"use strict";
});