sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Token",
	"sap/m/Dialog",
	'sap/m/Button',
	'sap/m/Text',
	"sap/m/Label",
	"sap/m/TextArea",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"WBS/manage/ZWBS_Manage/model/formatter",
	"sap/ui/core/BusyIndicator",
	"sap/ui/export/Spreadsheet",
	"sap/ui/generic/app/navigation/service/NavigationHandler",
	"sap/ui/generic/app/navigation/service/NavType",
	"sap/ushell/services/CrossApplicationNavigation",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Item",
	"sap/ushell/services/UserInfo",
	"sap/ui/model/odata/v2/ODataModel"
], function (Controller, Token, Dialog, Button, Text, Label, TextArea, JSONModel, MessageToast, MessageBox, Fragment, formatter,
	BusyIndicator,
	Spreadsheet, NavigationHandler,
	NavType,
	CrossApplicationNavigation,
	Filter, FilterOperator, Item, UserInfo, ODataModel) {
	"use strict";

	return Controller.extend("WBS.manage.ZWBS_Manage.controller.View1", {
		formatter: formatter,
		onInit: function () {

			var oUser = new UserInfo();
			var ouserId = oUser.getId();
			if (ouserId != "DEFAULT_USER") {
				var oViewModel = new JSONModel({
					Owner: ouserId,
					oCount: 0,
					//Owner: ouserId,
					//SerURL: "",
					//toppings: []
				});

				this.getView().setModel(oViewModel, "appView");
			} else {
				var oViewModel;
				oViewModel = new JSONModel({
					Owner: "23195986",
					oCount: 0,

					//Owner: ouserId,
					//SerURL: "",
					//toppings: []
				});
				this.getView().setModel(oViewModel, "appView");
			}
			var oLength = window.location.href.split("#")[1].split("?").length;
			if (oLength > 1) {
				this.oFlagChangPro = true;
				jQuery.sap.require("jquery.sap.storage");
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
				if (oStorage.get("oppData")) {
					this.getView().setModel(new sap.ui.model.json.JSONModel(oStorage.get("oppData")), "localData");
					oStorage.clear();

					this.getView().byId("idFltRequest").setEnabled(false);
					this.getView().byId("idStatus").setEnabled(false);
					this.getView().byId("idCreatedBY").setEnabled(false);
				}
			}

			var oModelOMT = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
			sap.ui.getCore().setModel(oModelOMT);
			var that = this;
			// var oModelOMTAPR = this.getView().getModel("oDataModel");
			var sPath = "/OMTReqAuthSet('" + ouserId + "')";
			oModelOMT.read(sPath, {
				success: function (oData, oResponse) {
					var oViewModel = that.getView().getModel("appView");
					that.OMTApr = oData.ApprFlg;
				},
				error: function (oError) {
					// sap.ui.core.BusyIndicator.hide();
				}
			});
			// var oMultiInput2 = this.getView().byId('idProject');

			// oMultiInput2.addValidator(function (args) {
			// 	if (args.suggestionObject) {
			// 		var key = args.suggestionObject.getCells()[0].getText();
			// 		//var text = key + "(" + args.suggestionObject.getCells()[0].getText() + ")";
			// 		var text = key;

			// 		return new Token({
			// 			key: key,
			// 			text: text
			// 		});
			// 	}
			// 	return null;
			// });
			// oMultiInput2.setSuggestionRowValidator(this.suggestionRowValidator);

			// var oMultiInputReqNum = this.getView().byId('idFltRequest');
			// oMultiInputReqNum.addValidator(function (args) {
			// 	if (args.suggestionObject) {
			// 		var key = args.suggestionObject.getCells()[0].getText();
			// 		//var text = key + "(" + args.suggestionObject.getCells()[0].getText() + ")";
			// 		var text = key;

			// 		return new Token({
			// 			key: key,
			// 			text: text
			// 		});
			// 	}
			// 	return null;
			// });
			// oMultiInputReqNum.setSuggestionRowValidator(this.suggestionRowValidator);

			// var oMultiInputCreatBy = this.getView().byId('idCreatedBY');
			// oMultiInputCreatBy.addValidator(function (args) {
			// 	if (args.suggestionObject) {
			// 		var key = args.suggestionObject.getCells()[0].getText();
			// 		//var text = key + "(" + args.suggestionObject.getCells()[0].getText() + ")";
			// 		var text = key;

			// 		return new Token({
			// 			key: key,
			// 			text: text
			// 		});
			// 	}
			// 	return null;
			// });
			// oMultiInputCreatBy.setSuggestionRowValidator(this.suggestionRowValidator);
			//this.oPPIDFilters = [];
			// var oLength = window.location.href.split("#")[1].split("?").length;
			// if (oLength > 1) {

			// 	if (window.location.href.split("#")[1].split("?")[1].split("=")[0] === "navAryy") {
			// 		var m = decodeURIComponent(decodeURIComponent(window.location.href));
			// 		var m1 = m.split("navAryy=")[1];
			// 		this.navAryy = JSON.parse(m1);
			// 		this.getView().byId("idFltRequest").setEnabled(false);
			// 		this.getView().byId("idStatus").setEnabled(false);
			// 		this.getView().byId("idCreatedBY").setEnabled(false);
			// 	}
			// }
			//this.oPPIDFilters.push(OptId);
			//this.onGetOppID();
			// this.navAryy = [{
			// 	CasesafeId: "00K2J00000LXXCGQAS",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// }, {
			// 	CasesafeId: "00K2J00000LXXCGQA1",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// }, {
			// 	CasesafeId: "00K2J00000LXXCGQA2",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// },{
			// 	CasesafeId: "00K2J00000LXXCGQA3",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// }, {
			// 	CasesafeId: "00K2J00000LXXCGQA4",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// }, {
			// 	CasesafeId: "00K2J00000LXXCGQA5",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// },{
			// 	CasesafeId: "00K2J00000LXXCGQA6",
			// 	OptId: "OPX-0020480486",
			// 	UniqId: "OPX-0020480486-2",
			// 	Zbukrs: "USA7"
			// }]
		},
		/*onGetOppID: function () {
			var oOPPModel = this.getOwnerComponent().getModel();
				var urlParameters = {
					"$select": "OptId"
				};
			BusyIndicator.show();
			oOPPModel.read("/Manage_request_OPPSet", {
				filters: this.oPPIDFilters,
				success: function (oData, oResponse) {
					BusyIndicator.hide();
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						sap.m.MessageToast.show(sMessage);
						return;
					}
					var oPPModel = new sap.ui.model.json.JSONModel(oData.results);

				}.bind(this),
				error: function (err) {
					BusyIndicator.hide();
				}
			});*/

		/*var sServiceUrl = "/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_SRV/Manage_request_OPPSet";
		var that = this;
		jQuery.ajax({
			type: "GET",
			contentType: "application/json",
			url: sServiceUrl,
			dataType: "json",
			async: false,
			success: function (oData, textStatus, jqXHR) {

				if (oData === null || oData === undefined) {
					var sMessage = "WARNING. Received a null or undefined response object.";
					sap.m.MessageToast.show(sMessage);
					return;
				}
				
				var oModel1 = new sap.ui.model.json.JSONModel(oData.d.results);
				var oModel = that.getView().getModel();
				// // var itab = oModel.getProperty("/iwoTab");
				// // itab.push(oModel1);
				//oModel.setProperty("/sowData", oModel1.getData());
			}
		});*/
		onSuggestionProjId: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.Contains, sTerm);
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestionRequest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter("Requestnumber", sap.ui.model.FilterOperator.Contains, sTerm);
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		onSuggestCreatBy: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm);

			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		// suggestionRowValidator: function (oColumnListItem) {
		// 	var aCells = oColumnListItem.getCells();

		// 	return new Item({
		// 		key: aCells[0].getText(),
		// 		text: aCells[0].getText()
		// 	});
		// },
		// onGarbageValue: function (oEvent) {
		// 	var oSrc = oEvent.getSource(),
		// 		sKey = oSrc.getSelectedKey();
		// 	if (!sKey) {
		// 		oSrc.setValue("");
		// 	}
		// },
		// onSuggestionmulProjId: function (oEvent) {

		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.Contains, sTerm),
		// 		]

		// 	});

		// 	this.oManageRequestModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
		// 	var oSource = oEvent.getSource();
		// 	var that = this;
		// 	this.oManageRequestModel.read("/Manage_Project_ProjDefSet", {
		// 		filters: [aFilters],
		// 		urlParameters: {
		// 			"$top": 100
		// 				//"$orderby": "Zpspid desc"
		// 		},
		// 		success: function (oResponse) {

		// 			var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
		// 			oSource.setModel(oModel, 'sug');
		// 			//oSource._refreshItemsDelayed();

		// 		},
		// 		error: function (oError) {}
		// 	});
		// },
		// onSuggestionmulReqNum: function (oEvent) {
		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Requestnumber", sap.ui.model.FilterOperator.Contains, sTerm),
		// 		]

		// 	});

		// 	this.oManageRequestModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
		// 	var oSource = oEvent.getSource();
		// 	var that = this;
		// 	this.oManageRequestModel.read("/SearchRequestNoSet", {
		// 		filters: [aFilters],
		// 		urlParameters: {
		// 			"$top": 100
		// 		},
		// 		success: function (oResponse) {

		// 			var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
		// 			oSource.setModel(oModel, 'sug');
		// 			//oSource._refreshItemsDelayed();

		// 		},
		// 		error: function (oError) {}
		// 	});

		// },
		// onSuggestionmulCreaBY: function (oEvent) {
		// 	var sTerm = oEvent.getParameter("suggestValue");
		// 	var aFilters = new sap.ui.model.Filter({
		// 		filters: [
		// 			new sap.ui.model.Filter("Pernr", sap.ui.model.FilterOperator.Contains, sTerm),
		// 		]

		// 	});

		// 	this.oManageRequestModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
		// 	var oSource = oEvent.getSource();
		// 	var that = this;
		// 	this.oManageRequestModel.read("/SearchEmpSet", {
		// 		filters: [aFilters],
		// 		urlParameters: {
		// 			"$top": 100
		// 		},
		// 		success: function (oResponse) {

		// 			var oModel = new sap.ui.model.json.JSONModel(oResponse.results);
		// 			oSource.setModel(oModel, 'sug');
		// 			//oSource._refreshItemsDelayed();

		// 		},
		// 		error: function (oError) {}
		// 	});

		// },

		/*onNav: function () {
			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService &&
				sap.ushell.Container.getService("CrossApplicationNavigation");
			var href = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "Action",
					action: "tortademo"
				},
				params: {
					"product": ["HT-1001", "HT-1002"]

				}
			})) || "";
			var finalUrl = window.location.href.split("#")[0] + href;
			sap.m.URLHelper.redirect(finalUrl, false);
		},*/
		multiinputTimeTrack: function (oEvent) {
			var newID = oEvent.getParameter("id");
			var oView = this.getView();
			var oMultiInpuidNonTrack = oView.byId(newID);
			// oMultiInpuidNonTrack.setTokens([
			// 	new Token({})
			// ]);

			// add validator
			var fnValidator = function (args) {
				var text = args.text;

				return new Token({
					key: text,
					text: text
				});
			};
			oMultiInpuidNonTrack.addValidator(fnValidator);
		},
		onCheckInputSearch: function (value) {
			// var value = oEvent.getParameters();
			for (var i = 0; i <= 2; i++) {
				var tokens = value.selectionSet[i].getTokens().length;
				if (tokens > 0) {
					return true;
				}
			}
			return false;
		},
		onSearch: function (oEvent) {
			this.selProjectIdVals = [];
			this.selRequestIdVals = [];
			this.selCreatedByVals = [];
			this.selStatusVals = [];
			// if (this.byId("matchedDrpdwn").getValue().length > 0) {
			for (var i = 0; i < this.byId("idProject").getTokens().length; i++) {
				this.selProjectIdVals[i] = this.byId("idProject").getTokens()[i].getKey();
			}
			for (var i = 0; i < this.byId("idFltRequest").getTokens().length; i++) {
				this.selRequestIdVals[i] = this.byId("idFltRequest").getTokens()[i].getKey();
			}
			for (var i = 0; i < this.byId("idCreatedBY").getTokens().length; i++) {
				this.selCreatedByVals[i] = this.byId("idCreatedBY").getTokens()[i].getKey();
			}
			for (var i = 0; i < this.byId("idStatus").getSelectedItems().length; i++) {

				this.selStatusVals[i] = this.byId("idStatus").getSelectedItems()[i].getKey();

			}

			/*if(this.selProjectIdVals.length === 0){
				this.getView().byId("idFltRequest").setEnabled(true);
				this.getView().byId("idStatus").setEnabled(true);
			}
			if(this.selRequestIdVals.length === 0){
				this.getView().byId("idProject").setEnabled(true);
			}*/
			this.getSearchData();
			/*if ((this.selProjectIdVals != 0) && (this.selRequestIdVals != 0)) {
				MessageBox.show("Please Enter Either Project ID or Request Number", sap.m.MessageBox.Icon.INFORMATION, "Information");
			} else {
				this.getSearchData();
			}*/

			// } else {
			// 	MessageBox.error("Please select the mandatory filters");
			// }

			/*var filtercon = [];
			var filterCondi = ["ProjectID", "ReqNo", "ActId", "Status"];
			var value = oEvent.getParameters();
			if (this.onCheckInputSearch(value)) {
				for (var i = 0; i <= 2; i++) {
					var tokens = value.selectionSet[i].getTokens();
					var tokenLenth = tokens.length - 1;
					var fieldName;
					if (tokenLenth >= 0) {
						fieldName = filterCondi[i];
						filtercon[i] = this.getFilterCondition(tokens, fieldName);
					} else if (tokenLenth < 0) {
						fieldName = filterCondi[i];
						filtercon[i] = fieldName + " eq ''";

					}
				}
				//var addFilterCon = this.onAddFilter(filtercon);
				// var sServiceUrl = "/sap/opu/odata/sap/ZEPM_PRODUCT_SRV/productSet?$filter=(" + filtercon[0] + ") and (" + filtercon[1] + ") and (" +
				// 	filtercon[2] + ")";
				// 
				var oViewModel = new JSONModel({
					oCount: 0,
					//Owner: ouserId,
					//SerURL: "",
					//toppings: []
				});
				this.getView().setModel(oViewModel, "appView");
				var sServiceUrl = "/sap/opu/odata/sap/ZODATA_WBS_MANAGE_SRV/HeaderRequestSet";
				var that = this;
				jQuery.ajax({
					type: "GET",
					contentType: "application/json",
					url: sServiceUrl,
					dataType: "json",
					async: false,
					success: function (oData, textStatus, jqXHR) {

						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							sap.m.MessageToast.show(sMessage);
							return;
						}
						var oModel = new sap.ui.model.json.JSONModel(oData);
						var oTable = that.byId("idManageTable");
						oTable.setModel(oModel);
						that.getView().getModel("appView").setProperty("/oCount", oData.d.results.length);
						// var multiBoxM = that.byId("idManageTable");
						//         multiBoxM.setModel(oModel);
					}
				});
			} else {
				MessageBox.show("Please enter value in search field!!!", sap.m.MessageBox.Icon.INFORMATION, "Information");
				this.getView().byId("idManageTable").setModel(new sap.ui.model.json.JSONModel({
					data: []
				}));
				this.getView().getModel("appView").setProperty("/oCount", 0);
				this.getView().byId("idChangeProj").setEnabled(false);
				this.getView().byId("idDuplicateExist").setEnabled(false);
				this.getView().byId("idChangeRequest").setEnabled(false);
				
				
			}*/

		},
		onCheckitem: function (oEvent) {
			this.oFlagSelectitem = true;
			var oTableData = oEvent.getParameter("selected");
			var oPath = this.getView().byId("idManageTable").getSelectedItem().getBindingContext().getPath().split("/")[1];
			var oSysId = this.getView().byId("idManageTable").getModel().getData()[oPath].SysId;
			var oStatus = this.getView().byId("idManageTable").getModel().getData()[oPath].Status;
			if (oTableData && this.oEntity === "/Manage_Project_ProjDefSet_Go") {
				if (oSysId === "C1") {
					this.getView().byId("idChangeProj").setEnabled(true);
					this.getView().byId("idDuplicateExist").setEnabled(false);
				} else {
					this.getView().byId("idChangeProj").setEnabled(true);
					this.getView().byId("idDuplicateExist").setEnabled(true);
					this.getView().byId("idDownload").setEnabled(true);
					this.getView().byId("idChangeRequest").setEnabled(false);
				}

			} else {
				// var oViewModel = this.getView().getModel("appView");
				// var oUsrId = oViewModel.getData().Owner;
				// var sPath = this.byId("idManageTable").getSelectedContextPaths()[0];
				// var sData = this.byId("idManageTable").getModel().getProperty(sPath);
				// var ocreateUser = sData.Changed_by;
				if (oSysId === "C1") {
					this.getView().byId("idChangeProj").setEnabled(false);
					this.getView().byId("idDuplicateExist").setEnabled(false);
					this.getView().byId("idDownload").setEnabled(false);
					this.getView().byId("idChangeRequest").setEnabled(true);
				} else {
					this.getView().byId("idChangeProj").setEnabled(false);
					this.getView().byId("idDuplicateExist").setEnabled(false);
					this.getView().byId("idDownload").setEnabled(true);
					this.getView().byId("idChangeRequest").setEnabled(true);
				}

				if (oStatus === "DRAFT" || oStatus === "REJECTED" || oStatus === "AUTOREJECT" || oStatus === "INPROGRESS") {
					this.getView().byId("idDeleteReq").setEnabled(true);
				} else if (oStatus === "INPROG-ERR") {
					this.getView().byId("idDeleteReq").setEnabled(true);
					this.getView().byId("idChangeRequest").setEnabled(true);
				} else {
					this.getView().byId("idDeleteReq").setEnabled(false);
				}

				//if (oStatus === "CANCELLED" || oStatus === "INPROG-ERR" || oStatus === "AUTOCANCEL") {
				if (oStatus === "CANCELLED" || oStatus === "AUTOCANCEL") {
					this.getView().byId("idChangeProj").setEnabled(false);
					this.getView().byId("idDuplicateExist").setEnabled(false);
					this.getView().byId("idDownload").setEnabled(false);
					this.getView().byId("idChangeRequest").setEnabled(true);
					this.getView().byId("idDeleteReq").setEnabled(false);
					//this.getView().byId("idUpload").setEnabled(false); //phase 3  Ratnakumar
				}

			}

		},
		getSearchData: function () {
			this.oFlagSelectitem = false;
			this.getView().byId("idChangeProj").setEnabled(false);
			this.getView().byId("idDuplicateExist").setEnabled(false);
			this.getView().byId("idChangeRequest").setEnabled(false);
			this.getView().byId("idDownload").setEnabled(false);
			this.getView().byId("idDeleteReq").setEnabled(false);
			//this.getView().byId("idUpload").setEnabled(false);
			var that = this;
			this.finalFilters = [];
			this.oEntity = "";
			if (this.selProjectIdVals.length > 0) {
				for (var i = 0; i < this.selProjectIdVals.length; i++) {
					this.finalFilters.push(new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.EQ, this.selProjectIdVals[i]));
				}
				this.getView().byId("idDeleteReq").setEnabled(false);
				this.oEntity = "/Manage_Project_ProjDefSet_Go";

			} else {
				if (this.selRequestIdVals.length > 0) {
					for (var i = 0; i < this.selRequestIdVals.length; i++) {
						this.finalFilters.push(new sap.ui.model.Filter("ReqNo", sap.ui.model.FilterOperator.EQ, this.selRequestIdVals[i]));
					}
					this.oEntity = "/ManageRequestSet";
				}
				if (this.selCreatedByVals.length > 0) {
					for (var i = 0; i < this.selCreatedByVals.length; i++) {
						this.finalFilters.push(new sap.ui.model.Filter("Changed_by", sap.ui.model.FilterOperator.EQ, this.selCreatedByVals[i]));
					}
					/*if (this.selProjectIdVals.length > 0) {
						this.oEntity = "/Manage_Project_ProjDefSet";
					} else {
						this.oEntity = "/ManageRequestSet";
					}*/
					this.oEntity = "/ManageRequestSet";
				}
				if (this.selStatusVals.length > 0) {
					for (var i = 0; i < this.selStatusVals.length; i++) {
						this.finalFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, this.selStatusVals[i]));
						if (this.finalFilters[i].oValue1 === "DRAFT" || this.finalFilters[i].oValue1 === "INPROGRESS") {
							this.getView().byId("idDeleteReq").setEnabled(true);
						} else {
							this.getView().byId("idDeleteReq").setEnabled(false);
						}
					}
					this.oEntity = "/ManageRequestSet";
				}
				// else {
				// 	this.finalFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.NE, "APPROVED"));

				// }
			}

			if (this.oEntity === "/Manage_Project_ProjDefSet_Go") {
				this.getView().byId("idColProDef").setVisible(true);
				this.getView().byId("idColLeadPract").setVisible(false);
				this.getView().byId("idColReqNum").setVisible(false);
				this.getView().byId("idColStartdate").setVisible(true);
				this.getView().byId("idColEnddate").setVisible(true);
				this.getView().byId("idColProjStatus").setVisible(true);
				this.getView().byId("idColIndCode").setVisible(false);
				this.getView().byId("idColClntID").setVisible(true);
				this.getView().byId("idColStatus").setVisible(false);
				this.getView().byId("idColCreatedBY").setVisible(false);
				this.getView().byId("idWb1").setVisible(false);
				this.getView().byId("idWb2").setVisible(false);
				this.getView().byId("idSold").setVisible(true);
				this.getView().byId("idContractNo").setVisible(true);
				this.getView().byId("idProType").setVisible(false);
				this.getView().byId("idReqType").setVisible(false);
				this.getView().byId("idColProgram").setVisible(true);
				//this.getView().byId("idColProJID").setVisible(false);

				//sap.ui.getCore().byId("a1").setEditable(false);
			}
			if (this.oEntity === "/ManageRequestSet") {
				//this.getView().byId("idColProJID").setVisible(false);
				this.getView().byId("idColProDef").setVisible(true);
				this.getView().byId("idColClntID").setVisible(true);
				this.getView().byId("idColIndCode").setVisible(false);
				this.getView().byId("idColReqNum").setVisible(true);
				this.getView().byId("idColStatus").setVisible(true);
				this.getView().byId("idColCreatedBY").setVisible(true);
				this.getView().byId("idColProCat").setVisible(false);
				this.getView().byId("idProType").setVisible(true);
				this.getView().byId("idReqType").setVisible(true);
				this.getView().byId("idColProjStatus").setVisible(false);
				this.getView().byId("idColProgram").setVisible(true);
				this.getView().byId("idColStartdate").setVisible(false);
				this.getView().byId("idColEnddate").setVisible(false);
				this.getView().byId("idContractNo").setVisible(false);

				//sap.ui.getCore().byId("a19").setEditable(false);

			}
			/*if(this.selProjectIdVals.length > 0 && this.selCreatedByVals.length > 0){
				this.getView().byId("idColProJID").setVisible(true);
				this.getView().byId("idColLeadPract").setVisible(true);
				this.getView().byId("idColReqNum").setVisible(false);
				this.getView().byId("idColProDef").setVisible(false);
				this.getView().byId("idColIndCode").setVisible(false);
				this.getView().byId("idColClntID").setVisible(false);
				this.getView().byId("idColStatus").setVisible(false);
				this.getView().byId("idColCreatedBY").setVisible(true);
			}*/
			/*if(this.oEntity === "/ManageRequestSet" && this.selCreatedByVals.length > 0){
				this.getView().byId("idColProJID").setVisible(true);
				this.getView().byId("idColProDef").setVisible(true);
				this.getView().byId("idColClntID").setVisible(true);
				this.getView().byId("idColIndCode").setVisible(true);
				this.getView().byId("idColReqNum").setVisible(true);
				this.getView().byId("idColStatus").setVisible(true);
				this.getView().byId("idColCreatedBY").setVisible(true);
			}*/
			if (this.finalFilters.length != 0 && this.oEntity != '') {
				var oDta = this.getOwnerComponent().getModel();
				//var oDta = this.getView().getModel("projectFilterModel");
				BusyIndicator.show();
				if (this.oEntity === "/Manage_Project_ProjDefSet_Go") {
					oDta.read(this.oEntity, {
						filters: this.finalFilters,
						success: function (oData, oResponse) {
							BusyIndicator.hide();
							if (oData === null || oData === undefined) {
								var sMessage = "WARNING. Received a null or undefined response object.";
								sap.m.MessageToast.show(sMessage);
								return;
							}
							/*var oUniurReqid = that.removeDuplicates(oData.results, "ReqNo");
							that.tableModel = new JSONModel(oUniurReqid);
							this.getView().byId("idManageTable").setModel(that.tableModel);
							that.getView().getModel("appView").setProperty("/oCount", oUniurReqid.length);*/
							//commnted by srinivas 
							// if(oData.results[0].Status !== "APPROVED"){
							// for(var i=0; i<oData.results.length; i++){
							// if(oData.results[i].SysId === "COMPASS"){
							// 	this.getView().byId("idColProgram").setVisible(true);
							// 	this.getView().byId("idContractNo").setVisible(false);
							// }else{
							// 	this.getView().byId("idColProgram").setVisible(false);
							// 	this.getView().byId("idContractNo").setVisible(true);
							// }
							// }
							this.tableModel = new JSONModel(oData.results);
							this.getView().byId("idManageTable").setModel(that.tableModel);
							this.getView().getModel("appView").setProperty("/oCount", oData.results.length);
							// }else{
							// 	this.oEmptyTale();
							// }

							//end Commneted by  srinivas

						}.bind(this),
						error: function (oError) {
							BusyIndicator.hide();
							var oErrorMsg = JSON.parse(oError.responseText).error.message.value;
							sap.m.MessageToast.show(oErrorMsg, {
								duration: 5000
							});
						}
					});
				} else {
					oDta.read(this.oEntity, {
						filters: this.finalFilters,
						urlParameters: {
							"$orderby": "ReqNum desc"
						},
						success: function (oData, oResponse) {
							BusyIndicator.hide();
							if (oData === null || oData === undefined) {
								var sMessage = "WARNING. Received a null or undefined response object.";
								sap.m.MessageToast.show(sMessage);
								return;
							}
							this.tableModel = new JSONModel(oData.results);
							this.getView().byId("idManageTable").setModel(that.tableModel);
							this.getView().getModel("appView").setProperty("/oCount", oData.results.length);
							/*var oUniurReqid = that.removeDuplicates(oData.results, "ReqNo");
							that.tableModel = new JSONModel(oUniurReqid);
							this.getView().byId("idManageTable").setModel(that.tableModel);
							that.getView().getModel("appView").setProperty("/oCount", oUniurReqid.length);*/
							//commnted by srinivas 
							// if(oData.results[0].Status !== "APPROVED"){
							// var oCompass = [];
							// var oC1 = [];
							// this.tableModel = new JSONModel(oData.results);
							// this.getView().byId("idManageTable").setModel(that.tableModel);
							// for(var i=0; i<oData.results.length; i++){
							// if(oData.results[i].SysId === "COMPASS"){
							// var oComcontrcid = this.getView().byId("idManageTable").getModel().getData()[i].Zpgid;
							// 	this.getView().byId("idManageTable").getModel().setProperty("/Zvbeln", oComcontrcid);

							// 	this.getView().byId("idColProgram").setVisible(true);
							// 	this.getView().byId("idContractNo").setVisible(false);
							// 	this.tableModel = new JSONModel(oData.results);
							// this.getView().byId("idManageTable").setModel(that.tableModel);
							// }else{
							// 	var oC1contrcid = this.getView().byId("idManageTable").getModel().getData()[i].Zvbeln;
							// 	this.getView().byId("idManageTable").getModel().setProperty("/Zpgid", oC1contrcid);

							// 	this.getView().byId("idColProgram").setVisible(false);
							// 	this.getView().byId("idContractNo").setVisible(true);
							// 	this.tableModel = new JSONModel(oData.results);
							// this.getView().byId("idManageTable").setModel(that.tableModel);
							// }
							// }

							// }else{
							// 	this.oEmptyTale();
							// }

							//end Commneted by  srinivas

						}.bind(this),
						error: function (err) {
							BusyIndicator.hide();
						}
					});
				}
			} else {

				MessageBox.show("Please enter data for at least one filter", sap.m.MessageBox.Icon.INFORMATION, "Information");
				this.oEmptyTale();

				/*this.getView().byId("idManageTable").setModel(new sap.ui.model.json.JSONModel({
						data: []
					}));
					this.getView().byId("idManageTable").setMode("None");*/
				this.getView().byId("idChangeProj").setEnabled(false);
				this.getView().byId("idDuplicateExist").setEnabled(false);
				this.getView().byId("idChangeRequest").setEnabled(false);
				this.getView().byId("idDownload").setEnabled(false);
				BusyIndicator.hide();
			}

		},
		onDeleteDraftRecords: function () {
			if (this.oFlagSelectitem !== true) {
				MessageToast.show("please select atleast one item");
			} else {

				if (!this.oApproveDialog) {
					//this.getView().byId(this.createId("submitDialogTextarea")).setValue("");
					//sap.ui.getCore().byId(this.createId("submitDialogTextarea")).setValue("");
					this.oApproveDialog = new Dialog({
						title: "Confirm",
						type: 'Message',
						contentWidth: "400px",
						contentHeight: "225px",
						resizable: true,
						// content: new Text({
						// 	text: "Sure you want to delete the record?"
						// }),
						content: [
							new Label({
								text: 'Do you wish to cancel the request?',
								labelFor: 'submitDialogTextarea'
							}),
							new TextArea(this.createId("submitDialogTextarea"), {
								width: '100%',
								height: "140px",
								maxLength: 500,
								showExceededText: true,
								// liveChange: function (oEvent) {
								// 	var sText = oEvent.getParameter('value');

								// 	var parent = oEvent.getSource().getParent();
								// 	parent.getBeginButton().setEnabled(sText.length > 0);
								// },
								liveChange: function (e) {
									var f = e.getParameter('value');
									var o = e.getSource().getParent();
									o.data("note", f);
									if (f.length > 500) {
										o.getBeginButton().setEnabled(false);
									} else {
										o.getBeginButton().setEnabled(f.length > 0);
									}
									var oTextArea = e.getSource(),
										iValueLength = oTextArea.getValue().length,
										iMaxLength = oTextArea.getMaxLength(),
										sState = iValueLength > iMaxLength ? "Error" : "None";

									oTextArea.setValueState(sState);

								},

								placeholder: 'Reason for cancellation'
							})

						],
						beginButton: new Button({
							enabled: false,
							text: "Yes",
							press: function (oEvent) {
								//MessageToast.show("development is going on");
								sap.ui.core.BusyIndicator.show(0);
								var textArea = sap.ui.getCore().byId(this.createId("submitDialogTextarea")).getValue();
								var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZODATA_WBS_MANAGE_PH2_SRV/");
								var sPath = this.byId("idManageTable").getSelectedContextPaths()[0];
								var sData = this.byId("idManageTable").getModel().getProperty(sPath);
								var ReqNum = sData.ReqNum;
								var oObj = {
									"d": {
										"ActCom": textArea
											// "toMssg": {
											// 	"results": [{
											// 		"Instanceid": "",
											// 		"Error": "",
											// 		"Mesage": ""
											// 	}]
											// }

									}

								};
								if (textArea === "") {
									sap.ui.core.BusyIndicator.hide();
									//that.cDialog.close();
									sap.m.MessageToast.show("Please enter the comment", {
										duration: 5000
									});
								} else {
									sap.ui.core.BusyIndicator.show(0);
									//this.onSearch();
									var that = this;
									this.oApproveDialog.close();
									oModel.update("/ManageRequestSet('" + ReqNum + "')", oObj, {
										success: function (oData, oResponse) {
											sap.ui.core.BusyIndicator.hide();
											var oStaCode = oResponse.statusCode;
											if (oStaCode === "204") {
												sap.m.MessageToast.show("Request cancelled  Successfully", {
													duration: 5000
												});
											}
											that.onSearch();
											//this.getSearchData();
											//that.getView().byId("idManageTable").getModel().refresh(true);
											//var oLength = oResponse.results.length;
											// if (oLength === 0) {
											// 	sap.m.MessageToast.show("No Cancellation comments", {
											// 		duration: 5000
											// 	});
											// } else {
											// 	var oStatus = oResponse.results[0].Status;
											// }
										},
										error: function (oError) {
											sap.ui.core.BusyIndicator.hide();
											var oErrorMsg = JSON.parse(oError.responseText).error.message.value;

											sap.m.MessageToast.show(oErrorMsg, {
												duration: 5000
											});
										}
									});

								}
								//this.oApproveDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "Cancel",
							press: function () {

								this.oApproveDialog.close();
							}.bind(this)
						})
					});
				}
				sap.ui.getCore().byId(this.createId("submitDialogTextarea")).setValue("");
				this.oApproveDialog.open();

			}
			/*this.newEditDialog.close();
			this.onSearch();*/

		},
		oEmptyTale: function () {
			/*this.getView().byId("idColComcode").setVisible(true);
			this.getView().byId("idColProDes").setVisible(true);
			this.getView().byId("idColProjectCC").setVisible(true);
			this.getView().byId("idColBusArea").setVisible(true);
			this.getView().byId("idColProfitCen").setVisible(true);
			this.getView().byId("idColContrm").setVisible(true);
			this.getView().byId("idColStartdate").setVisible(true);*/
			this.getView().byId("idDeleteReq").setEnabled(false);
			this.getView().byId("idChangeRequest").setEnabled(false);
			this.getView().byId("idDownload").setEnabled(false);
			var table = this.getView().byId("idManageTable");
			var oModel1 = new sap.ui.model.json.JSONModel();
			var data = [];
			oModel1.setData(data);
			var aData = oModel1.getProperty("/d/results");
			oModel1.setData({
				modelData: aData
			});

			table.setModel(oModel1);
			this.getView().getModel("appView").setProperty("/oCount", 0);
		},
		OnTokenUpdate: function (oEvent) {
			var selectedProjectID = this.byId("idProject").getTokens();
			var selectedReqNum = this.byId("idFltRequest").getTokens();
			var selectedCreatedBy = this.byId("idCreatedBY").getTokens();
			var selectedStatus = this.byId("idStatus").getSelectedItems();
			var oFiltersPID = [];
			var oFilterPID = [];

			var oFiltersReq = [];
			var oFilterPReq = [];

			var oFiltersCreBy = [];
			var oFilterCreBy = [];

			var oFiltersStatus = [];
			var oFilterPStatus = [];

			var removedProject;
			if (oEvent !== undefined && oEvent.getParameter("type") === "removed") {

				removedProject = oEvent.getParameter("removedTokens")[0].getProperty("key");

			}
			if (selectedProjectID !== undefined && selectedProjectID.length > 0) {
				for (var count = 0; count < selectedProjectID.length; count++) {
					if (removedProject !== selectedProjectID[count].getProperty("key")) {
						this.getView().byId("idFltRequest").setEnabled(false);
						this.getView().byId("idCreatedBY").setEnabled(false);
						this.getView().byId("idStatus").setEnabled(false);
						oFilterPID = new sap.ui.model.Filter("Zpspid", sap.ui.model.FilterOperator.EQ, selectedProjectID[count].getProperty(
							"key"));
						oFiltersPID.push(oFilterPID);
					} else {
						if (oFiltersPID.length === 0 && this.oFlagChangPro !== true) {
							this.getView().byId("idFltRequest").setEnabled(true);
							this.getView().byId("idStatus").setEnabled(true);
							this.getView().byId("idCreatedBY").setEnabled(true);

							this.oEmptyTale();

						} else {
							this.getView().byId("idFltRequest").setEnabled(false);
							this.getView().byId("idCreatedBY").setEnabled(false);
							this.getView().byId("idStatus").setEnabled(false);
						}
					}
				}
			}
			if (selectedCreatedBy !== undefined && selectedCreatedBy.length > 0) {
				for (var count = 0; count < selectedCreatedBy.length; count++) {
					if (removedProject !== selectedCreatedBy[count].getProperty("key")) {
						this.getView().byId("idProject").setEnabled(false);
						oFilterCreBy = new sap.ui.model.Filter("Changed_by", sap.ui.model.FilterOperator.EQ, selectedCreatedBy[count].getProperty(
							"key"));
						oFiltersCreBy.push(oFilterCreBy);
					} else {
						if (oFiltersCreBy.length === 0) {
							this.getView().byId("idProject").setEnabled(true);
							if (selectedReqNum.length === 0 && selectedStatus.length === 0) {
								this.oEmptyTale();
							}
						}
					}
				}
			}
			if (selectedReqNum !== undefined && selectedReqNum.length > 0) {
				for (var count = 0; count < selectedReqNum.length; count++) {
					if (removedProject !== selectedReqNum[count].getProperty("key")) {
						this.getView().byId("idProject").setEnabled(false);
						oFilterPReq = new sap.ui.model.Filter("ReqNo", sap.ui.model.FilterOperator.EQ, selectedReqNum[count].getProperty(
							"key"));
						oFiltersReq.push(oFilterPReq);

					} else {
						if (oFiltersReq.length === 0) {
							this.getView().byId("idProject").setEnabled(true);
							if (selectedCreatedBy.length === 0 && selectedStatus.length === 0) {
								this.oEmptyTale();
							}
						}
					}
				}
			}
			if (selectedStatus !== undefined && selectedStatus.length > 0) {
				for (var count = 0; count < selectedStatus.length; count++) {
					if (removedProject !== selectedStatus[count].getProperty("key")) {
						this.getView().byId("idProject").setEnabled(false);
						oFilterPStatus = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, selectedStatus[count].getProperty(
							"key"));
						oFiltersStatus.push(oFilterPStatus);
						//this.onSearch();

					}
				}
			} else {
				if (oFiltersStatus.length === 0 && oFiltersReq.length === 0 && oFiltersCreBy.length === 0) {
					this.getView().byId("idProject").setEnabled(true);
					if (selectedReqNum.length === 0 && selectedCreatedBy.length === 0 && selectedStatus.length === 0 && selectedProjectID.length ===
						0) {
						this.oEmptyTale();
					}

				}
			}

			/*if (selectedCustomers !== undefined && selectedCustomers.length > 0) {
				for (var count = 0; count < selectedCustomers.length; count++) {
					if (removedProject !== selectedCustomers[count].getProperty("key")) {
						oFilterC = new sap.ui.model.Filter("Primary_Client_ID", sap.ui.model.FilterOperator.EQ, selectedCustomers[count].getProperty(
							"key"));
						oFiltersC.push(oFilterC);

					}
				}
			}*/

		},
		onPressUpload: function (oEvent) {
			new sap.ushell.Container.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: "create"
					},
					params: {
						"TYPE": "Upload",
						"flag": true
					}
				});

		},
		onPressExport: function (oEvent) {
			sap.ui.core.BusyIndicator.show(0);
			var sPath = this.byId("idManageTable").getSelectedContextPaths()[0];
			var sData = this.byId("idManageTable").getModel().getProperty(sPath);
			var Projectid = sData.Zpspid;
			var ReqNumber = sData.ReqNo;
			var oOrgModel = this.getOwnerComponent().getModel();
			var oModel = new sap.ui.model.odata.ODataModel(oOrgModel.sServiceUrl);
			if (Projectid && !ReqNumber) {
				var ReqNumber = "";
				oModel.read("/WBSExcelDownloadSet(Zpspid='" + Projectid + "',ReqNo='" + ReqNumber + "')/$value", {
					success: function (oData, response) {
						sap.ui.core.BusyIndicator.hide();
						var file = response.requestUri;
						window.open(file);
					},
					error: function (odata) {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Error While Downloading", {
							duration: 5000
						});
					}
				});
			} else if (ReqNumber) {
				var Projectid = "";
				oModel.read("/WBSExcelDownloadSet(ReqNo='" + ReqNumber + "',Zpspid='" + Projectid + "')/$value", {
					success: function (oData, response) {
						sap.ui.core.BusyIndicator.hide();
						var file = response.requestUri;
						window.open(file);
					},
					error: function (odata) {
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Error While Downloading", {
							duration: 5000
						});
					}
				});
			}

			// var aCols, aRows, oSettings, oSheet, oExportPromise;
			// var arr = [];

			// aRows = this.tableModel;
			// var keys = Object.keys(aRows.oData)
			// for (var i = 0; i < keys.length; i++) {
			// 	arr.push(aRows.oData[keys[i]]);
			// }

			// aCols = this.exportHeadingsArray;
			// oSettings = {
			// 	workbook: {
			// 		columns: aCols

			// 	},
			// 	dataSource: arr,
			// 	fileName: "Compass"
			// };
			// oSheet = new Spreadsheet(oSettings);
			// oSheet.build().finally(function () {
			// 	oSheet.destroy();
			// });

		},
		/*removeDuplicates: function (originalArray, prop) {
			var newArray = [];
			var lookupObject = {};

			for (var i in originalArray) {
				lookupObject[originalArray[i][prop]] = originalArray[i];
			}

			for (i in lookupObject) {
				newArray.push(lookupObject[i]);
			}
			return newArray;
		},*/

		/*getFilterCondition: function (tokens, fieldName) {
			var tokenLenth = tokens.length - 1;
			var filtercon = "";
			var str1, token, str2;
			if (tokenLenth > 0) {
				for (var j = 0; j <= tokenLenth; j++) {
					token = tokens[j].getKey();
					str1 = fieldName + " eq '" + token;
					str2 = "'";
					var m1 = str1.concat(str2);
					var m = filtercon.concat(m1);
					var n;
					if (j < tokenLenth) {
						n = " or ";
						filtercon = m.concat(n);
					} else if (j === tokenLenth) {
						n = "";
						filtercon = m.concat(n);
					}
				}
			} else if (tokenLenth === 0) {
				token = tokens[0].getKey();
				str1 = fieldName + " eq '" + token;
				str2 = "'";
				filtercon = str1.concat(str2);
			} else {
				filtercon = "";
			}
			return filtercon;
		},*/
		/*onAddFilter: function (filtercon) {
			var filLength = filtercon.length - 1;
			var filValue = "";
			if (filLength > 0) {
				for (var i = 0; i <= filLength; i++) {
					if (filtercon[i] != undefined) {
						var filValue1 = "(" + filtercon[i] + ")";
						filValue = filValue.concat(filValue1);
						if (i < filLength) {
							filValue = filValue.concat(" and ");
						} else {
							return filValue;
						}
					}
				}
			} else if (filLength === 0) {
				filValue = "(" + filtercon[0] + ")";
				return filValue;
			}

		},*/
		onSetting: function (oEvent) {
			var oView = this.getView();
			var oData = {
				"ReqNo": oView.byId("idManageTable").getColumns()[0].getVisible(),
				"Status": oView.byId("idManageTable").getColumns()[1].getVisible(),
				"Zpspid": oView.byId("idManageTable").getColumns()[2].getVisible(),
				"Ktext": oView.byId("idManageTable").getColumns()[3].getVisible(),
				"Zbukrs": oView.byId("idManageTable").getColumns()[4].getVisible(),
				"Changed_by": oView.byId("idManageTable").getColumns()[5].getVisible(),
				"projTypDesc": oView.byId("idManageTable").getColumns()[6].getVisible(),
				"ActType": oView.byId("idManageTable").getColumns()[7].getVisible(),
				"Zkunnr": oView.byId("idManageTable").getColumns()[8].getVisible(),
				"Zpgid": oView.byId("idManageTable").getColumns()[9].getVisible(),
				"Zvbeln": oView.byId("idManageTable").getColumns()[10].getVisible(),
				"Soldto": oView.byId("idManageTable").getColumns()[11].getVisible(),
				"Guebg": oView.byId("idManageTable").getColumns()[12].getVisible(),
				"Gueen": oView.byId("idManageTable").getColumns()[13].getVisible(),
				"ProjStat": oView.byId("idManageTable").getColumns()[14].getVisible(),
				"Vernr": oView.byId("idManageTable").getColumns()[15].getVisible(),
				"Kostl": oView.byId("idManageTable").getColumns()[16].getVisible(),
				"Vgsbr": oView.byId("idManageTable").getColumns()[17].getVisible(),
				"ProfitCenter": oView.byId("idManageTable").getColumns()[18].getVisible(),
				"Zpjcgid": oView.byId("idManageTable").getColumns()[19].getVisible(),
				"Zzsoarincd": oView.byId("idManageTable").getColumns()[20].getVisible(),
				"Zzcntrcd": oView.byId("idManageTable").getColumns()[21].getVisible(),
				"Zzldpcid": oView.byId("idManageTable").getColumns()[22].getVisible(),
				"Wbsowner1": oView.byId("idManageTable").getColumns()[23].getVisible(),
				"Wbsowner2": oView.byId("idManageTable").getColumns()[24].getVisible()
			};
			var oDialog = oView.byId("idDialog");
			// create dialog lazily
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "WBS.manage.ZWBS_Manage.fragments.Setting", this);
				var oModel = new sap.ui.model.json.JSONModel(oData);
				oDialog.setModel(oModel);
				oDialog.open();
			}
		},
		onCancel: function () {
			var oDailog = this.byId("idDialog");
			oDailog.close();
			oDailog.destroy();
		},
		onsettingSavePress: function () {
			var oView = this.getView();
			if (oView.byId("a1").getSelected()) {
				oView.byId("idManageTable").getColumns()[0].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[0].setVisible(false);
			}
			if (oView.byId("a2").getSelected()) {
				oView.byId("idManageTable").getColumns()[1].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[1].setVisible(false);
			}
			if (oView.byId("a3").getSelected()) {
				oView.byId("idManageTable").getColumns()[2].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[2].setVisible(false);
			}
			if (oView.byId("a4").getSelected()) {
				oView.byId("idManageTable").getColumns()[3].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[3].setVisible(false);
			}
			if (oView.byId("a5").getSelected()) {
				oView.byId("idManageTable").getColumns()[4].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[4].setVisible(false);
			}
			if (oView.byId("a6").getSelected()) {
				oView.byId("idManageTable").getColumns()[5].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[5].setVisible(false);
			}
			if (oView.byId("a7").getSelected()) {
				oView.byId("idManageTable").getColumns()[6].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[6].setVisible(false);
			}
			if (oView.byId("a8").getSelected()) {
				oView.byId("idManageTable").getColumns()[7].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[7].setVisible(false);
			}
			if (oView.byId("a9").getSelected()) {
				oView.byId("idManageTable").getColumns()[8].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[8].setVisible(false);
			}
			if (oView.byId("a10").getSelected()) {
				oView.byId("idManageTable").getColumns()[9].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[9].setVisible(false);
			}
			if (oView.byId("a11").getSelected()) {
				oView.byId("idManageTable").getColumns()[10].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[10].setVisible(false);
			}
			if (oView.byId("a12").getSelected()) {
				oView.byId("idManageTable").getColumns()[11].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[11].setVisible(false);
			}
			if (oView.byId("a13").getSelected()) {
				oView.byId("idManageTable").getColumns()[12].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[12].setVisible(false);
			}
			if (oView.byId("a14").getSelected()) {
				oView.byId("idManageTable").getColumns()[13].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[13].setVisible(false);
			}
			if (oView.byId("a15").getSelected()) {
				oView.byId("idManageTable").getColumns()[14].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[14].setVisible(false);
			}
			if (oView.byId("a16").getSelected()) {
				oView.byId("idManageTable").getColumns()[15].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[15].setVisible(false);
			}
			if (oView.byId("a17").getSelected()) {
				oView.byId("idManageTable").getColumns()[16].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[16].setVisible(false);
			}

			if (oView.byId("a18").getSelected()) {
				oView.byId("idManageTable").getColumns()[17].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[17].setVisible(false);
			}
			if (oView.byId("a19").getSelected()) {
				oView.byId("idManageTable").getColumns()[18].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[18].setVisible(false);
			}

			if (oView.byId("a20").getSelected()) {
				oView.byId("idManageTable").getColumns()[19].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[19].setVisible(false);
			}
			if (oView.byId("a21").getSelected()) {
				oView.byId("idManageTable").getColumns()[20].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[20].setVisible(false);
			}
			if (oView.byId("a22").getSelected()) {
				oView.byId("idManageTable").getColumns()[21].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[21].setVisible(false);
			}
			if (oView.byId("a23").getSelected()) {
				oView.byId("idManageTable").getColumns()[22].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[22].setVisible(false);
			}
			if (oView.byId("a24").getSelected()) {
				oView.byId("idManageTable").getColumns()[23].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[23].setVisible(false);
			}
			if (oView.byId("a25").getSelected()) {
				oView.byId("idManageTable").getColumns()[24].setVisible(true);
			} else {
				oView.byId("idManageTable").getColumns()[24].setVisible(false);
			}
			// if (oView.byId("a26").getSelected()) {
			// 	oView.byId("idManageTable").getColumns()[25].setVisible(true);
			// } else {
			// 	oView.byId("idManageTable").getColumns()[25].setVisible(false);
			// }
			//this.oStateToSave.URL.setting = this.onSettingDataStore();
			this.onCancel();
		},
		/*onSettingDataStore: function () {
			var oView = this.getView();
			var oData = {
				"ReqNo": oView.byId("idManageTable").getColumns()[0].getVisible(),
				"Zpspid": oView.byId("idManageTable").getColumns()[1].getVisible(),
				"Zbukrs": oView.byId("idManageTable").getColumns()[2].getVisible(),
				"Ktext": oView.byId("idManageTable").getColumns()[3].getVisible(),
				"Vernr": oView.byId("idManageTable").getColumns()[4].getVisible(),
				"Kostl": oView.byId("idManageTable").getColumns()[5].getVisible(),
				"Vgsbr": oView.byId("idManageTable").getColumns()[6].getVisible(),
				"ProfitCenter": oView.byId("idManageTable").getColumns()[7].getVisible(),
				"Zpgid": oView.byId("idManageTable").getColumns()[8].getVisible(),
				"Zkunnr": oView.byId("idManageTable").getColumns()[9].getVisible(),
				"Zzsoarincd": oView.byId("idManageTable").getColumns()[10].getVisible(),

				"Zzcntrcd": oView.byId("idManageTable").getColumns()[11].getVisible(),
				"Guebg": oView.byId("idManageTable").getColumns()[12].getVisible(),

				"Gueen": oView.byId("idManageTable").getColumns()[13].getVisible(),
				"Zzldpcid": oView.byId("idManageTable").getColumns()[14].getVisible(),
				"Zpgid": oView.byId("idManageTable").getColumns()[15].getVisible()
			};
			return oData;
		},*/
		onChangeReq: function (oEvent) {

			var oViewModel = this.getView().getModel("appView");
			var oUsrId = oViewModel.getData().Owner;
			var sPath = this.byId("idManageTable").getSelectedContextPaths()[0];
			var sData = this.byId("idManageTable").getModel().getProperty(sPath);
			var ReqNo = sData.ReqNo;
			var CompanyCode = sData.Zbukrs;
			var oStatus = sData.Status; //project Id
			var Sysid = sData.SysId;
			var ocreateUser = sData.Changed_by;
			var oUser = ocreateUser.includes(oUsrId);
			//if(oUser === 0){
			//	ocreateUser = oUsrId;
			//}
			if (oUser !== true && oUsrId !== ocreateUser && this.OMTApr === "N" && (oStatus === "DRAFT" || oStatus === "REJECTED" || oStatus ==="AUTOREJECT")) {
				// 	//sap.m.MessageBox.show("You can only change you own requests", sap.m.MessageBox.Icon.INFORMATION, "Information");
				sap.m.MessageBox.show("No access to modify requests created by another user", sap.m.MessageBox.Icon.WARNING, "Warning");
			} else {

				if (Sysid === "COMPASS") {
					var Action = "create";
				}
				if (Sysid === "C1") {
					var Action = "createC1";
				}
				// if (this.OMTApr == "Y") {}

				if ((this.OMTApr == "Y" && oStatus === "REJECTED") || oStatus === "DRAFT" || oStatus === "REJECTED" || oStatus === "Rejected" || oStatus === "AUTOREJECT") {
					var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');
					if (crossApp != undefined) {
						crossApp.toExternal({
							target: {
								semanticObject: "DXCGPRS",
								action: Action

								//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
							},
							params: {
								"ReqNo": ReqNo,
								"TYPE": "ChangeRequest"
							}
							/*,
												appStateKey: oAppState.getKey()*/
						});

						//sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
					} else {
						sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
					}
				} else {
					var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');
					if (crossApp != undefined) {
						crossApp.toExternal({
							target: {
								semanticObject: "DXCGPRS",
								action: Action
									//'OrderStatus/' + oControllerS3.orderNo + '/',
									//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
							},
							params: {
								"ReqNo": ReqNo,
								"TYPE": "View"
							}
							/*,
												appStateKey: oAppState.getKey()*/
						});

						//sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
					} else {
						sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
					}
					// sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
				}

			}

		},
		onDuplicate: function (oEvent) {
			var sPath = this.byId("idManageTable").getSelectedContextPaths()[0];
			var sData = this.byId("idManageTable").getModel().getProperty(sPath);
			var CompanyCode = sData.Zbukrs;
			var Projectid = sData.Zpspid;
			var Sysid = sData.SysId;
			//var oCacheData = null;
			//jQuery.sap.require("jquery.sap.storage");
			//var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			//if (this.getView().getModel("localData")) {
			//oCacheData = this.getView().getModel("localData").getData();
			//}

			if (Sysid === "COMPASS") {
				var Action = "create";
			}
			if (Sysid === "C1") {
				var Action = "createC1";
			}
			//if (oCacheData === undefined || oCacheData === "" || oCacheData === null) {
			var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');
			if (crossApp != undefined) {
				crossApp.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: Action
							//'OrderStatus/' + oControllerS3.orderNo + '/', ////"SysId": Sysid,//"ReqNum": oPReqNo,
							//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
					},
					params: {
						"Zpspid": Projectid,
						"TYPE": "DuplicateExisting"

					}
					/*,
										appStateKey: oAppState.getKey()*/
				});

				//sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
			} else {
				sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
			}
			//} 
			// else {
			// 	var aNavAryy = this.getView().getModel("localData").getData();
			// 	for (var i = 0; i < aNavAryy.length; i++) {
			// 		aNavAryy[i].Projectid = Projectid;
			// 	}
			// 	if (CompanyCode === aNavAryy[0].Zbukrs) {
			// 		oStorage.put("oppData", aNavAryy);
			// 		var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');
			// 		if (crossApp != undefined) {
			// 			crossApp.toExternal({
			// 				target: {
			// 					semanticObject: "DXCGPRS",
			// 					action: Action
			// 						//'OrderStatus/' + oControllerS3.orderNo + '/',
			// 						//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
			// 				},
			// 				params: {
			// 					"navAryyDuplicateManage": "navAryy1"
			// 					//"TYPE": "OppDataDuplicateProject"
			// 				}
			// 				/*,
			// 									appStateKey: oAppState.getKey()*/
			// 			});

			// 			//sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
			// 		} else {
			// 			sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
			// 		}
			// 	} else {
			// 		sap.m.MessageBox.show("Company code of selected project and opportunity id do not match", sap.m.MessageBox.Icon.ERROR, "Error");
			// 	}
			// }
		},
		onChangeProject: function (oEvent) {

			var sPath = this.byId("idManageTable").getSelectedContextPaths()[0];
			var sData = this.byId("idManageTable").getModel().getProperty(sPath);
			var CompanyCode = sData.Zbukrs;
			var Projectid = sData.Zpspid;
			var Sysid = sData.SysId;
			var oCacheData = null;
			jQuery.sap.require("jquery.sap.storage");
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			if (this.getView().getModel("localData")) {
				oCacheData = this.getView().getModel("localData").getData();
			}
			//var oProjArry = this.navAryy;
			//var oPReqNo = sData.ReqNum;
			//"SysId": Sysid,
			//"ReqNum": oPReqNo,

			if (Sysid === "COMPASS") {
				var Action = "create";
			}
			if (Sysid === "C1") {
				var Action = "createC1";
			}
			if (oCacheData === undefined || oCacheData === "" || oCacheData === null) {
				var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');
				if (crossApp != undefined) {
					crossApp.toExternal({
						target: {
							semanticObject: "DXCGPRS",
							action: Action
								//'OrderStatus/' + oControllerS3.orderNo + '/',
								//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
						},

						params: {
							"Zpspid": Projectid,
							"TYPE": "ChangeProject"
						}
						/*,
											appStateKey: oAppState.getKey()*/
					});

					//sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
				} else {
					sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
				}
			} else {
				var aNavAryy = this.getView().getModel("localData").getData();
				for (var i = 0; i < aNavAryy.length; i++) {
					aNavAryy[i].Projectid = Projectid;
				}

				if (CompanyCode === aNavAryy[0].Zbukrs) {

					//var navAryy1 = JSON.stringify(oOppProjArry);
					// if (oStorage.get("navAryyManage")){
					// 	oStorage.clear();
					// }
					oStorage.put("oppData", aNavAryy);
					var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');
					if (crossApp != undefined) {
						crossApp.toExternal({
							target: {
								semanticObject: "DXCGPRS",
								action: Action
									//'OrderStatus/' + oControllerS3.orderNo + '/',
									//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
							},
							params: {
								"navAryyManage": "navAryy1"
									// "Zpspid": Projectid
							}
							/*,
												appStateKey: oAppState.getKey()*/
						});

						//sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
					} else {
						sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
					}
				} else {
					sap.m.MessageBox.show("Company code of selected project and opportunity id do not match", sap.m.MessageBox.Icon.ERROR, "Error");
				}

			}

		},
		/*OnItemPress: function (oEvent) {
			var bSelected = oEvent.getSource().getBindingContext().getPath().slice(1);
			var sData = oEvent.getSource().getBindingContext().getModel().getData()[bSelected];
			var sPath = oEvent.getParameter("listItem").getBindingContext().getPath();
			var data = this.byId("idManageTable").getModel().getProperty(sPath);
			var ReqNo = sData.ReqNo;
			var CompanyCode = sData.Zbukrs; //company code
			var Projctdef = sData.Zpspid; //project Definition
			//var oAction = sData.Action;
			var Sysid = sData.SysId;
			if (Sysid === "COMPASS") {
				var Action = "create"
			} else {
				var Action = "createC1"
			}

			var crossApp = sap.ushell.Container.getService('CrossApplicationNavigation');

			if (crossApp != undefined) {
				var sHash = crossApp.hrefForExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: Action
							//'OrderStatus/' + oControllerS3.orderNo + '/',
							//action: 'NonSanctionView/searchscreen/'+oControllerS3.OrderGuid+'/'+oControllerS3.Extkey+'/'+oControllerS3.Wfpthid+'/'+oControllerS3.Filetype+'',
					},
					params: {
						//"ReqNo": ReqNo,
						"Zbukrs": CompanyCode,
						"Zpspid": Projctdef,
						"TYPE": "View"
					}
				});

				sap.m.URLHelper.redirect(window.location.href.split('#')[0] + sHash, true);
			} else {
				sap.m.MessageBox.show("Invalid Navigation -Open App from Launchpad", sap.m.MessageBox.Icon.ERROR, "Error");
			}

				var passingparms = (sap.ushell && sap.ushell.Container &&
					sap.ushell.Container.getService("CrossApplicationNavigation").hrefForExternal({
						target: {
							semanticObject: "DXCGPRS",
							action: Action
						},
						params: {
							//"ReqNo": ReqNo,
							"Zbukrs": CompanyCode,
							"Zpspid": Projctdef,
							"TYPE": "View"
						}
					}));
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			// saving the app state and generating the state Key
			var oAppState = oCrossAppNavigator.createEmptyAppState(this.getOwnerComponent());
			oAppState.setData(this.oStateToSave); // object of values needed to be restored
			oAppState.save();

			var oHashChanger = sap.ui.core.routing.HashChanger.getInstance();
			var sOldHash = oHashChanger.getHash();
			var sOldHash = "";
			var sNewHash = sOldHash + "?" + "sap-iapp-state=" + oAppState.getKey();
			oHashChanger.replaceHash(sNewHash);

			sap.ushell.Container
				.getService("CrossApplicationNavigation")
				.toExternal({
					target: {
						semanticObject: "DXCGPRS",
						action: oAct
					},
					// target: {
					//  		semanticObject: "Action",
					//         		action: "todefaultapp"
					// 	},
					params: {
						//"ReqNo": ReqNo,
						"Zbukrs": CompanyCode,
						"Zpspid": Projctdef,
						"TYPE": "View"
					},
					appStateKey: oAppState.getKey()
				});

		}*/
	});
});