sap.ui.define([], function () {
	"use strict";

	return {
		getMessageType: function (sStatus) {
			switch (sStatus) {
			case "E":
				return 'Error';
			case "W":
				return 'Warning';
			case "I":
				return 'Information';
			default:
				return 'Error';
			}
		},
		getSowText: function (sStatus) {
			var getData = this.getView().getModel("oSowAppView");
			var json = getData.filter(function (a) {
				return a.Jobsubcat === keyID;
			});
			return json.Jobsubcattext;
		},
		twoDecimalValue: function (sValue) {
			var oValue;
			if (sValue === null) {
				oValue = "";
			} else {
				var num = parseFloat(sValue);;
				oValue = num.toFixed(2);
			}
			return oValue;
		},
		dateFormat: function (sValue) {
			var str;
			if (sValue === null) {
				str = "";
			} else {
				str = sValue.substring(0, sValue.length - 1);
				str = str.substring(1);

				str = str.replace(/\D/g, "");
				var dt = new Date(eval(str));
				var oDateFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					format: "yMMMd"
				});
				str = oDateFormat.format(dt);
			}
			//sValue = sValue.replace("/", "");
			return str;

		},
		dateFormatUTC: function (sValue) {
		
		if (sValue !== null) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MM/dd/YYYY"
				//	UTC: true
				});

				return oDateFormat.format(new Date(sValue));
			}
		/*
			var str;
			if (sValue === null) {
				str = "";
			} else {
				str = sValue.substring(0, sValue.length - 1);
				str = str.substring(1);

				str = str.replace(/\D/g, "");
				var dt = new Date(eval(str));
				var oDateFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					format: "yMMMd"
				});
				str = oDateFormat.format(dt);
				var datatoday = new Date(str);
				var n = datatoday.getTimezoneOffset() / 60;
				if (Math.sign(n) === 1) {

					var datatoday = new Date(str);
					var datatodays = datatoday.setDate(new Date(datatoday).getDate() + 1);
					var	todate = new Date(datatodays);

					str = oDateFormat.format(todate);
				} else {
					str = oDateFormat.format(dt);
				}
			}
			//sValue = sValue.replace("/", "");
			return str;

		*/},
		timeFormatpdf: function (sValue) {
			var ms = sValue.ms;
			var seconds = ms / 1000;
			// 2- Extract hours:
			var hours = parseInt(seconds / 3600); // 3,600 seconds in 1 hour
			seconds = seconds % 3600; // seconds remaining after extracting hours
			// 3- Extract minutes:
			var minutes = parseInt(seconds / 60); // 60 seconds in 1 minute
			// 4- Keep only seconds not extracted to minutes:
			seconds = seconds % 60;
			return hours + ":" + minutes + ":" + seconds;
		},
		dateFormatpdf: function (sValue) {
			var oDateFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				format: "yMMMd"
			});
			var str = oDateFormat.format(sValue);
			return str;
		}
	};
});